import * as i0 from "@angular/core";
/**
 * satHeaderTitle is deprecated, use satAppHeaderTitle instead.
 */
export declare class AppHeaderTitleDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderTitleDirective, "[satHeaderTitle], [satAppHeaderTitle]", ["satAppHeaderTitle"], {}, {}, never, never, true, never>;
}
