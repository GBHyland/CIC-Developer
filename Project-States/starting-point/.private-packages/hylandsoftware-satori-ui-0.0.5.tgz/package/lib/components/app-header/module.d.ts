import * as i0 from "@angular/core";
import * as i1 from "./app-header.component";
import * as i2 from "./app-header-title.directive";
import * as i3 from "./app-header-actions.directive";
import * as i4 from "./app-header-logo.directive";
import * as i5 from "./app-header-navigation.directive";
export declare class SatAppHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAppHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatAppHeaderModule, never, [typeof i1.HeaderComponent, typeof i1.AppHeaderComponent, typeof i2.AppHeaderTitleDirective, typeof i3.AppHeaderActionsDirective, typeof i4.AppHeaderLogoDirective, typeof i5.AppHeaderNavigationDirective], [typeof i1.HeaderComponent, typeof i1.AppHeaderComponent, typeof i2.AppHeaderTitleDirective, typeof i3.AppHeaderActionsDirective, typeof i4.AppHeaderLogoDirective, typeof i5.AppHeaderNavigationDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatAppHeaderModule>;
}
