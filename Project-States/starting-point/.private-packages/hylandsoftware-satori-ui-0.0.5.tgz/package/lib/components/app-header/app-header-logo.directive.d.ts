import * as i0 from "@angular/core";
/**
 * satHeaderLogo is deprecated, use satAppHeaderLogo instead.
 */
export declare class AppHeaderLogoDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderLogoDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderLogoDirective, "[satHeaderLogo], [satAppHeaderLogo]", ["satAppHeaderLogo"], {}, {}, never, never, true, never>;
}
