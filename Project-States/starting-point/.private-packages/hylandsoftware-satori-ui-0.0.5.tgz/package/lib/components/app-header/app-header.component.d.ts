import * as i0 from "@angular/core";
/**
 * @deprecated Use `sat-app-header` instead.
 */
export declare class HeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "sat-header", never, {}, {}, never, ["[satAppHeaderTitle], [satHeaderTitle]", "[satAppHeaderLogo], [satHeaderLogo]", "[satAppHeaderActions], [satHeaderActions]", "[satAppHeaderNavigation], [satHeaderNavigation]"], true, never>;
}
export declare class AppHeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppHeaderComponent, "sat-app-header", never, {}, {}, never, ["[satAppHeaderTitle], [satHeaderTitle]", "[satAppHeaderLogo], [satHeaderLogo]", "[satAppHeaderActions], [satHeaderActions]", "[satAppHeaderNavigation], [satHeaderNavigation]"], true, never>;
}
