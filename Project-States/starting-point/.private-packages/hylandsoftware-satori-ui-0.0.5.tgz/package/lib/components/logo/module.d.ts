import * as i0 from "@angular/core";
import * as i1 from "./logo.component";
import * as i2 from "./h-mark-logo/h-mark-logo.component";
import * as i3 from "./word-mark-logo/word-mark-logo.component";
export declare class SatLogoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatLogoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatLogoModule, never, [typeof i1.SatLogoComponent, typeof i2.SatHMarkLogoComponent, typeof i3.SatWordMarkLogoComponent], [typeof i1.SatLogoComponent, typeof i2.SatHMarkLogoComponent, typeof i3.SatWordMarkLogoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatLogoModule>;
}
