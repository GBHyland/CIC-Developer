import * as i0 from "@angular/core";
export declare class SatHMarkLogoComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatHMarkLogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatHMarkLogoComponent, "sat-h-mark-logo", never, {}, {}, never, never, true, never>;
}
