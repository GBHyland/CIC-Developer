import { SatLogoDirection } from './direction-type';
import * as i0 from "@angular/core";
export declare class SatLogoComponent {
    readonly direction: import("@angular/core").InputSignal<SatLogoDirection>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatLogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatLogoComponent, "sat-logo", never, { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; }, {}, never, ["sat-h-mark-logo", "sat-word-mark-logo"], true, never>;
}
