export type SatLogoDirection = 'horizontal' | 'vertical';
