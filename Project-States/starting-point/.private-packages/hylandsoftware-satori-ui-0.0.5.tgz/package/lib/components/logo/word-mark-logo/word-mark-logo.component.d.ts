import * as i0 from "@angular/core";
export declare class SatWordMarkLogoComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatWordMarkLogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatWordMarkLogoComponent, "sat-word-mark-logo", never, {}, {}, never, never, true, never>;
}
