import * as i0 from "@angular/core";
export declare class SatPlatformNavUserMenuDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatPlatformNavUserMenuDirective, "[satPlatformNavUserMenu]", ["satPlatformNavUserMenu"], {}, {}, never, never, true, never>;
}
