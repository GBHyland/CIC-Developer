import * as i0 from "@angular/core";
import * as i1 from "./platform-nav.component";
import * as i2 from "./components/platform-nav-container/platform-nav-container.component";
import * as i3 from "./components/platform-nav-main-content.component";
import * as i4 from "./components/platform-nav-list-item/platform-nav-list-item.component";
import * as i5 from "./components/platform-nav-user/platform-nav-user-profile.component";
import * as i6 from "./components/platform-nav-user/platform-nav-user.component";
import * as i7 from "./components/platform-nav-avatar/platform-nav-avatar.component";
import * as i8 from "./components/platform-nav-environment-switcher/platform-nav-environment-switcher.component";
import * as i9 from "./platform-nav-initials.pipe";
import * as i10 from "./components/platform-nav-user/platform-nav-user-menu.directive";
export declare class SatPlatformNavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatPlatformNavModule, never, [typeof i1.SatPlatformNavComponent, typeof i2.SatPlatformNavContainerComponent, typeof i3.SatPlatformNavMainContentComponent, typeof i4.SatPlatformNavListItemComponent, typeof i5.SatPlatformNavUserProfileComponent, typeof i6.SatPlatformNavUserComponent, typeof i7.SatPlatformNavAvatarComponent, typeof i8.SatPlatformNavEnvironmentSwitcherComponent, typeof i9.SatPlatformNavInitialsPipe, typeof i10.SatPlatformNavUserMenuDirective], [typeof i1.SatPlatformNavComponent, typeof i2.SatPlatformNavContainerComponent, typeof i3.SatPlatformNavMainContentComponent, typeof i4.SatPlatformNavListItemComponent, typeof i5.SatPlatformNavUserProfileComponent, typeof i6.SatPlatformNavUserComponent, typeof i7.SatPlatformNavAvatarComponent, typeof i8.SatPlatformNavEnvironmentSwitcherComponent, typeof i9.SatPlatformNavInitialsPipe, typeof i10.SatPlatformNavUserMenuDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatPlatformNavModule>;
}
