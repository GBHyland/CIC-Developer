interface SatBaseNavigationItem {
    label: string;
    path: string;
    active?: boolean;
}
interface SatNavigationItemWithIcon extends SatBaseNavigationItem {
    icon: string;
}
interface SatNavigationItemWithImage extends SatBaseNavigationItem {
    image: string;
}
export type SatNavigationItem = SatBaseNavigationItem | SatNavigationItemWithIcon | SatNavigationItemWithImage;
export {};
