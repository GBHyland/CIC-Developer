import * as i0 from "@angular/core";
export declare class SatPlatformNavStateService {
    private readonly _collapsed;
    /**
     * Whether the sidebar is currently collapsed.
     * You can use this in templates or components to update the UI.
     */
    readonly collapsed: import("@angular/core").Signal<boolean>;
    /**
     * Call this to toggle the sidebar between collapsed and expanded.
     */
    toggleCollapsed(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SatPlatformNavStateService>;
}
