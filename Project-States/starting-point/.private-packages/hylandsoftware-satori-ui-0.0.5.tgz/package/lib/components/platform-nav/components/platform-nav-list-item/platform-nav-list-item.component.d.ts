import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import { SatPlatformNavTooltipService } from '../../services/platform-nav-tooltip.service';
import * as i0 from "@angular/core";
export declare class SatPlatformNavListItemComponent {
    readonly active: import("@angular/core").InputSignal<boolean | undefined>;
    readonly labelText: import("@angular/core").WritableSignal<string | undefined>;
    readonly service: SatPlatformNavStateService;
    readonly tooltipService: SatPlatformNavTooltipService;
    private readonly tooltip;
    private readonly tooltipDelay;
    private tooltipTimer;
    onMouseEnter(): void;
    onMouseLeave(): void;
    labelChanged(event: MutationRecord[]): void;
    private hidePreviousTooltip;
    private showCurrentTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavListItemComponent, "sat-platform-nav-list-item", never, { "active": { "alias": "active"; "required": false; "isSignal": true; }; }, {}, never, ["mat-icon, sat-platform-nav-avatar", "*"], true, never>;
}
