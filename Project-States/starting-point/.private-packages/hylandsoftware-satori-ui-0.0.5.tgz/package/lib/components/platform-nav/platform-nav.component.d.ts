import { SatPlatformNavStateService } from './services/platform-nav-state.service';
import { SatPlatformNavTooltipService } from './services/platform-nav-tooltip.service';
import * as i0 from "@angular/core";
export declare class SatPlatformNavComponent {
    service: SatPlatformNavStateService;
    tooltipService: SatPlatformNavTooltipService;
    readonly neutralTheme: import("@angular/core").InputSignal<boolean>;
    /**
     * Clears the active tooltip on mouse leave.
     * Resets the tooltipShownFirst flag, hides and disables the current activated tooltip.
     */
    onMouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavComponent, "sat-platform-nav", never, { "neutralTheme": { "alias": "neutralTheme"; "required": false; "isSignal": true; }; }, {}, never, ["sat-platform-nav-switcher", "*", "sat-platform-nav-user"], true, never>;
}
