import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
export declare class SatPlatformNavContainerComponent {
    readonly service: SatPlatformNavStateService;
    closePlatformNav(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavContainerComponent, "sat-platform-nav-container", never, {}, {}, never, ["sat-platform-nav", "sat-platform-nav-main-content"], true, never>;
}
