import { SatPlatformNavEnvironmentType, SatPlatformNavStateService } from '../../public-api';
import * as i0 from "@angular/core";
export declare class SatPlatformNavEnvironmentSwitcherComponent {
    /**
     * The currently selected environment.
     * This should match the `value` property of one of the provided environment objects.
     */
    readonly value: import("@angular/core").InputSignal<string>;
    /**
     * @type SatPlatformNavEnvironmentType[]
     * The available environments.
     * This input is required and should be provided with an array of environment objects.
     * @required
     */
    readonly environments: import("@angular/core").InputSignal<SatPlatformNavEnvironmentType[]>;
    /**
     * Denotes whether the switcher is disabled.
     * @type boolean
     */
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * An event emitted when the environment is changed.
     * The value emitted is the currently selected environment.
     * @type SatPlatformNavEnvironmentType
     */
    readonly environmentChange: import("@angular/core").OutputEmitterRef<SatPlatformNavEnvironmentType>;
    readonly satPlatformNavStateService: SatPlatformNavStateService;
    private readonly initialSelection;
    private readonly userSelectedEnv;
    readonly selectedEnv: import("@angular/core").Signal<SatPlatformNavEnvironmentType | undefined>;
    onSelect(environment: SatPlatformNavEnvironmentType): void;
    private _propagateChanges;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavEnvironmentSwitcherComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavEnvironmentSwitcherComponent, "sat-platform-nav-switcher", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "environments": { "alias": "environments"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "environmentChange": "environmentChange"; }, never, never, true, never>;
}
