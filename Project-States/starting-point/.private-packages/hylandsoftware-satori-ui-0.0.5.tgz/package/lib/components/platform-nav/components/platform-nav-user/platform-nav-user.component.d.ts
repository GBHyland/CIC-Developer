import * as i0 from "@angular/core";
export declare class SatPlatformNavUserComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavUserComponent, "sat-platform-nav-user", never, {}, {}, never, ["sat-platform-nav-user-profile", "[satPlatformNavUserMenu]"], true, never>;
}
