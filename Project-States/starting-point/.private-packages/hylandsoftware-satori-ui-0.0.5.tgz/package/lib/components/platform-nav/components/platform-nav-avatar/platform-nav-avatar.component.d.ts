import * as i0 from "@angular/core";
export declare class SatPlatformNavAvatarComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavAvatarComponent, "sat-platform-nav-avatar", never, {}, {}, never, ["*"], true, never>;
}
