import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
export declare class SatPlatformNavUserProfileComponent {
    service: SatPlatformNavStateService;
    readonly profileNameText: import("@angular/core").WritableSignal<string | undefined>;
    profileNameChanged(event: MutationRecord[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavUserProfileComponent, "sat-platform-nav-user-profile", never, {}, {}, never, ["mat-icon, img", "*"], true, never>;
}
