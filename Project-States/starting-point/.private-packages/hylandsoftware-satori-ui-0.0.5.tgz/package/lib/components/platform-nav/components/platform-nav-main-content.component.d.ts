import * as i0 from "@angular/core";
export declare class SatPlatformNavMainContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavMainContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavMainContentComponent, "sat-platform-nav-main-content", never, {}, {}, never, ["*"], true, never>;
}
