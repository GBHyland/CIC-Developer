import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SatPlatformNavInitialsPipe implements PipeTransform {
    private readonly _maxWords;
    /**
     * Transforms a name string into initials by taking the first letter
     * of each word (up to the first two words).
     *
     * @param value The name to transform into initials
     * @param maxWords Optional parameter to specify maximum number of words to use (default: 2)
     * @returns The generated initials as uppercase letters
     */
    transform(value: string, maxWords?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavInitialsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SatPlatformNavInitialsPipe, "satPlatformNavInitials", true>;
}
