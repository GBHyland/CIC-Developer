export interface SatPlatformNavEnvironmentType {
    value: string;
    label: string;
    disabled?: boolean;
}
