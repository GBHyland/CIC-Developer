import * as i0 from "@angular/core";
export declare class SatSkipToContentComponent {
    visible: boolean;
    display(): void;
    hide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatSkipToContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatSkipToContentComponent, "sat-skip-to-content", never, {}, {}, never, never, true, never>;
}
