import { ElementRef, OnDestroy, TemplateRef } from '@angular/core';
import { RichTooltipBehavior, RichTooltipPositionX, RichTooltipPositionY, RichTooltipScrollStrategy } from './rich-tooltip-types';
import * as i0 from "@angular/core";
export declare class SatRichTooltipComponent implements OnDestroy {
    /** Settings for richTooltip, view setters and getters for more detail */
    private _positionX;
    private _positionY;
    private _behavior;
    private _scrollStrategy;
    private _showDelay;
    private _hideDelay;
    private _overlapTrigger;
    private _disableAnimation;
    private _targetOffsetX;
    private _targetOffsetY;
    private _closeOnClick;
    private _focusTrapEnabled;
    private _focusTrapAutoCaptureEnabled;
    private _uniqueId;
    _titleUniqueId: string;
    _contentUniqueId: string;
    /** Config object to be passed into the richTooltip's ngClass */
    classList: {
        [key: string]: boolean;
    };
    /** Closing disabled on richTooltip */
    closeDisabled: boolean;
    /** unique id for the rich tooltip panel. */
    readonly id: import("@angular/core").InputSignal<string>;
    /** aria-label for the rich tooltip panel. */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    /** aria-labelledby for the rich tooltip panel. This needs to be same with the id for the title element */
    readonly ariaLabelledby: import("@angular/core").InputSignal<string>;
    /** aria-describedby for the rich tooltip panel. This needs to be same with the id for the content */
    readonly ariaDescribedby: import("@angular/core").InputSignal<string>;
    /**
     * Position of the richTooltip in the X axis.
     * @default after
     */
    readonly positionX: import("@angular/core").InputSignalWithTransform<RichTooltipPositionX, RichTooltipPositionX>;
    /**
     * Position of the richTooltip in the Y axis.
     * @default below
     */
    readonly positionY: import("@angular/core").InputSignalWithTransform<RichTooltipPositionY, RichTooltipPositionY>;
    /**
     * RichTooltip behavior type
     * @default transient
     */
    readonly behavior: import("@angular/core").InputSignal<RichTooltipBehavior>;
    /**
     * RichTooltip scroll strategy
     * @default reposition
     */
    readonly scrollStrategy: import("@angular/core").InputSignal<RichTooltipScrollStrategy>;
    /**
     * RichTooltip enter delay
     * @default 200
     */
    readonly showDelay: import("@angular/core").InputSignal<number>;
    /**
     * RichTooltip leave delay
     * @default 1.5 seconds
     */
    readonly hideDelay: import("@angular/core").InputSignal<number>;
    /**
     * RichTooltip overlap trigger
     * @default false
     */
    readonly overlapTrigger: import("@angular/core").InputSignal<boolean>;
    /**
     * RichTooltip horizontal target offset
     * @default 0
     */
    readonly targetOffsetX: import("@angular/core").InputSignal<number>;
    /** RichTooltip vertical target offset
     * @default 20
     */
    readonly targetOffsetY: import("@angular/core").InputSignal<number>;
    /**
     * RichTooltip container close on click
     * @default false
     */
    readonly closeOnClick: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    /**
     * Disable animations of richTooltip and all child elements
     * @default false
     */
    readonly disableAnimation: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    /**
     * Rich Tooltip focus trap using cdkTrapFocus
     * @default true
     */
    readonly focusTrapEnabled: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    /**
     * Rich Tooltip focus trap auto capture using cdkTrapFocusAutoCapture
     * @default true
     */
    readonly focusTrapAutoCaptureEnabled: import("@angular/core").InputSignalWithTransform<boolean, string | boolean>;
    /**
     * Event emitted when the richTooltip is closed.
     */
    readonly close: import("@angular/core").OutputEmitterRef<void>;
    readonly templateRef: import("@angular/core").Signal<TemplateRef<ElementRef<any>> | undefined>;
    readonly monitoredEl: import("@angular/core").Signal<ElementRef<HTMLElement> | undefined>;
    constructor();
    /** Handle a keyboard event from the richTooltip, delegating to the appropriate action. */
    handleKeydown(event: KeyboardEvent): void;
    /**
     * This emits a close event to which the trigger is subscribed. When emitted, the
     * trigger will close the richTooltip.
     */
    emitCloseEvent(): void;
    /** Close richTooltip on click if closeOnClick is true */
    onClick(): void;
    /** Disables close of richTooltip when leaving trigger element and focus on the richTooltip either by keyboard or by mouse */
    onFocus(): void;
    /** Enables close of richTooltip when mouse leaving richTooltip element or the tooltip is loosing focus */
    onFocusOut(): void;
    /**
     * It's necessary to set position-based classes to ensure the richTooltip panel animation
     * folds out from the correct direction.
     */
    setPositionClasses(posX?: RichTooltipPositionX, posY?: RichTooltipPositionY): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipComponent, "sat-rich-tooltip", ["satRichTooltip"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "positionX": { "alias": "positionX"; "required": false; "isSignal": true; }; "positionY": { "alias": "positionY"; "required": false; "isSignal": true; }; "behavior": { "alias": "behavior"; "required": false; "isSignal": true; }; "scrollStrategy": { "alias": "scrollStrategy"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; "overlapTrigger": { "alias": "overlapTrigger"; "required": false; "isSignal": true; }; "targetOffsetX": { "alias": "targetOffsetX"; "required": false; "isSignal": true; }; "targetOffsetY": { "alias": "targetOffsetY"; "required": false; "isSignal": true; }; "closeOnClick": { "alias": "closeOnClick"; "required": false; "isSignal": true; }; "disableAnimation": { "alias": "disableAnimation"; "required": false; "isSignal": true; }; "focusTrapEnabled": { "alias": "focusTrapEnabled"; "required": false; "isSignal": true; }; "focusTrapAutoCaptureEnabled": { "alias": "focusTrapAutoCaptureEnabled"; "required": false; "isSignal": true; }; }, { "close": "close"; }, never, ["sat-rich-tooltip-title", "sat-rich-tooltip-content", "sat-rich-tooltip-actions"], true, never>;
}
