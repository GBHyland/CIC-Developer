import * as i0 from "@angular/core";
export declare class SatRichTooltipCloseDirective {
    private readonly tooltip;
    onClose(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipCloseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatRichTooltipCloseDirective, "[sat-rich-tooltip-close], [satRichTooltipClose]", ["satRichTooltipClose"], {}, {}, never, never, true, never>;
}
