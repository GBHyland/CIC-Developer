import * as i0 from "@angular/core";
export declare class SatRichTooltipTitleComponent {
    private readonly elementRef;
    private readonly tooltip;
    /** aria-label for the rich tooltip title. */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    get getAriaLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipTitleComponent, "sat-rich-tooltip-title", never, { "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
