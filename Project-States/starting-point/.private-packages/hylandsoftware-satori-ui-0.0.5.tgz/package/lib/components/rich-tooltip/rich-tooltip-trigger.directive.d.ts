import { AfterViewInit, OnDestroy } from '@angular/core';
import { SatRichTooltipComponent } from './rich-tooltip.component';
import * as i0 from "@angular/core";
export declare class SatRichTooltipTriggerDirective implements AfterViewInit, OnDestroy {
    private readonly elementRef;
    private readonly viewContainerRef;
    private readonly richTooltipOverlayService;
    private readonly richTooltipPositionService;
    private readonly changeDetectorRef;
    private richTooltipOpen;
    private richTooltipOpened;
    private richTooltipClosed;
    private portal?;
    private overlayRef;
    private halt;
    private backdropSubscription?;
    private positionSubscription?;
    private detachmentsSubscription?;
    private mouseoverTimer?;
    private openedByMouse;
    private _ariaDescriptionPending;
    /** References the richTooltip instance that the trigger is associated with. */
    readonly tooltip: import("@angular/core").InputSignal<SatRichTooltipComponent>;
    /** RichTooltip won't open on trigger */
    readonly satRichTooltipDisabled: import("@angular/core").InputSignal<boolean>;
    /** RichTooltip backdrop close on click */
    readonly satRichTooltipBackdropCloseOnClick: import("@angular/core").InputSignal<boolean>;
    /** Event emitted when the associated richTooltip is opened. */
    tooltipOpened: import("@angular/core").OutputEmitterRef<void>;
    /** Event emitted when the associated richTooltip is closed. */
    tooltipClosed: import("@angular/core").OutputEmitterRef<void>;
    ngAfterViewInit(): void;
    onClick(event: MouseEvent): void;
    onMouseEnter(event: MouseEvent): void;
    onFocus(event: KeyboardEvent): void;
    onMouseLeave(event: MouseEvent): void;
    checkTooltipToOpen(openedByMouse?: boolean): void;
    handleMousedown(event: MouseEvent): void;
    /** Toggles the richTooltip between the open and closed states. */
    toggleRichTooltip(): void;
    /** Opens the richTooltip. */
    openRichTooltip(): void;
    /** Closes the richTooltip. */
    closeRichTooltip(): void;
    /** Removes the richTooltip from the DOM. */
    destroyRichTooltip(): void;
    /** Updates the tooltip's ARIA description based on rich tooltip id. */
    private _syncAriaDescription;
    /** Focuses the richTooltip trigger. */
    private focus;
    /**
     * This method ensures that the richTooltip closes when the overlay backdrop is clicked.
     * We do not use first() here because doing so would not catch clicks from within
     * the richTooltip, and it would fail to unsubscribe properly. Instead, we unsubscribe
     * explicitly when the richTooltip is closed or destroyed.
     */
    private subscribeToBackdrop;
    private subscribeToDetachments;
    /**
     * This method sets the richTooltip state to open and focuses the first item if
     * the richTooltip was opened via the keyboard.
     */
    private initRichTooltip;
    /**
     * This method resets the richTooltip when it's closed, most importantly restoring
     * focus to the richTooltip trigger if the richTooltip was opened via the keyboard.
     */
    private resetRichTooltip;
    /** set state rather than toggle to support triggers sharing a richTooltip */
    private setRichTooltipOpened;
    /** set state rather than toggle to support triggers sharing a richTooltip */
    private setRichTooltipClosed;
    /**
     *  This method checks that a valid instance of MdRichTooltip has been passed into
     *  satRichTooltipTriggerFor. If not, an exception is thrown.
     */
    private checkRichTooltip;
    private cleanUpSubscriptions;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatRichTooltipTriggerDirective, "[satRichTooltipTriggerFor]", ["satRichTooltipTrigger"], { "tooltip": { "alias": "satRichTooltipTriggerFor"; "required": true; "isSignal": true; }; "satRichTooltipDisabled": { "alias": "satRichTooltipDisabled"; "required": false; "isSignal": true; }; "satRichTooltipBackdropCloseOnClick": { "alias": "satRichTooltipBackdropCloseOnClick"; "required": false; "isSignal": true; }; }, { "tooltipOpened": "tooltipOpened"; "tooltipClosed": "tooltipClosed"; }, never, never, true, never>;
}
