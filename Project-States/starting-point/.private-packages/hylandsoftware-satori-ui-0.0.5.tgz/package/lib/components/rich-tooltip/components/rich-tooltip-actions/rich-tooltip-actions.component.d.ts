import { RichTooltipActionAlignment, RichTooltipBehavior } from '../../rich-tooltip-types';
import * as i0 from "@angular/core";
export declare class SatRichTooltipActionsComponent {
    private readonly tooltip;
    /**
     * Alignment of the actions
     * @default
     * 'start'
     */
    readonly align: import("@angular/core").InputSignal<RichTooltipActionAlignment>;
    /**
     * Whether the close feature should be required
     * @default
     * false
     */
    readonly requireCloseFeature: import("@angular/core").InputSignal<boolean>;
    get tooltipBehaviour(): RichTooltipBehavior;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipActionsComponent, "sat-rich-tooltip-actions", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "requireCloseFeature": { "alias": "requireCloseFeature"; "required": false; "isSignal": true; }; }, {}, never, ["[button, a]"], true, never>;
}
