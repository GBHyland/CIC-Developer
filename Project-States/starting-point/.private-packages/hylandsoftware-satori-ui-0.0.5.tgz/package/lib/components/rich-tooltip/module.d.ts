import * as i0 from "@angular/core";
import * as i1 from "./rich-tooltip.component";
import * as i2 from "./rich-tooltip-trigger.directive";
import * as i3 from "./components/rich-tooltip-title.component";
import * as i4 from "./components/rich-tooltip-content.component";
import * as i5 from "./components/rich-tooltip-actions/rich-tooltip-actions.component";
import * as i6 from "./rich-tooltip-close.directive";
export declare class SatRichTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatRichTooltipModule, never, [typeof i1.SatRichTooltipComponent, typeof i2.SatRichTooltipTriggerDirective, typeof i3.SatRichTooltipTitleComponent, typeof i4.SatRichTooltipContentComponent, typeof i5.SatRichTooltipActionsComponent, typeof i6.SatRichTooltipCloseDirective], [typeof i1.SatRichTooltipComponent, typeof i2.SatRichTooltipTriggerDirective, typeof i3.SatRichTooltipTitleComponent, typeof i4.SatRichTooltipContentComponent, typeof i5.SatRichTooltipActionsComponent, typeof i6.SatRichTooltipCloseDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatRichTooltipModule>;
}
