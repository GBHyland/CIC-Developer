import { FlexibleConnectedPositionStrategy } from '@angular/cdk/overlay';
import { ElementRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { SatRichTooltipComponent } from '../rich-tooltip.component';
import * as i0 from "@angular/core";
export declare class RichTooltipPositionService {
    private readonly overlay;
    private readonly _ngZone;
    /**
     * This method builds the position strategy for the overlay, so the richTooltip is properly connected
     * to the trigger.
     * @returns ConnectedPositionStrategy
     */
    getPosition(tooltip: SatRichTooltipComponent, elementRef: ElementRef): FlexibleConnectedPositionStrategy;
    /**
     * Listens to changes in the position of the overlay and sets the correct classes
     * on the richTooltip based on the new position. This ensures the animation origin is always
     * correct, even if a fallback position is used for the overlay.
     */
    subscribeToPositions(tooltip: SatRichTooltipComponent, position: FlexibleConnectedPositionStrategy): Subscription;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTooltipPositionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RichTooltipPositionService>;
}
