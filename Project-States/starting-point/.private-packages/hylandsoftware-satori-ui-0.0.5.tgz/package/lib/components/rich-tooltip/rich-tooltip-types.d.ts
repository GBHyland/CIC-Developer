export type RichTooltipPositionX = 'before' | 'after';
export type RichTooltipPositionY = 'above' | 'below';
export type RichTooltipScrollStrategy = 'noop' | 'close' | 'block' | 'reposition';
export type RichTooltipBehavior = 'transient' | 'persistent';
export type RichTooltipActionAlignment = 'start' | 'center' | 'end';
