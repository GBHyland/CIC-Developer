/**
 * Throws an exception for the case when tooltip's x-position value isn't valid.
 * In other words, it doesn't match 'before' or 'after'.
 * @docs-private
 */
export declare function throwRichTooltipInvalidPositionX(): void;
/**
 * Throws an exception for the case when tooltip's y-position value isn't valid.
 * In other words, it doesn't match 'above' or 'below'.
 * @docs-private
 */
export declare function throwRichTooltipInvalidPositionY(): void;
/**
 * Throws an exception for the case when the trigger doesn't have a valid rich tooltip instance.
 * @docs-private
 */
export declare function throwRichTooltipMissingError(): void;
