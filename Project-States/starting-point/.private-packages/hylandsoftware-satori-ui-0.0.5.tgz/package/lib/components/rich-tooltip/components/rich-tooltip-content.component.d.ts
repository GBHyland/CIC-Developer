import * as i0 from "@angular/core";
export declare class SatRichTooltipContentComponent {
    private readonly elementRef;
    private readonly tooltip;
    /** aria-label for the rich tooltip content. */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    get getAriaLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipContentComponent, "sat-rich-tooltip-content", never, { "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
