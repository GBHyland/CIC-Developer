import { Direction } from '@angular/cdk/bidi';
import { OverlayConfig, OverlayRef, ScrollStrategy } from '@angular/cdk/overlay';
import { RichTooltipScrollStrategy } from '../rich-tooltip-types';
import { SatRichTooltipComponent } from '../rich-tooltip.component';
import * as i0 from "@angular/core";
export declare class RichTooltipOverlayService {
    private readonly overlay;
    private readonly directionality;
    /**
     *  This method creates the overlay from the provided richTooltip's template and saves its
     *  OverlayRef so that it can be attached to the DOM when openRichTooltip is called.
     */
    createOverlay(tooltip: SatRichTooltipComponent): OverlayRef;
    /** The text direction of the containing app. */
    get dir(): Direction;
    /**
     * This method builds the configuration object needed to create the overlay, the OverlayConfig.
     * @returns OverlayConfig
     */
    getOverlayConfig(tooltip: SatRichTooltipComponent): OverlayConfig;
    /**
     * This method returns the scroll strategy used by the cdk/overlay.
     */
    getOverlayScrollStrategy(strategy: RichTooltipScrollStrategy): ScrollStrategy;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTooltipOverlayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RichTooltipOverlayService>;
}
