import * as i0 from "@angular/core";
export declare class SatIconModule {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SatIconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatIconModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatIconModule>;
}
