import { EnvironmentProviders } from '@angular/core';
export interface LanguageConfig {
    default: string;
}
/**
 * Default providers for the Satori UI library.
 *
 * This function return providers for configuration of Angular Material components,
 * setting some default options related to Satori UI theme and appearance.
 */
export declare function provideSatoriTheme(): EnvironmentProviders;
/**
 * Provides the default translation feature for the Satori UI library.
 * This sets up the translation loader to fetch translation files from the `./i18n/` directory
 * @param languageConfig Configuration for the default language of the application.
 */
export declare function provideSatoriUITranslations(languageConfig: LanguageConfig): EnvironmentProviders;
