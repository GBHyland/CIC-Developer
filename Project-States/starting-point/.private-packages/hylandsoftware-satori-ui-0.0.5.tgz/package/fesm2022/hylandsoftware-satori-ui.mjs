import * as i0 from '@angular/core';
import { Component, ViewEncapsulation, Directive, NgModule, ChangeDetectionStrategy, input, signal, computed, Injectable, inject, booleanAttribute, ElementRef, EventEmitter, Output, output, Pipe, viewChild, HostListener, TemplateRef, NgZone, ViewContainerRef, ChangeDetectorRef, makeEnvironmentProviders } from '@angular/core';
import * as i1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2 from '@angular/cdk/menu';
import { CdkMenuModule } from '@angular/cdk/menu';
import * as i1$1 from '@angular/material/core';
import { MatRippleModule, MatPseudoCheckboxModule, MatRipple } from '@angular/material/core';
import * as i1$2 from '@angular/material/icon';
import { MatIconRegistry, MatIconModule } from '@angular/material/icon';
import * as i1$3 from '@angular/material/tooltip';
import { MatTooltip, MatTooltipModule } from '@angular/material/tooltip';
import { TranslatePipe, provideTranslateService, TranslateLoader } from '@ngx-translate/core';
import { DomSanitizer } from '@angular/platform-browser';
import { SATORI_ICONS } from '@hylandsoftware/satori-icons';
export { SATORI_ICONS } from '@hylandsoftware/satori-icons';
import { hasModifierKey, ESCAPE } from '@angular/cdk/keycodes';
import * as i2$1 from '@angular/cdk/observers';
import { ObserversModule } from '@angular/cdk/observers';
import { CdkTrapFocus, isFakeMousedownFromScreenReader } from '@angular/cdk/a11y';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i1$4 from '@angular/common';
import { CommonModule } from '@angular/common';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { TemplatePortal } from '@angular/cdk/portal';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Directionality } from '@angular/cdk/bidi';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { provideHttpClient, HttpClient } from '@angular/common/http';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { provideAnimations } from '@angular/platform-browser/animations';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

/**
 * @deprecated Use `sat-app-header` instead.
 */
class HeaderComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: HeaderComponent, isStandalone: true, selector: "sat-header", ngImport: i0, template: "<header>\n  <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n  <div class=\"sat-app-header-logo-actions\">\n    <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n    <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n  </div>\n</header>\n<ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--sys-outline-variant, #c8c5d3)}sat-header header,sat-app-header header{display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;flex-wrap:nowrap;gap:1rem;height:var(--sat-app-header-title-height, 4rem)}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--sat-app-header-title-font, 400 1.5rem/2rem Figtree, Noto Sans, sans-serif);font-size:var(--sat-app-header-title-size, 1.5rem);line-height:var(--sat-app-header-title-line-height, 2rem);letter-spacing:var(--sat-app-header-title-letter-spacing, 0);font-weight:var(--sat-app-header-title-weight, 400);color:var(--sat-app-header-title-color, var(--sys-on-surface-variant, #414752));margin:0}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px))}sat-header .sat-app-header-logo-actions,sat-app-header .sat-app-header-logo-actions{display:flex;align-items:center;gap:.5rem}\n"], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-header', standalone: true, encapsulation: ViewEncapsulation.None, template: "<header>\n  <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n  <div class=\"sat-app-header-logo-actions\">\n    <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n    <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n  </div>\n</header>\n<ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--sys-outline-variant, #c8c5d3)}sat-header header,sat-app-header header{display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;flex-wrap:nowrap;gap:1rem;height:var(--sat-app-header-title-height, 4rem)}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--sat-app-header-title-font, 400 1.5rem/2rem Figtree, Noto Sans, sans-serif);font-size:var(--sat-app-header-title-size, 1.5rem);line-height:var(--sat-app-header-title-line-height, 2rem);letter-spacing:var(--sat-app-header-title-letter-spacing, 0);font-weight:var(--sat-app-header-title-weight, 400);color:var(--sat-app-header-title-color, var(--sys-on-surface-variant, #414752));margin:0}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px))}sat-header .sat-app-header-logo-actions,sat-app-header .sat-app-header-logo-actions{display:flex;align-items:center;gap:.5rem}\n"] }]
        }] });
class AppHeaderComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: AppHeaderComponent, isStandalone: true, selector: "sat-app-header", ngImport: i0, template: "<header>\n  <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n  <div class=\"sat-app-header-logo-actions\">\n    <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n    <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n  </div>\n</header>\n<ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--sys-outline-variant, #c8c5d3)}sat-header header,sat-app-header header{display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;flex-wrap:nowrap;gap:1rem;height:var(--sat-app-header-title-height, 4rem)}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--sat-app-header-title-font, 400 1.5rem/2rem Figtree, Noto Sans, sans-serif);font-size:var(--sat-app-header-title-size, 1.5rem);line-height:var(--sat-app-header-title-line-height, 2rem);letter-spacing:var(--sat-app-header-title-letter-spacing, 0);font-weight:var(--sat-app-header-title-weight, 400);color:var(--sat-app-header-title-color, var(--sys-on-surface-variant, #414752));margin:0}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px))}sat-header .sat-app-header-logo-actions,sat-app-header .sat-app-header-logo-actions{display:flex;align-items:center;gap:.5rem}\n"], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-app-header', standalone: true, encapsulation: ViewEncapsulation.None, template: "<header>\n  <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n  <div class=\"sat-app-header-logo-actions\">\n    <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n    <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n  </div>\n</header>\n<ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--sys-outline-variant, #c8c5d3)}sat-header header,sat-app-header header{display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;flex-wrap:nowrap;gap:1rem;height:var(--sat-app-header-title-height, 4rem)}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--sat-app-header-title-font, 400 1.5rem/2rem Figtree, Noto Sans, sans-serif);font-size:var(--sat-app-header-title-size, 1.5rem);line-height:var(--sat-app-header-title-line-height, 2rem);letter-spacing:var(--sat-app-header-title-letter-spacing, 0);font-weight:var(--sat-app-header-title-weight, 400);color:var(--sat-app-header-title-color, var(--sys-on-surface-variant, #414752));margin:0}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px))}sat-header .sat-app-header-logo-actions,sat-app-header .sat-app-header-logo-actions{display:flex;align-items:center;gap:.5rem}\n"] }]
        }] });

/**
 * satHeaderTitle is deprecated, use satAppHeaderTitle instead.
 */
class AppHeaderTitleDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: AppHeaderTitleDirective, isStandalone: true, selector: "[satHeaderTitle], [satAppHeaderTitle]", host: { classAttribute: "sat-app-header-title" }, exportAs: ["satAppHeaderTitle"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderTitle], [satAppHeaderTitle]',
                    standalone: true,
                    exportAs: 'satAppHeaderTitle',
                    host: {
                        class: 'sat-app-header-title',
                    },
                }]
        }] });

/**
 * satHeaderActions is deprecated, use satAppHeaderActions instead.
 */
class AppHeaderActionsDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderActionsDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: AppHeaderActionsDirective, isStandalone: true, selector: "[satHeaderActions], [satAppHeaderActions]", host: { classAttribute: "sat-app-header-actions" }, exportAs: ["satAppHeaderActions"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderActionsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderActions], [satAppHeaderActions]',
                    standalone: true,
                    exportAs: 'satAppHeaderActions',
                    host: {
                        class: 'sat-app-header-actions',
                    },
                }]
        }] });

/**
 * satHeaderLogo is deprecated, use satAppHeaderLogo instead.
 */
class AppHeaderLogoDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderLogoDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: AppHeaderLogoDirective, isStandalone: true, selector: "[satHeaderLogo], [satAppHeaderLogo]", host: { classAttribute: "sat-app-header-logo" }, exportAs: ["satAppHeaderLogo"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderLogoDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderLogo], [satAppHeaderLogo]',
                    standalone: true,
                    exportAs: 'satAppHeaderLogo',
                    host: {
                        class: 'sat-app-header-logo',
                    },
                }]
        }] });

/**
 * satHeaderNavigation is deprecated, use satAppHeaderNavigation instead.
 */
class AppHeaderNavigationDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderNavigationDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: AppHeaderNavigationDirective, isStandalone: true, selector: "[satHeaderNavigation], [satAppHeaderNavigation]", host: { classAttribute: "sat-app-header-navigation" }, exportAs: ["satAppHeaderNavigation"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: AppHeaderNavigationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderNavigation], [satAppHeaderNavigation]',
                    standalone: true,
                    exportAs: 'satAppHeaderNavigation',
                    host: {
                        class: 'sat-app-header-navigation',
                    },
                }]
        }] });

const headerArtifacts = [
    HeaderComponent,
    AppHeaderComponent,
    AppHeaderTitleDirective,
    AppHeaderActionsDirective,
    AppHeaderLogoDirective,
    AppHeaderNavigationDirective,
];
class SatAppHeaderModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatAppHeaderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: SatAppHeaderModule, imports: [HeaderComponent,
            AppHeaderComponent,
            AppHeaderTitleDirective,
            AppHeaderActionsDirective,
            AppHeaderLogoDirective,
            AppHeaderNavigationDirective], exports: [HeaderComponent,
            AppHeaderComponent,
            AppHeaderTitleDirective,
            AppHeaderActionsDirective,
            AppHeaderLogoDirective,
            AppHeaderNavigationDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatAppHeaderModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatAppHeaderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: headerArtifacts,
                    exports: headerArtifacts,
                }]
        }] });

class SatHMarkLogoComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatHMarkLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SatHMarkLogoComponent, isStandalone: true, selector: "sat-h-mark-logo", ngImport: i0, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 56 30\" fill=\"none\">\n  <path d=\"M26.6593 -0.0090332L18.2177 14.9941H27.9944L36.4359 -0.0090332H26.6593Z\" fill=\"#6E33FF\"/>\n  <path d=\"M8.44107 14.9969L0 30H9.77667L18.2177 14.9969H8.44107Z\" fill=\"#F1CB61\"/>\n  <path d=\"M28.0037 15.005L19.5627 30.0085H29.3393L37.7804 15.005H28.0037Z\" fill=\"#52A1FF\"/>\n  <path d=\"M46.2224 -2.00626e-05L37.7804 15.005H47.558L56 -2.00626e-05H46.2224Z\" fill=\"#13EAC1\"/>\n</svg>\n", styles: ["sat-h-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/632.78}sat-h-mark-logo svg{width:100%;height:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatHMarkLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-h-mark-logo', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 56 30\" fill=\"none\">\n  <path d=\"M26.6593 -0.0090332L18.2177 14.9941H27.9944L36.4359 -0.0090332H26.6593Z\" fill=\"#6E33FF\"/>\n  <path d=\"M8.44107 14.9969L0 30H9.77667L18.2177 14.9969H8.44107Z\" fill=\"#F1CB61\"/>\n  <path d=\"M28.0037 15.005L19.5627 30.0085H29.3393L37.7804 15.005H28.0037Z\" fill=\"#52A1FF\"/>\n  <path d=\"M46.2224 -2.00626e-05L37.7804 15.005H47.558L56 -2.00626e-05H46.2224Z\" fill=\"#13EAC1\"/>\n</svg>\n", styles: ["sat-h-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/632.78}sat-h-mark-logo svg{width:100%;height:100%}\n"] }]
        }] });

class SatLogoComponent {
    direction = input('horizontal');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "18.2.13", type: SatLogoComponent, isStandalone: true, selector: "sat-logo", inputs: { direction: { classPropertyName: "direction", publicName: "direction", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.sat-logo-horizontal": "direction() === 'horizontal'", "class.sat-logo-vertical": "direction() === 'vertical'" } }, ngImport: i0, template: `
    <ng-content select="sat-h-mark-logo"></ng-content>
    <ng-content select="sat-word-mark-logo"></ng-content>
  `, isInline: true, styles: ["sat-logo{display:flex;align-items:center;justify-content:space-between;overflow:hidden}.sat-logo-horizontal{flex-direction:row;aspect-ratio:1200/248.44}.sat-logo-horizontal sat-h-mark-logo{width:39.2616666667%}.sat-logo-horizontal sat-word-mark-logo{width:58.6808333333%}.sat-logo-vertical{flex-direction:column;aspect-ratio:1200/536.06}.sat-logo-vertical sat-h-mark-logo{height:61.0677909189%;width:auto}.sat-logo-vertical sat-word-mark-logo{height:25.433720106%;width:auto}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-logo', standalone: true, host: {
                        '[class.sat-logo-horizontal]': "direction() === 'horizontal'",
                        '[class.sat-logo-vertical]': "direction() === 'vertical'",
                    }, template: `
    <ng-content select="sat-h-mark-logo"></ng-content>
    <ng-content select="sat-word-mark-logo"></ng-content>
  `, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: ["sat-logo{display:flex;align-items:center;justify-content:space-between;overflow:hidden}.sat-logo-horizontal{flex-direction:row;aspect-ratio:1200/248.44}.sat-logo-horizontal sat-h-mark-logo{width:39.2616666667%}.sat-logo-horizontal sat-word-mark-logo{width:58.6808333333%}.sat-logo-vertical{flex-direction:column;aspect-ratio:1200/536.06}.sat-logo-vertical sat-h-mark-logo{height:61.0677909189%;width:auto}.sat-logo-vertical sat-word-mark-logo{height:25.433720106%;width:auto}\n"] }]
        }] });

class SatWordMarkLogoComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatWordMarkLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SatWordMarkLogoComponent, isStandalone: true, selector: "sat-word-mark-logo", ngImport: i0, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 106 12\" fill=\"none\">\n  <path d=\"M12.8021 8.1691e-06V11.9304H10.0188V7.01175H2.78338V11.9304H0V8.1691e-06H2.78338V4.65278H10.0179V8.1691e-06H12.8021ZM27.2005 8.1691e-06H30.4679L24.516 6.98005V11.9322H21.7326V6.98005L15.7657 8.1691e-06H19.1162L23.1672 4.71882L27.2005 8.1691e-06ZM33.4289 8.1691e-06H36.2122V9.55475H44.2974V11.9304H33.4289V8.1691e-06ZM56.3964 8.1691e-06L62.3483 11.9304H59.3308L58.065 9.3716H51.4966L50.2308 11.9304H47.2636L53.2456 8.1691e-06H56.3964ZM52.6281 7.07867H56.9458L54.7949 2.72528L52.6281 7.07867ZM77.9286 11.9304H75.4782L68.0096 3.5389V11.9304H65.3092V8.1691e-06H68.1262L75.2273 7.99267V8.1691e-06H77.9277V11.9304H77.9286ZM82.642 -0.00439453H88.881C93.159 -0.00439453 95.8417 2.33696 95.8417 5.99825C95.8417 9.65953 93.1572 12.0009 88.881 12.0009H82.642V-0.00439453ZM88.8139 9.59701C91.41 9.59701 92.9258 8.17582 92.9258 5.99649C92.9258 3.81715 91.4109 2.39596 88.7971 2.39596H85.3512V9.59878H88.8139V9.59701ZM100.525 0.552107V2.77459H99.8776V0.552107H98.6674V8.1691e-06H101.731V0.552107H100.525ZM103.903 2.77459L102.961 0.6384V2.77459H102.329V8.1691e-06H103.307L104.174 1.98563L105.039 8.1691e-06H106V2.77459H105.372V0.637519L104.426 2.77371H103.903V2.77459Z\" fill=\"currentColor\"/>\n</svg>\n", styles: ["sat-word-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/136.33}sat-word-mark-logo svg{width:100%;height:100%;color:var(--sat-word-mark-logo-color)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatWordMarkLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-word-mark-logo', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 106 12\" fill=\"none\">\n  <path d=\"M12.8021 8.1691e-06V11.9304H10.0188V7.01175H2.78338V11.9304H0V8.1691e-06H2.78338V4.65278H10.0179V8.1691e-06H12.8021ZM27.2005 8.1691e-06H30.4679L24.516 6.98005V11.9322H21.7326V6.98005L15.7657 8.1691e-06H19.1162L23.1672 4.71882L27.2005 8.1691e-06ZM33.4289 8.1691e-06H36.2122V9.55475H44.2974V11.9304H33.4289V8.1691e-06ZM56.3964 8.1691e-06L62.3483 11.9304H59.3308L58.065 9.3716H51.4966L50.2308 11.9304H47.2636L53.2456 8.1691e-06H56.3964ZM52.6281 7.07867H56.9458L54.7949 2.72528L52.6281 7.07867ZM77.9286 11.9304H75.4782L68.0096 3.5389V11.9304H65.3092V8.1691e-06H68.1262L75.2273 7.99267V8.1691e-06H77.9277V11.9304H77.9286ZM82.642 -0.00439453H88.881C93.159 -0.00439453 95.8417 2.33696 95.8417 5.99825C95.8417 9.65953 93.1572 12.0009 88.881 12.0009H82.642V-0.00439453ZM88.8139 9.59701C91.41 9.59701 92.9258 8.17582 92.9258 5.99649C92.9258 3.81715 91.4109 2.39596 88.7971 2.39596H85.3512V9.59878H88.8139V9.59701ZM100.525 0.552107V2.77459H99.8776V0.552107H98.6674V8.1691e-06H101.731V0.552107H100.525ZM103.903 2.77459L102.961 0.6384V2.77459H102.329V8.1691e-06H103.307L104.174 1.98563L105.039 8.1691e-06H106V2.77459H105.372V0.637519L104.426 2.77371H103.903V2.77459Z\" fill=\"currentColor\"/>\n</svg>\n", styles: ["sat-word-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/136.33}sat-word-mark-logo svg{width:100%;height:100%;color:var(--sat-word-mark-logo-color)}\n"] }]
        }] });

const COMPONENTS$1 = [SatLogoComponent, SatHMarkLogoComponent, SatWordMarkLogoComponent];
class SatLogoModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatLogoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: SatLogoModule, imports: [SatLogoComponent, SatHMarkLogoComponent, SatWordMarkLogoComponent], exports: [SatLogoComponent, SatHMarkLogoComponent, SatWordMarkLogoComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatLogoModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatLogoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: COMPONENTS$1,
                    exports: COMPONENTS$1,
                }]
        }] });

class SatPlatformNavAvatarComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SatPlatformNavAvatarComponent, isStandalone: true, selector: "sat-platform-nav-avatar", ngImport: i0, template: `
    <span class="sat-platform-nav-avatar">
      <ng-content></ng-content>
    </span>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavAvatarComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-avatar',
                    template: `
    <span class="sat-platform-nav-avatar">
      <ng-content></ng-content>
    </span>
  `,
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

class SatSkipToContentComponent {
    visible = false;
    display() {
        this.visible = true;
    }
    hide() {
        this.visible = false;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatSkipToContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SatSkipToContentComponent, isStandalone: true, selector: "sat-skip-to-content", ngImport: i0, template: `
    <a
      mat-raised-button
      href="#main-content"
      tabindex="0"
      class="sat-skip-to-content-button"
      [class.sat-skip-to-content-button-visible]="visible"
      (focus)="display()"
      (blur)="hide()"
    >
      Skip to main content
    </a>
  `, isInline: true, styles: [".sat-skip-to-content-button{position:absolute;top:-100%;left:-100%;z-index:2000;opacity:0}\n", ".sat-skip-to-content-button-visible{position:fixed;top:24px;left:24px;opacity:100}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatAnchor, selector: "a[mat-button], a[mat-raised-button], a[mat-flat-button], a[mat-stroked-button]", exportAs: ["matButton", "matAnchor"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatSkipToContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-skip-to-content', template: `
    <a
      mat-raised-button
      href="#main-content"
      tabindex="0"
      class="sat-skip-to-content-button"
      [class.sat-skip-to-content-button-visible]="visible"
      (focus)="display()"
      (blur)="hide()"
    >
      Skip to main content
    </a>
  `, standalone: true, imports: [MatButtonModule], styles: [".sat-skip-to-content-button{position:absolute;top:-100%;left:-100%;z-index:2000;opacity:0}\n", ".sat-skip-to-content-button-visible{position:fixed;top:24px;left:24px;opacity:100}\n"] }]
        }] });

class SatPlatformNavStateService {
    _collapsed = signal(true);
    /**
     * Whether the sidebar is currently collapsed.
     * You can use this in templates or components to update the UI.
     */
    collapsed = computed(() => this._collapsed());
    /**
     * Call this to toggle the sidebar between collapsed and expanded.
     */
    toggleCollapsed() {
        this._collapsed.update(() => !this._collapsed());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavStateService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavStateService, decorators: [{
            type: Injectable
        }] });

class SatPlatformNavContainerComponent {
    service = inject(SatPlatformNavStateService);
    closePlatformNav() {
        if (!this.service.collapsed()) {
            this.service.toggleCollapsed();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatPlatformNavContainerComponent, isStandalone: true, selector: "sat-platform-nav-container", host: { classAttribute: "sat-platform-nav-container" }, ngImport: i0, template: `
    <sat-skip-to-content></sat-skip-to-content>
    @if(!service.collapsed()) {
      <div class="sat-platform-nav-backdrop" tabindex="0" (click)="closePlatformNav()" (keypress)="closePlatformNav()"></div>
    }
    <ng-content select="sat-platform-nav"></ng-content>
    <!-- Element ID used by SatSkipToContentComponent: -->
    <main id="main-content" class="sat-platform-nav-main-content" [class.sat-platform-nav-prevent-pointer]="!service.collapsed()">
      <ng-content select="sat-platform-nav-main-content"></ng-content>
    </main>
  `, isInline: true, styles: [".sat-platform-nav-container{height:100vh;width:100vw;display:flex}.sat-platform-nav-main-content{flex-grow:1;height:100vh;overflow:auto;margin-left:var(--sat-platform-nav-collapsed-width, 56px)}.sat-platform-nav-prevent-pointer{pointer-events:none}.sat-platform-nav-backdrop{position:fixed;top:0;left:0;width:100vw;height:100vh;background-color:color-mix(in srgb,var(--sys-scrim, #000) 32%,transparent);z-index:999;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1));cursor:pointer;pointer-events:auto}\n"], dependencies: [{ kind: "component", type: SatSkipToContentComponent, selector: "sat-skip-to-content" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-container', host: { class: 'sat-platform-nav-container' }, template: `
    <sat-skip-to-content></sat-skip-to-content>
    @if(!service.collapsed()) {
      <div class="sat-platform-nav-backdrop" tabindex="0" (click)="closePlatformNav()" (keypress)="closePlatformNav()"></div>
    }
    <ng-content select="sat-platform-nav"></ng-content>
    <!-- Element ID used by SatSkipToContentComponent: -->
    <main id="main-content" class="sat-platform-nav-main-content" [class.sat-platform-nav-prevent-pointer]="!service.collapsed()">
      <ng-content select="sat-platform-nav-main-content"></ng-content>
    </main>
  `, encapsulation: ViewEncapsulation.None, standalone: true, imports: [SatSkipToContentComponent], changeDetection: ChangeDetectionStrategy.OnPush, styles: [".sat-platform-nav-container{height:100vh;width:100vw;display:flex}.sat-platform-nav-main-content{flex-grow:1;height:100vh;overflow:auto;margin-left:var(--sat-platform-nav-collapsed-width, 56px)}.sat-platform-nav-prevent-pointer{pointer-events:none}.sat-platform-nav-backdrop{position:fixed;top:0;left:0;width:100vw;height:100vh;background-color:color-mix(in srgb,var(--sys-scrim, #000) 32%,transparent);z-index:999;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1));cursor:pointer;pointer-events:auto}\n"] }]
        }] });

class SatIconModule {
    constructor() {
        const registry = inject(MatIconRegistry);
        const sanitizer = inject(DomSanitizer);
        registry.addSvgIconSetLiteral(sanitizer.bypassSecurityTrustHtml(SATORI_ICONS));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatIconModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: SatIconModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatIconModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatIconModule, decorators: [{
            type: NgModule
        }], ctorParameters: () => [] });

class SatPlatformNavEnvironmentSwitcherItemComponent {
    value = input.required();
    active = input(false);
    disabled = input(false, { transform: booleanAttribute });
    _element = inject(ElementRef);
    /** Event to notify parent when this item is clicked */
    selectionChange = new EventEmitter();
    onSelectionChange() {
        if (!this.disabled() && !this.active()) {
            // Emit the selection change event
            this.selectionChange.emit(this.value());
        }
    }
    /**
     * Handles keyboard interaction for accessibility:
     * Only responds to Enter and Space keys to select the option.
     */
    handleKeydown(event) {
        if (!this.disabled() &&
            !this.active() &&
            (event.code === 'Enter' || event.code === 'Space') &&
            !hasModifierKey(event)) {
            this.onSelectionChange();
            // Prevent the page from scrolling down and form submits.
            event.preventDefault();
        }
    }
    /** Gets the host DOM element. */
    _getHostElement() {
        return this._element.nativeElement;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatPlatformNavEnvironmentSwitcherItemComponent, isStandalone: true, selector: "sat-platform-nav-switcher-item", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange" }, host: { attributes: { "role": "option", "tabindex": "0" }, listeners: { "click": "onSelectionChange()", "keydown": "handleKeydown($event)" }, properties: { "attr.id": "value()", "attr.aria-checked": "active()", "attr.aria-selected": "active()", "attr.aria-disabled": "disabled()", "class.sat-platform-nav-switcher-item--selected": "active()", "class.sat-platform-nav-switcher-item--active": "active()", "class.sat-platform-nav-switcher-item--disabled": "disabled()" }, classAttribute: "sat-platform-nav-switcher-item" }, ngImport: i0, template: `
    <span class="sat-platform-nav-switcher-item-content">
      <ng-content></ng-content>
    </span>
    @if (active()) {
      <mat-pseudo-checkbox
        [disabled]="disabled()"
        state="checked"
        aria-hidden="true"
        appearance="minimal"
      ></mat-pseudo-checkbox>
    }

    <div class="sat-environment-switcher-ripple" aria-hidden="true" mat-ripple
      [matRippleTrigger]="_getHostElement()" [matRippleDisabled]="disabled()"></div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: MatRippleModule }, { kind: "directive", type: i1$1.MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "ngmodule", type: MatPseudoCheckboxModule }, { kind: "component", type: i1$1.MatPseudoCheckbox, selector: "mat-pseudo-checkbox", inputs: ["state", "disabled", "appearance"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherItemComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-switcher-item',
                    host: {
                        'role': 'option',
                        'tabindex': '0',
                        '[attr.id]': 'value()',
                        '[attr.aria-checked]': 'active()',
                        '[attr.aria-selected]': 'active()',
                        '[attr.aria-disabled]': 'disabled()',
                        '[class.sat-platform-nav-switcher-item--selected]': 'active()',
                        '[class.sat-platform-nav-switcher-item--active]': 'active()',
                        '[class.sat-platform-nav-switcher-item--disabled]': 'disabled()',
                        '(click)': 'onSelectionChange()',
                        '(keydown)': 'handleKeydown($event)',
                        'class': 'sat-platform-nav-switcher-item',
                    },
                    standalone: true,
                    imports: [MatRippleModule, MatPseudoCheckboxModule],
                    template: `
    <span class="sat-platform-nav-switcher-item-content">
      <ng-content></ng-content>
    </span>
    @if (active()) {
      <mat-pseudo-checkbox
        [disabled]="disabled()"
        state="checked"
        aria-hidden="true"
        appearance="minimal"
      ></mat-pseudo-checkbox>
    }

    <div class="sat-environment-switcher-ripple" aria-hidden="true" mat-ripple
      [matRippleTrigger]="_getHostElement()" [matRippleDisabled]="disabled()"></div>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { selectionChange: [{
                type: Output
            }] } });

class SatPlatformNavEnvironmentSwitcherComponent {
    /**
     * The currently selected environment.
     * This should match the `value` property of one of the provided environment objects.
     */
    value = input.required();
    /**
     * @type SatPlatformNavEnvironmentType[]
     * The available environments.
     * This input is required and should be provided with an array of environment objects.
     * @required
     */
    environments = input.required();
    /**
     * Denotes whether the switcher is disabled.
     * @type boolean
     */
    disabled = input(false, { transform: booleanAttribute });
    /**
     * An event emitted when the environment is changed.
     * The value emitted is the currently selected environment.
     * @type SatPlatformNavEnvironmentType
     */
    environmentChange = output();
    satPlatformNavStateService = inject(SatPlatformNavStateService);
    initialSelection = computed(() => {
        return this.environments()?.find((env) => env.value === this.value());
    });
    userSelectedEnv = signal(null);
    // User selection takes precedence over the initial selection.
    selectedEnv = computed(() => this.userSelectedEnv() ?? this.initialSelection());
    // Handle option selection
    onSelect(environment) {
        if (!this.disabled()) {
            const wasSelected = this.selectedEnv()?.value === environment.value;
            const isEnvironmentInList = this.environments().some((env) => env.value === environment.value);
            if (isEnvironmentInList && !wasSelected) {
                this.userSelectedEnv.set(environment);
                this._propagateChanges();
            }
        }
    }
    // Propagates the selected environment change to the output event.
    _propagateChanges() {
        const selectedEnv = this.selectedEnv();
        if (selectedEnv) {
            this.environmentChange.emit(selectedEnv);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatPlatformNavEnvironmentSwitcherComponent, isStandalone: true, selector: "sat-platform-nav-switcher", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, environments: { classPropertyName: "environments", publicName: "environments", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { environmentChange: "environmentChange" }, host: { properties: { "attr.tabindex": "-1" } }, ngImport: i0, template: "<button\n  matRipple\n  matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n  id=\"sat-platform-nav-env-switcher-button\"\n  aria-haspopup=\"listbox\"\n  title=\"{{ 'platform-nav.environment-switcher.trigger-title' | translate }}\"\n  [attr.aria-expanded]=\"trigger.isOpen()\"\n  aria-controls=\"sat-platform-nav-env-switcher-menu\"\n  aria-labelledby=\"sat-platform-nav-env-switcher-button-label\"\n  aria-describedby=\"sat-platform-nav-env-switcher-button-value\"\n  [matTooltip]=\"\n    satPlatformNavStateService.collapsed() && selectedEnv()\n    ? ('platform-nav.environment-switcher.trigger-tooltip-prefix' | translate)  + selectedEnv()?.label\n    : null\n  \"\n  matTooltipPosition=\"right\"\n  tabindex=\"0\"\n  [cdkMenuTriggerFor]=\"switcherMenu\"\n  [disabled]=\"disabled()\"\n  #trigger=\"cdkMenuTriggerFor\"\n  class=\"sat-platform-nav-switcher-button sat-platform-nav-item\"\n  [class.sat-platform-nav-switcher-button--disabled]=\"disabled()\"\n>\n  <div class=\"sat-platform-nav-switcher-button-text\">\n    <div class=\"sat-platform-nav-icon\">\n      <mat-icon svgIcon=\"cloud_24px\" aria-hidden=\"true\"></mat-icon>\n    </div>\n\n    @if (!satPlatformNavStateService.collapsed()) {\n      <div class=\"sat-platform-nav-switcher-button-name\">\n        <span\n          class=\"sat-platform-nav-switcher-button-label\"\n          id=\"sat-platform-nav-env-switcher-button-label\"\n        >\n          {{ 'platform-nav.environment-switcher.trigger-label' | translate }}\n        </span>\n        <span\n          class=\"sat-platform-nav-switcher-button-value\"\n          id=\"sat-platform-nav-env-switcher-button-value\"\n        >\n          {{selectedEnv()?.label}}\n        </span>\n      </div>\n    }\n  </div>\n\n  <mat-icon\n    class=\"sat-platform-nav-switcher-button-suffix-icon\"\n    svgIcon=\"arrow_drop_down_24px\"\n    aria-hidden=\"true\"\n    iconPositionEnd\n  >\n  </mat-icon>\n</button>\n\n<ng-template #switcherMenu>\n  <div\n    cdkMenu\n    role=\"listbox\"\n    aria-multiselectable=\"false\"\n    [attr.aria-activedescendant]=\"selectedEnv()?.value\"\n    aria-labelledby=\"sat-platform-nav-env-switcher-button-label\"\n    id=\"sat-platform-nav-env-switcher-menu\"\n    [class.sat-platform-nav-switcher-menu--expanded]=\"!satPlatformNavStateService.collapsed()\"\n    class=\"sat-platform-nav-switcher-menu mat-elevation-z2\"\n  >\n    <div cdkMenuGroup style=\"width: 100%;\">\n      @for (environment of environments(); track environment) {\n        <sat-platform-nav-switcher-item\n          cdkMenuItemRadio\n          role=\"option\"\n          [id]=\"environment.value\"\n          [value]=\"environment.value\"\n          [disabled]=\"environment.disabled\"\n          [active]=\"selectedEnv()?.value === environment.value\"\n          (selectionChange)=\"onSelect(environment)\"\n        >\n          {{ environment.label }}\n        </sat-platform-nav-switcher-item>\n      }\n    </div>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: SatIconModule }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: CdkMenuModule }, { kind: "directive", type: i2.CdkMenu, selector: "[cdkMenu]", outputs: ["closed"], exportAs: ["cdkMenu"] }, { kind: "directive", type: i2.CdkMenuItemRadio, selector: "[cdkMenuItemRadio]", exportAs: ["cdkMenuItemRadio"] }, { kind: "directive", type: i2.CdkMenuTrigger, selector: "[cdkMenuTriggerFor]", inputs: ["cdkMenuTriggerFor", "cdkMenuPosition", "cdkMenuTriggerData"], outputs: ["cdkMenuOpened", "cdkMenuClosed"], exportAs: ["cdkMenuTriggerFor"] }, { kind: "directive", type: i2.CdkMenuGroup, selector: "[cdkMenuGroup]", exportAs: ["cdkMenuGroup"] }, { kind: "component", type: SatPlatformNavEnvironmentSwitcherItemComponent, selector: "sat-platform-nav-switcher-item", inputs: ["value", "active", "disabled"], outputs: ["selectionChange"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-switcher', host: {
                        '[attr.tabindex]': '-1',
                    }, standalone: true, imports: [
                        MatRipple,
                        MatButtonModule,
                        MatIconModule,
                        SatIconModule,
                        MatTooltip,
                        CdkMenuModule,
                        SatPlatformNavEnvironmentSwitcherItemComponent,
                        TranslatePipe,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  matRipple\n  matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n  id=\"sat-platform-nav-env-switcher-button\"\n  aria-haspopup=\"listbox\"\n  title=\"{{ 'platform-nav.environment-switcher.trigger-title' | translate }}\"\n  [attr.aria-expanded]=\"trigger.isOpen()\"\n  aria-controls=\"sat-platform-nav-env-switcher-menu\"\n  aria-labelledby=\"sat-platform-nav-env-switcher-button-label\"\n  aria-describedby=\"sat-platform-nav-env-switcher-button-value\"\n  [matTooltip]=\"\n    satPlatformNavStateService.collapsed() && selectedEnv()\n    ? ('platform-nav.environment-switcher.trigger-tooltip-prefix' | translate)  + selectedEnv()?.label\n    : null\n  \"\n  matTooltipPosition=\"right\"\n  tabindex=\"0\"\n  [cdkMenuTriggerFor]=\"switcherMenu\"\n  [disabled]=\"disabled()\"\n  #trigger=\"cdkMenuTriggerFor\"\n  class=\"sat-platform-nav-switcher-button sat-platform-nav-item\"\n  [class.sat-platform-nav-switcher-button--disabled]=\"disabled()\"\n>\n  <div class=\"sat-platform-nav-switcher-button-text\">\n    <div class=\"sat-platform-nav-icon\">\n      <mat-icon svgIcon=\"cloud_24px\" aria-hidden=\"true\"></mat-icon>\n    </div>\n\n    @if (!satPlatformNavStateService.collapsed()) {\n      <div class=\"sat-platform-nav-switcher-button-name\">\n        <span\n          class=\"sat-platform-nav-switcher-button-label\"\n          id=\"sat-platform-nav-env-switcher-button-label\"\n        >\n          {{ 'platform-nav.environment-switcher.trigger-label' | translate }}\n        </span>\n        <span\n          class=\"sat-platform-nav-switcher-button-value\"\n          id=\"sat-platform-nav-env-switcher-button-value\"\n        >\n          {{selectedEnv()?.label}}\n        </span>\n      </div>\n    }\n  </div>\n\n  <mat-icon\n    class=\"sat-platform-nav-switcher-button-suffix-icon\"\n    svgIcon=\"arrow_drop_down_24px\"\n    aria-hidden=\"true\"\n    iconPositionEnd\n  >\n  </mat-icon>\n</button>\n\n<ng-template #switcherMenu>\n  <div\n    cdkMenu\n    role=\"listbox\"\n    aria-multiselectable=\"false\"\n    [attr.aria-activedescendant]=\"selectedEnv()?.value\"\n    aria-labelledby=\"sat-platform-nav-env-switcher-button-label\"\n    id=\"sat-platform-nav-env-switcher-menu\"\n    [class.sat-platform-nav-switcher-menu--expanded]=\"!satPlatformNavStateService.collapsed()\"\n    class=\"sat-platform-nav-switcher-menu mat-elevation-z2\"\n  >\n    <div cdkMenuGroup style=\"width: 100%;\">\n      @for (environment of environments(); track environment) {\n        <sat-platform-nav-switcher-item\n          cdkMenuItemRadio\n          role=\"option\"\n          [id]=\"environment.value\"\n          [value]=\"environment.value\"\n          [disabled]=\"environment.disabled\"\n          [active]=\"selectedEnv()?.value === environment.value\"\n          (selectionChange)=\"onSelect(environment)\"\n        >\n          {{ environment.label }}\n        </sat-platform-nav-switcher-item>\n      }\n    </div>\n  </div>\n</ng-template>\n" }]
        }] });

// initials.pipe.ts
class SatPlatformNavInitialsPipe {
    _maxWords = 2;
    /**
     * Transforms a name string into initials by taking the first letter
     * of each word (up to the first two words).
     *
     * @param value The name to transform into initials
     * @param maxWords Optional parameter to specify maximum number of words to use (default: 2)
     * @returns The generated initials as uppercase letters
     */
    transform(value, maxWords = this._maxWords) {
        if (!value || typeof value !== 'string')
            return '';
        const trimmedValue = value.trim();
        if (!trimmedValue)
            return '';
        const words = trimmedValue.split(/\s+/).slice(0, maxWords);
        if (words.length === 1) {
            return words[0].substring(0, maxWords).toUpperCase();
        }
        else {
            return words.map(word => word.charAt(0).toUpperCase()).join('');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavInitialsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavInitialsPipe, isStandalone: true, name: "satPlatformNavInitials" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavInitialsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'satPlatformNavInitials',
                    standalone: true,
                    pure: true,
                }]
        }] });

class SatPlatformNavTooltipService {
    _tooltipShownFirst = signal(false);
    /**
     * Whether the tooltip has already been shown.
     * Useful for showing tooltips with a delay only the first time.
     */
    tooltipShownFirst = computed(() => this._tooltipShownFirst());
    /**
     * Currently active tooltip instance.
     * Used to ensure only one tooltip is visible at a time.
     * When a new tooltip is triggered (via focus or hover), the previous one is hidden using this reference.
     */
    activateTooltip = null;
    /**
     * Marks that the tooltip has been shown at least once.
     * Call this after showing your tooltip so it doesn't repeat the delay.
     *
     * @param value A boolean indicating whether the tooltip has already been shown.
     */
    updateTooltipShownFirst(value) {
        this._tooltipShownFirst.set(value);
    }
    /**
     * Updates the currently active tooltip.
     * Call this whenever a tooltip is shown or hidden so the service can manage exclusive visibility.
     *
     * @param tooltip The tooltip instance to set as active, or null to clear it.
     */
    updateActiveTooltip(tooltip) {
        this.activateTooltip = tooltip;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavTooltipService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavTooltipService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavTooltipService, decorators: [{
            type: Injectable
        }] });

class SatPlatformNavListItemComponent {
    active = input();
    labelText = signal(undefined);
    service = inject(SatPlatformNavStateService);
    tooltipService = inject(SatPlatformNavTooltipService);
    tooltip = viewChild('tooltip');
    tooltipDelay = 600;
    tooltipTimer = null;
    onMouseEnter() {
        if (this.service.collapsed()) {
            const currentTooltip = this.tooltip();
            const previousTooltip = this.tooltipService.activateTooltip;
            if (!currentTooltip) {
                return;
            }
            if (previousTooltip && previousTooltip !== currentTooltip) {
                this.hidePreviousTooltip(previousTooltip);
            }
            const delayTime = this.tooltipService.tooltipShownFirst() ? 0 : this.tooltipDelay;
            if (delayTime) {
                this.tooltipTimer = setTimeout(() => {
                    this.showCurrentTooltip(currentTooltip);
                    this.tooltipService.updateTooltipShownFirst(true);
                }, delayTime);
            }
            else {
                this.showCurrentTooltip(currentTooltip);
            }
        }
    }
    onMouseLeave() {
        if (this.tooltipTimer) {
            clearTimeout(this.tooltipTimer);
            this.tooltipTimer = null;
        }
        const currentTooltip = this.tooltip();
        if (currentTooltip && this.tooltipService.activateTooltip === currentTooltip) {
            this.hidePreviousTooltip(this.tooltipService.activateTooltip);
        }
    }
    labelChanged(event) {
        const text = event[0]?.target?.textContent;
        if (text) {
            this.labelText.set(text);
        }
    }
    hidePreviousTooltip(previousTooltip) {
        previousTooltip.disabled = true;
        previousTooltip.hide();
        this.tooltipService.updateActiveTooltip(null);
    }
    showCurrentTooltip(tooltip) {
        this.tooltipService.updateActiveTooltip(tooltip);
        tooltip.disabled = false;
        tooltip.show();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavListItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatPlatformNavListItemComponent, isStandalone: true, selector: "sat-platform-nav-list-item", inputs: { active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "link" }, listeners: { "mouseenter": "onMouseEnter()", "mouseleave": "onMouseLeave()" }, properties: { "attr.tabindex": "-1" } }, viewQueries: [{ propertyName: "tooltip", first: true, predicate: ["tooltip"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <a
      matRipple
      matRippleColor="var(--sat-sys-on-primary-opacity-12)"
      class="sat-platform-nav-item"
      tabIndex="0"
      [class.sat-platform-nav-item-active]="active()"
      [matTooltip]="labelText() ?? label.innerText"
      matTooltipPosition="right"
      matTooltipDisabled="true"
      #tooltip="matTooltip"
      aria-label="Platform nav item"
      (focus)="onMouseEnter()"
      (blur)="onMouseLeave()"
    >
      @if (active()) {
        <div class="sat-platform-nav-list-item-active-indicator"></div>
      }
      <div class="sat-platform-nav-icon">
        <ng-container #iconContainer>
          <ng-content select="mat-icon, sat-platform-nav-avatar"></ng-content>
        </ng-container>
        @if (
          iconContainer?.previousElementSibling?.localName !== 'mat-icon' &&
          iconContainer?.previousElementSibling?.localName !== 'sat-platform-nav-avatar'
        ) {
          <sat-platform-nav-avatar>
            {{ labelText() ?? label.innerText | satPlatformNavInitials }}
          </sat-platform-nav-avatar>
        }
      </div>
      <p #label
        class="sat-platform-nav-item-label"
        [class.sat-platform-nav-hidden]="service.collapsed()"
        (cdkObserveContent)="labelChanged($event)"
        >
        <ng-content></ng-content>
      </p>
    </a>
  `, isInline: true, dependencies: [{ kind: "directive", type: MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "component", type: SatPlatformNavAvatarComponent, selector: "sat-platform-nav-avatar" }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: SatPlatformNavInitialsPipe, name: "satPlatformNavInitials" }, { kind: "ngmodule", type: ObserversModule }, { kind: "directive", type: i2$1.CdkObserveContent, selector: "[cdkObserveContent]", inputs: ["cdkObserveContentDisabled", "debounce"], outputs: ["cdkObserveContent"], exportAs: ["cdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavListItemComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-list-item',
                    host: {
                        '[attr.tabindex]': '-1',
                        'role': 'link',
                    },
                    template: `
    <a
      matRipple
      matRippleColor="var(--sat-sys-on-primary-opacity-12)"
      class="sat-platform-nav-item"
      tabIndex="0"
      [class.sat-platform-nav-item-active]="active()"
      [matTooltip]="labelText() ?? label.innerText"
      matTooltipPosition="right"
      matTooltipDisabled="true"
      #tooltip="matTooltip"
      aria-label="Platform nav item"
      (focus)="onMouseEnter()"
      (blur)="onMouseLeave()"
    >
      @if (active()) {
        <div class="sat-platform-nav-list-item-active-indicator"></div>
      }
      <div class="sat-platform-nav-icon">
        <ng-container #iconContainer>
          <ng-content select="mat-icon, sat-platform-nav-avatar"></ng-content>
        </ng-container>
        @if (
          iconContainer?.previousElementSibling?.localName !== 'mat-icon' &&
          iconContainer?.previousElementSibling?.localName !== 'sat-platform-nav-avatar'
        ) {
          <sat-platform-nav-avatar>
            {{ labelText() ?? label.innerText | satPlatformNavInitials }}
          </sat-platform-nav-avatar>
        }
      </div>
      <p #label
        class="sat-platform-nav-item-label"
        [class.sat-platform-nav-hidden]="service.collapsed()"
        (cdkObserveContent)="labelChanged($event)"
        >
        <ng-content></ng-content>
      </p>
    </a>
  `,
                    standalone: true,
                    imports: [
                        MatRipple,
                        SatPlatformNavAvatarComponent,
                        MatTooltipModule,
                        SatPlatformNavInitialsPipe,
                        ObserversModule,
                    ],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }] } });

class SatPlatformNavMainContentComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavMainContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SatPlatformNavMainContentComponent, isStandalone: true, selector: "sat-platform-nav-main-content", ngImport: i0, template: '<ng-content></ng-content>', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavMainContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-main-content',
                    template: '<ng-content></ng-content>',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

class SatPlatformNavUserMenuDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavUserMenuDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: SatPlatformNavUserMenuDirective, isStandalone: true, selector: "[satPlatformNavUserMenu]", exportAs: ["satPlatformNavUserMenu"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavUserMenuDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satPlatformNavUserMenu]',
                    standalone: true,
                    exportAs: 'satPlatformNavUserMenu',
                }]
        }] });

class SatPlatformNavUserProfileComponent {
    service = inject(SatPlatformNavStateService);
    profileNameText = signal(undefined);
    profileNameChanged(event) {
        const text = event[0]?.target?.textContent;
        if (text) {
            this.profileNameText.set(text);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavUserProfileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatPlatformNavUserProfileComponent, isStandalone: true, selector: "sat-platform-nav-user-profile", ngImport: i0, template: `
    <button class="sat-platform-nav-item" aria-haspopup="menu">
      <span class="sat-platform-nav-icon">
        <ng-container #avatarContainer>
          <ng-content select="mat-icon, img"></ng-content>
        </ng-container>
        @if (
          avatarContainer?.previousElementSibling?.localName !== 'mat-icon' &&
          avatarContainer?.previousElementSibling?.localName !== 'img'
        ) {
          <sat-platform-nav-avatar class="sat-platform-nav-user-avatar">
            {{ profileNameText() ?? profileName.innerText | satPlatformNavInitials }}
          </sat-platform-nav-avatar>
        }
      </span>
      <p #profileName
        class="sat-platform-nav-item-label"
        [class.sat-platform-nav-hidden]="service.collapsed()"
        (cdkObserveContent)="profileNameChanged($event)"
      >
        <ng-content></ng-content>
      </p>
    </button>
  `, isInline: true, dependencies: [{ kind: "component", type: SatPlatformNavAvatarComponent, selector: "sat-platform-nav-avatar" }, { kind: "pipe", type: SatPlatformNavInitialsPipe, name: "satPlatformNavInitials" }, { kind: "ngmodule", type: ObserversModule }, { kind: "directive", type: i2$1.CdkObserveContent, selector: "[cdkObserveContent]", inputs: ["cdkObserveContentDisabled", "debounce"], outputs: ["cdkObserveContent"], exportAs: ["cdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavUserProfileComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-user-profile',
                    standalone: true,
                    template: `
    <button class="sat-platform-nav-item" aria-haspopup="menu">
      <span class="sat-platform-nav-icon">
        <ng-container #avatarContainer>
          <ng-content select="mat-icon, img"></ng-content>
        </ng-container>
        @if (
          avatarContainer?.previousElementSibling?.localName !== 'mat-icon' &&
          avatarContainer?.previousElementSibling?.localName !== 'img'
        ) {
          <sat-platform-nav-avatar class="sat-platform-nav-user-avatar">
            {{ profileNameText() ?? profileName.innerText | satPlatformNavInitials }}
          </sat-platform-nav-avatar>
        }
      </span>
      <p #profileName
        class="sat-platform-nav-item-label"
        [class.sat-platform-nav-hidden]="service.collapsed()"
        (cdkObserveContent)="profileNameChanged($event)"
      >
        <ng-content></ng-content>
      </p>
    </button>
  `,
                    imports: [SatPlatformNavAvatarComponent, SatPlatformNavInitialsPipe, ObserversModule],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

class SatPlatformNavUserComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavUserComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.13", type: SatPlatformNavUserComponent, isStandalone: true, selector: "sat-platform-nav-user", ngImport: i0, template: `
    <div class="sat-platform-nav-user">
      <ng-content select="sat-platform-nav-user-profile"></ng-content>
    </div>
    <ng-content select="[satPlatformNavUserMenu]"></ng-content>
  `, isInline: true, styles: [".sat-platform-nav-user{margin:0 4px 8px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavUserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-user', standalone: true, template: `
    <div class="sat-platform-nav-user">
      <ng-content select="sat-platform-nav-user-profile"></ng-content>
    </div>
    <ng-content select="[satPlatformNavUserMenu]"></ng-content>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".sat-platform-nav-user{margin:0 4px 8px}\n"] }]
        }] });

class SatPlatformNavComponent {
    service = inject(SatPlatformNavStateService);
    tooltipService = inject(SatPlatformNavTooltipService);
    neutralTheme = input(false);
    /**
     * Clears the active tooltip on mouse leave.
     * Resets the tooltipShownFirst flag, hides and disables the current activated tooltip.
     */
    onMouseLeave() {
        this.tooltipService.updateTooltipShownFirst(false);
        const activateTooltip = this.tooltipService.activateTooltip;
        if (activateTooltip) {
            activateTooltip.disabled = true;
            activateTooltip.hide();
        }
        this.tooltipService.updateActiveTooltip(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatPlatformNavComponent, isStandalone: true, selector: "sat-platform-nav", inputs: { neutralTheme: { classPropertyName: "neutralTheme", publicName: "neutralTheme", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div\n  class=\"sat-platform-nav-panel sat-light-theme-system-variables\"\n  [class.sat-neutral-theme]=\"neutralTheme()\"\n  [class.sat-platform-nav-panel-expanded]=\"!service.collapsed()\"\n>\n  <h2 class=\"sat-platform-nav-title\">\n    <button\n      matRipple\n      type=\"button\"\n      matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n      id=\"sat-platform-nav-title-icon\"\n      title=\"sat-platform-nav-title-icon\"\n      class=\"sat-platform-nav-item\"\n      [matTooltip]=\"(service.collapsed() ? 'platform-nav.expand' : 'platform-nav.collapse') | translate\"\n      matTooltipPosition=\"below\"\n      (click)=\"service.toggleCollapsed()\"\n      [attr.data-automation-id]=\"service.collapsed() ? 'platform-nav-expand-button' : 'platform-nav-collapse-button'\"\n      [attr.aria-pressed]=\"service.collapsed() ? false : true\"\n    >\n      <svg\n        xmlns=\"http://www.w3.org/2000/svg\"\n        width=\"32\"\n        height=\"32\"\n        viewBox=\"0 0 32 32\"\n        fill=\"none\"\n        class=\"sat-platform-nav-title-icon\"\n      >\n        <path d=\"M15.2736 8L10.6997 15.997H15.997L20.5708 8H15.2736Z\" fill=\"white\" />\n        <path d=\"M5.40245 15.9984L0.828857 23.9954H6.12612L10.6997 15.9984H5.40245Z\" fill=\"white\" />\n        <path d=\"M16.002 16.0028L11.4284 24H16.7257L21.2993 16.0028H16.002Z\" fill=\"white\" />\n        <path d=\"M25.8734 8.00474L21.2993 16.0027H26.5971L31.1712 8.00474H25.8734Z\" fill=\"white\" />\n      </svg>\n    </button>\n    @if (!service.collapsed()) {\n      Content Innovation Cloud\n    }\n  </h2>\n  <ng-content select=\"sat-platform-nav-switcher\"></ng-content>\n  <nav class=\"sat-platform-nav-list\" (mouseleave)=\"onMouseLeave()\">\n    <ng-content></ng-content>\n  </nav>\n  <ng-content select=\"sat-platform-nav-user\"></ng-content>\n</div>\n", styles: ["sat-platform-nav .sat-neutral-theme{--sat-platform-nav-background: var(--sys-inverse-surface, #2f3033);--sat-platform-nav-on-background: var(--sys-on-primary, #fff);--sat-platform-nav-outline: var(--sys-outline, #777683);--sat-platform-nav-icon-color: var(--sys-on-surface, #1a1c1e);--sat-platform-nav-primary-loud: var(--sat-sys-inverse-surface-loud, #101112);--sat-platform-nav-avatar-color: var(--sat-sys-inverse-surface-loud, #101112)}sat-platform-nav .sat-platform-nav-panel{position:fixed;background-color:var(--sat-platform-nav-background, var(--sys-primary, #5654ac));display:flex;flex-direction:column;height:var(--sat-platform-nav-height-max, 100%);width:var(--sat-platform-nav-collapsed-width, 56px);z-index:1000;box-sizing:border-box;overflow:hidden;transition:width var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}sat-platform-nav h2.sat-platform-nav-title{display:flex;align-items:center;margin:8px 4px;white-space:nowrap;height:var(--sat-platform-nav-height-high, 48px);flex-shrink:0;color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff));font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-title-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-title-letter-spacing, .009rem)}sat-platform-nav p.sat-platform-nav-item-label{font-family:var(--sat-platform-nav-label-large-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-large-size, .875rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-large-line-height, 1.25rem);letter-spacing:var(--sat-platform-nav-label-large-tracking, .006rem);margin:0}sat-platform-nav .sat-platform-nav-avatar{font-family:var(--sat-platform-nav-label-medium-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-medium-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .0031rem);display:flex;justify-content:center;align-items:center;width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px);border-radius:var(--sat-platform-nav-corner-extra-small, 4px);background-color:var(--sat-platform-nav-avatar-color, var(--sys-inverse-surface, #2f3033));color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff))}sat-platform-nav .sat-platform-nav-user-avatar .sat-platform-nav-avatar{border-radius:50%}sat-platform-nav .sat-platform-nav-hidden{display:none}sat-platform-nav .sat-platform-nav-list{padding:0 4px 2px;flex-grow:1;overflow-x:hidden;overflow-y:hidden;-ms-overflow-style:auto}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar{width:4px;height:4px}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-track{background:transparent}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-thumb{background:var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0));border-radius:var(--sat-platform-nav-corner-full, 1000px)}sat-platform-nav sat-platform-nav-switcher+.sat-platform-nav-list{padding-top:10px}sat-platform-nav .sat-platform-nav-title+.sat-platform-nav-list{padding-top:48px}sat-platform-nav .sat-platform-nav-list:hover{overflow-y:scroll;padding-right:0}sat-platform-nav .sat-platform-nav-item{position:relative;display:flex;align-items:center;padding:0 10px;white-space:nowrap;text-decoration:none;background:none;box-sizing:border-box;border:none;gap:var(--sat-platform-nav-gap-medium, 12px);height:var(--sat-platform-nav-height-high, 48px);width:var(--sat-platform-nav-width-max, 100%);flex-shrink:0;cursor:pointer;color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff));border-radius:var(--sat-platform-nav-corner-medium, 12px)}sat-platform-nav .sat-platform-nav-item:hover{background-color:var(--sat-sys-on-primary-opacity-08, rgba(255, 255, 255, .08))}sat-platform-nav .sat-platform-nav-item:active{background-color:var(--sat-sys-on-primary-opacity-12, rgba(255, 255, 255, .12))}sat-platform-nav .sat-platform-nav-item:focus-visible{outline:2px solid var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0));outline-offset:-2px}sat-platform-nav .sat-platform-nav-title .sat-platform-nav-item{width:var(--sat-platform-nav-width-high, 48px);padding:0 8px;border-radius:50%}sat-platform-nav .sat-platform-nav-item-active{background-color:var(--sat-sys-on-primary-opacity-12, rgba(255, 255, 255, .12))}sat-platform-nav .sat-platform-nav-item-active:focus,sat-platform-nav .sat-platform-nav-item-active:hover{background-color:var(--sat-sys-on-primary-opacity-12, rgba(255, 255, 255, .12))}sat-platform-nav .sat-platform-nav-item-active:focus-visible{outline:2px solid var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0));outline-offset:-2px}sat-platform-nav .sat-platform-nav-item-active:active,sat-platform-nav .sat-platform-nav-item-active:focus:active,sat-platform-nav .sat-platform-nav-item-active:focus-visible:active{background-color:var(--sat-sys-on-primary-opacity-08, rgba(255, 255, 255, .08))}sat-platform-nav .sat-platform-nav-icon{width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px);display:flex;justify-content:center;align-items:center;background:none;border:none;padding:0;cursor:pointer;flex-shrink:0;border-radius:var(--sat-platform-nav-corner-extra-small, 4px)}sat-platform-nav .sat-platform-nav-icon .mat-icon{width:var(--sat-platform-nav-width-small, 24px);height:var(--sat-platform-nav-height-small, 24px)}sat-platform-nav .sat-platform-nav-icon img{width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px)}sat-platform-nav .sat-platform-nav-icon .sat-platform-nav-avatar img{width:100%;height:100%;border-radius:var(--sat-platform-nav-corner-extra-small, 4px);aspect-ratio:1/1;object-fit:contain}sat-platform-nav .sat-platform-nav-title-icon{width:32px;height:32px}sat-platform-nav .sat-platform-nav-list-item-active-indicator{position:absolute;top:14px;left:0;width:4px;height:20px;border-radius:0 var(--sat-platform-nav-corner-large, 16px) var(--sat-platform-nav-corner-large, 16px) 0;background:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff))}sat-platform-nav .sat-platform-nav-switcher-button{height:56px;gap:0;border-radius:0;width:100%;background-color:var(--sat-platform-nav-primary-loud, var(--sat-sys-primary-loud, #322f86));color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff))}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text{display:flex;align-items:center;gap:12px;flex-grow:1}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;width:208px}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-label{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-body-small-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .031rem);user-select:none;-webkit-user-select:none}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-value{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;width:100%;font-weight:400;text-align:left;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem);white-space:nowrap;overflow:hidden;user-select:none;-webkit-user-select:none;text-overflow:ellipsis}sat-platform-nav .sat-platform-nav-switcher-button.sat-platform-nav-switcher-button--disabled{cursor:default;pointer-events:none;opacity:.38}sat-platform-nav .sat-platform-nav-panel .sat-platform-nav-switcher-button{padding:4px 3px 4px 14px}sat-platform-nav .sat-platform-nav-panel .mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:-5px;width:16px;height:16px}sat-platform-nav .sat-platform-nav-panel-expanded{width:var(--sat-platform-nav-expanded-width, 300px)}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-switcher-button{padding:4px 14px}sat-platform-nav .sat-platform-nav-panel-expanded .mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:0;width:24px;height:24px}@-moz-document url-prefix(){sat-platform-nav .sat-platform-nav-list{scrollbar-gutter:stable;scrollbar-width:thin;scrollbar-color:var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0)) transparent}sat-platform-nav .sat-platform-nav-list:hover{padding-right:4px!important}}.sat-platform-nav-switcher-menu{display:flex;flex-direction:column;padding:8px 0;align-items:flex-start;align-self:stretch;border-radius:4px;min-width:112px;max-width:600px;background:var(--sys-surface-container, #eeedf1)}.sat-platform-nav-switcher-menu.sat-platform-nav-switcher-menu--expanded{min-width:300px;max-width:600px}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item{display:flex;justify-content:space-between;align-items:center;min-height:48px;padding:4px 16px;position:relative;color:var(--sys-on-surface, #1a1c1e);box-sizing:border-box;cursor:pointer;user-select:none;-webkit-user-select:none}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item .sat-platform-nav-switcher-item-content{font-family:var(--sat-platform-nav-title-font, \"Noto Sans\");font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:400;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem)}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item:hover:not(.sat-platform-nav-switcher-item--disabled){background:var(--sat-environment-switcher-hover-layer-color)}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--active:not(.sat-platform-nav-switcher-item--disabled){background:var(--sys-secondary-container, #e2dfff);color:var(--sys-on-secondary-container, #181838)}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled{cursor:default;pointer-events:none}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled .sat-platform-nav-switcher-item-content{opacity:.38}.sat-environment-switcher-ripple{inset:0;position:absolute;pointer-events:none}\n"], dependencies: [{ kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav', standalone: true, imports: [MatTooltipModule, MatRipple, TranslatePipe], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div\n  class=\"sat-platform-nav-panel sat-light-theme-system-variables\"\n  [class.sat-neutral-theme]=\"neutralTheme()\"\n  [class.sat-platform-nav-panel-expanded]=\"!service.collapsed()\"\n>\n  <h2 class=\"sat-platform-nav-title\">\n    <button\n      matRipple\n      type=\"button\"\n      matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n      id=\"sat-platform-nav-title-icon\"\n      title=\"sat-platform-nav-title-icon\"\n      class=\"sat-platform-nav-item\"\n      [matTooltip]=\"(service.collapsed() ? 'platform-nav.expand' : 'platform-nav.collapse') | translate\"\n      matTooltipPosition=\"below\"\n      (click)=\"service.toggleCollapsed()\"\n      [attr.data-automation-id]=\"service.collapsed() ? 'platform-nav-expand-button' : 'platform-nav-collapse-button'\"\n      [attr.aria-pressed]=\"service.collapsed() ? false : true\"\n    >\n      <svg\n        xmlns=\"http://www.w3.org/2000/svg\"\n        width=\"32\"\n        height=\"32\"\n        viewBox=\"0 0 32 32\"\n        fill=\"none\"\n        class=\"sat-platform-nav-title-icon\"\n      >\n        <path d=\"M15.2736 8L10.6997 15.997H15.997L20.5708 8H15.2736Z\" fill=\"white\" />\n        <path d=\"M5.40245 15.9984L0.828857 23.9954H6.12612L10.6997 15.9984H5.40245Z\" fill=\"white\" />\n        <path d=\"M16.002 16.0028L11.4284 24H16.7257L21.2993 16.0028H16.002Z\" fill=\"white\" />\n        <path d=\"M25.8734 8.00474L21.2993 16.0027H26.5971L31.1712 8.00474H25.8734Z\" fill=\"white\" />\n      </svg>\n    </button>\n    @if (!service.collapsed()) {\n      Content Innovation Cloud\n    }\n  </h2>\n  <ng-content select=\"sat-platform-nav-switcher\"></ng-content>\n  <nav class=\"sat-platform-nav-list\" (mouseleave)=\"onMouseLeave()\">\n    <ng-content></ng-content>\n  </nav>\n  <ng-content select=\"sat-platform-nav-user\"></ng-content>\n</div>\n", styles: ["sat-platform-nav .sat-neutral-theme{--sat-platform-nav-background: var(--sys-inverse-surface, #2f3033);--sat-platform-nav-on-background: var(--sys-on-primary, #fff);--sat-platform-nav-outline: var(--sys-outline, #777683);--sat-platform-nav-icon-color: var(--sys-on-surface, #1a1c1e);--sat-platform-nav-primary-loud: var(--sat-sys-inverse-surface-loud, #101112);--sat-platform-nav-avatar-color: var(--sat-sys-inverse-surface-loud, #101112)}sat-platform-nav .sat-platform-nav-panel{position:fixed;background-color:var(--sat-platform-nav-background, var(--sys-primary, #5654ac));display:flex;flex-direction:column;height:var(--sat-platform-nav-height-max, 100%);width:var(--sat-platform-nav-collapsed-width, 56px);z-index:1000;box-sizing:border-box;overflow:hidden;transition:width var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}sat-platform-nav h2.sat-platform-nav-title{display:flex;align-items:center;margin:8px 4px;white-space:nowrap;height:var(--sat-platform-nav-height-high, 48px);flex-shrink:0;color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff));font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-title-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-title-letter-spacing, .009rem)}sat-platform-nav p.sat-platform-nav-item-label{font-family:var(--sat-platform-nav-label-large-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-large-size, .875rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-large-line-height, 1.25rem);letter-spacing:var(--sat-platform-nav-label-large-tracking, .006rem);margin:0}sat-platform-nav .sat-platform-nav-avatar{font-family:var(--sat-platform-nav-label-medium-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-medium-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .0031rem);display:flex;justify-content:center;align-items:center;width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px);border-radius:var(--sat-platform-nav-corner-extra-small, 4px);background-color:var(--sat-platform-nav-avatar-color, var(--sys-inverse-surface, #2f3033));color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff))}sat-platform-nav .sat-platform-nav-user-avatar .sat-platform-nav-avatar{border-radius:50%}sat-platform-nav .sat-platform-nav-hidden{display:none}sat-platform-nav .sat-platform-nav-list{padding:0 4px 2px;flex-grow:1;overflow-x:hidden;overflow-y:hidden;-ms-overflow-style:auto}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar{width:4px;height:4px}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-track{background:transparent}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-thumb{background:var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0));border-radius:var(--sat-platform-nav-corner-full, 1000px)}sat-platform-nav sat-platform-nav-switcher+.sat-platform-nav-list{padding-top:10px}sat-platform-nav .sat-platform-nav-title+.sat-platform-nav-list{padding-top:48px}sat-platform-nav .sat-platform-nav-list:hover{overflow-y:scroll;padding-right:0}sat-platform-nav .sat-platform-nav-item{position:relative;display:flex;align-items:center;padding:0 10px;white-space:nowrap;text-decoration:none;background:none;box-sizing:border-box;border:none;gap:var(--sat-platform-nav-gap-medium, 12px);height:var(--sat-platform-nav-height-high, 48px);width:var(--sat-platform-nav-width-max, 100%);flex-shrink:0;cursor:pointer;color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff));border-radius:var(--sat-platform-nav-corner-medium, 12px)}sat-platform-nav .sat-platform-nav-item:hover{background-color:var(--sat-sys-on-primary-opacity-08, rgba(255, 255, 255, .08))}sat-platform-nav .sat-platform-nav-item:active{background-color:var(--sat-sys-on-primary-opacity-12, rgba(255, 255, 255, .12))}sat-platform-nav .sat-platform-nav-item:focus-visible{outline:2px solid var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0));outline-offset:-2px}sat-platform-nav .sat-platform-nav-title .sat-platform-nav-item{width:var(--sat-platform-nav-width-high, 48px);padding:0 8px;border-radius:50%}sat-platform-nav .sat-platform-nav-item-active{background-color:var(--sat-sys-on-primary-opacity-12, rgba(255, 255, 255, .12))}sat-platform-nav .sat-platform-nav-item-active:focus,sat-platform-nav .sat-platform-nav-item-active:hover{background-color:var(--sat-sys-on-primary-opacity-12, rgba(255, 255, 255, .12))}sat-platform-nav .sat-platform-nav-item-active:focus-visible{outline:2px solid var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0));outline-offset:-2px}sat-platform-nav .sat-platform-nav-item-active:active,sat-platform-nav .sat-platform-nav-item-active:focus:active,sat-platform-nav .sat-platform-nav-item-active:focus-visible:active{background-color:var(--sat-sys-on-primary-opacity-08, rgba(255, 255, 255, .08))}sat-platform-nav .sat-platform-nav-icon{width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px);display:flex;justify-content:center;align-items:center;background:none;border:none;padding:0;cursor:pointer;flex-shrink:0;border-radius:var(--sat-platform-nav-corner-extra-small, 4px)}sat-platform-nav .sat-platform-nav-icon .mat-icon{width:var(--sat-platform-nav-width-small, 24px);height:var(--sat-platform-nav-height-small, 24px)}sat-platform-nav .sat-platform-nav-icon img{width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px)}sat-platform-nav .sat-platform-nav-icon .sat-platform-nav-avatar img{width:100%;height:100%;border-radius:var(--sat-platform-nav-corner-extra-small, 4px);aspect-ratio:1/1;object-fit:contain}sat-platform-nav .sat-platform-nav-title-icon{width:32px;height:32px}sat-platform-nav .sat-platform-nav-list-item-active-indicator{position:absolute;top:14px;left:0;width:4px;height:20px;border-radius:0 var(--sat-platform-nav-corner-large, 16px) var(--sat-platform-nav-corner-large, 16px) 0;background:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff))}sat-platform-nav .sat-platform-nav-switcher-button{height:56px;gap:0;border-radius:0;width:100%;background-color:var(--sat-platform-nav-primary-loud, var(--sat-sys-primary-loud, #322f86));color:var(--sat-platform-nav-on-background, var(--sys-on-primary, #fff))}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text{display:flex;align-items:center;gap:12px;flex-grow:1}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;width:208px}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-label{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-body-small-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .031rem);user-select:none;-webkit-user-select:none}sat-platform-nav .sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-value{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;width:100%;font-weight:400;text-align:left;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem);white-space:nowrap;overflow:hidden;user-select:none;-webkit-user-select:none;text-overflow:ellipsis}sat-platform-nav .sat-platform-nav-switcher-button.sat-platform-nav-switcher-button--disabled{cursor:default;pointer-events:none;opacity:.38}sat-platform-nav .sat-platform-nav-panel .sat-platform-nav-switcher-button{padding:4px 3px 4px 14px}sat-platform-nav .sat-platform-nav-panel .mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:-5px;width:16px;height:16px}sat-platform-nav .sat-platform-nav-panel-expanded{width:var(--sat-platform-nav-expanded-width, 300px)}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-switcher-button{padding:4px 14px}sat-platform-nav .sat-platform-nav-panel-expanded .mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:0;width:24px;height:24px}@-moz-document url-prefix(){sat-platform-nav .sat-platform-nav-list{scrollbar-gutter:stable;scrollbar-width:thin;scrollbar-color:var(--sat-platform-nav-outline, var(--sys-outline-variant, #c8c6d0)) transparent}sat-platform-nav .sat-platform-nav-list:hover{padding-right:4px!important}}.sat-platform-nav-switcher-menu{display:flex;flex-direction:column;padding:8px 0;align-items:flex-start;align-self:stretch;border-radius:4px;min-width:112px;max-width:600px;background:var(--sys-surface-container, #eeedf1)}.sat-platform-nav-switcher-menu.sat-platform-nav-switcher-menu--expanded{min-width:300px;max-width:600px}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item{display:flex;justify-content:space-between;align-items:center;min-height:48px;padding:4px 16px;position:relative;color:var(--sys-on-surface, #1a1c1e);box-sizing:border-box;cursor:pointer;user-select:none;-webkit-user-select:none}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item .sat-platform-nav-switcher-item-content{font-family:var(--sat-platform-nav-title-font, \"Noto Sans\");font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:400;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem)}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item:hover:not(.sat-platform-nav-switcher-item--disabled){background:var(--sat-environment-switcher-hover-layer-color)}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--active:not(.sat-platform-nav-switcher-item--disabled){background:var(--sys-secondary-container, #e2dfff);color:var(--sys-on-secondary-container, #181838)}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled{cursor:default;pointer-events:none}.sat-platform-nav-switcher-menu .sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled .sat-platform-nav-switcher-item-content{opacity:.38}.sat-environment-switcher-ripple{inset:0;position:absolute;pointer-events:none}\n"] }]
        }] });

const COMPONENTS = [
    SatPlatformNavComponent,
    SatPlatformNavContainerComponent,
    SatPlatformNavMainContentComponent,
    SatPlatformNavListItemComponent,
    SatPlatformNavUserProfileComponent,
    SatPlatformNavUserComponent,
    SatPlatformNavAvatarComponent,
    SatPlatformNavEnvironmentSwitcherComponent,
];
const PIPES = [SatPlatformNavInitialsPipe];
const DIRECTIVES = [SatPlatformNavUserMenuDirective];
class SatPlatformNavModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavModule, imports: [SatPlatformNavComponent,
            SatPlatformNavContainerComponent,
            SatPlatformNavMainContentComponent,
            SatPlatformNavListItemComponent,
            SatPlatformNavUserProfileComponent,
            SatPlatformNavUserComponent,
            SatPlatformNavAvatarComponent,
            SatPlatformNavEnvironmentSwitcherComponent, SatPlatformNavInitialsPipe, SatPlatformNavUserMenuDirective], exports: [SatPlatformNavComponent,
            SatPlatformNavContainerComponent,
            SatPlatformNavMainContentComponent,
            SatPlatformNavListItemComponent,
            SatPlatformNavUserProfileComponent,
            SatPlatformNavUserComponent,
            SatPlatformNavAvatarComponent,
            SatPlatformNavEnvironmentSwitcherComponent, SatPlatformNavInitialsPipe, SatPlatformNavUserMenuDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavModule, providers: [SatPlatformNavStateService, SatPlatformNavTooltipService], imports: [SatPlatformNavComponent,
            SatPlatformNavContainerComponent,
            SatPlatformNavListItemComponent,
            SatPlatformNavUserProfileComponent,
            SatPlatformNavEnvironmentSwitcherComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatPlatformNavModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...COMPONENTS, ...PIPES, ...DIRECTIVES],
                    exports: [...COMPONENTS, ...PIPES, ...DIRECTIVES],
                    providers: [SatPlatformNavStateService, SatPlatformNavTooltipService],
                }]
        }] });

const transformRichTooltip = trigger('transformRichTooltip', [
    state('enter', style({
        opacity: 1,
        transform: `scale(1)`,
    })),
    transition('void => *', [
        style({
            opacity: 0,
            transform: `scale(0)`,
        }),
        animate(`200ms cubic-bezier(0.25, 0.8, 0.25, 1)`),
    ]),
    transition('* => void', [animate('50ms 100ms linear', style({ opacity: 0 }))]),
]);

/**
 * Throws an exception for the case when tooltip's x-position value isn't valid.
 * In other words, it doesn't match 'before' or 'after'.
 * @docs-private
 */
function throwRichTooltipInvalidPositionX() {
    throw Error(`positionX value must be either 'before' or 'after'.
    Example: <sat-rich-tooltip positionX="before" #tooltip="satRichTooltip"></sat-rich-tooltip>`);
}
/**
 * Throws an exception for the case when tooltip's y-position value isn't valid.
 * In other words, it doesn't match 'above' or 'below'.
 * @docs-private
 */
function throwRichTooltipInvalidPositionY() {
    throw Error(`positionY value must be either 'above' or 'below'.
    Example: <sat-rich-tooltip positionY="above" #tooltip="satRichTooltip"></sat-rich-tooltip>`);
}
/**
 * Throws an exception for the case when the trigger doesn't have a valid rich tooltip instance.
 * @docs-private
 */
function throwRichTooltipMissingError() {
    throw Error(`satRichTooltipTriggerFor: must pass in a rich-tooltip instance.
    Example:
      <sat-rich-tooltip #tooltip="satRichTooltip"></sat-rich-tooltip>
      <button [satRichTooltipTriggerFor]="tooltip"></button>`);
}

/** Counter for generating unique element ids.
 * This is needed for accessibility.
 */
let idCounter = 0;
class SatRichTooltipComponent {
    /** Settings for richTooltip, view setters and getters for more detail */
    _positionX = 'after';
    _positionY = 'below';
    _behavior = 'transient';
    _scrollStrategy = 'reposition';
    _showDelay = 200;
    _hideDelay = 1500;
    _overlapTrigger = false;
    _disableAnimation = false;
    _targetOffsetX = 0;
    _targetOffsetY = 20;
    _closeOnClick = false;
    _focusTrapEnabled = true;
    _focusTrapAutoCaptureEnabled = true;
    _uniqueId = idCounter++;
    _titleUniqueId = `sat-rich-tooltip-${this._uniqueId}-title`;
    _contentUniqueId = `sat-rich-tooltip-${this._uniqueId}-content`;
    /** Config object to be passed into the richTooltip's ngClass */
    classList = {};
    /** Closing disabled on richTooltip */
    closeDisabled = false;
    /** unique id for the rich tooltip panel. */
    id = input(`sat-rich-tooltip-${this._uniqueId}`);
    /** aria-label for the rich tooltip panel. */
    ariaLabel = input('Rich Tooltip', { alias: 'aria-label' });
    /** aria-labelledby for the rich tooltip panel. This needs to be same with the id for the title element */
    ariaLabelledby = input(this._titleUniqueId, { alias: 'aria-labelledby' });
    /** aria-describedby for the rich tooltip panel. This needs to be same with the id for the content */
    ariaDescribedby = input(this._contentUniqueId, { alias: 'aria-describedby' });
    /**
     * Position of the richTooltip in the X axis.
     * @default after
     */
    positionX = input(this._positionX, {
        transform: (value) => {
            if (value !== 'before' && value !== 'after') {
                throwRichTooltipInvalidPositionX();
            }
            this._positionX = value;
            this.setPositionClasses();
            return value;
        },
    });
    /**
     * Position of the richTooltip in the Y axis.
     * @default below
     */
    positionY = input(this._positionY, {
        transform: (value) => {
            if (value !== 'above' && value !== 'below') {
                throwRichTooltipInvalidPositionY();
            }
            this._positionY = value;
            this.setPositionClasses();
            return value;
        },
    });
    /**
     * RichTooltip behavior type
     * @default transient
     */
    behavior = input(this._behavior);
    /**
     * RichTooltip scroll strategy
     * @default reposition
     */
    scrollStrategy = input(this._scrollStrategy);
    /**
     * RichTooltip enter delay
     * @default 200
     */
    showDelay = input(this._showDelay);
    /**
     * RichTooltip leave delay
     * @default 1.5 seconds
     */
    hideDelay = input(this._hideDelay);
    /**
     * RichTooltip overlap trigger
     * @default false
     */
    overlapTrigger = input(this._overlapTrigger);
    /**
     * RichTooltip horizontal target offset
     * @default 0
     */
    targetOffsetX = input(this._targetOffsetX);
    /** RichTooltip vertical target offset
     * @default 20
     */
    targetOffsetY = input(this._targetOffsetY);
    /**
     * RichTooltip container close on click
     * @default false
     */
    closeOnClick = input(this._closeOnClick, {
        transform: (value) => coerceBooleanProperty(value),
    });
    /**
     * Disable animations of richTooltip and all child elements
     * @default false
     */
    disableAnimation = input(this._disableAnimation, {
        transform: (value) => coerceBooleanProperty(value),
    });
    /**
     * Rich Tooltip focus trap using cdkTrapFocus
     * @default true
     */
    focusTrapEnabled = input(this._focusTrapEnabled, {
        transform: (value) => coerceBooleanProperty(value),
    });
    /**
     * Rich Tooltip focus trap auto capture using cdkTrapFocusAutoCapture
     * @default true
     */
    focusTrapAutoCaptureEnabled = input(this._focusTrapAutoCaptureEnabled, {
        transform: (value) => coerceBooleanProperty(value),
    });
    /**
     * Event emitted when the richTooltip is closed.
     */
    // TODO: consider to rename this event `close` seems to be a native event name for WebSockets.
    // eslint-disable-next-line @angular-eslint/no-output-native
    close = output();
    templateRef = viewChild(TemplateRef);
    monitoredEl = viewChild('monitoredEl');
    constructor() {
        this.setPositionClasses();
    }
    /** Handle a keyboard event from the richTooltip, delegating to the appropriate action. */
    handleKeydown(event) {
        switch (event.keyCode) {
            case ESCAPE:
                this.emitCloseEvent();
                return;
        }
    }
    /**
     * This emits a close event to which the trigger is subscribed. When emitted, the
     * trigger will close the richTooltip.
     */
    emitCloseEvent() {
        this.close.emit();
    }
    /** Close richTooltip on click if closeOnClick is true */
    onClick() {
        if (this.closeOnClick()) {
            this.emitCloseEvent();
        }
    }
    /** Disables close of richTooltip when leaving trigger element and focus on the richTooltip either by keyboard or by mouse */
    onFocus() {
        if (this.behavior() === 'transient') {
            this.closeDisabled = true;
        }
    }
    /** Enables close of richTooltip when mouse leaving richTooltip element or the tooltip is loosing focus */
    onFocusOut() {
        if (this.behavior() === 'transient') {
            this.closeDisabled = false;
            this.emitCloseEvent();
        }
    }
    /**
     * It's necessary to set position-based classes to ensure the richTooltip panel animation
     * folds out from the correct direction.
     */
    setPositionClasses(posX = this.positionX(), posY = this.positionY()) {
        this.classList['sat-rich-tooltip-before'] = posX === 'before';
        this.classList['sat-rich-tooltip-after'] = posX === 'after';
        this.classList['sat-rich-tooltip-above'] = posY === 'above';
        this.classList['sat-rich-tooltip-below'] = posY === 'below';
    }
    ngOnDestroy() {
        this.emitCloseEvent();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "18.2.13", type: SatRichTooltipComponent, isStandalone: true, selector: "sat-rich-tooltip", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledby: { classPropertyName: "ariaLabelledby", publicName: "aria-labelledby", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "aria-describedby", isSignal: true, isRequired: false, transformFunction: null }, positionX: { classPropertyName: "positionX", publicName: "positionX", isSignal: true, isRequired: false, transformFunction: null }, positionY: { classPropertyName: "positionY", publicName: "positionY", isSignal: true, isRequired: false, transformFunction: null }, behavior: { classPropertyName: "behavior", publicName: "behavior", isSignal: true, isRequired: false, transformFunction: null }, scrollStrategy: { classPropertyName: "scrollStrategy", publicName: "scrollStrategy", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: true, isRequired: false, transformFunction: null }, overlapTrigger: { classPropertyName: "overlapTrigger", publicName: "overlapTrigger", isSignal: true, isRequired: false, transformFunction: null }, targetOffsetX: { classPropertyName: "targetOffsetX", publicName: "targetOffsetX", isSignal: true, isRequired: false, transformFunction: null }, targetOffsetY: { classPropertyName: "targetOffsetY", publicName: "targetOffsetY", isSignal: true, isRequired: false, transformFunction: null }, closeOnClick: { classPropertyName: "closeOnClick", publicName: "closeOnClick", isSignal: true, isRequired: false, transformFunction: null }, disableAnimation: { classPropertyName: "disableAnimation", publicName: "disableAnimation", isSignal: true, isRequired: false, transformFunction: null }, focusTrapEnabled: { classPropertyName: "focusTrapEnabled", publicName: "focusTrapEnabled", isSignal: true, isRequired: false, transformFunction: null }, focusTrapAutoCaptureEnabled: { classPropertyName: "focusTrapAutoCaptureEnabled", publicName: "focusTrapAutoCaptureEnabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { close: "close" }, viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true, isSignal: true }, { propertyName: "monitoredEl", first: true, predicate: ["monitoredEl"], descendants: true, isSignal: true }], exportAs: ["satRichTooltip"], ngImport: i0, template: "<ng-template>\n  <div\n    class=\"sat-rich-tooltip-container mat-elevation-z2\"\n    role=\"tooltip\"\n    [id]=\"id()\"\n    [class.sat-rich-tooltip-overlap]=\"overlapTrigger()\"\n    [ngClass]=\"classList\"\n    (keydown)=\"handleKeydown($event)\"\n    (click)=\"onClick()\"\n    (mouseover)=\"onFocus()\"\n    (focus)=\"onFocus()\"\n    (mouseleave)=\"onFocusOut()\"\n    [@.disabled]=\"disableAnimation()\"\n    [cdkTrapFocus]=\"focusTrapEnabled()\"\n    [cdkTrapFocusAutoCapture]=\"focusTrapAutoCaptureEnabled()\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-labelledby]=\"ariaLabelledby()\"\n    [attr.aria-describedby]=\"ariaDescribedby()\"\n    [@transformRichTooltip]=\"'enter'\"\n  >\n    <ng-content select=\"sat-rich-tooltip-title\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-content\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-actions\"></ng-content>\n  </div>\n</ng-template>\n", styles: [".sat-rich-tooltip-container{display:grid;padding-bottom:8px;gap:4px;border-radius:12px}.sat-rich-tooltip-title{display:block;align-self:stretch;margin:12px 16px 0}.sat-rich-tooltip-content{display:block;align-self:stretch;margin:0 16px;overflow:auto;max-height:25vh;max-width:40vw}.sat-rich-tooltip-actions{display:flex;align-items:center;margin:8px 8px 0;gap:8px;align-self:stretch}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-start{justify-content:start}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-center{justify-content:center}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-end{justify-content:flex-end}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }], animations: [transformRichTooltip], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-rich-tooltip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, animations: [transformRichTooltip], imports: [CommonModule, CdkTrapFocus], exportAs: 'satRichTooltip', template: "<ng-template>\n  <div\n    class=\"sat-rich-tooltip-container mat-elevation-z2\"\n    role=\"tooltip\"\n    [id]=\"id()\"\n    [class.sat-rich-tooltip-overlap]=\"overlapTrigger()\"\n    [ngClass]=\"classList\"\n    (keydown)=\"handleKeydown($event)\"\n    (click)=\"onClick()\"\n    (mouseover)=\"onFocus()\"\n    (focus)=\"onFocus()\"\n    (mouseleave)=\"onFocusOut()\"\n    [@.disabled]=\"disableAnimation()\"\n    [cdkTrapFocus]=\"focusTrapEnabled()\"\n    [cdkTrapFocusAutoCapture]=\"focusTrapAutoCaptureEnabled()\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-labelledby]=\"ariaLabelledby()\"\n    [attr.aria-describedby]=\"ariaDescribedby()\"\n    [@transformRichTooltip]=\"'enter'\"\n  >\n    <ng-content select=\"sat-rich-tooltip-title\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-content\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-actions\"></ng-content>\n  </div>\n</ng-template>\n", styles: [".sat-rich-tooltip-container{display:grid;padding-bottom:8px;gap:4px;border-radius:12px}.sat-rich-tooltip-title{display:block;align-self:stretch;margin:12px 16px 0}.sat-rich-tooltip-content{display:block;align-self:stretch;margin:0 16px;overflow:auto;max-height:25vh;max-width:40vw}.sat-rich-tooltip-actions{display:flex;align-items:center;margin:8px 8px 0;gap:8px;align-self:stretch}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-start{justify-content:start}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-center{justify-content:center}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-end{justify-content:flex-end}\n"] }]
        }], ctorParameters: () => [] });

class SatRichTooltipCloseDirective {
    tooltip = inject(SatRichTooltipComponent);
    onClose(event) {
        event.stopPropagation(); // Prevent event bubbling
        this.tooltip.emitCloseEvent(); // Call the close method on the tooltip instance
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipCloseDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.13", type: SatRichTooltipCloseDirective, isStandalone: true, selector: "[sat-rich-tooltip-close], [satRichTooltipClose]", host: { listeners: { "click": "onClose($event)" }, properties: { "attr.aria-label": "ariaLabel || null", "attr.type": "type" } }, exportAs: ["satRichTooltipClose"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipCloseDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sat-rich-tooltip-close], [satRichTooltipClose]',
                    standalone: true,
                    exportAs: 'satRichTooltipClose',
                    host: {
                        '[attr.aria-label]': 'ariaLabel || null',
                        '[attr.type]': 'type',
                    },
                }]
        }], propDecorators: { onClose: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class SatRichTooltipActionsComponent {
    tooltip = inject(SatRichTooltipComponent);
    /**
     * Alignment of the actions
     * @default
     * 'start'
     */
    align = input('start');
    /**
     * Whether the close feature should be required
     * @default
     * false
     */
    requireCloseFeature = input(false);
    get tooltipBehaviour() {
        return this.tooltip.behavior();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.13", type: SatRichTooltipActionsComponent, isStandalone: true, selector: "sat-rich-tooltip-actions", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, requireCloseFeature: { classPropertyName: "requireCloseFeature", publicName: "requireCloseFeature", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.sat-rich-tooltip-actions-align-start": "align() === \"start\"", "class.sat-rich-tooltip-actions-align-center": "align() === \"center\"", "class.sat-rich-tooltip-actions-align-end": "align() === \"end\"" }, classAttribute: "sat-rich-tooltip-actions" }, ngImport: i0, template: "<ng-content select=\"[button, a]\"></ng-content>\n\n@if (requireCloseFeature() || tooltipBehaviour === 'persistent') {\n  <button mat-button type=\"button\" sat-rich-tooltip-close>Close</button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "directive", type: SatRichTooltipCloseDirective, selector: "[sat-rich-tooltip-close], [satRichTooltipClose]", exportAs: ["satRichTooltipClose"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipActionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-rich-tooltip-actions', standalone: true, host: {
                        'class': 'sat-rich-tooltip-actions',
                        '[class.sat-rich-tooltip-actions-align-start]': 'align() === "start"',
                        '[class.sat-rich-tooltip-actions-align-center]': 'align() === "center"',
                        '[class.sat-rich-tooltip-actions-align-end]': 'align() === "end"',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [MatButtonModule, SatRichTooltipCloseDirective], template: "<ng-content select=\"[button, a]\"></ng-content>\n\n@if (requireCloseFeature() || tooltipBehaviour === 'persistent') {\n  <button mat-button type=\"button\" sat-rich-tooltip-close>Close</button>\n}\n" }]
        }] });

class SatRichTooltipContentComponent {
    elementRef = inject(ElementRef);
    tooltip = inject(SatRichTooltipComponent);
    /** aria-label for the rich tooltip content. */
    ariaLabel = input('', { alias: 'aria-label' });
    get getAriaLabel() {
        return this.elementRef.nativeElement.textContent?.trim();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "18.2.13", type: SatRichTooltipContentComponent, isStandalone: true, selector: "sat-rich-tooltip-content", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-label": "ariaLabel() || getAriaLabel", "attr.id": "tooltip.ariaDescribedby()" }, classAttribute: "sat-rich-tooltip-content" }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-rich-tooltip-content',
                    template: `<ng-content></ng-content>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    standalone: true,
                    host: {
                        'class': 'sat-rich-tooltip-content',
                        '[attr.aria-label]': 'ariaLabel() || getAriaLabel',
                        '[attr.id]': 'tooltip.ariaDescribedby()',
                    },
                }]
        }] });

class SatRichTooltipTitleComponent {
    elementRef = inject(ElementRef);
    tooltip = inject(SatRichTooltipComponent);
    /** aria-label for the rich tooltip title. */
    ariaLabel = input('', { alias: 'aria-label' });
    get getAriaLabel() {
        return this.elementRef.nativeElement.textContent?.trim();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipTitleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "18.2.13", type: SatRichTooltipTitleComponent, isStandalone: true, selector: "sat-rich-tooltip-title", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-label": "ariaLabel() || getAriaLabel", "attr.id": "tooltip.ariaLabelledby()" }, classAttribute: "sat-rich-tooltip-title" }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipTitleComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-rich-tooltip-title',
                    template: `<ng-content></ng-content>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    standalone: true,
                    host: {
                        'class': 'sat-rich-tooltip-title',
                        '[attr.aria-label]': 'ariaLabel() || getAriaLabel',
                        '[attr.id]': 'tooltip.ariaLabelledby()',
                    },
                }]
        }] });

class RichTooltipOverlayService {
    overlay = inject(Overlay);
    directionality = inject(Directionality);
    /**
     *  This method creates the overlay from the provided richTooltip's template and saves its
     *  OverlayRef so that it can be attached to the DOM when openRichTooltip is called.
     */
    createOverlay(tooltip) {
        return this.overlay.create(this.getOverlayConfig(tooltip));
    }
    /** The text direction of the containing app. */
    get dir() {
        return this.directionality && this.directionality.value === 'rtl' ? 'rtl' : 'ltr';
    }
    /**
     * This method builds the configuration object needed to create the overlay, the OverlayConfig.
     * @returns OverlayConfig
     */
    getOverlayConfig(tooltip) {
        const overlayState = new OverlayConfig();
        /** Display overlay backdrop if trigger event is click */
        if (tooltip.behavior() === 'persistent') {
            overlayState.hasBackdrop = true;
            overlayState.backdropClass = 'cdk-overlay-transparent-backdrop';
        }
        overlayState.direction = this.dir;
        overlayState.scrollStrategy = this.getOverlayScrollStrategy(tooltip.scrollStrategy());
        return overlayState;
    }
    /**
     * This method returns the scroll strategy used by the cdk/overlay.
     */
    getOverlayScrollStrategy(strategy) {
        switch (strategy) {
            case 'noop':
                return this.overlay.scrollStrategies.noop();
            case 'close':
                return this.overlay.scrollStrategies.close();
            case 'block':
                return this.overlay.scrollStrategies.block();
            case 'reposition':
            default:
                return this.overlay.scrollStrategies.reposition();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RichTooltipOverlayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RichTooltipOverlayService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RichTooltipOverlayService, decorators: [{
            type: Injectable
        }] });

class RichTooltipPositionService {
    overlay = inject(Overlay);
    _ngZone = inject(NgZone);
    /**
     * This method builds the position strategy for the overlay, so the richTooltip is properly connected
     * to the trigger.
     * @returns ConnectedPositionStrategy
     */
    getPosition(tooltip, elementRef) {
        const [originX, originFallbackX] = tooltip.positionX() === 'before' ? ['end', 'start'] : ['start', 'end'];
        const [overlayY, overlayFallbackY] = tooltip.positionY() === 'above' ? ['bottom', 'top'] : ['top', 'bottom'];
        let originY = overlayY;
        let originFallbackY = overlayFallbackY;
        const overlayX = originX;
        const overlayFallbackX = originFallbackX;
        let offsetX = 0;
        let offsetY = 0;
        /**
         * Reverse overlayY and fallbackOverlayY when overlapTrigger is false.
         * Also update the horizontal and vertical offset
         */
        if (!tooltip.overlapTrigger()) {
            originY = overlayY === 'top' ? 'bottom' : 'top';
            originFallbackY = overlayFallbackY === 'top' ? 'bottom' : 'top';
            if (tooltip.targetOffsetX() && !isNaN(Number(tooltip.targetOffsetX()))) {
                const targetOffsetX = Number(tooltip.targetOffsetX());
                // Need to have a horizontal offset if provided by the input
                if (originX === 'start')
                    offsetX = targetOffsetX;
                // Need to have the horizontal offset in the negetive direction
                else
                    offsetX = -targetOffsetX;
            }
            if (tooltip.targetOffsetY() && !isNaN(Number(tooltip.targetOffsetY()))) {
                const targetOffsetY = Number(tooltip.targetOffsetY());
                // Need to have a vertical offset if provided by the input
                if (originY === 'bottom')
                    offsetY = targetOffsetY;
                // Need to have the vertical offset in the negetive direction
                else
                    offsetY = -targetOffsetY;
            }
        }
        return this.overlay
            .position()
            .flexibleConnectedTo(elementRef)
            .withLockedPosition(true)
            .withPush(true) // Enables pushing the overlay into the viewport
            .withViewportMargin(8) // Set an 8px margin to keep the overlay from touching the viewport edges.
            .withPositions([
            {
                originX,
                originY,
                overlayX,
                overlayY,
                offsetY,
            },
            {
                originX: originFallbackX,
                originY,
                overlayX: overlayFallbackX,
                overlayY,
                offsetY,
            },
            {
                originX,
                originY: originFallbackY,
                overlayX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
            {
                originX: originFallbackX,
                originY: originFallbackY,
                overlayX: overlayFallbackX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
        ])
            .withDefaultOffsetX(offsetX)
            .withDefaultOffsetY(offsetY);
    }
    /**
     * Listens to changes in the position of the overlay and sets the correct classes
     * on the richTooltip based on the new position. This ensures the animation origin is always
     * correct, even if a fallback position is used for the overlay.
     */
    subscribeToPositions(tooltip, position) {
        return position.positionChanges.subscribe((change) => {
            this._ngZone.run(() => {
                const posX = change.connectionPair.overlayX === 'start' ? 'after' : 'before';
                let posY = change.connectionPair.overlayY === 'top' ? 'below' : 'above';
                if (!tooltip.overlapTrigger()) {
                    posY = posY === 'below' ? 'above' : 'below';
                }
                tooltip.setPositionClasses(posX, posY);
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RichTooltipPositionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RichTooltipPositionService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: RichTooltipPositionService, decorators: [{
            type: Injectable
        }] });

class SatRichTooltipTriggerDirective {
    elementRef = inject(ElementRef);
    viewContainerRef = inject(ViewContainerRef);
    richTooltipOverlayService = inject(RichTooltipOverlayService);
    richTooltipPositionService = inject(RichTooltipPositionService);
    changeDetectorRef = inject(ChangeDetectorRef);
    richTooltipOpen = false;
    richTooltipOpened = new Subject();
    richTooltipClosed = new Subject();
    portal;
    overlayRef = null;
    halt = false; // Restricts the tooltip to be triggered multiple time if there is a delay while opening it.
    backdropSubscription;
    positionSubscription;
    detachmentsSubscription;
    mouseoverTimer;
    openedByMouse = false;
    _ariaDescriptionPending = false;
    /** References the richTooltip instance that the trigger is associated with. */
    tooltip = input.required({ alias: 'satRichTooltipTriggerFor' });
    /** RichTooltip won't open on trigger */
    satRichTooltipDisabled = input(false);
    /** RichTooltip backdrop close on click */
    satRichTooltipBackdropCloseOnClick = input(true);
    /** Event emitted when the associated richTooltip is opened. */
    tooltipOpened = output();
    /** Event emitted when the associated richTooltip is closed. */
    tooltipClosed = output();
    ngAfterViewInit() {
        this.checkRichTooltip();
        this.tooltip().close.subscribe(() => this.closeRichTooltip());
        this._syncAriaDescription();
    }
    onClick(event) {
        if (event && this.tooltip().behavior() === 'persistent') {
            this.toggleRichTooltip();
        }
    }
    onMouseEnter(event) {
        if (event && !this.richTooltipOpen && this.tooltip().behavior() === 'transient') {
            this.checkTooltipToOpen(true);
        }
    }
    onFocus(event) {
        if (event && !this.richTooltipOpen && this.tooltip().behavior() === 'transient') {
            this.checkTooltipToOpen();
        }
    }
    onMouseLeave(event) {
        if (event && this.tooltip().behavior() === 'transient') {
            if (this.richTooltipOpen) {
                if (this.mouseoverTimer) {
                    clearTimeout(this.mouseoverTimer);
                    this.mouseoverTimer = null;
                }
                setTimeout(() => {
                    if (!this.tooltip().closeDisabled) {
                        this.closeRichTooltip();
                    }
                }, this.tooltip().hideDelay());
            }
        }
    }
    checkTooltipToOpen(openedByMouse = false) {
        if (!this.halt) {
            this.halt = true;
            this.openedByMouse = openedByMouse;
            this.mouseoverTimer = setTimeout(() => {
                this.openRichTooltip();
            }, this.tooltip().showDelay());
        }
    }
    handleMousedown(event) {
        if (event && !isFakeMousedownFromScreenReader(event)) {
            this.openedByMouse = true;
        }
    }
    /** Toggles the richTooltip between the open and closed states. */
    toggleRichTooltip() {
        return this.richTooltipOpen ? this.closeRichTooltip() : this.openRichTooltip();
    }
    /** Opens the richTooltip. */
    openRichTooltip() {
        if (!this.satRichTooltipDisabled() && !this.richTooltipOpen) {
            const positionStrategy = this.richTooltipPositionService.getPosition(this.tooltip(), this.elementRef);
            if (!this.overlayRef) {
                const templateRef = this.tooltip().templateRef();
                if (templateRef)
                    this.portal = new TemplatePortal(templateRef, this.viewContainerRef);
                this.overlayRef = this.richTooltipOverlayService.createOverlay(this.tooltip());
                this.overlayRef.updatePositionStrategy(positionStrategy);
                this.positionSubscription = this.richTooltipPositionService.subscribeToPositions(this.tooltip(), positionStrategy);
            }
            this.overlayRef.attach(this.portal);
            // required for ChangeDetectionStrategy.OnPush
            this.changeDetectorRef.markForCheck();
            this.subscribeToBackdrop();
            this.subscribeToDetachments();
            this.initRichTooltip();
        }
    }
    /** Closes the richTooltip. */
    closeRichTooltip() {
        this.overlayRef?.detach();
        this.changeDetectorRef.markForCheck();
        this.resetRichTooltip();
    }
    /** Removes the richTooltip from the DOM. */
    destroyRichTooltip() {
        if (this.mouseoverTimer) {
            clearTimeout(this.mouseoverTimer);
            this.mouseoverTimer = null;
        }
        if (this.overlayRef) {
            this.overlayRef.dispose();
            this.overlayRef = null;
            this.cleanUpSubscriptions();
        }
        this.elementRef.nativeElement.removeAttribute('aria-describedby');
        this._ariaDescriptionPending = false;
        this.richTooltipOpened.complete();
        this.richTooltipClosed.complete();
    }
    /** Updates the tooltip's ARIA description based on rich tooltip id. */
    _syncAriaDescription() {
        if (this._ariaDescriptionPending) {
            return;
        }
        this.elementRef.nativeElement.setAttribute('aria-describedby', this.tooltip().id());
        this._ariaDescriptionPending = true;
    }
    /** Focuses the richTooltip trigger. */
    focus() {
        this.elementRef.nativeElement.focus();
    }
    /**
     * This method ensures that the richTooltip closes when the overlay backdrop is clicked.
     * We do not use first() here because doing so would not catch clicks from within
     * the richTooltip, and it would fail to unsubscribe properly. Instead, we unsubscribe
     * explicitly when the richTooltip is closed or destroyed.
     */
    subscribeToBackdrop() {
        /** Only subscribe to backdrop if trigger event is click */
        if (this.overlayRef) {
            if (this.tooltip().behavior() === 'persistent' &&
                this.satRichTooltipBackdropCloseOnClick() === true) {
                this.overlayRef
                    .backdropClick()
                    .pipe(takeUntil(this.richTooltipClosed))
                    .subscribe(() => {
                    this.tooltip().emitCloseEvent();
                });
            }
        }
    }
    subscribeToDetachments() {
        if (this.overlayRef) {
            this.overlayRef
                .detachments()
                .pipe(takeUntil(this.richTooltipClosed))
                .subscribe(() => {
                this.setRichTooltipClosed();
            });
        }
    }
    /**
     * This method sets the richTooltip state to open and focuses the first item if
     * the richTooltip was opened via the keyboard.
     */
    initRichTooltip() {
        this.setRichTooltipOpened();
    }
    /**
     * This method resets the richTooltip when it's closed, most importantly restoring
     * focus to the richTooltip trigger if the richTooltip was opened via the keyboard.
     */
    resetRichTooltip() {
        this.setRichTooltipClosed();
        // Focus only needs to be reset to the host element if the richTooltip was opened by the keyboard.
        if (!this.openedByMouse) {
            this.focus();
        }
        this.openedByMouse = false;
    }
    /** set state rather than toggle to support triggers sharing a richTooltip */
    setRichTooltipOpened() {
        if (!this.richTooltipOpen) {
            this.richTooltipOpen = true;
            this.halt = false;
            this.richTooltipOpened.next();
            this.tooltipOpened.emit();
        }
    }
    /** set state rather than toggle to support triggers sharing a richTooltip */
    setRichTooltipClosed() {
        if (this.richTooltipOpen) {
            this.richTooltipOpen = false;
            this.richTooltipClosed.next();
            this.tooltipClosed.emit();
        }
    }
    /**
     *  This method checks that a valid instance of MdRichTooltip has been passed into
     *  satRichTooltipTriggerFor. If not, an exception is thrown.
     */
    checkRichTooltip() {
        if (!this.tooltip()) {
            throwRichTooltipMissingError();
        }
    }
    cleanUpSubscriptions() {
        if (this.backdropSubscription) {
            this.backdropSubscription.unsubscribe();
        }
        if (this.positionSubscription) {
            this.positionSubscription.unsubscribe();
        }
        if (this.detachmentsSubscription) {
            this.detachmentsSubscription.unsubscribe();
        }
    }
    ngOnDestroy() {
        this.destroyRichTooltip();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipTriggerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "18.2.13", type: SatRichTooltipTriggerDirective, isStandalone: true, selector: "[satRichTooltipTriggerFor]", inputs: { tooltip: { classPropertyName: "tooltip", publicName: "satRichTooltipTriggerFor", isSignal: true, isRequired: true, transformFunction: null }, satRichTooltipDisabled: { classPropertyName: "satRichTooltipDisabled", publicName: "satRichTooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, satRichTooltipBackdropCloseOnClick: { classPropertyName: "satRichTooltipBackdropCloseOnClick", publicName: "satRichTooltipBackdropCloseOnClick", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { tooltipOpened: "tooltipOpened", tooltipClosed: "tooltipClosed" }, host: { listeners: { "click": "onClick($event)", "mouseenter": "onMouseEnter($event)", "focus": "onFocus($event)", "mouseleave": "onMouseLeave($event)", "mousedown": "handleMousedown($event)" }, properties: { "class.sat-rich-tooltip-disabled": "satRichTooltipDisabled()", "attr.aria-haspopup": "true" }, classAttribute: "sat-rich-tooltip-trigger" }, providers: [RichTooltipOverlayService, RichTooltipPositionService], exportAs: ["satRichTooltipTrigger"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: `[satRichTooltipTriggerFor]`,
                    standalone: true,
                    providers: [RichTooltipOverlayService, RichTooltipPositionService],
                    host: {
                        'class': 'sat-rich-tooltip-trigger',
                        '[class.sat-rich-tooltip-disabled]': 'satRichTooltipDisabled()',
                        '[attr.aria-haspopup]': 'true',
                    },
                    exportAs: 'satRichTooltipTrigger',
                }]
        }], propDecorators: { onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter', ['$event']]
            }], onFocus: [{
                type: HostListener,
                args: ['focus', ['$event']]
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave', ['$event']]
            }], handleMousedown: [{
                type: HostListener,
                args: ['mousedown', ['$event']]
            }] } });

const satRichTooltipArtifacts = [
    SatRichTooltipComponent,
    SatRichTooltipTriggerDirective,
    SatRichTooltipTitleComponent,
    SatRichTooltipContentComponent,
    SatRichTooltipActionsComponent,
    SatRichTooltipCloseDirective,
];
class SatRichTooltipModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipModule, imports: [SatRichTooltipComponent,
            SatRichTooltipTriggerDirective,
            SatRichTooltipTitleComponent,
            SatRichTooltipContentComponent,
            SatRichTooltipActionsComponent,
            SatRichTooltipCloseDirective], exports: [SatRichTooltipComponent,
            SatRichTooltipTriggerDirective,
            SatRichTooltipTitleComponent,
            SatRichTooltipContentComponent,
            SatRichTooltipActionsComponent,
            SatRichTooltipCloseDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipModule, imports: [SatRichTooltipComponent,
            SatRichTooltipActionsComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.13", ngImport: i0, type: SatRichTooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: satRichTooltipArtifacts,
                    exports: satRichTooltipArtifacts,
                }]
        }] });

const httpLoaderFactory = (http) => new TranslateHttpLoader(http, './i18n/', '.json');
/**
 * Default providers for the Satori UI library.
 *
 * This function return providers for configuration of Angular Material components,
 * setting some default options related to Satori UI theme and appearance.
 */
function provideSatoriTheme() {
    return makeEnvironmentProviders([
        {
            provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
            useValue: {
                appearance: 'outline',
                floatLabel: 'always',
            },
        },
        provideAnimations(),
    ]);
}
/**
 * Provides the default translation feature for the Satori UI library.
 * This sets up the translation loader to fetch translation files from the `./i18n/` directory
 * @param languageConfig Configuration for the default language of the application.
 */
function provideSatoriUITranslations(languageConfig) {
    return makeEnvironmentProviders([
        provideHttpClient(),
        provideTranslateService({
            defaultLanguage: languageConfig.default,
            loader: {
                provide: TranslateLoader,
                useFactory: httpLoaderFactory,
                deps: [HttpClient],
            },
        }),
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AppHeaderActionsDirective, AppHeaderComponent, AppHeaderLogoDirective, AppHeaderNavigationDirective, AppHeaderTitleDirective, HeaderComponent, SatAppHeaderModule, SatHMarkLogoComponent, SatAppHeaderModule as SatHeaderModule, SatIconModule, SatLogoComponent, SatLogoModule, SatPlatformNavAvatarComponent, SatPlatformNavComponent, SatPlatformNavContainerComponent, SatPlatformNavEnvironmentSwitcherComponent, SatPlatformNavInitialsPipe, SatPlatformNavListItemComponent, SatPlatformNavMainContentComponent, SatPlatformNavModule, SatPlatformNavStateService, SatPlatformNavUserComponent, SatPlatformNavUserMenuDirective, SatPlatformNavUserProfileComponent, SatRichTooltipActionsComponent, SatRichTooltipCloseDirective, SatRichTooltipComponent, SatRichTooltipContentComponent, SatRichTooltipModule, SatRichTooltipTitleComponent, SatRichTooltipTriggerDirective, SatWordMarkLogoComponent, provideSatoriTheme, provideSatoriUITranslations };
//# sourceMappingURL=hylandsoftware-satori-ui.mjs.map
