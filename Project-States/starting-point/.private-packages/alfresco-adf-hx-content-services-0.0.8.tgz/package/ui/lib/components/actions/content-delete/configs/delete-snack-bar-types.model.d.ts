import { DefaultStatusSnackBarIcon } from '@alfresco/adf-hx-content-services/api';
import { DeletedStatus } from './deleted-status.enum';
export declare const deleteSnackBarTypes: Record<DeletedStatus, DefaultStatusSnackBarIcon>;
