import { BaseFilterFormType, SearchFilterData, SearchFilterValueService, FilterId, BaseSearchFilter } from '@alfresco/adf-hx-content-services/services';
import { EventEmitter } from '@angular/core';
import { FormGroup, AbstractControl } from '@angular/forms';
import { SearchFilterContainerComponent } from '../filters/search-filter-container/search-filter-container.component';
import * as i0 from "@angular/core";
export declare abstract class BaseSearchFilterDirective<T = BaseFilterFormType> implements BaseSearchFilter {
    protected searchFilterValueService: SearchFilterValueService;
    selectedValue?: SearchFilterData;
    filterCleared: EventEmitter<void>;
    filterApplied: EventEmitter<SearchFilterData | undefined>;
    protected searchFilterContainer: SearchFilterContainerComponent;
    protected filterForm: FormGroup;
    protected oldFormValue: T;
    protected initialFormValue: T;
    value?: SearchFilterData;
    [key: string]: any;
    constructor(searchFilterValueService: SearchFilterValueService);
    /**
     * Gets the unique identifier of the filter.
     * Note that filters should contribute their own id to the FilterId type.
     */
    abstract get id(): FilterId;
    clearFilter(): void;
    applyFilter(): void;
    applyChanges(): void;
    clearChanges(): void;
    /**
     * A change is pending if the currently selected value is different from the value already applied.
     */
    hasPendingChanges(): boolean;
    /**
     * Discards pending changes by resetting the selected value to the applied value.
     */
    discardPendingChanges(): void;
    /**
     * Populates whatever properties the filter needs with the provided data and updates the filter container.
     */
    populateWith(data: SearchFilterData): void;
    protected clearForm(): void;
    /**
     * Called when the overlay is closed.
     * Discards any pending changes, because neither clear and filter actions were applied.
     */
    protected overlayClosed(): void;
    /**
     * Converts the provided data value to an HXQL string.
     */
    abstract toHXQL(data: SearchFilterData): string;
    /**
     * Filters extending this class should implement this method to provide the necessary form controls.
     */
    protected abstract getFormControls(): {
        [key: string]: AbstractControl;
    };
    /**
     * Sets the provided data to the filter's internal properties.
     * Filters extending this class should implement this method to populate their properties with the provided data.
     */
    protected abstract setData(data: SearchFilterData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseSearchFilterDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseSearchFilterDirective<any>, never, never, { "selectedValue": { "alias": "selectedValue"; "required": false; }; }, { "filterCleared": "filterCleared"; "filterApplied": "filterApplied"; }, never, never, true, never>;
}
