export declare class FileTypeNode {
    id: string;
    label: string;
    formats: {
        id: string;
        label: string;
        extensions?: string[];
        mimeTypes?: string[];
        mimeTypeIcon: string;
    }[];
}
export declare class FileTypeFlatNode {
    id: string;
    label: string;
    level?: number;
    expandable?: boolean;
    mimeTypes?: string[];
    extensions?: string[];
    mimeTypeIcon: string;
}
export declare const TREE_DATA: FileTypeNode[];
