import { ActionContext, DocumentActionService, DocumentService, HxpNotificationService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class VersionRestoreActionService extends DocumentActionService {
    private hxpNotificationService;
    private documentService;
    constructor(hxpNotificationService: HxpNotificationService, documentService: DocumentService);
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionRestoreActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionRestoreActionService>;
}
