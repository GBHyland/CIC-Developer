import { BaseFilterFormType } from '@alfresco/adf-hx-content-services/services';
export interface SearchTermFormType extends BaseFilterFormType {
    query: string;
    type: string;
}
