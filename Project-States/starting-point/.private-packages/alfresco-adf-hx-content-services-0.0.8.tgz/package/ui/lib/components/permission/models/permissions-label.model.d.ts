import { NewPermission, PermissionLabel } from '@alfresco/adf-hx-content-services/services';
export declare const NewPermissionLabels: Readonly<Record<NewPermission, string>>;
export declare const PermissionLabels: Readonly<Record<PermissionLabel, string>>;
