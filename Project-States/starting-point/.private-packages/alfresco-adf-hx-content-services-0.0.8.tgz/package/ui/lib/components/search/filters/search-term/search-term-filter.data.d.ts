import { SearchFilterData, SearchFilterValue, SearchType } from '@alfresco/adf-hx-content-services/services';
export declare class SearchTermFilterValue implements SearchFilterValue {
    label: string;
    term: string;
    type: SearchType;
}
export declare class SearchTermFilterData implements SearchFilterData {
    values: SearchTermFilterValue[];
    constructor(values?: SearchTermFilterValue[]);
    isEquivalentTo(data?: SearchTermFilterData): boolean;
}
