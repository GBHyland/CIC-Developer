import { Document } from '@hylandsoftware/hxcs-js-client';
import { DocumentRouterService, DocumentVersionsService, HxpNotificationService, VersionableDocument, ContextActionConfiguration } from '@alfresco/adf-hx-content-services/services';
import { VersionContextMenuActionsService } from './version-context-menu.service';
import { EventEmitter, OnChanges, TemplateRef, OnInit } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class ManageVersionsSidebarComponent implements OnInit, OnChanges {
    private documentRouterService;
    private documentVersionsService;
    private hxpNotificationService;
    private dialog;
    private versionContextMenuActionsService;
    /**
     * The document to display the versions for
     * @type {Document}
     */
    document?: Document;
    /**
     * Emits an event when the sidebar is closed
     */
    closeVersionsSidebar: EventEmitter<void>;
    documentVersions: VersionableDocument[];
    isLoading: boolean;
    protected workingCopy: VersionableDocument | undefined;
    protected selectedDocument: VersionableDocument | undefined;
    protected contextActionMenuTemplateRef: TemplateRef<any> | null;
    protected menuTrigger?: MatMenuTrigger;
    protected hiddenTrigger: MatMenuTrigger;
    protected contextMenuPosition: {
        x: string;
        y: string;
    };
    protected contextActions: ContextActionConfiguration[];
    protected isNewContextMenu: boolean;
    private featuresService;
    constructor(documentRouterService: DocumentRouterService, documentVersionsService: DocumentVersionsService, hxpNotificationService: HxpNotificationService, dialog: MatDialog, versionContextMenuActionsService: VersionContextMenuActionsService);
    ngOnInit(): void;
    ngOnChanges(): void;
    redirectToVersion(document: Document): void;
    openEditVersionDialog(version: VersionableDocument): void;
    openDeleteVersionDialog(version: VersionableDocument): void;
    protected onClose(): void;
    protected onContextMenu(event: MouseEvent, version: VersionableDocument): void;
    private getContextActions;
    private loadVersions;
    private updateVersion;
    private deleteVersion;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageVersionsSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ManageVersionsSidebarComponent, "hxp-manage-versions-sidebar", never, { "document": { "alias": "document"; "required": false; }; }, { "closeVersionsSidebar": "closeVersionsSidebar"; }, ["contextActionMenuTemplateRef"], never, true, never>;
}
