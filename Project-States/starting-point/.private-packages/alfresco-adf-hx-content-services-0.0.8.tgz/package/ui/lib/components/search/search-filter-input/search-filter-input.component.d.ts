import { EventEmitter } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class SearchFilterInputComponent {
    private matIconRegistry;
    private domSanitizer;
    applyOnEnter?: boolean;
    inputAriaLabel?: string;
    placeholder?: string;
    clearAriaLabel?: string;
    prefixIcon?: string;
    prefixAriaLabel?: string;
    search: EventEmitter<string>;
    clear: EventEmitter<void>;
    prefixClick: EventEmitter<void>;
    searchTerm: string;
    constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer);
    applyFilter(event: KeyboardEvent): void;
    emitSearch(): void;
    clearInput(): void;
    onPrefixClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFilterInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchFilterInputComponent, "hxp-search-filter-input", never, { "applyOnEnter": { "alias": "applyOnEnter"; "required": false; }; "inputAriaLabel": { "alias": "inputAriaLabel"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "clearAriaLabel": { "alias": "clearAriaLabel"; "required": false; }; "prefixIcon": { "alias": "prefixIcon"; "required": false; }; "prefixAriaLabel": { "alias": "prefixAriaLabel"; "required": false; }; }, { "search": "search"; "clear": "clear"; "prefixClick": "prefixClick"; }, never, never, true, never>;
}
