import { ElementRef, AfterViewInit, SimpleChanges, OnChanges, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormatDocumentPathDirective implements OnChanges, AfterViewInit {
    private el;
    private renderer;
    columnWidths: {
        [key: string]: number;
    };
    private originalText;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private truncatePath;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatDocumentPathDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormatDocumentPathDirective, "[hxpFormatDocumentPath]", never, { "columnWidths": { "alias": "hxpFormatDocumentPath"; "required": false; }; }, {}, never, never, true, never>;
}
