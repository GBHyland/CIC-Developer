import { SearchFilterInputComponent } from './search-filter-input.component';
export declare const getMockInput: () => SearchFilterInputComponent;
