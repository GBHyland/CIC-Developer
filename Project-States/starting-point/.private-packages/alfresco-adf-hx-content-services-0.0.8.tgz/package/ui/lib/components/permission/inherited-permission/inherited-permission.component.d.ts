import { Permission, PermissionLabel } from '@alfresco/adf-hx-content-services/services';
import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare const InheritedPermissionLabels: Readonly<Record<PermissionLabel, string>>;
export declare class InheritedPermissionComponent implements OnChanges {
    permission: Permission;
    inheritanceEnabled: boolean | null;
    protected label: string;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InheritedPermissionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InheritedPermissionComponent, "hxp-inherited-permission", never, { "permission": { "alias": "permission"; "required": false; }; "inheritanceEnabled": { "alias": "inheritanceEnabled"; "required": false; }; }, {}, never, never, true, never>;
}
