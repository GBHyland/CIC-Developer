import { EditPropertiesStatus } from './edit-properties-status.enum';
import { DefaultStatusSnackBarIcon } from '@alfresco/adf-hx-content-services/api';
export declare const editPropertiesSnackBarTypes: Record<EditPropertiesStatus, DefaultStatusSnackBarIcon>;
