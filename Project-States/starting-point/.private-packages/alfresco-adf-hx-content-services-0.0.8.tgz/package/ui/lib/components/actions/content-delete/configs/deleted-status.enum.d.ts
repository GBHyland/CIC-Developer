export declare const DeletedStatus: {
    readonly REQUEST: "REQUEST";
    readonly SUCCESS: "SUCCESS";
    readonly ERROR: "ERROR";
};
export type DeletedStatus = typeof DeletedStatus[keyof typeof DeletedStatus];
