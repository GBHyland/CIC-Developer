import { PermissionsManagementRow } from '@alfresco/adf-hx-content-services/services';
import { AfterContentChecked, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PermissionsTableComponent implements AfterContentChecked {
    title: string;
    activePermissionsManagementRows: PermissionsManagementRow[];
    entityColumnHeaderTemplateRef: TemplateRef<any> | null;
    inheritedPermissionColumnHeaderTemplateRef: TemplateRef<any> | null;
    fileColumnHeaderTemplateRef: TemplateRef<any> | null;
    emptyTableTemplateRef?: TemplateRef<any>;
    entityCellTemplateRef?: TemplateRef<any>;
    inheritedPermissionCellTemplateRef: TemplateRef<any> | null;
    fileCellTemplateRef?: TemplateRef<any>;
    protected displayedColumns: string[];
    ngAfterContentChecked(): void;
    private getAvailableColumns;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionsTableComponent, "hxp-permissions-table", never, { "title": { "alias": "title"; "required": false; }; "activePermissionsManagementRows": { "alias": "activePermissionsManagementRows"; "required": false; }; }, {}, ["entityColumnHeaderTemplateRef", "inheritedPermissionColumnHeaderTemplateRef", "fileColumnHeaderTemplateRef", "emptyTableTemplateRef", "entityCellTemplateRef", "inheritedPermissionCellTemplateRef", "fileCellTemplateRef"], ["[permission-search]"], true, never>;
}
