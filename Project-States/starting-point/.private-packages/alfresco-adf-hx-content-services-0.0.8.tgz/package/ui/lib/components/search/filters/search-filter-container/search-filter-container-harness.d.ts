import { ComponentHarness } from '@angular/cdk/testing';
import { MatButtonHarness } from '@angular/material/button/testing';
import { MatIconHarness } from '@angular/material/icon/testing';
export declare class SearchFilterHarness extends ComponentHarness {
    static hostSelector: string;
    getLabel: import("@angular/cdk/harness-environment.d-ccca6bee").A<import("@angular/cdk/harness-environment.d-ccca6bee").i | null>;
    getExpandIcon: import("@angular/cdk/harness-environment.d-ccca6bee").A<MatIconHarness | null>;
    getBadge: import("@angular/cdk/harness-environment.d-ccca6bee").A<import("@angular/cdk/harness-environment.d-ccca6bee").i | null>;
    getApplyButton: import("@angular/cdk/harness-environment.d-ccca6bee").A<MatButtonHarness | null>;
    getClearButton: import("@angular/cdk/harness-environment.d-ccca6bee").A<MatButtonHarness | null>;
    getOverlayBackdrop: import("@angular/cdk/harness-environment.d-ccca6bee").A<import("@angular/cdk/harness-environment.d-ccca6bee").i | null>;
    protected getChip: import("@angular/cdk/harness-environment.d-ccca6bee").A<import("@angular/cdk/harness-environment.d-ccca6bee").i | null>;
    protected getOverlayContainer: import("@angular/cdk/harness-environment.d-ccca6bee").A<import("@angular/cdk/harness-environment.d-ccca6bee").i | null>;
    isOpen(): Promise<boolean>;
    open(): Promise<void | undefined>;
}
