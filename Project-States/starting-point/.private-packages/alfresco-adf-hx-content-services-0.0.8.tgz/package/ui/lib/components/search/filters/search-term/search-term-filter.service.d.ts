import { SearchTermFilterData } from './search-term-filter.data';
import { SearchFilterService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class SearchTermFilterService implements SearchFilterService {
    toHXQL(data: SearchTermFilterData): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchTermFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchTermFilterService>;
}
