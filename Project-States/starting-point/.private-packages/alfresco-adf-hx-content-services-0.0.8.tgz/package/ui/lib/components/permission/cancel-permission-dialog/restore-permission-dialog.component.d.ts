import { MatDialogRef } from '@angular/material/dialog';
import { UserType } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class RestorePermissionDialogComponent {
    private dialogRef;
    restoreOption: UserType;
    constructor(dialogRef: MatDialogRef<RestorePermissionDialogComponent>);
    reject(): void;
    confirm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RestorePermissionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RestorePermissionDialogComponent, "hxp-restore-permission-dialog", never, {}, {}, never, never, true, never>;
}
