import { MatDialogRef } from '@angular/material/dialog';
import { PermissionsPanelRequestService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export interface DismissPermissionDialogData<T = any> {
    dialogTitle: string;
    dialogDescription: string;
    dialogRejectButton: string;
    dialogConfirmButton: string;
    permissionDialogRef?: MatDialogRef<T>;
}
export declare abstract class DismissPermission {
    protected abstract close(isEdited: boolean): void;
    protected abstract cancel(isEdited: boolean): void;
}
export declare class CancelPermissionDialogComponent {
    private dialogRef;
    readonly dialogData: DismissPermissionDialogData;
    private permissionsPanelRequestService;
    constructor(dialogRef: MatDialogRef<CancelPermissionDialogComponent>, dialogData: DismissPermissionDialogData, permissionsPanelRequestService: PermissionsPanelRequestService);
    reject(): void;
    confirm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelPermissionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelPermissionDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
