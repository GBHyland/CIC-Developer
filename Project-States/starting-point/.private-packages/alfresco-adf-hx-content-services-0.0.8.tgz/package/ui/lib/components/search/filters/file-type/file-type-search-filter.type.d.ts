import { BaseFilterFormType } from '@alfresco/adf-hx-content-services/services';
import { FileTypeFlatNode } from './tree/file-type-search-filter-file-type-node';
export interface FileTypeSearchFilterFormType extends BaseFilterFormType {
    selectedDocuments: FileTypeFlatNode[];
}
