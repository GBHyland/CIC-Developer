import { MatDialog } from '@angular/material/dialog';
import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class DeleteButtonActionService extends DocumentActionService {
    private dialog;
    constructor(dialog: MatDialog);
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    private canOpenConfirmationDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeleteButtonActionService>;
}
