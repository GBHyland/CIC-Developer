import { OnChanges } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { DefaultIcon, MimeType } from '@alfresco/adf-hx-content-services/icons';
import * as i0 from "@angular/core";
/**
 * Component that display the content type icon of a given `Document`.
 *
 * To use the `ContentTypeIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { ContentTypeIconComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentTypeIconComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *   <hxp-document-type-icon [document]="document" [isExpanded]="isExpanded"></hxp-document-type-icon>
 */
export declare class ContentTypeIconComponent implements OnChanges {
    /**
     * The document for which the icon will be displayed.
     * @type {Document}
     */
    document?: Document;
    /**
     * Toggles between expanded and collapsed for folder type documents only.
     * If the document is not a folder, this property is ignored.
     * @type {boolean}
     * @default false
     */
    isExpanded: boolean;
    protected documentIconType: DefaultIcon | MimeType;
    /**
     * The mime type of the `Document`.
     * @type {string}
     * @readonly
     */
    get mimeType(): DefaultIcon | MimeType;
    ngOnChanges(): void;
    private checkDocumentIconType;
    private getFolderIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentTypeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentTypeIconComponent, "hxp-document-type-icon", never, { "document": { "alias": "document"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; }, {}, never, never, true, never>;
}
