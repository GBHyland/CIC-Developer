import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PermissionInheritanceToggleComponent {
    isInheritanceEnabled: boolean | null;
    toggleChange: EventEmitter<boolean>;
    onToggleChange(isEnabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionInheritanceToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionInheritanceToggleComponent, "hxp-permissions-inheritance-toggle", never, { "isInheritanceEnabled": { "alias": "isInheritanceEnabled"; "required": false; }; }, { "toggleChange": "toggleChange"; }, never, never, true, never>;
}
