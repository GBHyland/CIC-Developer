import { CardViewItem, CardViewUpdateService } from '@alfresco/adf-core';
import { EventEmitter, OnChanges } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { SharedDocumentService, HxpNotificationService, SharedDocumentPropertiesService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
/**
 * Component presents document properties viewer container.
 *
 * To use the `PropertiesViewerContainerComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PropertiesViewerContainerComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         PropertiesViewerContainerComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-viewer-container
 *    [document]="document"
 *    [properties]="defaultProperties"
 *    [editable]="editable"
 *    [expanded]="expanded"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayDefaultProperties]="displayDefaultProperties"
 *    [displayEmpty]="displayEmpty"
 *    [multi]="multi"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty"
 *    [displayLabelForChips]="true">
 * </hxp-properties-viewer-container>
 */
export declare class PropertiesViewerContainerComponent implements OnChanges {
    private documentService;
    private cardViewUpdateService;
    private hxpNotificationService;
    private documentPropertiesService;
    /**
     * An attribute representing a text to display in the header. Can be a key to translate.
     * @type {boolean}
     * @default false
     */
    headerText: string;
    private destroyRef;
    /**
     * The document to display the properties for.
     * @type {Document}
     * @required
     */
    document: Document | undefined;
    /**
     * The properties to display in the card view.
     * @type {CardViewItem[]}
     * @default []
     *
     * ```ts
     * export interface CardViewItem {
     *      label: string;
     *      value: any;
     *      key: string;
     *      default?: any;
     *      type: string;
     *      displayValue: any;
     *      editable?: boolean;
     *      icon?: string;
     * }
     * ```
     *
     */
    properties: CardViewItem[];
    /**
     * Toggles whether or not to enable copy to clipboard action.
     * @type {boolean}
     * @default true
     */
    copyToClipboardAction: boolean;
    /**
     * Toggles whether the metadata properties should be shown.
     * @type {boolean}
     * @default true
     */
    displayDefaultProperties: boolean;
    /**
     * Toggles whether to display empty values in the card view.
     * @type {boolean}
     * @default false
     */
    displayEmpty: boolean;
    /**
     * Toggles whether the edit button should be shown
     * @type {boolean}
     * @default false
     */
    editable: boolean;
    /**
     * Expand or collapse the panel.
     * @type {boolean}
     * @default false
     */
    expanded: boolean;
    /**
     * The multi parameter of the underlying material expansion panel, set to true to allow multi accordion to be expanded at the same time.
     * @type {boolean}
     * @default false
     */
    multi: boolean;
    /**
     * Toggles whether or not to enable chips for multivalued properties.
     * @type {boolean}
     * @default true
     */
    useChipsForMultiValueProperty: boolean;
    /**
     * Toggles whether or not to display label for multivalued properties.
     * @type {boolean}
     * @default false
     */
    displayLabelForChips: boolean;
    propertyUpdateRequest: EventEmitter<boolean>;
    protected editMode: boolean;
    protected workingCopy: boolean;
    protected isEditableRecord: boolean;
    private cardValueValidationMap;
    private documentPropertiesToUpdate;
    private requiredProperties;
    constructor(documentService: SharedDocumentService, cardViewUpdateService: CardViewUpdateService, hxpNotificationService: HxpNotificationService, documentPropertiesService: SharedDocumentPropertiesService, 
    /**
     * An attribute representing a text to display in the header. Can be a key to translate.
     * @type {boolean}
     * @default false
     */
    headerText?: string);
    ngOnChanges(): void;
    protected onSaveProperties(): void;
    protected toggleEditMode(): void;
    protected hasBeenModified(): boolean;
    protected allCardValuesAreValid(): boolean;
    private respondToCardUpdate;
    private getUpdatedComplexProperty;
    private validateCardValue;
    private isComplexProperty;
    private isEmptyProperty;
    private handleEmptyProperty;
    static ɵfac: i0.ɵɵFactoryDeclaration<PropertiesViewerContainerComponent, [null, null, null, null, { attribute: "headerText"; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PropertiesViewerContainerComponent, "hxp-properties-viewer-container", never, { "document": { "alias": "document"; "required": false; }; "properties": { "alias": "properties"; "required": false; }; "copyToClipboardAction": { "alias": "copyToClipboardAction"; "required": false; }; "displayDefaultProperties": { "alias": "displayDefaultProperties"; "required": false; }; "displayEmpty": { "alias": "displayEmpty"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "multi": { "alias": "multi"; "required": false; }; "useChipsForMultiValueProperty": { "alias": "useChipsForMultiValueProperty"; "required": false; }; "displayLabelForChips": { "alias": "displayLabelForChips"; "required": false; }; }, { "propertyUpdateRequest": "propertyUpdateRequest"; }, never, never, true, never>;
}
