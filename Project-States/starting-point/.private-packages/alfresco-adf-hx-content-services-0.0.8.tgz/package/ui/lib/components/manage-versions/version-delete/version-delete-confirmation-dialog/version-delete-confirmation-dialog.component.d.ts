import { MatDialogRef } from '@angular/material/dialog';
import { VersionDeleteDialogData } from '../configs/version-delete-dialog.interface';
import { DocumentRouterService, DocumentService, DocumentVersionsService, HxpNotificationService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class VersionDeleteConfirmationDialogComponent {
    private dialogData;
    private dialogRef;
    private documentVersionsService;
    private documentService;
    private hxpNotificationService;
    private documentRouterService;
    protected isDeleting: boolean;
    private readonly version;
    private readonly parentId;
    constructor(dialogData: VersionDeleteDialogData, dialogRef: MatDialogRef<VersionDeleteConfirmationDialogComponent>, documentVersionsService: DocumentVersionsService, documentService: DocumentService, hxpNotificationService: HxpNotificationService, documentRouterService: DocumentRouterService);
    protected onDelete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionDeleteConfirmationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionDeleteConfirmationDialogComponent, "hxp-version-delete-confirmation-dialog", never, {}, {}, never, never, true, never>;
}
