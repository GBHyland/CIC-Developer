import { DocumentVersionsService, HxpNotificationService, VersionableDocument } from '@alfresco/adf-hx-content-services/services';
import { DatePipe } from '@angular/common';
import { OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class VersionEditDialogComponent implements OnInit {
    version: VersionableDocument;
    private fb;
    private datePipe;
    private hxpNotificationService;
    private dialogRef;
    private documentVersionService;
    protected isUpdating: boolean;
    protected form: FormGroup;
    private dateFormat;
    constructor(version: VersionableDocument, fb: FormBuilder, datePipe: DatePipe, hxpNotificationService: HxpNotificationService, dialogRef: MatDialogRef<VersionEditDialogComponent>, documentVersionService: DocumentVersionsService);
    ngOnInit(): void;
    protected onSave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionEditDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionEditDialogComponent, "hxp-version-edit-dialog", never, {}, {}, never, never, true, never>;
}
