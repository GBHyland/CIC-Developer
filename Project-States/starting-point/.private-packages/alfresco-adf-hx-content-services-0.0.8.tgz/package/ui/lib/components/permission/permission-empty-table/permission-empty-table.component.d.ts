import * as i0 from "@angular/core";
export declare class PermissionEmptyTableComponent {
    message: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionEmptyTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionEmptyTableComponent, "hxp-permissions-empty-table", never, { "message": { "alias": "message"; "required": false; }; }, {}, never, never, true, never>;
}
