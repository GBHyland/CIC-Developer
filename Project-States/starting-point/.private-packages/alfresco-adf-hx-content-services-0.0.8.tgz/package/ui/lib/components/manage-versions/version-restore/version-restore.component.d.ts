import { OnChanges } from '@angular/core';
import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class VersionRestoreComponent implements OnChanges {
    isAvailable: boolean;
    data: ActionContext;
    private versionRestoreService;
    ngOnChanges(): void;
    protected restoreVersion(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionRestoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionRestoreComponent, "hxp-version-restore", never, { "isAvailable": { "alias": "isAvailable"; "required": false; }; "data": { "alias": "data"; "required": false; }; }, {}, never, never, true, never>;
}
