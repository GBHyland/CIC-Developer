import { Document } from '@hylandsoftware/hxcs-js-client';
export interface ContentDeleteDialogData {
    documents: Document[];
    shouldRedirect: boolean;
    refererURL: string;
}
export interface ContentDeletedDialogResponse {
    success: boolean;
    docId: string;
    error?: string;
}
