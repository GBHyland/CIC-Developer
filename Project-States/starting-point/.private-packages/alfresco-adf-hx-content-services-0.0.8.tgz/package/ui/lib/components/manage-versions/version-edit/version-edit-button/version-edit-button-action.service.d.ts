import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import { MatDialog } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class VersionEditButtonActionService extends DocumentActionService {
    private dialog;
    constructor(dialog: MatDialog);
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionEditButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionEditButtonActionService>;
}
