export declare const EditPropertiesStatus: {
    readonly SUCCESS: "SUCCESS";
    readonly ERROR: "ERROR";
    readonly INFO: "INFO";
};
export type EditPropertiesStatus = typeof EditPropertiesStatus[keyof typeof EditPropertiesStatus];
