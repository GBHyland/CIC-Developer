import { FormBuilder } from '@angular/forms';
import { Clipboard } from '@angular/cdk/clipboard';
import { ContentShareService, HxpNotificationService } from '@alfresco/adf-hx-content-services/services';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export interface DialogData {
    sharedDocument: Document;
}
export declare class ContentShareDialogComponent {
    private readonly _fb;
    data: DialogData;
    contentShareService: ContentShareService;
    private clipboard;
    private hxpNotificationService;
    readonly shareDocumentForm: import("@angular/forms").FormGroup<{
        shared_link: import("@angular/forms").FormControl<string | null>;
    }>;
    constructor(_fb: FormBuilder, data: DialogData, contentShareService: ContentShareService, clipboard: Clipboard, hxpNotificationService: HxpNotificationService);
    onCopy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentShareDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentShareDialogComponent, "hxp-alfresco-dbp-content-share-dialog", never, {}, {}, never, never, true, never>;
}
