import { ElementRef, OnInit } from '@angular/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { TranslateService } from '@ngx-translate/core';
import { DatePipe } from '@angular/common';
import { AbstractControl, ValidatorFn } from '@angular/forms';
import { CreatedDateFormType } from './created-date-search-filter.type';
import { CreatedDateSearchFilterService } from './created-date-search-filter.service';
import { Subject } from 'rxjs';
import { CreatedDateSearchFilterData } from './created-date-search-filter.data';
import { MatIconRegistry } from '@angular/material/icon';
import { MatSelectionList } from '@angular/material/list';
import { FilterId, SearchFilterValueService } from '@alfresco/adf-hx-content-services/services';
import { DomSanitizer } from '@angular/platform-browser';
import { BaseSearchFilterDirective } from '../../directives/base-search-filter.directive';
import * as i0 from "@angular/core";
export interface CreatedDateOption {
    label: string;
    date: string;
}
export declare class CreatedDateSearchFiltersComponent extends BaseSearchFilterDirective<CreatedDateFormType> implements OnInit {
    protected datePipe: DatePipe;
    protected searchFilterValueService: SearchFilterValueService;
    protected createdDateSearchFilterService: CreatedDateSearchFilterService;
    private translate;
    private matIconRegistry;
    private domSanitizer;
    private readonly destroyRef;
    protected afterDateInput?: ElementRef;
    protected beforeDateInput?: ElementRef;
    selectionList?: MatSelectionList;
    defaultCreatedDateOptions: CreatedDateOption[];
    protected beforeDateInputSubject: Subject<void>;
    protected afterDateInputSubject: Subject<void>;
    constructor(datePipe: DatePipe, searchFilterValueService: SearchFilterValueService, createdDateSearchFilterService: CreatedDateSearchFilterService, translate: TranslateService, matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer);
    get id(): FilterId;
    ngOnInit(): void;
    toHXQL(data: CreatedDateSearchFilterData): string;
    afterDateFilter: (d: Date | null) => boolean;
    beforeDateFilter: (d: Date | null) => boolean;
    protected setData(data: CreatedDateSearchFilterData): void;
    protected getFormControls(): {
        [key: string]: AbstractControl;
    };
    protected dateFormatValidator(dateInputTypeLocator: string): ValidatorFn;
    protected afterDateValidator(): ValidatorFn;
    protected beforeDateValidator(): ValidatorFn;
    protected enableCustomDate(e: Event): void;
    protected createdDateValueChanged(data: CreatedDateOption): void;
    protected afterDateChanged(event: MatDatepickerInputEvent<Date>): void;
    protected beforeDateChanged(event: MatDatepickerInputEvent<Date>): void;
    protected clearAfterDate(event: MouseEvent): void;
    protected clearBeforeDate(event: MouseEvent): void;
    protected validateInput(event: KeyboardEvent): void;
    private updateCustomDateSelectedValue;
    discardPendingChanges(): void;
    clearChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreatedDateSearchFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CreatedDateSearchFiltersComponent, "hxp-search-created-date-filter", never, {}, {}, never, never, true, never>;
}
