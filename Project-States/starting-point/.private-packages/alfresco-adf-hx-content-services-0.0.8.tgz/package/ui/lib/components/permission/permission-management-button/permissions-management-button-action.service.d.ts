import { MatDialog } from '@angular/material/dialog';
import { ActionContext, DocumentActionService, PermissionsPanelRequestService, PermissionsManagementComponentType } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class PermissionsButtonActionService extends DocumentActionService {
    private dialog;
    private permissionsPanelRequestService;
    private componentType;
    constructor(dialog: MatDialog, permissionsPanelRequestService: PermissionsPanelRequestService, componentType?: PermissionsManagementComponentType);
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    private openPermissionsManagementDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsButtonActionService, [null, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsButtonActionService>;
}
