import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PanelSkeletonLoaderComponent implements OnChanges {
    /**
     * Default value of skeleton panel rows to display.
     * @readonly
     * @type {number}
     */
    protected static readonly DEFAULT_SKELETON_ROWS = 10;
    /**
     * Indicates the number of rows to display in the skeleton panel.
     * @type {number}
     * @default 10
     */
    skeletonRows: number;
    protected skeletonRowArray: number[];
    ngOnChanges(): void;
    protected skeletonRowTrackBy(index: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelSkeletonLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelSkeletonLoaderComponent, "hxp-panel-skeleton-loader", never, { "skeletonRows": { "alias": "skeletonRows"; "required": false; }; }, {}, never, never, true, never>;
}
