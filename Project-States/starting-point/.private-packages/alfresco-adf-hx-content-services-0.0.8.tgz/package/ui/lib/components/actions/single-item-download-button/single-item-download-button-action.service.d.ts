import { ActionContext, DocumentActionService, FileDownloadService, IsSingleDocumentWithMainBlobService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class SingleItemDownloadButtonActionService extends DocumentActionService {
    private fileDownloadService;
    private isSingleDocumentWithMainBlobService;
    constructor(fileDownloadService: FileDownloadService, isSingleDocumentWithMainBlobService: IsSingleDocumentWithMainBlobService);
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleItemDownloadButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SingleItemDownloadButtonActionService>;
}
