import { SearchFilterService } from '@alfresco/adf-hx-content-services/services';
import { FileTypeSearchFilterData } from './file-type-search-filter.data';
import * as i0 from "@angular/core";
export declare class FileTypeSearchFilterService implements SearchFilterService {
    toHXQL(data: FileTypeSearchFilterData): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTypeSearchFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileTypeSearchFilterService>;
}
