import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Component representing a skeleton to display during content loading.
 *
 * To use the `TableSkeletonLoaderComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { TableSkeletonLoaderComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         TableSkeletonLoaderComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-table-skeleton-loader></hxp-table-skeleton-loader>
 */
export declare class TableSkeletonLoaderComponent implements OnChanges {
    /**
     * Default value of skeleton tree rows to display.
     * @readonly
     * @type {number}
     */
    protected static readonly DEFAULT_SKELETON_ROWS = 5;
    /**
     * Indicates the number of rows to display in the skeleton table.
     * @type {number}
     * @default 5
     */
    skeletonRows: number;
    protected skeletonRowArray: number[];
    ngOnChanges(): void;
    protected skeletonRowTrackBy(index: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableSkeletonLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableSkeletonLoaderComponent, "hxp-table-skeleton-loader", never, { "skeletonRows": { "alias": "skeletonRows"; "required": false; }; }, {}, never, never, true, never>;
}
