import { Subject } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export interface VersionContextActionConfiguration {
    data: Document;
    model: {
        key: string;
        icon: string;
        title: string;
        visible: boolean;
    };
    subject: Subject<any>;
}
export declare class VersionContextMenuActionsService {
    private documentSingleItemDownloadHandler;
    private documentShareHandler;
    private documentVersionRestoreHandler?;
    private documentVersionEditHandler?;
    private documentVersionDeleteHandler?;
    constructor(documentSingleItemDownloadHandler: DocumentActionService, documentShareHandler: DocumentActionService, documentVersionRestoreHandler?: DocumentActionService | undefined, documentVersionEditHandler?: DocumentActionService | undefined, documentVersionDeleteHandler?: DocumentActionService | undefined);
    getVersionContextActions(data: Document, parentDocument?: Document): VersionContextActionConfiguration[];
    private toContextAction;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionContextMenuActionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionContextMenuActionsService>;
}
