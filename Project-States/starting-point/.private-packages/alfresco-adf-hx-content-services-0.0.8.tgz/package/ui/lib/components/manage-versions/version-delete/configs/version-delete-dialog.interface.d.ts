import { VersionableDocument } from '@alfresco/adf-hx-content-services/services';
export interface VersionDeleteDialogData {
    version: VersionableDocument;
    shouldRedirect: boolean;
    parentId: string;
}
