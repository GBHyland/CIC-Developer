import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ContentPropertyViewerActionService extends DocumentActionService {
    showPropertyPanel$: Observable<boolean>;
    private showPropertyPanelSubject;
    constructor();
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentPropertyViewerActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentPropertyViewerActionService>;
}
