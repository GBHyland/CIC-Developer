import { MatDialog } from '@angular/material/dialog';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { PermissionsPanelRequestService } from '@alfresco/adf-hx-content-services/services';
import { DismissPermission } from '../cancel-permission-dialog/cancel-permission-dialog.component';
import * as i0 from "@angular/core";
/**
 * This component is responsible for managing the permissions in the form of a panel.
 * The rest of the application is still accessible.
 *
 * It includes functionalities to add, edit, and display permissions to `User`s and `Group`s.
 *
 * Available permissions are `Read`, `Write` and `Everything`.
 *
 * Permissions are inherited from the parent `Document`.
 * It's possible to only upgrade a inherited permission.
 *
 * To use the `PermissionsManagementPanelComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PermissionsManagementPanelComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         PermissionsManagementPanelComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-permissions-management-panel></hxp-permissions-management-panel>
 */
export declare class PermissionsManagementPanelComponent extends DismissPermission {
    private permissionsPanelRequestService;
    private dialog;
    /**
     * The document to display and manage permissions for.
     * @type {Document}
     */
    document: Document;
    parentDocument: Document;
    constructor(permissionsPanelRequestService: PermissionsPanelRequestService, dialog: MatDialog);
    protected cancel(isEdited: boolean): void;
    protected close(): void;
    protected restore(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsManagementPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionsManagementPanelComponent, "hxp-permissions-management-panel", never, { "document": { "alias": "document"; "required": false; }; "parentDocument": { "alias": "parentDocument"; "required": false; }; }, {}, never, never, true, never>;
}
