import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { PermissionsManagementDialogData } from '@alfresco/adf-hx-content-services/services';
import { DismissPermission } from '../cancel-permission-dialog/cancel-permission-dialog.component';
import { PermissionManagementContainerComponent } from '../permission-management-container/permission-management-container.component';
import * as i0 from "@angular/core";
export declare const DIALOG_MIN_WIDTH = 436;
/**
 * This component is responsible for managing the permissions in the form of dialog.
 * The dialog overlay prevent the user to interact with the rest of the application.
 *
 * It includes functionalities to add, edit, and display permissions to `User`s and `Group`s.
 *
 * Available permissions are `Read`, `Write` and `Everything`.
 *
 * Permissions are inherited from the parent `Document`.
 * It's possible to only upgrade a inherited permission.
 *
 * To use the `PermissionsManagementPanelComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MatDialog } from '@angular/material/dialog';
 * import { PermissionsManagementPanelComponent } from '@alfresco/adf-hx-content-services/ui';
 * import { PermissionsManagementDialogData } from '@alfresco/adf-hx-content-services/services';
 *
 * @Component({
 *     template: '<button (click)="openPermissionsManagementDialog(document)">{{ document.sys_title }}</button>',
 *     standalone: true,
 * })
 * class OpenDialogButtonComponent {
 *
 *     constructor(
 *         private dialog: MatDialog,
 *     ) {}
 *
 *     openPermissionsManagementDialog(document: Document) {
 *         this.dialog.open<
 *             PermissionsManagementDialogComponent,
 *             PermissionsManagementDialogData
 *         >(PermissionsManagementDialogComponent, {
 *             data: { document }
 *          });
 *     }
 * }
 * ```
 */
export declare class PermissionsManagementDialogComponent extends DismissPermission {
    private dialog;
    private dialogRef;
    /**
     * The `Document` to display and manage permissions for.
     *
     * To pass the `Document` open the dialog and provide `MAT_DIALOG_DATA` as `PermissionsManagementDialogData`.
     *
     * ```ts
     * interface PermissionsManagementDialogData {
     *     document: Document;
     * }
     * ```
     *
     * @type {Document}
     */
    document: Document;
    parentDocument: Document;
    container: PermissionManagementContainerComponent;
    constructor(data: PermissionsManagementDialogData, dialog: MatDialog, dialogRef: MatDialogRef<PermissionsManagementDialogComponent>);
    protected cancel(isEdited: boolean): void;
    protected close(isEdited: boolean): void;
    protected restore(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsManagementDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionsManagementDialogComponent, "hxp-permissions-management-dialog", never, {}, {}, never, never, true, never>;
}
