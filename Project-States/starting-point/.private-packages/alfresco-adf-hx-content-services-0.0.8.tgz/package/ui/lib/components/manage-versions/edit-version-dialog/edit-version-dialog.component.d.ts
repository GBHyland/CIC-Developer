import { OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EditDocumentVersion, VersionableDocument } from '@alfresco/adf-hx-content-services/services';
import { Subject } from 'rxjs';
import { DatePipe } from '@angular/common';
import * as i0 from "@angular/core";
export declare class EditVersionDialogComponent implements OnInit {
    version: VersionableDocument;
    private fb;
    private datePipe;
    isUpdating: boolean;
    versionUpdated$: Subject<EditDocumentVersion>;
    protected form: FormGroup;
    private dateFormat;
    constructor(version: VersionableDocument, fb: FormBuilder, datePipe: DatePipe);
    ngOnInit(): void;
    save(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditVersionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditVersionDialogComponent, "hxp-edit-version-dialog", never, {}, {}, never, never, true, never>;
}
