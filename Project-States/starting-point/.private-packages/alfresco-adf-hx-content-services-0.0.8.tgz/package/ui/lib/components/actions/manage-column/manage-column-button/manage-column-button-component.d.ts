import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ManageColumnButtonComponent implements OnChanges {
    private manageColumnActionService;
    actionContext: ActionContext;
    isAvailable: boolean;
    constructor(manageColumnActionService: DocumentActionService);
    ngOnChanges(): void;
    onCopy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageColumnButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ManageColumnButtonComponent, "hxp-manage-column-button", never, { "actionContext": { "alias": "actionContext"; "required": false; }; "isAvailable": { "alias": "isAvailable"; "required": false; }; }, {}, never, never, true, never>;
}
