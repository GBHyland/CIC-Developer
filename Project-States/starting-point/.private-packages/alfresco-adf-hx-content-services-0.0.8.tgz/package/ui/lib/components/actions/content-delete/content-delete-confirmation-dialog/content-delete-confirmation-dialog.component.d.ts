import { MatDialogRef } from '@angular/material/dialog';
import { DocumentService, HxpNotificationService, RouterExtService, DocumentRouterService } from '@alfresco/adf-hx-content-services/services';
import { TranslateService } from '@ngx-translate/core';
import { ContentDeleteDialogData } from '../configs/delete-dialog.interface';
import * as i0 from "@angular/core";
export declare class ContentDeleteConfirmationDialogComponent {
    private dialogData;
    private dialogRef;
    private hxpNotificationService;
    private documentService;
    private documentRouterService;
    private routerExtService;
    private translate;
    protected dialogTitle: string;
    protected dialogDescription: string;
    protected isDeleting: boolean;
    private readonly deleteDocument$;
    private readonly documents;
    private readonly shouldRedirect;
    private readonly refererURL;
    constructor(dialogData: ContentDeleteDialogData, dialogRef: MatDialogRef<ContentDeleteConfirmationDialogComponent>, hxpNotificationService: HxpNotificationService, documentService: DocumentService, documentRouterService: DocumentRouterService, routerExtService: RouterExtService, translate: TranslateService);
    protected onDelete(): void;
    private redirectToReferer;
    private processDeletionResultsAndNotify;
    private displayNotificationMessage;
    private populateDialogTitleAndDescription;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentDeleteConfirmationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentDeleteConfirmationDialogComponent, "hxp-content-delete-confirmation-dialog", never, {}, {}, never, never, true, never>;
}
