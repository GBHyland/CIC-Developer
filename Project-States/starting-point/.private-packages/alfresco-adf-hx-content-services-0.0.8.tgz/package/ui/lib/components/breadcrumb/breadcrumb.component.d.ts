import { DocumentService } from '@alfresco/adf-hx-content-services/services';
import { OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
/**
 * Component that displays a series of clickable links that represent the path to a given `Document`.
 * To use the `HxpBreadcrumbComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpBreadcrumbComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         HxpBreadcrumbComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-breadcrumb [document]="document"></hxp-breadcrumb>
 *
 */
export declare class HxpBreadcrumbComponent implements OnInit, OnChanges {
    private documentService;
    /**
     * The `Document` object for which the breadcrumb is displayed.
     * The breadcrumb will be built based on the ancestors of the given `Document`.
     * @type {Document}
     */
    document: Document;
    /**
     * If true, breadcrumb elements are grouped together and displayed as ellipsis, except for the first and last entry.
     * @default false
     * @type {boolean}
     */
    compact: boolean;
    protected breadcrumbElements: Array<Document>;
    constructor(documentService: DocumentService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private _buildBreadcrumb;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpBreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpBreadcrumbComponent, "hxp-breadcrumb", never, { "document": { "alias": "document"; "required": false; }; "compact": { "alias": "compact"; "required": false; }; }, {}, never, never, true, never>;
}
