import { VersionableDocument } from '@alfresco/adf-hx-content-services/services';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class DeleteVersionDialogComponent {
    version: VersionableDocument;
    isDeleting: boolean;
    versionDeleted$: Subject<boolean>;
    constructor(version: VersionableDocument);
    delete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteVersionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteVersionDialogComponent, "hxp-delete-version-dialog", never, {}, {}, never, never, true, never>;
}
