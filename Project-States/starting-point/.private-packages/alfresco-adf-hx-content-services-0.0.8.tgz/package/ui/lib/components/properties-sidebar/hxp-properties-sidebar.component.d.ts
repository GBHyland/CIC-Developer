import { CardViewItem } from '@alfresco/adf-core';
import { EventEmitter, OnChanges } from '@angular/core';
import { DocumentService, SharedDocumentPropertiesService } from '@alfresco/adf-hx-content-services/services';
import { Observable } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpPropertiesSidebarComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpPropertiesSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpPropertiesSidebarComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-sidebar [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
export declare class HxpPropertiesSidebarComponent implements OnChanges {
    private documentService;
    private documentPropertiesService;
    private readonly destroyRef;
    /**
     * The document to display the properties for
     * @type {Document}
     */
    document?: Document;
    /**
     * Input property to enable or disable edit mode availability
     * @type {boolean}
     * @default true
     */
    editable: boolean;
    /**
     * Emits an event when the sidebar is closed
     */
    closePropertySidebar: EventEmitter<void>;
    protected propertyLoading: boolean;
    protected selectedDocument: Document;
    protected documentProperties$: Observable<CardViewItem[]>;
    protected otherDocumentProperties$: Observable<CardViewItem[]>;
    constructor(documentService: DocumentService, documentPropertiesService: SharedDocumentPropertiesService);
    ngOnChanges(): void;
    protected handlePropertyUpdate(propertyUpdated: boolean): void;
    protected onClose(): void;
    private subscribeToDocumentUpdates;
    private loadDocumentProperties;
    private fetchDocumentProperties;
    private initializeDocumentWithSchema;
    private fetchDefaultProperties;
    private fetchOtherProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpPropertiesSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpPropertiesSidebarComponent, "hxp-properties-sidebar", never, { "document": { "alias": "document"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; }, { "closePropertySidebar": "closePropertySidebar"; }, never, never, true, never>;
}
