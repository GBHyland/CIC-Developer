import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class VersionDeleteButtonComponent implements OnChanges {
    private versionDeleteActionService;
    actionContext: ActionContext;
    protected isAvailable: boolean;
    constructor(versionDeleteActionService: DocumentActionService);
    ngOnChanges(): void;
    protected onDelete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionDeleteButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionDeleteButtonComponent, "hxp-version-delete-button", never, { "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
