import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
/**
 * Component presents document breadcrumb.
 * To use the `HxpUiBreadcrumbComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpUiBreadcrumbComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         HxpUiBreadcrumbComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-ui-breadcrumb [documents]="documents"></hxp-ui-breadcrumb>
 */
export declare class HxpUiBreadcrumbComponent {
    /**
     * List of `Document` object the breadcrumb is rendered from.
     * @type {Document}
     */
    documents: Array<Document>;
    /**
     * If true, breadcrumb elements are grouped together and displayed as ellipsis, except for the first and last entry.
     * @default false
     * @type {boolean}
     */
    compact: boolean;
    protected documentTrackBy(_index: number, document: Document): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpUiBreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpUiBreadcrumbComponent, "hxp-ui-breadcrumb", never, { "documents": { "alias": "documents"; "required": false; }; "compact": { "alias": "compact"; "required": false; }; }, {}, never, never, true, never>;
}
