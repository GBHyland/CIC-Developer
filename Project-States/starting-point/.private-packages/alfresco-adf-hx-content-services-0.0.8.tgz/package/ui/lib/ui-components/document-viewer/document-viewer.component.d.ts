import { ViewerComponent, ViewUtilService } from '@alfresco/adf-core';
import { BlobDownloadService, RenditionsService } from '@alfresco/adf-hx-content-services/services';
import { EventEmitter, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Component that display the content of a Document.
 *
 * To use the `HxpUiDocumentViewerComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpUiDocumentViewerComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         HxpUiDocumentViewerComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *  <hxp-ui-document-viewer
 *      [document]="document"
 *      [showRightSidebar]="showRightSidebar"
 *      [fullScreen]="fullScreen"
 *      (closeViewer)="onClose()">
 *          <ng-template #toolbar>
 *              <div>Your optional custom toolbar</div>
 *          </ng-template>
 *          <ng-template #sidebar>
 *              <div>Your optional custom sidebar</div>
 *          </ng-template>
 *  </hxp-ui-document-viewer>
 */
export declare class HxpUiDocumentViewerComponent implements OnChanges {
    private blobDownloadService;
    private renditionsService;
    private viewUtilService;
    private destroyRef;
    /**
     * Input property that accepts a `Document` object.
     * This property is used to pass the document to be viewed by the component.
     * @type {Document}
     * @required
     */
    document: Document;
    /**
     * A boolean input property that determines whether the right sidebar is displayed.
     * When set to `true`, the right sidebar will be shown. When set to `false`, the right sidebar will be hidden.
     * @type {boolean}
     * @default false
     */
    showRightSidebar: boolean;
    /**
     * A boolean input property that trigger the browser native full-screen mode.
     * The default value is `false`. To trigger the full-screen mode, set the property to `true`.
     * Setting it back to `false` will not exit the full-screen mode,
     * you have to manually set it to `false` when the `closeViewer` event is emitted
     *
     * @type {boolean}
     * @default false
     */
    fullScreen: boolean;
    /**
     * Event emitter that notifies when the document has been closed.
     *
     * @event closeViewer
     */
    closeViewer: EventEmitter<void>;
    protected viewer: ViewerComponent<Document>;
    protected toolbarTemplateRef: TemplateRef<any> | null;
    protected sidebarTemplateRef: TemplateRef<any> | null;
    protected blobFile$: Observable<Blob>;
    private isRenditionLoading;
    private isEnteredFullScreenMode;
    constructor(blobDownloadService: BlobDownloadService, renditionsService: RenditionsService, viewUtilService: ViewUtilService);
    ngOnChanges(changes: SimpleChanges): void;
    protected onClose(): void;
    private manageFullScreenMode;
    private fetchBlob;
    private requestRendition;
    private getRendition;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpUiDocumentViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpUiDocumentViewerComponent, "hxp-ui-document-viewer", never, { "document": { "alias": "document"; "required": false; }; "showRightSidebar": { "alias": "showRightSidebar"; "required": false; }; "fullScreen": { "alias": "fullScreen"; "required": false; }; }, { "closeViewer": "closeViewer"; }, ["toolbarTemplateRef", "sidebarTemplateRef"], never, true, never>;
}
