import { PipeTransform } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { DocumentRouterOptions, DocumentRouterService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
/**
 * Pipe that transforms a Document object into a URL string using the DocumentRouterService.
 *
 * @example
 * * Using the pipe in a component:
 * ```typescript
 * const document: Document = { id: '123', name: 'example.docx' };
 * const options: DocumentRouterOptions = { absolute: true };
 * const url: string = documentRouterPipe.transform(document, options);
 * ```
 * Using the pipe in a template:
 * ```html
 * <a [href]="document | urlFor: { absolute: true }">Document Details</a>
 * ```
 */
export declare class DocumentRouterPipe implements PipeTransform {
    private documentRouterService;
    constructor(documentRouterService: DocumentRouterService);
    transform(document: Document, options?: DocumentRouterOptions): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentRouterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DocumentRouterPipe, "urlFor", true>;
}
