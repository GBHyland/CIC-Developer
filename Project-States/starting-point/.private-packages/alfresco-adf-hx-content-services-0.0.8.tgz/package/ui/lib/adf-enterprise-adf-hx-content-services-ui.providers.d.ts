import { DeleteButtonActionService } from './components/actions/content-delete/content-delete-button/content-delete-button-action.service';
import { ContentShareButtonActionService } from './components/actions/content-share/content-share-button/content-share-button-action.service';
import { SingleItemDownloadButtonActionService } from './components/actions/single-item-download-button/single-item-download-button-action.service';
import { PermissionsButtonActionService } from './components/permission/permission-management-button/permissions-management-button-action.service';
import { ContentPropertyViewerActionService } from './components/actions/content-properties-viewer-button/content-properties-viewer-button-action.service';
import { VersionDeleteButtonActionService } from './components/manage-versions/version-delete/version-delete-button/version-delete-button-action.service';
import { VersionEditButtonActionService } from './components/manage-versions/version-edit/version-edit-button/version-edit-button-action.service';
import { VersionRestoreActionService } from './components/manage-versions/version-restore/version-restore-action.service';
import { ManageColumnActionService } from './components/actions/manage-column/manage-column-button/manage-column-button-action.service';
export declare const CONTEXT_MENU_ACTIONS_PROVIDERS: ({
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof PermissionsButtonActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof DeleteButtonActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof SingleItemDownloadButtonActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof ContentShareButtonActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof ContentPropertyViewerActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof VersionDeleteButtonActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof VersionEditButtonActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof VersionRestoreActionService;
} | {
    provide: import("@angular/core").InjectionToken<import("@alfresco/adf-hx-content-services/services").DocumentActionService>;
    useClass: typeof ManageColumnActionService;
})[];
