import { PipeTransform } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export declare class BreadcrumbLabelPipe implements PipeTransform {
    private readonly cacheLabelService;
    transform(doc: Document, translationKey: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbLabelPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<BreadcrumbLabelPipe, "breadcrumbLabel", true>;
}
