import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export declare class CacheLabelService {
    private cache;
    private readonly translationService;
    getCache(): Map<string, string>;
    getTranslation(doc: Document, rootTranslationKey: string): string;
    private getLabel;
    private generateUniqueKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<CacheLabelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CacheLabelService>;
}
