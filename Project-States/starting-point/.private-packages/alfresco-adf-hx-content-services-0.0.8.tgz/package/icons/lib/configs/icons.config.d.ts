export declare const DefaultIcon: {
    readonly UNKNOWN: "";
    readonly FOLDER: "folder";
    readonly OPEN_FOLDER: "openFolder";
};
export type DefaultIcon = typeof DefaultIcon[keyof typeof DefaultIcon];
