export type SearchIcon = 'SEARCH' | 'CLEAR';
export declare const SearchIconAssets: Record<SearchIcon, string>;
