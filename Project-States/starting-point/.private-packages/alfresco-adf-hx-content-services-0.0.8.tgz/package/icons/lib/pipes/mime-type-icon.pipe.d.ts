import { PipeTransform } from '@angular/core';
import { ThumbnailService } from '../services/thumbnail.service';
import * as i0 from "@angular/core";
export declare class MimeTypeIconPipe implements PipeTransform {
    private thumbnailService;
    constructor(thumbnailService: ThumbnailService);
    transform(text: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MimeTypeIconPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MimeTypeIconPipe, "hxpMimeTypeIcon", true>;
}
