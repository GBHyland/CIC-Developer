import { ThumbnailService as AdfThumbnailService } from '@alfresco/adf-core';
import { mimeTypeLinkedImages } from '../configs/mime-type.config';
import * as i0 from "@angular/core";
export type MimeType = keyof typeof mimeTypeLinkedImages;
export declare class ThumbnailService extends AdfThumbnailService {
    mimeTypeIcons: Record<string, string>;
    private readonly DEFAULT_ICON;
    getMimeTypeIcon(mimeType: string): string;
    getDefaultMimeTypeIcon(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThumbnailService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThumbnailService>;
}
