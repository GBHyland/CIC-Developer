/**
 * @internal
 */
export declare const ADF_HX_CONTENT_SERVICES_INTERNAL: {
    readonly WORKSPACE_VERSIONING: "workspace-versioning";
    readonly CIC_GOVERNANCE_WORKSPACE_EXTENSION: "cic-governance-workspace-extension";
    readonly VERSIONING_NEW_CONTEXT_MENU: "cic-versioning-new-context-menu";
    readonly CIC_GOVERNANCE_WORKSPACE_LEGAL_HOLD: "cic-governance-workspace-legal-hold";
    readonly CIC_WORKSPACE_SATORI_APPLICATION_CHROME: "cic-workspace-satori-application-chrome";
};
export type ADF_HX_CONTENT_SERVICES_INTERNAL = typeof ADF_HX_CONTENT_SERVICES_INTERNAL[keyof typeof ADF_HX_CONTENT_SERVICES_INTERNAL];
