import { Document } from '@hylandsoftware/hxcs-js-client';
import { DocumentRouterService } from '../document/document-router/document-router.service';
import * as i0 from "@angular/core";
export declare class ContentShareService {
    private documentRouterService;
    constructor(documentRouterService: DocumentRouterService);
    getSingleContentShareLink(document?: Document): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentShareService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentShareService>;
}
