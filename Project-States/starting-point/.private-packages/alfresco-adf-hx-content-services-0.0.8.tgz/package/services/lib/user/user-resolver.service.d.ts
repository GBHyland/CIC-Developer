import { User } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { UserService } from '../user/user.service';
import * as i0 from "@angular/core";
export declare class UserResolverService {
    private userService;
    constructor(userService: UserService);
    parse(userData?: Array<string | User>): Observable<string>;
    private resolveUser;
    private getFullName;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserResolverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserResolverService>;
}
