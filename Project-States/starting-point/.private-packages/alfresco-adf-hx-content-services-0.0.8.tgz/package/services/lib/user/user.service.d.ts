import { User, UserApi } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class UserService {
    private userApi;
    protected cache: Map<string, Observable<User>>;
    constructor(userApi: UserApi);
    resolveUser(id: string): Observable<User>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserService>;
}
