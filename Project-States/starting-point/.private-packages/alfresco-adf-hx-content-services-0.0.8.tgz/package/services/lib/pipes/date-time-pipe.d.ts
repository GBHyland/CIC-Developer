import { UserPreferencesService } from '@alfresco/adf-core';
import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class DateTimeFormatPipe implements PipeTransform {
    userPreferenceService: UserPreferencesService;
    static readonly DEFAULT_LOCALE = "en-US";
    static readonly DATE_TIME_FORMAT_24_HR = "YYYY-MM-d H:mm:ss";
    static readonly DATE_TIME_FORMAT_12_HR = "MMM d, y h:mm a";
    defaultLocale: string;
    constructor(userPreferenceService: UserPreferencesService);
    transform(value: Date, format: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimeFormatPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DateTimeFormatPipe, "hxpDateTimePipe", true>;
}
