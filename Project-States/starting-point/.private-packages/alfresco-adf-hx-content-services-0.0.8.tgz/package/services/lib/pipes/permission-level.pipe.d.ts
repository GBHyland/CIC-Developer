import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
interface PermissionInfo {
    value: string;
    class: string;
}
/**
 * Transforms an array of effective permissions into a PermissionInfo object.
 *
 * @param effectivePermissions - The array of effective permissions.
 * @returns The PermissionInfo object representing the permission level, or undefined if the array is empty or no matching permission is found.
 *
 * @example
 * ```html
 * <div>{{ effectivePermissions | permissionLevel }}</div>
 * ```
 */
export declare class PermissionLevelPipe implements PipeTransform {
    transform(effectivePermissions?: string[]): PermissionInfo | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionLevelPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PermissionLevelPipe, "permissionLevel", true>;
}
export {};
