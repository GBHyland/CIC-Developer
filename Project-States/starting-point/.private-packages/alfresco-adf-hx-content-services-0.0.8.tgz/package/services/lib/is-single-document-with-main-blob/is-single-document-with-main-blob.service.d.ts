import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export declare class IsSingleDocumentWithMainBlobService {
    /**
     * Checks if the given array of documents represents a single document with a valid file blob.
     *
     * @param documents - The array of documents to be checked.
     * @returns A boolean value indicating whether the array represents a single document with a valid file blob.
     */
    validate(documents: Document[]): boolean;
    private isOneFileDocument;
    private hasValidFileBlob;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsSingleDocumentWithMainBlobService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IsSingleDocumentWithMainBlobService>;
}
