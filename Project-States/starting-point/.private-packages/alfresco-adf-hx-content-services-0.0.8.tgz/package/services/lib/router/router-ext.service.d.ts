import { Router, ActivatedRoute } from '@angular/router';
import * as i0 from "@angular/core";
export declare class RouterExtService {
    private router;
    private route;
    private previousUrl;
    private currentUrl;
    constructor(router: Router, route: ActivatedRoute);
    getPreviousUrl(): string;
    redirectToReferer(refererURL: string, defaultPath: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RouterExtService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RouterExtService>;
}
