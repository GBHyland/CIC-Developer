import { Observable } from 'rxjs';
import { ActionContext } from '../../context-menu-actions/actions/action-context.interface';
import { DocumentActionService } from '../../context-menu-actions/actions/document-action.service';
import * as i0 from "@angular/core";
export declare class ManageVersionsButtonActionService extends DocumentActionService {
    showVersionsPanel$: Observable<boolean>;
    private showVersionsPanelSubject;
    constructor();
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageVersionsButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ManageVersionsButtonActionService>;
}
