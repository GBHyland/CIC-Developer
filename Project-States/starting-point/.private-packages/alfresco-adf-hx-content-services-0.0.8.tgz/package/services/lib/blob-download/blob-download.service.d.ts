import { DownloadApi } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class BlobDownloadService {
    private downloadApi;
    constructor(downloadApi: DownloadApi);
    downloadBlob(documentId: string, property?: string, repositoryId?: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BlobDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BlobDownloadService>;
}
