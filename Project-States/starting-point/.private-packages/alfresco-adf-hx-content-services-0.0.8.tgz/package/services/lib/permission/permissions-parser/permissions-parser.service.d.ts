import { Group, User } from '@hylandsoftware/hxcs-js-client';
import { PermissionEntity, PermissionsManagementRow } from '../models/permissions-management-row.model';
import { RequiredAce } from '../models/required-ace.model';
import { PermissionsParserHelper } from './permissions-parser.helper';
import { IIdentityUserService } from '../../identity-user/identity-user.service';
import { DocumentAclData } from '../models/permission-checker.interface';
import * as i0 from "@angular/core";
export declare class PermissionsParserService {
    private identityUserService;
    private helper;
    constructor(identityUserService: IIdentityUserService, helper: PermissionsParserHelper);
    aclToPermissionsManagementRows(document: DocumentAclData): PermissionsManagementRow[];
    permissionsManagementRowsToAcl(permissionsManagementRow: PermissionsManagementRow[], isInheritanceEnabled?: boolean): RequiredAce[];
    getEntityPropertiesFromGroups(entities: Group[]): PermissionEntity[];
    getEntityPropertiesFromUsers(entities: User[]): PermissionEntity[];
    private getEntityFromPermissionsManagementRow;
    private isPermissionHigherThanInherited;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsParserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsParserService>;
}
