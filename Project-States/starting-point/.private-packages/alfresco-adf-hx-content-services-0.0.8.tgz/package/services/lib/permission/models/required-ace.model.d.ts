import { ACE } from '@hylandsoftware/hxcs-js-client';
type BaseRequiredAce = ACE & Required<Pick<ACE, 'creator' | 'permission' | 'granted'>>;
type UserRequiredAce = BaseRequiredAce & Required<Pick<BaseRequiredAce, 'user'>>;
type GroupRequiredAce = BaseRequiredAce & Required<Pick<BaseRequiredAce, 'group'>>;
export type RequiredAce = UserRequiredAce | GroupRequiredAce;
export {};
