import { AsyncValidatorFn } from '@angular/forms';
import { Observable } from 'rxjs';
import { PermissionEntity } from '../models/permissions-management-row.model';
import * as i0 from "@angular/core";
export declare class IsSuggestedPermissionEntityValidator {
    createValidator(suggestions$: Observable<PermissionEntity[]>): AsyncValidatorFn;
    private isValid;
    private isPermissionEntity;
    private suggestionsIncludePermissionEntity;
    private isSameArray;
    private error;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsSuggestedPermissionEntityValidator, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IsSuggestedPermissionEntityValidator>;
}
