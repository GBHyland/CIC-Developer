import { ACE, Document } from '@hylandsoftware/hxcs-js-client';
import { Permission } from '../models/permissions-management-row.model';
import { UserType } from '../models/user-type.enum';
export declare const EVERYONE_USER_ID = "__Everyone__";
export declare const EVERYTHING_PERMISSION = "Everything";
export declare const EFFECTIVE_STATUS = "EFFECTIVE";
export declare const NOTIFICATION_MESSAGES: {
    restore: {
        success: {
            GROUPS: string;
            USERS: string;
            ALL: string;
        };
        error: string;
    };
    save: {
        success: string;
        error: string;
    };
};
export declare const getHighestAce: (acl: Array<ACE | undefined>) => ACE | undefined;
export declare const getHighestPermission: (permission1: Permission, permission2: Permission) => Permission;
export declare const isPermissionInheritanceEnabled: (document: Document) => boolean;
export declare const isAclInheritanceBlocked: (ace?: ACE) => boolean;
export declare function removeUserTypeFromAcl(acl: ACE[], restoreOption: UserType): ACE[];
export declare function getNotificationMessage(isSuccess: boolean, restoreType?: UserType): string;
