import { QueryApi, QueryResult } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { SearchOptions } from './models/search-options.interface';
import * as i0 from "@angular/core";
export declare class SearchService {
    private queryApi;
    constructor(queryApi: QueryApi);
    getDocumentsByQuery(search: string, options?: SearchOptions): Observable<QueryResult>;
    sanitizeQuery(query: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchService>;
}
