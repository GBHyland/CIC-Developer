import { SearchFilterData, SearchFilterValue } from './search-filter.data';
export declare class MockSearchFilterValue implements SearchFilterValue {
    label: string;
    value: string;
}
export declare class MockSearchFilterData implements SearchFilterData {
    values: MockSearchFilterValue[];
    constructor(values?: MockSearchFilterValue[]);
    isEquivalentTo(data?: MockSearchFilterData): boolean;
}
