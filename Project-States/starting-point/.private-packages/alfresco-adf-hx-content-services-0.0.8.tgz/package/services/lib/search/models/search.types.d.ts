export declare const SearchType: {
    readonly BASIC: "basic";
    readonly HXQL: "hxql";
};
export type SearchType = typeof SearchType[keyof typeof SearchType];
