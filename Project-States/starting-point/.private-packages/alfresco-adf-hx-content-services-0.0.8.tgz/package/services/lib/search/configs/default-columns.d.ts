import { ColumnConfig } from '../models/column-config-data.interface';
export declare const DEFAULT_COLUMNS: ColumnConfig[];
