import { SearchFilterData } from './models/search-filter.data';
import { StorageService } from '@alfresco/adf-core';
import { BaseSearchFilter } from './models/search-filter.interface';
import { IIdentityUserService } from '../../identity-user/identity-user.service';
import * as i0 from "@angular/core";
export declare class SearchFilterValueStoreService {
    private identityUserService;
    private storageService;
    readonly SEARCH_FILTER_VALUES_KEY = "hxp-search-filters-value-store";
    protected storedValues: Map<string, SearchFilterData>;
    constructor(identityUserService: IIdentityUserService, storageService: StorageService);
    private get storageKey();
    reset(): void;
    addValue(filter: BaseSearchFilter, data: SearchFilterData): void;
    deleteValue(filter: BaseSearchFilter): void;
    getValue(filter: BaseSearchFilter): SearchFilterData | undefined;
    hasValues(): boolean;
    private load;
    private save;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFilterValueStoreService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchFilterValueStoreService>;
}
