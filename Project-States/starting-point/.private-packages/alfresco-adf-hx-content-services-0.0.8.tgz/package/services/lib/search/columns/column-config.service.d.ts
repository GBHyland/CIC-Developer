import { IdentityUserModel, StorageService, TranslationService } from '@alfresco/adf-core';
import { Observable } from 'rxjs';
import { ColumnConfig } from '../models/column-config-data.interface';
import { ColumnDataService } from './column-data.service';
import { DocumentModelService } from '../../document/document-model/document-model.service';
import * as i0 from "@angular/core";
export declare class ColumnConfigService {
    private storageService;
    private documentModeService;
    private columnDataService;
    protected translationService: TranslationService;
    columnConfigs$: Observable<ColumnConfig[]>;
    private columnConfigsSubject;
    constructor(storageService: StorageService, documentModeService: DocumentModelService, columnDataService: ColumnDataService, translationService: TranslationService);
    getDefaultColumns(): ColumnConfig[];
    getSelectedColumnsForCurrentUser(userInfo: IdentityUserModel): ColumnConfig[];
    setCurrentSelectedColumnsForCurrentUser(userInfo: IdentityUserModel, columns: ColumnConfig[]): void;
    getCustomColumns(): Observable<ColumnConfig[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ColumnConfigService>;
}
