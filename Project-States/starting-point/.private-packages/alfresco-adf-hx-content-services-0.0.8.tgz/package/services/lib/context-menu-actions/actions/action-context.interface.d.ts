import { Document } from '@hylandsoftware/hxcs-js-client';
export interface ActionContext {
    parentDocument?: Document;
    documents: Document[];
    shouldRedirect?: boolean;
    refererURL?: string;
    showPanel?: 'property' | 'version';
}
