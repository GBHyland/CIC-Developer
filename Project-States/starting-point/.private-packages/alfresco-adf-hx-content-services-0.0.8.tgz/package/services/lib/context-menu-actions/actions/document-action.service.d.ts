import { ActionContext } from './action-context.interface';
import { ActionExecutor } from './action-executor.interface';
import { PermissionChecker } from '../../permission/models/permission-checker.interface';
import * as i0 from "@angular/core";
export declare abstract class DocumentActionService implements PermissionChecker, ActionExecutor {
    abstract isAvailable(context: ActionContext): boolean;
    abstract execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentActionService>;
}
