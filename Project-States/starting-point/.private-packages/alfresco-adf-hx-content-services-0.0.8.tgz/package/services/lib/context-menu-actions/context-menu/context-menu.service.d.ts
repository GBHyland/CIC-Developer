import { Subject } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { DocumentActionService } from '../../context-menu-actions/actions/document-action.service';
import { IFeaturesService } from '@alfresco/adf-core/feature-flags';
import { ManageVersionsButtonActionService } from '../../manage-versions/manage-versions-button/manage-versions-button-action.service';
import * as i0 from "@angular/core";
export interface ContextActionConfiguration {
    data: Document;
    model: {
        key: string;
        icon: string;
        title: string;
        visible: boolean;
    };
    subject: Subject<any>;
}
export declare class ContextMenuActionsService {
    private documentDeleteHandler;
    private documentPermissionsHandler;
    private documentShareHandler;
    private documentSingleItemDownloadHandler;
    private documentInfoHandler;
    private featuresService;
    private documentCopyHandler?;
    private documentMoveHandler?;
    private replaceFileHander?;
    private createVersionHander?;
    private manageVersionsHandler?;
    private isVersioningFlagOn;
    constructor(documentDeleteHandler: DocumentActionService, documentPermissionsHandler: DocumentActionService, documentShareHandler: DocumentActionService, documentSingleItemDownloadHandler: DocumentActionService, documentInfoHandler: DocumentActionService, featuresService: IFeaturesService, documentCopyHandler?: DocumentActionService | undefined, documentMoveHandler?: DocumentActionService | undefined, replaceFileHander?: DocumentActionService | undefined, createVersionHander?: DocumentActionService | undefined, manageVersionsHandler?: ManageVersionsButtonActionService | undefined);
    getContextActions(data: Document, parentDocument?: Document): ContextActionConfiguration[];
    private toContextAction;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContextMenuActionsService, [null, null, null, null, null, null, { optional: true; }, { optional: true; }, { optional: true; }, { optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContextMenuActionsService>;
}
