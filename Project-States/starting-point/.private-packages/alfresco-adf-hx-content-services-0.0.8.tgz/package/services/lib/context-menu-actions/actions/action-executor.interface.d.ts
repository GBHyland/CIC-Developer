import { ActionContext } from './action-context.interface';
export interface ActionExecutor {
    execute(context: ActionContext): void;
}
