import { Model as HXCSModel } from '@hylandsoftware/hxcs-js-client';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
interface ComplexPropertyField {
    name: string;
    type: FieldType;
}
export declare class DocumentModel {
    private model;
    SYS_ROOT: string;
    constructor(model: HXCSModel);
    get documentModel(): HXCSModel;
    getFieldType(field: string): FieldType;
    isMultivaluedType(type: FieldType | undefined): boolean;
    isFieldTypeArray(fieldType: FieldType): boolean;
    getComplexFieldDetails(fieldName: string): ComplexPropertyField[];
    resolveType(type?: string): FieldType;
    getSubtypes(primaryType: string): string[];
    getFilishTypes(): string[];
    getFolderishTypes(): string[];
    hasMixin(primaryType: string, mixin: string): boolean;
    getAllTypes(): string[];
    isCustomSchema(schemaName: string): boolean;
    private getSchemaByPrefix;
    private hasResolver;
    private getResolverType;
    private getSchemas;
    private getFieldDefinition;
}
export {};
