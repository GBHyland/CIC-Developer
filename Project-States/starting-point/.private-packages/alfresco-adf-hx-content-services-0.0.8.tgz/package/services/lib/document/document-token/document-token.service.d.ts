import { InjectionToken } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare const DOCUMENT_SERVICE: InjectionToken<SharedDocumentService>;
export declare abstract class SharedDocumentService {
    abstract getDocumentById(documentId: string): Observable<Document>;
    abstract getDocumentByPath(path: string): Observable<Document>;
    abstract updateDocument(documentId: string, updatedFileReq: {
        [key: string]: any;
    } | undefined): Observable<Document>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedDocumentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharedDocumentService>;
}
