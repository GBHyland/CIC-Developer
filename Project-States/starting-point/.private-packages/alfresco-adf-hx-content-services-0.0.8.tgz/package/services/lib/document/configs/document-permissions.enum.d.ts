export declare const DocumentPermissions: {
    readonly CREATE_CHILD: "CreateChild";
    readonly CREATE_VERSION: "CreateVersion";
    readonly DELETE: "Delete";
    readonly DELETE_CHILD: "DeleteChild";
    readonly EVERYTHING: "Everything";
    readonly MANAGE_LOCK: "ManageLock";
    readonly MANAGE_RETENTION: "ManageRetention";
    readonly READ: "Read";
    readonly READ_WRITE: "ReadWrite";
    readonly WRITE: "Write";
    readonly WRITE_VERSION: "WriteVersion";
    readonly MANAGE_SECURITY: "ManageSecurity";
    readonly READ_VERSION: "ReadVersion";
};
export type DocumentPermissions = typeof DocumentPermissions[keyof typeof DocumentPermissions];
