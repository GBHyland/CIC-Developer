import { ModelApi } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { DocumentModel } from './document-model.model';
import * as i0 from "@angular/core";
export declare class DocumentModelService {
    protected modelApi: ModelApi;
    private model$;
    constructor(modelApi: ModelApi);
    getModel(): Observable<DocumentModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentModelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentModelService>;
}
