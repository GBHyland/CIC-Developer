import { CardViewItem } from '@alfresco/adf-core';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { PropertyUtilService } from './document-properties.util.service';
import { SharedDocumentPropertiesService } from './shared-document-properties.service';
import { DocumentModelService } from '../document-model/document-model.service';
import * as i0 from "@angular/core";
type SchemaPrefix = string;
type PrefixedProperty = string;
interface DocumentPropertiesFilteringOptions {
    exclude?: {
        properties?: PrefixedProperty[];
        schemas?: SchemaPrefix[];
    };
    include?: {
        properties?: PrefixedProperty[];
        schemas?: SchemaPrefix[];
    };
}
export declare class DocumentPropertiesService extends SharedDocumentPropertiesService {
    private documentModelService;
    private propertyUtilService;
    private model;
    constructor(documentModelService: DocumentModelService, propertyUtilService: PropertyUtilService);
    getPropertiesFromDocument(document?: Document, options?: DocumentPropertiesFilteringOptions): Observable<CardViewItem[]>;
    getDefaultPropertiesFromDocument(document?: Document): Observable<CardViewItem[]>;
    propertyType(property: string): FieldType | undefined;
    isFieldTypeArray(property: FieldType): boolean | undefined;
    extractCustomSchemaFields(primaryType: string): Observable<Record<string, any>>;
    getRequiredProperties(): string[];
    private getCustomSchemaFields;
    private populateCustomSchemaFields;
    private handleComplexFieldType;
    private getNestedFields;
    private fetchDocumentModel;
    private getCardItem;
    private createComplexCardItems;
    private filterProperty;
    private sortCardsByLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentPropertiesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentPropertiesService>;
}
export {};
