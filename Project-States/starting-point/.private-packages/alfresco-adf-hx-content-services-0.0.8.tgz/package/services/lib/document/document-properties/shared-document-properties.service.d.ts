import { Observable } from 'rxjs';
import { CardViewItem } from '@alfresco/adf-core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
import { InjectionToken } from '@angular/core';
import * as i0 from "@angular/core";
export declare const DOCUMENT_PROPERTIES_SERVICE: InjectionToken<SharedDocumentPropertiesService>;
export declare abstract class SharedDocumentPropertiesService {
    abstract getPropertiesFromDocument(document?: Document | null, options?: any): Observable<CardViewItem[]>;
    abstract getDefaultPropertiesFromDocument(document?: Document | null): Observable<CardViewItem[]>;
    abstract propertyType(property: string): FieldType | undefined;
    abstract getRequiredProperties(): string[];
    abstract extractCustomSchemaFields(documentId: string): Observable<Record<string, any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedDocumentPropertiesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharedDocumentPropertiesService>;
}
