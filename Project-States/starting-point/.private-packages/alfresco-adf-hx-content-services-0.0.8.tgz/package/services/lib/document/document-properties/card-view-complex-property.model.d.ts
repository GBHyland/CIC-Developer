import { CardViewItem, CardViewItemProperties, CardViewBaseItemModel, DynamicComponentModel } from '@alfresco/adf-core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { PropertyUtilService } from './document-properties.util.service';
import { DocumentModel } from '../document-model/document-model.model';
export interface ComplexCardViewItemProperties {
    document: Document;
    model: DocumentModel | undefined;
    propertyUtilService: PropertyUtilService;
}
export declare class ComplexFieldCardViewItemModel extends CardViewBaseItemModel implements CardViewItem, DynamicComponentModel {
    type: string;
    private property;
    private complexCardViewItemProperties;
    constructor(cardViewItemProperties: CardViewItemProperties, complexCardViewItemProperties: ComplexCardViewItemProperties);
    get displayValue(): CardViewItem[];
    private createCardItem;
}
