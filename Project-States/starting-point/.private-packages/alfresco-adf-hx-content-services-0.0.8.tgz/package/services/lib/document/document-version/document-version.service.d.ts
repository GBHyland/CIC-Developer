import { CheckInApi, Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class CreateDocumentVersionService {
    private checkInApi;
    constructor(checkInApi: CheckInApi);
    checkin(documentId: string, minor: boolean, repositoryId: string): Observable<Document>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreateDocumentVersionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CreateDocumentVersionService>;
}
