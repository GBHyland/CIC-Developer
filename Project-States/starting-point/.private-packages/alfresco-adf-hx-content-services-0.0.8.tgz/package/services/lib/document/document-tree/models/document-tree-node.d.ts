import { Document } from '@hylandsoftware/hxcs-js-client';
import { Subject } from 'rxjs';
export declare class DocumentTreeNode {
    document: Document;
    level: number;
    isExpandable: boolean;
    isLoading: boolean;
    isSelectable: boolean;
    isSkeleton: boolean;
    totalCount: number;
    nodeLoaded: Subject<boolean>;
    loadCancel$: Subject<void>;
    constructor(document: Document, level?: number, isExpandable?: boolean, isLoading?: boolean, isSelectable?: boolean, isSkeleton?: boolean, totalCount?: number, nodeLoaded?: Subject<boolean>, loadCancel$?: Subject<void>);
}
