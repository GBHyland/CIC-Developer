import { SnackBarData } from '@alfresco/adf-core';
import { DefaultStatusSnackBarIcon } from '@alfresco/adf-hx-content-services/api';
import { MatSnackBarConfig } from '@angular/material/snack-bar';
export interface INotificationService {
    showInfo(message: string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    showSuccess(message: string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    showError(message: string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    openSnackBar(message: string, decorativeIcon: DefaultStatusSnackBarIcon | string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
}
