import { NotificationService, SnackBarData } from '@alfresco/adf-core';
import { DefaultStatusSnackBarIcon } from '@alfresco/adf-hx-content-services/api';
import { MatSnackBarConfig } from '@angular/material/snack-bar';
import { INotificationService } from './notification.model';
import * as i0 from "@angular/core";
export declare class HxpNotificationService implements INotificationService {
    private notificationService;
    constructor(notificationService: NotificationService);
    showInfo(message: string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    showSuccess(message: string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    showError(message: string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    openSnackBar(message: string, decorativeIcon?: DefaultStatusSnackBarIcon | string, config?: MatSnackBarConfig<Omit<SnackBarData, 'actionLabel' | 'message'>>, interpolateArgs?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HxpNotificationService>;
}
