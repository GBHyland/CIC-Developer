export declare const CopyStatus: {
    readonly SUCCESS: "SUCCESS";
    readonly ERROR: "ERROR";
};
export type CopyStatus = typeof CopyStatus[keyof typeof CopyStatus];
