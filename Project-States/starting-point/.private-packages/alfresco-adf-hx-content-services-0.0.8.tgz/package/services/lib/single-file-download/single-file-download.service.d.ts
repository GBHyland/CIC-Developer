import { Document } from '@hylandsoftware/hxcs-js-client';
import { DownloadService } from '@alfresco/adf-core';
import { Observable } from 'rxjs';
import { BlobDownloadService } from '../blob-download/blob-download.service';
import { DownloadStatus } from './models/download-status.enum';
import * as i0 from "@angular/core";
export declare class SingleFileDownloadService {
    private downloadService;
    private blobDownloadService;
    constructor(downloadService: DownloadService, blobDownloadService: BlobDownloadService);
    download(document: Document): Observable<DownloadStatus>;
    private emitDownloadStatusError;
    private emitDownloadStatusSuccess;
    private emitDownloadStatusRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleFileDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SingleFileDownloadService>;
}
