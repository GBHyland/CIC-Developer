import { Document } from '@hylandsoftware/hxcs-js-client';
import { SingleFileDownloadService } from './single-file-download.service';
import { HxpNotificationService } from '../notification/hxp-notification.service';
import { IsSingleDocumentWithMainBlobService } from '../is-single-document-with-main-blob/is-single-document-with-main-blob.service';
import * as i0 from "@angular/core";
export declare class FileDownloadService {
    private singleFileDownloadService;
    private hxpNotificationService;
    private isSingleDocumentWithMainBlobService;
    constructor(singleFileDownloadService: SingleFileDownloadService, hxpNotificationService: HxpNotificationService, isSingleDocumentWithMainBlobService: IsSingleDocumentWithMainBlobService);
    downloadFile(hxpSingleFileDownload: Document[]): void;
    private displayNotificationMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileDownloadService>;
}
