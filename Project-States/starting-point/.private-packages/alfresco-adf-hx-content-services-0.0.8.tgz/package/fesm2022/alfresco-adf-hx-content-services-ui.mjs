import * as i0 from '@angular/core';
import { Input, Component, Injectable, inject, Pipe, DestroyRef, EventEmitter, ViewChild, ContentChild, Output, Inject, ViewEncapsulation, ChangeDetectionStrategy, Optional, HostListener, Attribute, Directive } from '@angular/core';
import { from, of, BehaviorSubject, filter as filter$1, take, switchMap as switchMap$1, EMPTY, map as map$1, Subject, iif, defer, merge, finalize as finalize$1 } from 'rxjs';
import { filter, switchMap, catchError, finalize, mergeMap, map, toArray, debounceTime, shareReplay, take as take$1 } from 'rxjs/operators';
import * as i1 from '@alfresco/adf-hx-content-services/services';
import { DocumentActionService, hasPermission, DocumentPermissions, isRoot, DEFAULT_ITEMS_PER_PAGE, isFolder, HXP_DOCUMENT_INFO_ACTION_SERVICE, HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE, ContextMenuActionsService, DocumentTreeDatabaseService, getRetentionStatus, BLOCK_DELETE_STATUSES, isVersion, getHighestPermission, PermissionsManagementFacade, PermissionsManagementStateService, UserType, PERMISSIONS_MANAGEMENT_COMPONENT_TYPE, IDENTITY_USER_SERVICE_TOKEN, HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE, HXP_DOCUMENT_DELETE_ACTION_SERVICE, HXP_DOCUMENT_SHARE_ACTION_SERVICE, HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE, HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE, HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE, HXP_MANAGE_COLUMN_ACTION_SERVICE, DocumentCacheService, hasBlob, BLOCK_EDIT_STATUSES, DOCUMENT_SERVICE, DOCUMENT_PROPERTIES_SERVICE, hasRenditionBlob, RenditionStatus, DEFAULT_RENDITION_ID, pollWhile, UserResolverPipe, SearchType } from '@alfresco/adf-hx-content-services/services';
import * as i4 from '@ngx-translate/core';
import { TranslatePipe, TranslateModule } from '@ngx-translate/core';
import { ROOT_DOCUMENT, FieldType } from '@alfresco/adf-hx-content-services/api';
import * as i6 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import { SelectionModel } from '@angular/cdk/collections';
import * as i3$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i6$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule, MatProgressSpinner } from '@angular/material/progress-spinner';
import * as i3 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i7 from '@angular/material/tree';
import { MatTreeModule, MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { FolderIconComponent, DefaultIcon, MimeTypeIconComponent, SearchActionIconComponent } from '@alfresco/adf-hx-content-services/icons';
import * as i2$2 from '@angular/common';
import { NgFor, NgIf, NgClass, NgTemplateOutlet, KeyValuePipe, CommonModule, AsyncPipe, NgSwitch, NgSwitchCase, DatePipe } from '@angular/common';
import * as i2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i1$5 from '@alfresco/adf-core';
import { TranslationService, DataColumnListComponent, NoContentTemplateDirective, EmptyContentComponent, DataTableComponent, provideTranslations, LoadingContentTemplateDirective, CardViewComponent, InfoDrawerLayoutComponent, InfoDrawerContentDirective, InfoDrawerComponent, InfoDrawerTabComponent, ViewerComponent, ViewerToolbarComponent, ViewerSidebarComponent, CustomEmptyContentTemplateDirective } from '@alfresco/adf-core';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i1$2 from '@angular/forms';
import { FormControlName, Validators, ReactiveFormsModule, FormsModule, FormGroup, FormControl } from '@angular/forms';
import * as i3$2 from '@angular/cdk/clipboard';
import * as i2$3 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i6$2 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i7$1 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i3$5 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i3$4 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i5 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i1$3 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import * as i3$3 from '@angular/material/autocomplete';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatOptionModule, ShowOnDirtyErrorStateMatcher } from '@angular/material/core';
import * as i2$1 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i1$4 from '@angular/material/button-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import * as i9 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i7$2 from '@angular/cdk/text-field';
import * as i3$6 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import { BreadcrumbComponent, BreadcrumbItemComponent } from '@alfresco/adf-core/breadcrumbs';
import { RouterLink } from '@angular/router';
import { DynamicExtensionComponent } from '@alfresco/adf-extensions';
import { FeaturesServiceToken } from '@alfresco/adf-core/feature-flags';
import { ADF_HX_CONTENT_SERVICES_INTERNAL } from '@alfresco/adf-hx-content-services/features';
import * as i2$4 from '@angular/platform-browser';
import * as i10 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { sub, formatISO, isBefore, isAfter, parse, isValid } from 'date-fns';
import * as i13 from '@angular/material/list';
import { MatListModule, MatSelectionList } from '@angular/material/list';
import * as i1$6 from '@angular/cdk/overlay';
import { OverlayConfig, OverlayModule } from '@angular/cdk/overlay';
import { TemplatePortal, PortalModule } from '@angular/cdk/portal';
import * as i6$3 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import { FlatTreeControl } from '@angular/cdk/tree';
import { ngMocks } from 'ng-mocks';
import { ComponentHarness } from '@angular/cdk/testing';
import { MatButtonHarness } from '@angular/material/button/testing';
import { MatIconHarness } from '@angular/material/icon/testing';

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a skeleton to display during content loading.
 *
 * To use the `TreeSkeletonLoaderComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { TreeSkeletonLoaderComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         TreeSkeletonLoaderComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-tree-skeleton-loader></hxp-tree-skeleton-loader>
 */
class TreeSkeletonLoaderComponent {
    constructor() {
        /**
         * Indicates the number of rows to display in the skeleton tree.
         * @type {number}
         * @default 10
         */
        this.skeletonRows = TreeSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    /**
     * Default value of skeleton tree rows to display.
     * @readonly
     * @type {number}
     */
    static { this.DEFAULT_SKELETON_ROWS = 10; }
    ngOnChanges() {
        if (!this.skeletonRows && this.skeletonRows !== 0) {
            this.skeletonRows = TreeSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        }
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    skeletonRowTrackBy(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: TreeSkeletonLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: TreeSkeletonLoaderComponent, isStandalone: true, selector: "hxp-tree-skeleton-loader", inputs: { skeletonRows: "skeletonRows" }, usesOnChanges: true, ngImport: i0, template: "<table class=\"hxp-skeleton-table\">\n    <tbody>\n        <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n            <td class=\"hxp-skeleton-icon-cell\">\n                <div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div>\n            </td>\n            <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n        </tr>\n    </tbody>\n</table>\n", styles: [".hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:#d1d5db;border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-icon{width:30px;height:30px}.hxp-skeleton-text-100{width:100%;height:30px}.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: TreeSkeletonLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-tree-skeleton-loader', standalone: true, imports: [NgFor], template: "<table class=\"hxp-skeleton-table\">\n    <tbody>\n        <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n            <td class=\"hxp-skeleton-icon-cell\">\n                <div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div>\n            </td>\n            <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n        </tr>\n    </tbody>\n</table>\n", styles: [".hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:#d1d5db;border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-icon{width:30px;height:30px}.hxp-skeleton-text-100{width:100%;height:30px}.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"] }]
        }], propDecorators: { skeletonRows: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SingleItemDownloadButtonActionService extends DocumentActionService {
    constructor(fileDownloadService, isSingleDocumentWithMainBlobService) {
        super();
        this.fileDownloadService = fileDownloadService;
        this.isSingleDocumentWithMainBlobService = isSingleDocumentWithMainBlobService;
    }
    isAvailable(context) {
        return (context?.documents &&
            this.isSingleDocumentWithMainBlobService.validate(context.documents) &&
            hasPermission(context.documents?.[0], DocumentPermissions.READ));
    }
    execute(context) {
        if (context?.documents[0]) {
            this.fileDownloadService.downloadFile(context?.documents);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SingleItemDownloadButtonActionService, deps: [{ token: i1.FileDownloadService }, { token: i1.IsSingleDocumentWithMainBlobService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SingleItemDownloadButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SingleItemDownloadButtonActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.FileDownloadService }, { type: i1.IsSingleDocumentWithMainBlobService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CacheLabelService {
    constructor() {
        this.cache = new Map();
        this.translationService = inject(TranslationService);
    }
    getCache() {
        return this.cache;
    }
    getTranslation(doc, rootTranslationKey) {
        const key = doc.sys_id ?? this.generateUniqueKey(doc);
        if (this.cache.has(key)) {
            return this.cache.get(key);
        }
        const translatedValue = this.getLabel(doc, rootTranslationKey);
        this.cache.set(key, translatedValue);
        return translatedValue;
    }
    getLabel(doc, rootTranslationKey) {
        return isRoot(doc) ? this.translationService.instant(rootTranslationKey) : doc?.sys_title;
    }
    generateUniqueKey(doc) {
        const sortedEntries = Object.entries(doc).sort(([keyA], [keyB]) => keyA.localeCompare(keyB));
        const keyString = sortedEntries
            .map(([key, value]) => {
            return `${key}=${value ?? ''}`;
        })
            .join('|');
        return keyString;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CacheLabelService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CacheLabelService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CacheLabelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class BreadcrumbLabelPipe {
    constructor() {
        this.cacheLabelService = inject(CacheLabelService);
    }
    transform(doc, translationKey) {
        if (!doc) {
            return '';
        }
        return this.cacheLabelService.getTranslation(doc, translationKey);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: BreadcrumbLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: BreadcrumbLabelPipe, isStandalone: true, name: "breadcrumbLabel" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: BreadcrumbLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'breadcrumbLabel',
                    standalone: true,
                }]
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that displays a tree of documents.
 *
 * To use the `HxpDocumentTreeComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpDocumentTreeComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *    imports: [
 *       HxpDocumentTreeComponent,
 *      ...
 *   ],
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-tree></hxp-document-tree>
 *
 */
class HxpDocumentTreeComponent {
    constructor(documentService, contextMenuActionsService, changeDetectorRef, dataSource) {
        this.documentService = documentService;
        this.contextMenuActionsService = contextMenuActionsService;
        this.changeDetectorRef = changeDetectorRef;
        this.dataSource = dataSource;
        this.destroyRef = inject(DestroyRef);
        /**
         * Emits the document that has been selected or unselected.
         */
        this.selectedDocument = new EventEmitter();
        this.contextActionMenuTemplateRef = null;
        this.DEFAULT_ITEMS_PER_PAGE = DEFAULT_ITEMS_PER_PAGE;
        this.contextMenuPosition = { x: '0px', y: '0px' };
        this.isInitialTreeLoad = false;
        this.hasChild = (_, _nodeData) => _nodeData.isExpandable;
        this.contextActions = [];
        this.multiSelection = false;
        this.selection = new SelectionModel(true, [], true, (doc1, doc2) => doc1?.sys_id === doc2?.sys_id);
        this.rootDocument = ROOT_DOCUMENT;
        this.documents = [];
        this.treeControl = this.dataSource.treeControl;
    }
    ngOnInit() {
        this.loadInitialData();
        this.destroyRef.onDestroy(() => {
            this.dataSource.disconnect();
        });
    }
    ngOnChanges(changes) {
        if (changes['documents'] && this.documents) {
            this.selection.clear();
            for (const doc of this.documents) {
                this.selection.toggle(doc);
            }
            from(this.documents)
                .pipe(filter((doc) => !!doc), switchMap((doc) => this.documentService.getAncestors(doc?.sys_id || '').pipe(catchError(() => of([{ ...ROOT_DOCUMENT }])))))
                .subscribe({
                next: (documents) => this.openNodes(documents),
            });
        }
    }
    ngAfterContentChecked() {
        this.changeDetectorRef.detectChanges();
    }
    onContextMenu(event, document) {
        if (this.multiSelection || !this.contextActionMenuTemplateRef) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuPosition.x = event.clientX + 'px';
        this.contextMenuPosition.y = event.clientY + 'px';
        const targetHtmlElement = event.target;
        if (targetHtmlElement.tagName !== 'BUTTON' && targetHtmlElement.tagName !== 'MAT-ICON') {
            const node = targetHtmlElement.closest('mat-tree-node');
            const trigger = node?.querySelector('.hxp-menu-trigger');
            this.contextActions = this.getContextActions(document);
            if (this.contextActions.some((action) => action.model?.visible)) {
                trigger?.dispatchEvent(new MouseEvent('click'));
            }
        }
    }
    openContextMenu(_, document) {
        if (this.contextActionMenuTemplateRef && !this.multiSelection) {
            this.contextActions = this.getContextActions(document);
        }
    }
    hasVisibleActions(document) {
        const contextActions = this.getContextActions(document);
        return contextActions.some((action) => action.model?.visible);
    }
    onDocumentSelected(document, e) {
        // To prevent selecting the same document multiple times
        if (!this.multiSelection && this.documents?.length === 1 && this.documents[0]?.sys_id === document.sys_id) {
            return;
        }
        if (!this.multiSelection) {
            this.selection.clear();
        }
        this.selection.toggle(document);
        this.documents = [...this.selection.selected];
        this.selectedDocument.emit(document);
        if (e?.target) {
            this.scrollTreeNodeIntoView(e);
        }
    }
    isDocumentExpandable(document) {
        return isRoot(document) || isFolder(document);
    }
    onNodeExpand(event) {
        this.scrollTreeNodeIntoView(event);
        event.preventDefault();
        event.stopPropagation();
    }
    loadInitialData() {
        this.isInitialTreeLoad = true;
        this.dataSource
            .dataChanges()
            .pipe(takeUntilDestroyed(this.destroyRef), finalize(() => {
            this.isInitialTreeLoad = false;
        }))
            .subscribe({
            next: () => {
                if (this.dataSource.treeControl.dataNodes?.length > 0) {
                    this.isInitialTreeLoad = false;
                    this.changeDetectorRef.detectChanges();
                }
            },
            error: (err) => {
                console.error(err);
            },
        });
        this.dataSource.setDocumentTreeRoot(this.rootDocument);
        this.dataSource.openNodeAtIndex(0);
    }
    getContextActions(document) {
        return this.contextMenuActionsService.getContextActions(document, this.documents[0]);
    }
    openNodes(documents) {
        if (!this.multiSelection && Array.isArray(documents) && documents.length > 0) {
            this.dataSource.openNodes(documents);
        }
    }
    scrollTreeNodeIntoView(e) {
        const el = e.target;
        const treeNode = el.closest('mat-tree-node');
        if (treeNode) {
            treeNode.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'end' });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpDocumentTreeComponent, deps: [{ token: i1.DocumentService }, { token: i1.ContextMenuActionsService }, { token: i0.ChangeDetectorRef }, { token: i1.DocumentTreeDatabaseService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: HxpDocumentTreeComponent, isStandalone: true, selector: "hxp-document-tree", inputs: { rootDocument: "rootDocument", documents: "documents", multiSelection: "multiSelection" }, outputs: { selectedDocument: "selectedDocument" }, providers: [
            /*  We're hiding info action since it's based on a selection mechanism that's
            non-existing in the document tree
            */
            {
                provide: HXP_DOCUMENT_INFO_ACTION_SERVICE,
                useValue: {
                    isAvailable: () => false,
                    execute: () => { },
                },
            },
            {
                provide: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE,
                useClass: SingleItemDownloadButtonActionService,
            },
            ContextMenuActionsService,
            DocumentTreeDatabaseService,
        ], queries: [{ propertyName: "contextActionMenuTemplateRef", first: true, predicate: ["contextActionMenu"], descendants: true }], viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: ["trigger"], descendants: true }, { propertyName: "hiddenTrigger", first: true, predicate: ["hiddenTrigger"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-tree-container\" #treeContainer>\n    <mat-tree\n        [dataSource]=\"dataSource\"\n        [treeControl]=\"treeControl\"\n        class=\"hxp-fill\"\n        *ngIf=\"!isInitialTreeLoad\"\n    >\n        <mat-tree-node\n            *matTreeNodeDef=\"let node\"\n            matTreeNodePadding\n            [ngClass]=\"{\n                'hxp-selected': !multiSelection && selection.isSelected(node.document)\n            }\"\n            (click)=\"onDocumentSelected(node.document, $event)\"\n        >\n        <ng-container *ngIf=\"!node.isSkeleton; else skeletonTemplate\">\n            <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                <mat-progress-spinner mode=\"indeterminate\" diameter=\"30\" />\n            </ng-container>\n\n            <ng-template #showFolderIcon>\n                <hxp-folder-icon\n                    *ngIf=\"isDocumentExpandable(node.document)\"\n                    [isExpanded]=\"treeControl.isExpanded(node)\"\n                />\n            </ng-template>\n            <span\n                (click)=\"onDocumentSelected(node.document, $event)\"\n                class=\"hxp-node-label\"\n            >\n                {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n            </span>\n        </ng-container>\n\n        <ng-template #skeletonTemplate>\n            <hxp-tree-skeleton-loader [skeletonRows]=\"1\" />\n        </ng-template>\n        </mat-tree-node>\n\n        <mat-tree-node\n            *matTreeNodeDef=\"let node; when: hasChild\"\n            matTreeNodePadding\n            [ngClass]=\"{\n                'hxp-selected': !multiSelection && selection.isSelected(node.document),\n                'hxp-node-context-opened': menuTrigger?.menuOpen || hiddenTrigger?.menuOpen\n            }\"\n        >\n            <button\n                mat-icon-button\n                [attr.aria-label]=\"('DOCUMENT_TREE.TOGGLE_ARIA-LABEL ' | translate) + node.name\"\n                matTreeNodeToggle\n                (click)=\"onNodeExpand($event)\"\n            >\n                <mat-icon class=\"mat-icon-rtl-mirror\">\n                    {{\n                        treeControl.isExpanded(node) ? 'expand_more' : 'chevron_right'\n                    }}\n                </mat-icon>\n            </button>\n\n            <mat-checkbox\n                *ngIf=\"multiSelection && node.isSelectable\"\n                class=\"hxp-node-selection-checkbox\"\n                (change)=\"onDocumentSelected(node.document)\"\n                [checked]=\"selection.isSelected(node.document)\"\n            />\n\n            <ng-container>\n                <div\n                    class=\"hxp-node-container\"\n                    (click)=\"onDocumentSelected(node.document, $event)\"\n                    (contextmenu)=\"onContextMenu($event, node.document)\"\n                >\n                    <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                        <mat-progress-spinner mode=\"indeterminate\" diameter=\"30\" />\n                    </ng-container>\n\n                    <ng-template #showFolderIcon>\n                        <hxp-folder-icon\n                            *ngIf=\"isDocumentExpandable(node.document)\"\n                            [isExpanded]=\"treeControl.isExpanded(node)\"\n                        />\n                    </ng-template>\n\n                    <span class=\"hxp-node-label\" title=\"{{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\">\n                        {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n                    </span>\n                </div>\n\n                <div class=\"hxp-context-btn\" *ngIf=\"!multiSelection && contextActionMenuTemplateRef\">\n                    <button\n                        mat-icon-button\n                        #trigger=\"matMenuTrigger\"\n                        role=\"button\"\n                        *ngIf=\"hasVisibleActions(node.document)\"\n                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                        [matMenuTriggerFor]=\"contextMenu\"\n                        [matMenuTriggerData]=\"{ actions: contextActions }\"\n                        [ngClass]=\"{ 'hxp-menu-opened': trigger.menuOpen || hiddenTrigger.menuOpen }\"\n                        (click)=\"openContextMenu($event, node.document)\"\n                    >\n                        <mat-icon aria-hidden=\"true\">more_vert</mat-icon>\n                    </button>\n                </div>\n\n                <div\n                    #hiddenTrigger=\"matMenuTrigger\"\n                    class=\"hxp-menu-trigger\"\n                    [style.left]=\"contextMenuPosition.x\"\n                    [style.top]=\"contextMenuPosition.y\"\n                    [matMenuTriggerFor]=\"contextMenu\"\n                    [matMenuTriggerData]=\"{ actions: contextActions }\"\n                ></div>\n            </ng-container>\n        </mat-tree-node>\n    </mat-tree>\n\n    <hxp-tree-skeleton-loader *ngIf=\"isInitialTreeLoad\" [skeletonRows]=\"DEFAULT_ITEMS_PER_PAGE\" />\n</div>\n<mat-menu #contextMenu=\"matMenu\" class=\"hxp-context-menu\">\n    <ng-container\n        *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n</mat-menu>\n", styles: [".hxp-context-btn button{opacity:0}.hxp-context-btn button.hxp-menu-opened{opacity:1}mat-tree{overflow-y:auto;overflow-x:auto;background-color:transparent;width:100%;height:100%;display:flex;flex-direction:column}mat-tree-node{border-left:6px solid transparent;min-height:48px;text-wrap:wrap;width:calc(100% - 40px)}mat-tree-node[aria-level=\"1\"]{width:100%}mat-tree-node.hxp-node-context-opened{background-color:var(--theme-background-selected-button-color, #e0e0e0);opacity:.9}mat-tree-node:hover{background-color:#ebeaf5;opacity:.9;cursor:pointer}mat-tree-node:hover .hxp-context-btn button{opacity:1}mat-tree-node:hover .hxp-node-label{max-width:112px}button :not(.hxp-context-btn button){transform:scale(.9)}.hxp-selected{background-color:var(--theme-background-hover-color, #f9f9fc);border-left:6px solid var(--theme-primary-color, #5654ac)}.hxp-node-label{max-width:135px;margin-left:10px;overflow:hidden;text-overflow:ellipsis;word-wrap:normal;white-space:nowrap}.hxp-node-container{display:flex;flex:1;align-items:center}.hxp-menu-trigger{visibility:hidden;position:fixed}.hxp-fill{height:100%;min-height:100%;min-width:100%;width:100%}.hxp-node-selection-checkbox{margin:0 24px 0 12px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: FolderIconComponent, selector: "hxp-folder-icon", inputs: ["isExpanded"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i3.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i6.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i6.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: MatTreeModule }, { kind: "directive", type: i7.MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: i7.MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "directive", type: i7.MatTreeNodeToggle, selector: "[matTreeNodeToggle]", inputs: ["matTreeNodeToggleRecursive"] }, { kind: "component", type: i7.MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: i7.MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "ngmodule", type: MatSnackBarModule }, { kind: "component", type: TreeSkeletonLoaderComponent, selector: "hxp-tree-skeleton-loader", inputs: ["skeletonRows"] }, { kind: "pipe", type: BreadcrumbLabelPipe, name: "breadcrumbLabel" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpDocumentTreeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-tree', providers: [
                        /*  We're hiding info action since it's based on a selection mechanism that's
                        non-existing in the document tree
                        */
                        {
                            provide: HXP_DOCUMENT_INFO_ACTION_SERVICE,
                            useValue: {
                                isAvailable: () => false,
                                execute: () => { },
                            },
                        },
                        {
                            provide: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE,
                            useClass: SingleItemDownloadButtonActionService,
                        },
                        ContextMenuActionsService,
                        DocumentTreeDatabaseService,
                    ], standalone: true, imports: [
                        NgIf,
                        NgClass,
                        NgTemplateOutlet,
                        FolderIconComponent,
                        MatButtonModule,
                        MatCheckboxModule,
                        MatIconModule,
                        MatMenuModule,
                        MatProgressSpinnerModule,
                        MatTreeModule,
                        TranslatePipe,
                        MatSnackBarModule,
                        TreeSkeletonLoaderComponent,
                        BreadcrumbLabelPipe,
                    ], template: "<div class=\"hxp-tree-container\" #treeContainer>\n    <mat-tree\n        [dataSource]=\"dataSource\"\n        [treeControl]=\"treeControl\"\n        class=\"hxp-fill\"\n        *ngIf=\"!isInitialTreeLoad\"\n    >\n        <mat-tree-node\n            *matTreeNodeDef=\"let node\"\n            matTreeNodePadding\n            [ngClass]=\"{\n                'hxp-selected': !multiSelection && selection.isSelected(node.document)\n            }\"\n            (click)=\"onDocumentSelected(node.document, $event)\"\n        >\n        <ng-container *ngIf=\"!node.isSkeleton; else skeletonTemplate\">\n            <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                <mat-progress-spinner mode=\"indeterminate\" diameter=\"30\" />\n            </ng-container>\n\n            <ng-template #showFolderIcon>\n                <hxp-folder-icon\n                    *ngIf=\"isDocumentExpandable(node.document)\"\n                    [isExpanded]=\"treeControl.isExpanded(node)\"\n                />\n            </ng-template>\n            <span\n                (click)=\"onDocumentSelected(node.document, $event)\"\n                class=\"hxp-node-label\"\n            >\n                {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n            </span>\n        </ng-container>\n\n        <ng-template #skeletonTemplate>\n            <hxp-tree-skeleton-loader [skeletonRows]=\"1\" />\n        </ng-template>\n        </mat-tree-node>\n\n        <mat-tree-node\n            *matTreeNodeDef=\"let node; when: hasChild\"\n            matTreeNodePadding\n            [ngClass]=\"{\n                'hxp-selected': !multiSelection && selection.isSelected(node.document),\n                'hxp-node-context-opened': menuTrigger?.menuOpen || hiddenTrigger?.menuOpen\n            }\"\n        >\n            <button\n                mat-icon-button\n                [attr.aria-label]=\"('DOCUMENT_TREE.TOGGLE_ARIA-LABEL ' | translate) + node.name\"\n                matTreeNodeToggle\n                (click)=\"onNodeExpand($event)\"\n            >\n                <mat-icon class=\"mat-icon-rtl-mirror\">\n                    {{\n                        treeControl.isExpanded(node) ? 'expand_more' : 'chevron_right'\n                    }}\n                </mat-icon>\n            </button>\n\n            <mat-checkbox\n                *ngIf=\"multiSelection && node.isSelectable\"\n                class=\"hxp-node-selection-checkbox\"\n                (change)=\"onDocumentSelected(node.document)\"\n                [checked]=\"selection.isSelected(node.document)\"\n            />\n\n            <ng-container>\n                <div\n                    class=\"hxp-node-container\"\n                    (click)=\"onDocumentSelected(node.document, $event)\"\n                    (contextmenu)=\"onContextMenu($event, node.document)\"\n                >\n                    <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                        <mat-progress-spinner mode=\"indeterminate\" diameter=\"30\" />\n                    </ng-container>\n\n                    <ng-template #showFolderIcon>\n                        <hxp-folder-icon\n                            *ngIf=\"isDocumentExpandable(node.document)\"\n                            [isExpanded]=\"treeControl.isExpanded(node)\"\n                        />\n                    </ng-template>\n\n                    <span class=\"hxp-node-label\" title=\"{{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\">\n                        {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n                    </span>\n                </div>\n\n                <div class=\"hxp-context-btn\" *ngIf=\"!multiSelection && contextActionMenuTemplateRef\">\n                    <button\n                        mat-icon-button\n                        #trigger=\"matMenuTrigger\"\n                        role=\"button\"\n                        *ngIf=\"hasVisibleActions(node.document)\"\n                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                        [matMenuTriggerFor]=\"contextMenu\"\n                        [matMenuTriggerData]=\"{ actions: contextActions }\"\n                        [ngClass]=\"{ 'hxp-menu-opened': trigger.menuOpen || hiddenTrigger.menuOpen }\"\n                        (click)=\"openContextMenu($event, node.document)\"\n                    >\n                        <mat-icon aria-hidden=\"true\">more_vert</mat-icon>\n                    </button>\n                </div>\n\n                <div\n                    #hiddenTrigger=\"matMenuTrigger\"\n                    class=\"hxp-menu-trigger\"\n                    [style.left]=\"contextMenuPosition.x\"\n                    [style.top]=\"contextMenuPosition.y\"\n                    [matMenuTriggerFor]=\"contextMenu\"\n                    [matMenuTriggerData]=\"{ actions: contextActions }\"\n                ></div>\n            </ng-container>\n        </mat-tree-node>\n    </mat-tree>\n\n    <hxp-tree-skeleton-loader *ngIf=\"isInitialTreeLoad\" [skeletonRows]=\"DEFAULT_ITEMS_PER_PAGE\" />\n</div>\n<mat-menu #contextMenu=\"matMenu\" class=\"hxp-context-menu\">\n    <ng-container\n        *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n</mat-menu>\n", styles: [".hxp-context-btn button{opacity:0}.hxp-context-btn button.hxp-menu-opened{opacity:1}mat-tree{overflow-y:auto;overflow-x:auto;background-color:transparent;width:100%;height:100%;display:flex;flex-direction:column}mat-tree-node{border-left:6px solid transparent;min-height:48px;text-wrap:wrap;width:calc(100% - 40px)}mat-tree-node[aria-level=\"1\"]{width:100%}mat-tree-node.hxp-node-context-opened{background-color:var(--theme-background-selected-button-color, #e0e0e0);opacity:.9}mat-tree-node:hover{background-color:#ebeaf5;opacity:.9;cursor:pointer}mat-tree-node:hover .hxp-context-btn button{opacity:1}mat-tree-node:hover .hxp-node-label{max-width:112px}button :not(.hxp-context-btn button){transform:scale(.9)}.hxp-selected{background-color:var(--theme-background-hover-color, #f9f9fc);border-left:6px solid var(--theme-primary-color, #5654ac)}.hxp-node-label{max-width:135px;margin-left:10px;overflow:hidden;text-overflow:ellipsis;word-wrap:normal;white-space:nowrap}.hxp-node-container{display:flex;flex:1;align-items:center}.hxp-menu-trigger{visibility:hidden;position:fixed}.hxp-fill{height:100%;min-height:100%;min-width:100%;width:100%}.hxp-node-selection-checkbox{margin:0 24px 0 12px}\n"] }]
        }], ctorParameters: () => [{ type: i1.DocumentService }, { type: i1.ContextMenuActionsService }, { type: i0.ChangeDetectorRef }, { type: i1.DocumentTreeDatabaseService }], propDecorators: { rootDocument: [{
                type: Input
            }], documents: [{
                type: Input
            }], multiSelection: [{
                type: Input
            }], selectedDocument: [{
                type: Output
            }], contextActionMenuTemplateRef: [{
                type: ContentChild,
                args: ['contextActionMenu', { static: false }]
            }], menuTrigger: [{
                type: ViewChild,
                args: ['trigger', { static: false }]
            }], hiddenTrigger: [{
                type: ViewChild,
                args: ['hiddenTrigger', { static: false }]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DeletedStatus = {
    REQUEST: 'REQUEST',
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const deleteItemNotificationMessages = {
    [DeletedStatus.REQUEST]: {
        SINGLE: 'DOCUMENT_DELETE.SNACKBAR.DELETE.ITEM.REQUEST',
        MULTI: 'DOCUMENT_DELETE.SNACKBAR.DELETE.MULTIPLE_ITEMS.REQUEST',
    },
    [DeletedStatus.SUCCESS]: {
        SINGLE: 'DOCUMENT_DELETE.SNACKBAR.DELETE.ITEM.SUCCESS',
        MULTI: 'DOCUMENT_DELETE.SNACKBAR.DELETE.MULTIPLE_ITEMS.SUCCESS',
    },
    [DeletedStatus.ERROR]: {
        SINGLE: 'DOCUMENT_DELETE.SNACKBAR.DELETE.ITEM.ERROR',
        MULTI: 'DOCUMENT_DELETE.SNACKBAR.DELETE.MULTIPLE_ITEMS.ERROR',
    },
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const deleteSnackBarTypes = {
    [DeletedStatus.REQUEST]: 'info',
    [DeletedStatus.SUCCESS]: 'done',
    [DeletedStatus.ERROR]: 'error',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentDeleteConfirmationDialogComponent {
    constructor(dialogData, dialogRef, hxpNotificationService, documentService, documentRouterService, routerExtService, translate) {
        this.dialogData = dialogData;
        this.dialogRef = dialogRef;
        this.hxpNotificationService = hxpNotificationService;
        this.documentService = documentService;
        this.documentRouterService = documentRouterService;
        this.routerExtService = routerExtService;
        this.translate = translate;
        this.documents = [];
        this.shouldRedirect = this.dialogData?.shouldRedirect;
        this.refererURL = this.dialogData?.refererURL;
        this.isDeleting = false;
        this.documents = this.dialogData?.documents ?? [];
        this.populateDialogTitleAndDescription();
        this.deleteDocument$ = from(this.documents).pipe(filter((document) => !!document?.sys_id), mergeMap((document) => this.documentService.deleteDocument(document.sys_id).pipe(map((docId) => ({
            success: true,
            docId,
        })), catchError((error) => of({
            success: false,
            error: error,
            docId: document.sys_id,
        })))), toArray());
    }
    onDelete() {
        this.isDeleting = true;
        this.deleteDocument$.subscribe({
            next: (results) => {
                this.processDeletionResultsAndNotify(results);
            },
            error: () => {
                this.displayNotificationMessage('DOCUMENT_DELETE.SNACKBAR.DELETE.ERROR', DeletedStatus.ERROR);
            },
            complete: () => {
                this.isDeleting = false;
                this.dialogRef.close();
                if (this.shouldRedirect) {
                    this.redirectToReferer();
                }
            },
        });
    }
    redirectToReferer() {
        this.routerExtService.redirectToReferer(this.refererURL, this.documentRouterService.urlForParent(this.documents[0]));
    }
    processDeletionResultsAndNotify(results) {
        const successCount = results.filter((res) => res.success).length;
        const errorCount = results.length - successCount;
        const messages = [];
        if (successCount > 0) {
            const successMessageKey = successCount === 1
                ? deleteItemNotificationMessages[DeletedStatus.SUCCESS].SINGLE
                : deleteItemNotificationMessages[DeletedStatus.SUCCESS].MULTI;
            messages.push(this.translate.instant(successMessageKey).replace('{count}', successCount.toString()));
        }
        if (errorCount > 0) {
            const errorMessageKey = errorCount === 1
                ? deleteItemNotificationMessages[DeletedStatus.ERROR].SINGLE
                : deleteItemNotificationMessages[DeletedStatus.ERROR].MULTI;
            messages.push(this.translate.instant(errorMessageKey).replace('{count}', errorCount.toString()));
        }
        const finalMessage = messages.join(' ');
        let status;
        if (successCount > 0 && errorCount > 0) {
            status = DeletedStatus.REQUEST;
        }
        else if (successCount > 0) {
            status = DeletedStatus.SUCCESS;
        }
        else {
            status = DeletedStatus.ERROR;
        }
        if (finalMessage) {
            this.displayNotificationMessage(finalMessage, status);
        }
    }
    displayNotificationMessage(message, status) {
        this.hxpNotificationService.openSnackBar(message, deleteSnackBarTypes[status]);
    }
    populateDialogTitleAndDescription() {
        this.dialogTitle =
            this.documents.length > 1 ? 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.MULTIPLE_ITEMS.TITLE' : 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.ITEM.TITLE';
        this.dialogDescription =
            this.documents.length > 1
                ? 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.MULTIPLE_ITEMS.DESCRIPTION'
                : 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.ITEM.DESCRIPTION';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentDeleteConfirmationDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$1.MatDialogRef }, { token: i1.HxpNotificationService }, { token: i1.DocumentService }, { token: i1.DocumentRouterService }, { token: i1.RouterExtService }, { token: i4.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ContentDeleteConfirmationDialogComponent, isStandalone: true, selector: "hxp-content-delete-confirmation-dialog", ngImport: i0, template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ dialogTitle | translate }}</h1>\n        <button class=\"hxp-dialog-fixed-size-wrapper-close-btn\" aria-label=\"close dialog\" mat-dialog-close>\n            <mat-icon>close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <p> {{ dialogDescription | translate }} </p>\n    </div>\n    <mat-dialog-actions [align]=\"'end'\">\n        <button mat-button class=\"hxp-delete-dialog-close-button\" mat-dialog-close>{{ 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-flat-button color=\"warn\" class=\"hxp-primary-warn-button\" [ngClass]=\"{'hxp-disable-btn': isDeleting}\" (click)=\"onDelete()\">\n            <span class=\"hxp-primary-warn-button-label\">\n                <mat-progress-spinner\n                    *ngIf=\"isDeleting\"\n                    mode=\"indeterminate\"\n                    diameter=\"15\" />\n                {{ dialogTitle | translate }}\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-dialog-fixed-size-wrapper .dialog-title{display:flex;justify-content:space-between;align-items:baseline}.hxp-dialog-fixed-size-wrapper .dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper .hxp-delete-dialog-close-button{color:var(--theme-primary-color, #5654ac);border:0}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button.hxp-disable-btn{pointer-events:none;opacity:.6}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .mat-mdc-progress-spinner{margin-right:10px}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .mat-mdc-progress-spinner circle{stroke:var(--theme-accent-color-default-contrast, white)}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .hxp-primary-warn-button-label{display:flex;align-items:center}.hxp-dialog-fixed-size-wrapper .hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentDeleteConfirmationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-content-delete-confirmation-dialog', encapsulation: ViewEncapsulation.None, standalone: true, imports: [MatDialogModule, MatIconModule, MatButtonModule, NgClass, NgIf, MatProgressSpinnerModule, TranslatePipe], template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ dialogTitle | translate }}</h1>\n        <button class=\"hxp-dialog-fixed-size-wrapper-close-btn\" aria-label=\"close dialog\" mat-dialog-close>\n            <mat-icon>close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <p> {{ dialogDescription | translate }} </p>\n    </div>\n    <mat-dialog-actions [align]=\"'end'\">\n        <button mat-button class=\"hxp-delete-dialog-close-button\" mat-dialog-close>{{ 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-flat-button color=\"warn\" class=\"hxp-primary-warn-button\" [ngClass]=\"{'hxp-disable-btn': isDeleting}\" (click)=\"onDelete()\">\n            <span class=\"hxp-primary-warn-button-label\">\n                <mat-progress-spinner\n                    *ngIf=\"isDeleting\"\n                    mode=\"indeterminate\"\n                    diameter=\"15\" />\n                {{ dialogTitle | translate }}\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-dialog-fixed-size-wrapper .dialog-title{display:flex;justify-content:space-between;align-items:baseline}.hxp-dialog-fixed-size-wrapper .dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper .hxp-delete-dialog-close-button{color:var(--theme-primary-color, #5654ac);border:0}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button.hxp-disable-btn{pointer-events:none;opacity:.6}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .mat-mdc-progress-spinner{margin-right:10px}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .mat-mdc-progress-spinner circle{stroke:var(--theme-accent-color-default-contrast, white)}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .hxp-primary-warn-button-label{display:flex;align-items:center}.hxp-dialog-fixed-size-wrapper .hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$1.MatDialogRef }, { type: i1.HxpNotificationService }, { type: i1.DocumentService }, { type: i1.DocumentRouterService }, { type: i1.RouterExtService }, { type: i4.TranslateService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DeleteButtonActionService extends DocumentActionService {
    constructor(dialog) {
        super();
        this.dialog = dialog;
    }
    isAvailable(context) {
        const docs = context.documents ?? [];
        const parent = context.parentDocument;
        if (!parent || docs.length === 0) {
            return false;
        }
        const hasRequiredPermissions = docs.every((doc) => hasPermission(doc, DocumentPermissions.DELETE)) && hasPermission(parent, DocumentPermissions.DELETE_CHILD);
        const isAnyRetainedOrHold = docs.some((doc) => {
            const status = getRetentionStatus(doc);
            return status && BLOCK_DELETE_STATUSES.includes(status);
        });
        const isAnyVersion = isVersion(docs[0]);
        return hasRequiredPermissions && !isAnyRetainedOrHold && !isAnyVersion;
    }
    execute(context) {
        if (this.canOpenConfirmationDialog(context)) {
            this.dialog.open(ContentDeleteConfirmationDialogComponent, {
                data: {
                    documents: context.documents,
                    shouldRedirect: context.shouldRedirect || false,
                    refererURL: context.refererURL || '',
                },
            });
        }
    }
    canOpenConfirmationDialog(context) {
        return context.documents?.length > 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DeleteButtonActionService, deps: [{ token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DeleteButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DeleteButtonActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.MatDialog }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const originFormControlNameNgOnChanges = FormControlName.prototype.ngOnChanges;
FormControlName.prototype.ngOnChanges = function (...arg) {
    const result = originFormControlNameNgOnChanges.apply(this, arg);
    this.control.nativeElement = this.valueAccessor?._elementRef?.nativeElement;
    return result;
};
class ContentShareDialogComponent {
    constructor(_fb, data, contentShareService, clipboard, hxpNotificationService) {
        this._fb = _fb;
        this.data = data;
        this.contentShareService = contentShareService;
        this.clipboard = clipboard;
        this.hxpNotificationService = hxpNotificationService;
        this.shareDocumentForm = this._fb.group({
            shared_link: ['', Validators.required],
        });
        if (this.data?.sharedDocument) {
            const sharedLink = this.contentShareService.getSingleContentShareLink(this.data.sharedDocument);
            this.shareDocumentForm.patchValue({ shared_link: sharedLink });
        }
    }
    onCopy() {
        this.clipboard.copy(this.shareDocumentForm.value.shared_link ?? '');
        this.shareDocumentForm.get('shared_link').nativeElement.select();
        this.hxpNotificationService.openSnackBar('DOCUMENT_SHARE.SNACKBAR.SHARE.SUCCESS', 'done');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareDialogComponent, deps: [{ token: i1$2.FormBuilder }, { token: MAT_DIALOG_DATA }, { token: i1.ContentShareService }, { token: i3$2.Clipboard }, { token: i1.HxpNotificationService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ContentShareDialogComponent, isStandalone: true, selector: "hxp-alfresco-dbp-content-share-dialog", ngImport: i0, template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.SHARED_ITEM' | translate }}</h1>\n        <button class=\"hxp-dialog-fixed-size-wrapper-close-btn\" aria-label=\"{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.SHARED_ITEM' | translate }}\" mat-dialog-close>\n            <mat-icon>close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <form [formGroup]=\"shareDocumentForm\">\n            <mat-label>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate }}</mat-label>\n            <div class=\"hxp-share-dialog-field-container\">\n                <mat-form-field appearance=\"fill\">\n                    <input\n                        #sharedLinkInput\n                        matInput\n                        [attr.aria-label]=\"'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate\"\n                        formControlName=\"shared_link\"\n                        type=\"text\"\n                        readonly\n                        md-select-on-focus\n                    />\n                    <mat-icon matSuffix class=\"hxp-shared-link-copy-button\" (click)=\"onCopy()\">content_copy</mat-icon>\n                </mat-form-field>\n            </div>\n        </form>\n    </div>\n</div>\n", styles: [".hxp-share-dialog-field-container{display:flex;flex-direction:column}.hxp-shared-link-copy-button{cursor:pointer}.dialog-title{display:flex;justify-content:space-between;align-items:baseline}.dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "ngmodule", type: MatSnackBarModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-alfresco-dbp-content-share-dialog', standalone: true, imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        MatIconModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        MatInputModule,
                        TranslatePipe,
                        MatSnackBarModule,
                    ], template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.SHARED_ITEM' | translate }}</h1>\n        <button class=\"hxp-dialog-fixed-size-wrapper-close-btn\" aria-label=\"{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.SHARED_ITEM' | translate }}\" mat-dialog-close>\n            <mat-icon>close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <form [formGroup]=\"shareDocumentForm\">\n            <mat-label>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate }}</mat-label>\n            <div class=\"hxp-share-dialog-field-container\">\n                <mat-form-field appearance=\"fill\">\n                    <input\n                        #sharedLinkInput\n                        matInput\n                        [attr.aria-label]=\"'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate\"\n                        formControlName=\"shared_link\"\n                        type=\"text\"\n                        readonly\n                        md-select-on-focus\n                    />\n                    <mat-icon matSuffix class=\"hxp-shared-link-copy-button\" (click)=\"onCopy()\">content_copy</mat-icon>\n                </mat-form-field>\n            </div>\n        </form>\n    </div>\n</div>\n", styles: [".hxp-share-dialog-field-container{display:flex;flex-direction:column}.hxp-shared-link-copy-button{cursor:pointer}.dialog-title{display:flex;justify-content:space-between;align-items:baseline}.dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.FormBuilder }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1.ContentShareService }, { type: i3$2.Clipboard }, { type: i1.HxpNotificationService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentShareButtonActionService extends DocumentActionService {
    constructor(dialog) {
        super();
        this.dialog = dialog;
    }
    isAvailable(context) {
        return context.documents?.length === 1 && hasPermission(context.documents[0], DocumentPermissions.READ);
    }
    execute(context) {
        const DIALOG_MIN_WIDTH = '750px';
        if (context.documents?.[0]?.sys_id) {
            this.dialog.open(ContentShareDialogComponent, {
                width: DIALOG_MIN_WIDTH,
                data: { sharedDocument: context.documents[0] },
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareButtonActionService, deps: [{ token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareButtonActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.MatDialog }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DismissPermission {
}
class CancelPermissionDialogComponent {
    constructor(dialogRef, dialogData, permissionsPanelRequestService) {
        this.dialogRef = dialogRef;
        this.dialogData = dialogData;
        this.permissionsPanelRequestService = permissionsPanelRequestService;
    }
    reject() {
        this.dialogRef.close();
    }
    confirm() {
        this.dialogRef.close();
        if (this.dialogData?.permissionDialogRef) {
            this.dialogData.permissionDialogRef.close();
        }
        else {
            this.permissionsPanelRequestService.requestClosePanel();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CancelPermissionDialogComponent, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }, { token: i1.PermissionsPanelRequestService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: CancelPermissionDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate}}</p>\n    </div>\n    <div mat-dialog-actions [align]=\"'end'\">\n        <button mat-flat-button disableRipple class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ dialogData.dialogRejectButton | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button hxp-primary-button\" (click)=\"confirm()\">\n            {{ dialogData.dialogConfirmButton | translate}}\n        </button>\n    </div>\n</div>\n", styles: [".hxp-restore-permission-dialog .hxp-permission-reset-options{display:flex;flex-direction:column}.hxp-restore-permission-dialog .mat-mdc-dialog-actions{justify-content:flex-end}.hxp-cancel-permission-dialog .mat-mdc-dialog-title{margin:0}.hxp-cancel-permission-dialog .hxp-permission-dialog-reject-button{color:var(--theme-primary-color, #5654ac);border:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "ngmodule", type: FormsModule }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CancelPermissionDialogComponent, decorators: [{
            type: Component,
            args: [{ encapsulation: ViewEncapsulation.None, standalone: true, imports: [MatDialogModule, MatButtonModule, MatRadioModule, FormsModule, TranslatePipe], template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate}}</p>\n    </div>\n    <div mat-dialog-actions [align]=\"'end'\">\n        <button mat-flat-button disableRipple class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ dialogData.dialogRejectButton | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button hxp-primary-button\" (click)=\"confirm()\">\n            {{ dialogData.dialogConfirmButton | translate}}\n        </button>\n    </div>\n</div>\n", styles: [".hxp-restore-permission-dialog .hxp-permission-reset-options{display:flex;flex-direction:column}.hxp-restore-permission-dialog .mat-mdc-dialog-actions{justify-content:flex-end}.hxp-cancel-permission-dialog .mat-mdc-dialog-title{margin:0}.hxp-cancel-permission-dialog .hxp-permission-dialog-reject-button{color:var(--theme-primary-color, #5654ac);border:0}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1.PermissionsPanelRequestService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DialogConfig = {
    small: {
        width: '500px',
        height: '640px',
    },
    medium: {
        width: '700px',
        height: '640px',
    },
    large: {
        width: '900px',
        height: '640px',
    },
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ClosePermissionDialogComponent {
    constructor(dialogRef, dialogData) {
        this.dialogRef = dialogRef;
        this.dialogData = dialogData;
    }
    reject() {
        this.closeDialog();
    }
    confirm() {
        this.closeDialog(true);
    }
    closeDialog(save = false) {
        this.dialogRef.close({ save });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ClosePermissionDialogComponent, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ClosePermissionDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate}}</p>\n    </div>\n    <div mat-dialog-actions [align]=\"'end'\">\n        <button mat-flat-button disableRipple class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ dialogData.dialogRejectButton | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button hxp-primary-button\" (click)=\"confirm()\">\n            {{ dialogData.dialogConfirmButton | translate}}\n        </button>\n    </div>\n</div>\n", styles: [".hxp-restore-permission-dialog .hxp-permission-reset-options{display:flex;flex-direction:column}.hxp-restore-permission-dialog .mat-mdc-dialog-actions{justify-content:flex-end}.hxp-cancel-permission-dialog .mat-mdc-dialog-title{margin:0}.hxp-cancel-permission-dialog .hxp-permission-dialog-reject-button{color:var(--theme-primary-color, #5654ac);border:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ClosePermissionDialogComponent, decorators: [{
            type: Component,
            args: [{ encapsulation: ViewEncapsulation.None, standalone: true, imports: [MatDialogModule, MatButtonModule, TranslatePipe], template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate}}</p>\n    </div>\n    <div mat-dialog-actions [align]=\"'end'\">\n        <button mat-flat-button disableRipple class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ dialogData.dialogRejectButton | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button hxp-primary-button\" (click)=\"confirm()\">\n            {{ dialogData.dialogConfirmButton | translate}}\n        </button>\n    </div>\n</div>\n", styles: [".hxp-restore-permission-dialog .hxp-permission-reset-options{display:flex;flex-direction:column}.hxp-restore-permission-dialog .mat-mdc-dialog-actions{justify-content:flex-end}.hxp-cancel-permission-dialog .mat-mdc-dialog-title{margin:0}.hxp-cancel-permission-dialog .hxp-permission-dialog-reject-button{color:var(--theme-primary-color, #5654ac);border:0}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class PermissionsTableComponent {
    constructor() {
        this.title = '';
        this.activePermissionsManagementRows = [];
        // HEADER INJECTED CONTENTS
        // unicorn/no-null rule is disabled because TemplateRef cannot be undefined, unless a default ref is provided in the template.
        // Headers have no default reference
        this.entityColumnHeaderTemplateRef = null;
        this.inheritedPermissionColumnHeaderTemplateRef = null;
        this.fileColumnHeaderTemplateRef = null;
        this.inheritedPermissionCellTemplateRef = null;
        this.displayedColumns = ['permissionEntity', 'permission'];
    }
    ngAfterContentChecked() {
        this.displayedColumns = this.getAvailableColumns();
    }
    getAvailableColumns() {
        return this.inheritedPermissionCellTemplateRef
            ? ['permissionEntity', 'inheritedPermission', 'permission']
            : ['permissionEntity', 'permission'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionsTableComponent, isStandalone: true, selector: "hxp-permissions-table", inputs: { title: "title", activePermissionsManagementRows: "activePermissionsManagementRows" }, queries: [{ propertyName: "entityColumnHeaderTemplateRef", first: true, predicate: ["entityColumnHeader"], descendants: true }, { propertyName: "inheritedPermissionColumnHeaderTemplateRef", first: true, predicate: ["inheritedPermissionColumnHeader"], descendants: true }, { propertyName: "fileColumnHeaderTemplateRef", first: true, predicate: ["fileColumnHeader"], descendants: true }, { propertyName: "emptyTableTemplateRef", first: true, predicate: ["emptyTable"], descendants: true }, { propertyName: "entityCellTemplateRef", first: true, predicate: ["entityCell"], descendants: true }, { propertyName: "inheritedPermissionCellTemplateRef", first: true, predicate: ["inheritedPermissionCell"], descendants: true }, { propertyName: "fileCellTemplateRef", first: true, predicate: ["fileCell"], descendants: true }], ngImport: i0, template: "<ng-content select=\"[permission-search]\" />\n\n<div id=\"who-access\" class=\"hxp-permission-dialog-who\">\n    {{ title | translate }}\n</div>\n\n<div class=\"hxp-user-table\">\n    <table\n        *ngIf=\"activePermissionsManagementRows.length > 0 else emptyTable\"\n        mat-table\n        [dataSource]=\"activePermissionsManagementRows\"\n        class=\"hxp-permission-dialog-list mat-elevation-z0\"\n        aria-describedby=\"who-access\"\n    >\n        <ng-container matColumnDef=\"permissionEntity\">\n            <th mat-header-cell *matHeaderCellDef>\n                <ng-template *ngTemplateOutlet=\"entityColumnHeaderTemplateRef\" />\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n\n                <ng-template #defaultUserGroupCell let-element>\n                    {{ element.entityLabel }}\n                </ng-template>\n\n                <ng-container\n                    *ngTemplateOutlet=\"entityCellTemplateRef || defaultUserGroupCell; context: { $implicit: element }\" />\n\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"inheritedPermission\">\n            <th mat-header-cell *matHeaderCellDef>\n                <ng-template *ngTemplateOutlet=\"inheritedPermissionColumnHeaderTemplateRef\" />\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n\n                <ng-container\n                    *ngTemplateOutlet=\"inheritedPermissionCellTemplateRef; context: { $implicit: element }\" />\n\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"permission\">\n            <th mat-header-cell *matHeaderCellDef>\n                <ng-template *ngTemplateOutlet=\"fileColumnHeaderTemplateRef\" />\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n\n                <ng-template #defaultPermissionCell let-element>\n                    {{ element.permission }}\n                </ng-template>\n\n                <ng-container\n                    *ngTemplateOutlet=\"fileCellTemplateRef || defaultPermissionCell; context: { $implicit: element }\" />\n\n            </td>\n        </ng-container>\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\" class=\"hxp-permission-row\"></tr>\n    </table>\n</div>\n\n<ng-template #defaultEmptyTable>\n    <div class=\"hxp-no-permission\">\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.DEFAULT' | translate }}\n    </div>\n</ng-template>\n\n<ng-template #emptyTable>\n    <ng-template *ngTemplateOutlet=\"emptyTableTemplateRef || defaultEmptyTable\" />\n</ng-template>\n", styles: [".hxp-permissions-management-panel-container th,.hxp-permissions-management-dialog-container th{color:#6b7280}.hxp-permissions-management-panel-container .mat-column-permission,.hxp-permissions-management-dialog-container .mat-column-permission{display:flex;align-items:center;height:inherit;padding:5px}.hxp-permissions-management-panel-container .hxp-permission-dialog-who,.hxp-permissions-management-dialog-container .hxp-permission-dialog-who{font-style:normal;font-weight:600;font-size:14px;line-height:23px;color:var(--adf-theme-foreground-text-color);margin:24px 0 16px}.hxp-permissions-management-panel-container .hxp-no-permission,.hxp-permissions-management-dialog-container .hxp-no-permission{font-style:normal;font-size:14px;line-height:23px;color:var(--adf-theme-foreground-text-color);margin-top:15px;padding:0 10px}.hxp-permissions-management-panel-container .hxp-user-table,.hxp-permissions-management-dialog-container .hxp-user-table{height:280px;border:1px solid var(--adf-theme-foreground-text-color-025);border-radius:12px;padding:0 0 10px;overflow-y:auto;background-color:var(--adf-info-drawer-tab-default-background)}.hxp-permissions-management-panel-container .hxp-permission-dialog-user-list,.hxp-permissions-management-dialog-container .hxp-permission-dialog-user-list{display:flex;flex-direction:row;align-items:center;padding:0 16px;gap:8px;flex:none;order:1;align-self:stretch;flex-grow:0}.hxp-permissions-management-panel-container table,.hxp-permissions-management-dialog-container table{width:100%}.hxp-permissions-management-panel-container .mat-mdc-cell,.hxp-permissions-management-panel-container .mat-mdc-header-cell,.hxp-permissions-management-dialog-container .mat-mdc-cell,.hxp-permissions-management-dialog-container .mat-mdc-header-cell{border:none;vertical-align:middle}.hxp-permissions-management-panel-container .mat-mdc-table__wrapper .mat-mdc-table,.hxp-permissions-management-dialog-container .mat-mdc-table__wrapper .mat-mdc-table{min-width:auto;width:100%}.hxp-permissions-management-panel-container .mat-mdc-dialog-content,.hxp-permissions-management-dialog-container .mat-mdc-dialog-content{max-height:initial}.hxp-permissions-management-panel-container mat-select,.hxp-permissions-management-dialog-container mat-select{display:flex;flex-direction:row;align-items:center;gap:8px}.hxp-permissions-management-panel-container .mat-mdc-form-field-infix,.hxp-permissions-management-dialog-container .mat-mdc-form-field-infix{width:auto}.hxp-permissions-management-panel-container .mdc-line-ripple,.hxp-permissions-management-dialog-container .mdc-line-ripple{display:none}.hxp-permissions-management-panel-container .mat-mdc-row,.hxp-permissions-management-dialog-container .mat-mdc-row{vertical-align:initial;display:flex;margin:0 0 4px}.hxp-permissions-management-panel-container .mat-mdc-header-cell,.hxp-permissions-management-panel-container .mat-mdc-cell,.hxp-permissions-management-dialog-container .mat-mdc-header-cell,.hxp-permissions-management-dialog-container .mat-mdc-cell{width:33.3333333333%}.hxp-permissions-management-panel-container .mat-mdc-header-cell:nth-child(1),.hxp-permissions-management-panel-container .mat-mdc-cell:nth-child(1),.hxp-permissions-management-dialog-container .mat-mdc-header-cell:nth-child(1),.hxp-permissions-management-dialog-container .mat-mdc-cell:nth-child(1){flex-grow:1}.hxp-permissions-management-panel-container .hxp-permission-row:hover,.hxp-permissions-management-dialog-container .hxp-permission-row:hover{background-color:var(--theme-background-hover-color, #f9f9fc)}.hxp-permissions-management-panel-container .mat-mdc-header-row,.hxp-permissions-management-dialog-container .mat-mdc-header-row{display:flex;align-items:center}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i1$3.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i1$3.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i1$3.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i1$3.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i1$3.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i1$3.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i1$3.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i1$3.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i1$3.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i1$3.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-table', encapsulation: ViewEncapsulation.None, standalone: true, imports: [NgIf, MatTableModule, NgTemplateOutlet, NgClass, TranslatePipe], template: "<ng-content select=\"[permission-search]\" />\n\n<div id=\"who-access\" class=\"hxp-permission-dialog-who\">\n    {{ title | translate }}\n</div>\n\n<div class=\"hxp-user-table\">\n    <table\n        *ngIf=\"activePermissionsManagementRows.length > 0 else emptyTable\"\n        mat-table\n        [dataSource]=\"activePermissionsManagementRows\"\n        class=\"hxp-permission-dialog-list mat-elevation-z0\"\n        aria-describedby=\"who-access\"\n    >\n        <ng-container matColumnDef=\"permissionEntity\">\n            <th mat-header-cell *matHeaderCellDef>\n                <ng-template *ngTemplateOutlet=\"entityColumnHeaderTemplateRef\" />\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n\n                <ng-template #defaultUserGroupCell let-element>\n                    {{ element.entityLabel }}\n                </ng-template>\n\n                <ng-container\n                    *ngTemplateOutlet=\"entityCellTemplateRef || defaultUserGroupCell; context: { $implicit: element }\" />\n\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"inheritedPermission\">\n            <th mat-header-cell *matHeaderCellDef>\n                <ng-template *ngTemplateOutlet=\"inheritedPermissionColumnHeaderTemplateRef\" />\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n\n                <ng-container\n                    *ngTemplateOutlet=\"inheritedPermissionCellTemplateRef; context: { $implicit: element }\" />\n\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"permission\">\n            <th mat-header-cell *matHeaderCellDef>\n                <ng-template *ngTemplateOutlet=\"fileColumnHeaderTemplateRef\" />\n            </th>\n            <td mat-cell *matCellDef=\"let element\">\n\n                <ng-template #defaultPermissionCell let-element>\n                    {{ element.permission }}\n                </ng-template>\n\n                <ng-container\n                    *ngTemplateOutlet=\"fileCellTemplateRef || defaultPermissionCell; context: { $implicit: element }\" />\n\n            </td>\n        </ng-container>\n        <tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>\n        <tr mat-row *matRowDef=\"let row; columns: displayedColumns;\" class=\"hxp-permission-row\"></tr>\n    </table>\n</div>\n\n<ng-template #defaultEmptyTable>\n    <div class=\"hxp-no-permission\">\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.DEFAULT' | translate }}\n    </div>\n</ng-template>\n\n<ng-template #emptyTable>\n    <ng-template *ngTemplateOutlet=\"emptyTableTemplateRef || defaultEmptyTable\" />\n</ng-template>\n", styles: [".hxp-permissions-management-panel-container th,.hxp-permissions-management-dialog-container th{color:#6b7280}.hxp-permissions-management-panel-container .mat-column-permission,.hxp-permissions-management-dialog-container .mat-column-permission{display:flex;align-items:center;height:inherit;padding:5px}.hxp-permissions-management-panel-container .hxp-permission-dialog-who,.hxp-permissions-management-dialog-container .hxp-permission-dialog-who{font-style:normal;font-weight:600;font-size:14px;line-height:23px;color:var(--adf-theme-foreground-text-color);margin:24px 0 16px}.hxp-permissions-management-panel-container .hxp-no-permission,.hxp-permissions-management-dialog-container .hxp-no-permission{font-style:normal;font-size:14px;line-height:23px;color:var(--adf-theme-foreground-text-color);margin-top:15px;padding:0 10px}.hxp-permissions-management-panel-container .hxp-user-table,.hxp-permissions-management-dialog-container .hxp-user-table{height:280px;border:1px solid var(--adf-theme-foreground-text-color-025);border-radius:12px;padding:0 0 10px;overflow-y:auto;background-color:var(--adf-info-drawer-tab-default-background)}.hxp-permissions-management-panel-container .hxp-permission-dialog-user-list,.hxp-permissions-management-dialog-container .hxp-permission-dialog-user-list{display:flex;flex-direction:row;align-items:center;padding:0 16px;gap:8px;flex:none;order:1;align-self:stretch;flex-grow:0}.hxp-permissions-management-panel-container table,.hxp-permissions-management-dialog-container table{width:100%}.hxp-permissions-management-panel-container .mat-mdc-cell,.hxp-permissions-management-panel-container .mat-mdc-header-cell,.hxp-permissions-management-dialog-container .mat-mdc-cell,.hxp-permissions-management-dialog-container .mat-mdc-header-cell{border:none;vertical-align:middle}.hxp-permissions-management-panel-container .mat-mdc-table__wrapper .mat-mdc-table,.hxp-permissions-management-dialog-container .mat-mdc-table__wrapper .mat-mdc-table{min-width:auto;width:100%}.hxp-permissions-management-panel-container .mat-mdc-dialog-content,.hxp-permissions-management-dialog-container .mat-mdc-dialog-content{max-height:initial}.hxp-permissions-management-panel-container mat-select,.hxp-permissions-management-dialog-container mat-select{display:flex;flex-direction:row;align-items:center;gap:8px}.hxp-permissions-management-panel-container .mat-mdc-form-field-infix,.hxp-permissions-management-dialog-container .mat-mdc-form-field-infix{width:auto}.hxp-permissions-management-panel-container .mdc-line-ripple,.hxp-permissions-management-dialog-container .mdc-line-ripple{display:none}.hxp-permissions-management-panel-container .mat-mdc-row,.hxp-permissions-management-dialog-container .mat-mdc-row{vertical-align:initial;display:flex;margin:0 0 4px}.hxp-permissions-management-panel-container .mat-mdc-header-cell,.hxp-permissions-management-panel-container .mat-mdc-cell,.hxp-permissions-management-dialog-container .mat-mdc-header-cell,.hxp-permissions-management-dialog-container .mat-mdc-cell{width:33.3333333333%}.hxp-permissions-management-panel-container .mat-mdc-header-cell:nth-child(1),.hxp-permissions-management-panel-container .mat-mdc-cell:nth-child(1),.hxp-permissions-management-dialog-container .mat-mdc-header-cell:nth-child(1),.hxp-permissions-management-dialog-container .mat-mdc-cell:nth-child(1){flex-grow:1}.hxp-permissions-management-panel-container .hxp-permission-row:hover,.hxp-permissions-management-dialog-container .hxp-permission-row:hover{background-color:var(--theme-background-hover-color, #f9f9fc)}.hxp-permissions-management-panel-container .mat-mdc-header-row,.hxp-permissions-management-dialog-container .mat-mdc-header-row{display:flex;align-items:center}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], activePermissionsManagementRows: [{
                type: Input
            }], 
        // eslint-disable-next-line unicorn/no-null
        entityColumnHeaderTemplateRef: [{
                type: ContentChild,
                args: ['entityColumnHeader', { static: false }]
            }], 
        // eslint-disable-next-line unicorn/no-null
        inheritedPermissionColumnHeaderTemplateRef: [{
                type: ContentChild,
                args: ['inheritedPermissionColumnHeader', { static: false }]
            }], 
        // eslint-disable-next-line unicorn/no-null
        fileColumnHeaderTemplateRef: [{
                type: ContentChild,
                args: ['fileColumnHeader', { static: false }]
            }], 
        // eslint-disable-next-line unicorn/no-null
        emptyTableTemplateRef: [{
                type: ContentChild,
                args: ['emptyTable', { static: false }]
            }], entityCellTemplateRef: [{
                type: ContentChild,
                args: ['entityCell', { static: false }]
            }], 
        // in this case the column is optional, therefore there is no default ref.
        // eslint-disable-next-line unicorn/no-null
        inheritedPermissionCellTemplateRef: [{
                type: ContentChild,
                args: ['inheritedPermissionCell', { static: false }]
            }], fileCellTemplateRef: [{
                type: ContentChild,
                args: ['fileCell', { static: false }]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsSearchComponent {
    constructor() {
        this.placeHolder = '';
        this.activePermissionsManagementRows = [];
        this.search = new EventEmitter();
    }
    onKey(event) {
        this.emit(event.target.value);
    }
    emit(value) {
        this.search.emit(value);
    }
    permissionsManagementRowTrackBy(_index, row) {
        return row.index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsSearchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionsSearchComponent, isStandalone: true, selector: "hxp-permission-search", inputs: { placeHolder: "placeHolder", activePermissionsManagementRows: "activePermissionsManagementRows" }, outputs: { search: "search" }, ngImport: i0, template: "<div class=\"hxp-permission-dialog-search-holder\">\n    <input\n        id=\"hxp-permission-user-search\"\n        class=\"hxp-permission-dialog-search\"\n        matInput\n        placeholder=\"{{ placeHolder }}\"\n        type=\"text\"\n        [matAutocomplete]=\"auto\"\n        (keyup)=\"onKey($event)\"\n    />\n\n    <mat-autocomplete autoActiveFirstOption #auto=\"matAutocomplete\">\n        <mat-option\n            *ngFor=\"let option of activePermissionsManagementRows;\n            trackBy: permissionsManagementRowTrackBy\"\n            [value]=\"option.entityLabel\"\n            (click)=\"emit(option.entityLabel)\"\n        >\n            {{ option.entityLabel }}\n        </mat-option>\n    </mat-autocomplete>\n\n    <div class=\"hxp-search-permission-dialog-divider\">\n        <mat-icon matSuffix>search</mat-icon>\n    </div>\n</div>\n", styles: [".hxp-permission-dialog-search-holder{display:flex;max-width:400px}.hxp-permission-dialog-search{padding:1px 12px;gap:12px;height:48px;border:1px solid var(--adf-edit-process-filter-header-description-color);border-right:0;margin-top:24px;font-weight:var(--theme-menu-container-font-weight, 300);font-size:14px;line-height:23px;flex-grow:1;border-top-left-radius:8px;border-bottom-left-radius:8px;outline:#6b7280;font-family:var(--theme-font-family, \"Noto Sans\");background-color:var(--theme-card-background-color, white)}.hxp-search-permission-dialog-divider{display:flex;flex-direction:column;justify-content:center;align-items:center;padding:0;height:50px;width:50px;margin-top:24px;border:1px solid var(--adf-edit-process-filter-header-description-color);border-left:1px solid var(--adf-theme-foreground-text-color-014);border-top-right-radius:8px;border-bottom-right-radius:8px}\n"], dependencies: [{ kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i3$3.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i3$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i3$3.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permission-search', standalone: true, imports: [MatInputModule, MatAutocompleteModule, NgFor, MatOptionModule, MatIconModule, MatFormFieldModule], template: "<div class=\"hxp-permission-dialog-search-holder\">\n    <input\n        id=\"hxp-permission-user-search\"\n        class=\"hxp-permission-dialog-search\"\n        matInput\n        placeholder=\"{{ placeHolder }}\"\n        type=\"text\"\n        [matAutocomplete]=\"auto\"\n        (keyup)=\"onKey($event)\"\n    />\n\n    <mat-autocomplete autoActiveFirstOption #auto=\"matAutocomplete\">\n        <mat-option\n            *ngFor=\"let option of activePermissionsManagementRows;\n            trackBy: permissionsManagementRowTrackBy\"\n            [value]=\"option.entityLabel\"\n            (click)=\"emit(option.entityLabel)\"\n        >\n            {{ option.entityLabel }}\n        </mat-option>\n    </mat-autocomplete>\n\n    <div class=\"hxp-search-permission-dialog-divider\">\n        <mat-icon matSuffix>search</mat-icon>\n    </div>\n</div>\n", styles: [".hxp-permission-dialog-search-holder{display:flex;max-width:400px}.hxp-permission-dialog-search{padding:1px 12px;gap:12px;height:48px;border:1px solid var(--adf-edit-process-filter-header-description-color);border-right:0;margin-top:24px;font-weight:var(--theme-menu-container-font-weight, 300);font-size:14px;line-height:23px;flex-grow:1;border-top-left-radius:8px;border-bottom-left-radius:8px;outline:#6b7280;font-family:var(--theme-font-family, \"Noto Sans\");background-color:var(--theme-card-background-color, white)}.hxp-search-permission-dialog-divider{display:flex;flex-direction:column;justify-content:center;align-items:center;padding:0;height:50px;width:50px;margin-top:24px;border:1px solid var(--adf-edit-process-filter-header-description-color);border-left:1px solid var(--adf-theme-foreground-text-color-014);border-top-right-radius:8px;border-bottom-right-radius:8px}\n"] }]
        }], propDecorators: { placeHolder: [{
                type: Input
            }], activePermissionsManagementRows: [{
                type: Input
            }], search: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const NewPermissionLabels = {
    Read: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.READ',
    ReadWrite: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.READ_WRITE',
    Everything: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.EVERYTHING',
};
const PermissionLabels = {
    None: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.NO_ACCESS',
    Blocked: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.BLOCKED',
    ...NewPermissionLabels,
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsComponent {
    constructor() {
        this.inheritedPermission = 'None';
        this.inheritanceEnabled = true;
        this.disabled = false;
        this.changePermission = new EventEmitter();
        this.permissionLabels = PermissionLabels;
        this.newPermissionLabels = NewPermissionLabels;
        this.isOptionDisabled = (permission) => {
            return this.inheritanceEnabled && this.inheritedPermission !== 'None' && this.isPermissionLowerThanInherited(permission);
        };
        this.originalOrder = () => 0;
    }
    onPermissionChange($event) {
        this.changePermission.emit($event);
    }
    optionTrackBy(index) {
        return index;
    }
    isPermissionLowerThanInherited(permission) {
        return getHighestPermission(permission, this.inheritedPermission) === this.inheritedPermission;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionsComponent, isStandalone: true, selector: "hxp-permissions", inputs: { permission: "permission", inheritedPermission: "inheritedPermission", inheritanceEnabled: "inheritanceEnabled", disabled: "disabled" }, outputs: { changePermission: "changePermission" }, ngImport: i0, template: "<div class=\"hxp-permission-select\" [class]=\"permission ? 'hxp-permission-' + permission : ''\">\n    <mat-form-field *ngIf=\"!disabled; else disabledField\" subscriptSizing=\"dynamic\">\n        <mat-select\n            id=\"hxp-user-permission\"\n            [placeholder]=\"'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.PLACEHOLDER' | translate\"\n            [ngModel]=\"permission\"\n            (ngModelChange)=\"onPermissionChange($event)\"\n            class=\"hxp-select-permission\"\n            [panelWidth]=\"''\"\n            panelClass=\"hxp-permission-select-panel\"\n        >\n            <mat-option *ngIf=\"!!permission\">\n                <ng-container *ngIf=\"!inheritedPermission || inheritedPermission === 'None'; else clearPermission\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.NO_ACCESS' | translate }}\n                </ng-container>\n                <ng-template #clearPermission>\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.CLEAR' | translate }}\n                </ng-template>\n            </mat-option>\n            <mat-option\n                *ngFor=\"let options of newPermissionLabels | keyvalue: originalOrder; trackBy: optionTrackBy\"\n                [value]=\"options.key\"\n                [disabled]=\"isOptionDisabled(options.key)\"\n                [class]=\"{ 'hxp-permission-selected-option': options.key === permission }\"\n            >\n                {{ options.value | translate\n                }}{{\n                    inheritanceEnabled && options.key === inheritedPermission\n                        ? ' - ' + ('PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.INHERITED' | translate)\n                        : ''\n                }}\n            </mat-option>\n        </mat-select>\n        <mat-icon class=\"hxp-dropdown-arrow\" matSuffix>keyboard_arrow_down</mat-icon>\n    </mat-form-field>\n    <ng-template #disabledField>\n        <div class=\"hxp-select-permission hxp-disabled\">\n            <div *ngIf=\"permission; else disabledInheritedPermission\">{{ newPermissionLabels[permission] | translate }}</div>\n            <ng-template #disabledInheritedPermission>\n                <div *ngIf=\"inheritedPermission\">{{ permissionLabels[inheritedPermission] | translate }}</div>\n            </ng-template>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-select-arrow,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-select-arrow{display:none}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-select-placeholder,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-select-placeholder,.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-select-placeholder .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-select-placeholder .mat-icon{color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-form-field-infix,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-form-field-infix{border:0}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-form-field-infix:not(:disabled),.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-form-field-infix:not(:disabled){padding-top:0;padding-bottom:0;min-height:0}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-form-field-flex,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-form-field-flex{align-items:center}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-text-field-wrapper,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-text-field-wrapper{padding:0}.hxp-permissions-management-panel-container .hxp-permission-select .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-icon{padding:2px}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-select-permission,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-select-permission{font-size:14px;padding-left:5px}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-select-permission.hxp-disabled,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-select-permission.hxp-disabled{padding-left:0}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-select-permission.hxp-disabled>div,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-select-permission.hxp-disabled>div{padding:5px 10px}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-dropdown-arrow,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-dropdown-arrow{color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Everything,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Everything{background:#e9d5ff}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Everything .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Everything .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Everything .mat-mdc-select-value-text,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Everything .mat-mdc-select-value-text{color:#6b21a8}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-None,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-None{background-color:transparent}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-None .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-None .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-None .mat-mdc-select-value-text,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-None .mat-mdc-select-value-text{color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Read,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Read{background:#ebeaf5}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Read .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Read .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Read .mat-select-value,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Read .mat-select-value{color:#4b5563}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-ReadWrite,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-ReadWrite{background:#ecfccb}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-ReadWrite .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-ReadWrite .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-ReadWrite .mat-select-value,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-ReadWrite .mat-select-value{color:#3f6212}.hxp-permission-select-panel .mat-pseudo-checkbox{display:none}.hxp-permission-select-panel .hxp-permission-selected-option{border-left:4px solid var(--theme-primary-color, #5654ac)}.hxp-permission-select-panel .hxp-permission-selected-option:not(.mdc-list-item--disabled):not(.mat-mdc-option-multiple){background-color:#ebeaf5}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$1.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i3$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions', encapsulation: ViewEncapsulation.None, standalone: true, imports: [NgIf, MatFormFieldModule, MatSelectModule, FormsModule, NgFor, MatOptionModule, MatIconModule, KeyValuePipe, TranslatePipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"hxp-permission-select\" [class]=\"permission ? 'hxp-permission-' + permission : ''\">\n    <mat-form-field *ngIf=\"!disabled; else disabledField\" subscriptSizing=\"dynamic\">\n        <mat-select\n            id=\"hxp-user-permission\"\n            [placeholder]=\"'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.PLACEHOLDER' | translate\"\n            [ngModel]=\"permission\"\n            (ngModelChange)=\"onPermissionChange($event)\"\n            class=\"hxp-select-permission\"\n            [panelWidth]=\"''\"\n            panelClass=\"hxp-permission-select-panel\"\n        >\n            <mat-option *ngIf=\"!!permission\">\n                <ng-container *ngIf=\"!inheritedPermission || inheritedPermission === 'None'; else clearPermission\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.NO_ACCESS' | translate }}\n                </ng-container>\n                <ng-template #clearPermission>\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.CLEAR' | translate }}\n                </ng-template>\n            </mat-option>\n            <mat-option\n                *ngFor=\"let options of newPermissionLabels | keyvalue: originalOrder; trackBy: optionTrackBy\"\n                [value]=\"options.key\"\n                [disabled]=\"isOptionDisabled(options.key)\"\n                [class]=\"{ 'hxp-permission-selected-option': options.key === permission }\"\n            >\n                {{ options.value | translate\n                }}{{\n                    inheritanceEnabled && options.key === inheritedPermission\n                        ? ' - ' + ('PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.INHERITED' | translate)\n                        : ''\n                }}\n            </mat-option>\n        </mat-select>\n        <mat-icon class=\"hxp-dropdown-arrow\" matSuffix>keyboard_arrow_down</mat-icon>\n    </mat-form-field>\n    <ng-template #disabledField>\n        <div class=\"hxp-select-permission hxp-disabled\">\n            <div *ngIf=\"permission; else disabledInheritedPermission\">{{ newPermissionLabels[permission] | translate }}</div>\n            <ng-template #disabledInheritedPermission>\n                <div *ngIf=\"inheritedPermission\">{{ permissionLabels[inheritedPermission] | translate }}</div>\n            </ng-template>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-select-arrow,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-select-arrow{display:none}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-select-placeholder,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-select-placeholder,.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-select-placeholder .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-select-placeholder .mat-icon{color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-form-field-infix,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-form-field-infix{border:0}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-form-field-infix:not(:disabled),.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-form-field-infix:not(:disabled){padding-top:0;padding-bottom:0;min-height:0}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-form-field-flex,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-form-field-flex{align-items:center}.hxp-permissions-management-panel-container .hxp-permission-select .mat-mdc-text-field-wrapper,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-mdc-text-field-wrapper{padding:0}.hxp-permissions-management-panel-container .hxp-permission-select .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select .mat-icon{padding:2px}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-select-permission,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-select-permission{font-size:14px;padding-left:5px}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-select-permission.hxp-disabled,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-select-permission.hxp-disabled{padding-left:0}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-select-permission.hxp-disabled>div,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-select-permission.hxp-disabled>div{padding:5px 10px}.hxp-permissions-management-panel-container .hxp-permission-select .hxp-dropdown-arrow,.hxp-permissions-management-dialog-container .hxp-permission-select .hxp-dropdown-arrow{color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Everything,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Everything{background:#e9d5ff}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Everything .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Everything .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Everything .mat-mdc-select-value-text,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Everything .mat-mdc-select-value-text{color:#6b21a8}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-None,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-None{background-color:transparent}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-None .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-None .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-None .mat-mdc-select-value-text,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-None .mat-mdc-select-value-text{color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Read,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Read{background:#ebeaf5}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Read .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Read .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-Read .mat-select-value,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-Read .mat-select-value{color:#4b5563}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-ReadWrite,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-ReadWrite{background:#ecfccb}.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-ReadWrite .mat-icon,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-ReadWrite .mat-icon,.hxp-permissions-management-panel-container .hxp-permission-select.hxp-permission-ReadWrite .mat-select-value,.hxp-permissions-management-dialog-container .hxp-permission-select.hxp-permission-ReadWrite .mat-select-value{color:#3f6212}.hxp-permission-select-panel .mat-pseudo-checkbox{display:none}.hxp-permission-select-panel .hxp-permission-selected-option{border-left:4px solid var(--theme-primary-color, #5654ac)}.hxp-permission-select-panel .hxp-permission-selected-option:not(.mdc-list-item--disabled):not(.mat-mdc-option-multiple){background-color:#ebeaf5}\n"] }]
        }], propDecorators: { permission: [{
                type: Input
            }], inheritedPermission: [{
                type: Input
            }], inheritanceEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], changePermission: [{
                type: Output
            }] } });

const InheritedPermissionLabels = {
    Read: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.READ',
    ReadWrite: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.READ_WRITE',
    Everything: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.EVERYTHING',
    None: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.NO_ACCESS',
    Blocked: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.BLOCKED',
};
class InheritedPermissionComponent {
    constructor() {
        this.permission = 'None';
        this.inheritanceEnabled = true;
        this.label = InheritedPermissionLabels[this.permission];
    }
    ngOnChanges() {
        this.label = this.inheritanceEnabled ? InheritedPermissionLabels[this.permission] : InheritedPermissionLabels['Blocked'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InheritedPermissionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: InheritedPermissionComponent, isStandalone: true, selector: "hxp-inherited-permission", inputs: { permission: "permission", inheritanceEnabled: "inheritanceEnabled" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-inherited-permission\">\n    {{ label | translate }}\n</div>\n", styles: [".hxp-inherited-permission{display:flex;height:100%;align-items:center;color:#6b7280}\n"], dependencies: [{ kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: InheritedPermissionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-inherited-permission', imports: [TranslatePipe], standalone: true, template: "<div class=\"hxp-inherited-permission\">\n    {{ label | translate }}\n</div>\n", styles: [".hxp-inherited-permission{display:flex;height:100%;align-items:center;color:#6b7280}\n"] }]
        }], propDecorators: { permission: [{
                type: Input
            }], inheritanceEnabled: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class AddPermissionComponent {
    constructor(isSuggestedPermissionEntityValidator) {
        this.isSuggestedPermissionEntityValidator = isSuggestedPermissionEntityValidator;
        this.destroyRef = inject(DestroyRef);
        this.suggestions = [];
        this.addButtonLabel = '';
        this.searchPlaceholderText = '';
        this.loading = false;
        this.addNewPermission = new EventEmitter();
        this.search = new EventEmitter();
        this.permissionLabels = NewPermissionLabels;
        this.suggestionsSubject = new BehaviorSubject([]);
        this.originalOrder = () => 0;
        this.form = new FormGroup({
            search: new FormControl('', {
                validators: Validators.required,
                asyncValidators: this.isSuggestedPermissionEntityValidator.createValidator(this.suggestionsSubject.asObservable()),
                nonNullable: true,
            }),
            permission: new FormControl({ value: undefined, disabled: true }, {
                validators: Validators.required,
                nonNullable: true,
            }),
        }, { validators: this.getDisableValidator.bind(this) });
        this.form.controls.search.valueChanges
            .pipe(filter((text) => typeof text === 'string'), takeUntilDestroyed(this.destroyRef))
            .subscribe({
            next: (text) => {
                this.search.emit(text.trim());
            },
        });
        this.destroyRef.onDestroy(() => {
            this.suggestionsSubject.complete();
        });
    }
    ngOnChanges() {
        this.suggestionsSubject.next(this.suggestions);
    }
    addPermission() {
        if (this.selectedSuggestion) {
            const { inheritedPermission, ...suggestedEntity } = this.selectedSuggestion;
            const newPermission = {
                ...suggestedEntity,
                permission: this.form.controls.permission.value,
            };
            this.form.controls.search.patchValue('');
            this.form.controls.permission.patchValue(undefined);
            this.selectedSuggestion = undefined;
            this.form.controls.permission.disable();
            this.addNewPermission.emit(newPermission);
        }
    }
    selectSuggestion(event) {
        this.selectedSuggestion = event.option.value;
        if (this.selectedSuggestion) {
            this.permissionLabels = this.getAvailablePermissionsOptions(this.selectedSuggestion.inheritedPermission);
            this.form.controls.permission.enable();
        }
    }
    getEntityLabel(entity) {
        return entity?.entityLabel ?? '';
    }
    suggestionTrackBy(_index, suggestion) {
        return suggestion.entityId;
    }
    getAvailablePermissionsOptions(permission) {
        if (!permission) {
            return NewPermissionLabels;
        }
        const levels = ['None', 'Read', 'ReadWrite', 'Everything'];
        const currentLevel = levels.indexOf(permission);
        const availableOptions = {};
        for (const [key, value] of Object.entries(NewPermissionLabels)) {
            const level = levels.indexOf(key);
            if (level > currentLevel) {
                availableOptions[key] = value;
            }
        }
        return availableOptions;
    }
    getDisableValidator() {
        if (this.form?.controls?.permission?.disabled) {
            return { isStillDisabled: true };
        }
        // eslint-disable-next-line unicorn/no-null
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AddPermissionComponent, deps: [{ token: i1.IsSuggestedPermissionEntityValidator }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: AddPermissionComponent, isStandalone: true, selector: "hxp-add-permission", inputs: { suggestions: "suggestions", addButtonLabel: "addButtonLabel", searchPlaceholderText: "searchPlaceholderText", loading: "loading" }, outputs: { addNewPermission: "addNewPermission", search: "search" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-add-permission\">\n    <div class=\"hxp-permission-dialog-input-area\">\n        <div class=\"hxp-permission-dialog-input-title\">\n            <ng-content select=\"[title]\" />\n        </div>\n\n        <div class=\"hxp-input-area\">\n            <mat-form-field hideRequiredMarker subscriptSizing=\"dynamic\">\n                <input matInput id=\"hxp-add-permissions-text-search\" class=\"\" [formControl]=\"form.controls.search\"\n                    [placeholder]=\"searchPlaceholderText\" type=\"text\" [matAutocomplete]=\"auto\" md-select-on-focus/>\n                <mat-icon class=\"hxp-permission-dialog-align-arrow-right\" matSuffix>\n                    keyboard_arrow_down\n                </mat-icon>\n\n                <mat-autocomplete autoActiveFirstOption #auto=\"matAutocomplete\"\n                    (optionSelected)=\"selectSuggestion($event)\" [displayWith]=\"getEntityLabel\" class=\"hxp-user-panel\">\n                    <mat-option *ngIf=\"loading; else display_suggestions\">\n                        <mat-spinner diameter=\"25\" />\n                    </mat-option>\n                    <ng-template #display_suggestions>\n                        <mat-option\n                            *ngFor=\"let suggestion of suggestions;\n                            trackBy: suggestionTrackBy\"\n                            [value]=\"suggestion\"\n                            [ngClass]=\"{'hxp-selected-suggestion': suggestion.entityLabel === selectedSuggestion?.entityLabel}\">\n                            {{ suggestion.entityLabel }}\n                        </mat-option>\n                    </ng-template>\n                </mat-autocomplete>\n            </mat-form-field>\n        </div>\n    </div>\n    <div class=\"hxp-permission-dialog-input-area\">\n        <div class=\"hxp-permission-dialog-input-title\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SET_PERMISSION' | translate }}\n        </div>\n        <div class=\"hxp-input-area\">\n            <mat-form-field hideRequiredMarker subscriptSizing=\"dynamic\">\n                <mat-select id=\"hxp-permission-select\"\n                    [placeholder]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_PERMISSION' | translate\"\n                    class=\"hxp-permission-dialog-input\"\n                    [formControl]=\"form.controls.permission\"\n                    [disableOptionCentering]=\"true\"\n                    panelClass=\"hxp-permission-panel\">\n                    <mat-option *ngFor=\"let permission of permissionLabels | keyvalue: originalOrder\"\n                        [value]=\"permission.key\">\n                        {{ permission.value | translate }}\n                    </mat-option>\n                </mat-select>\n                <mat-icon class=\"hxp-permission-dialog-align-arrow-right\" matSuffix>\n                    keyboard_arrow_down\n                </mat-icon>\n            </mat-form-field>\n        </div>\n    </div>\n    <button\n        (click)=\"addPermission()\"\n        id=\"hxp-add-permission-button\"\n        class=\"hxp-permission-dialog-button\"\n        mat-button\n        color=\"primary\"\n        [disabled]=\"!form.valid\">\n        {{ addButtonLabel }}\n    </button>\n</div>\n", styles: [".hxp-permissions-management-panel-container .hxp-add-permission,.hxp-permissions-management-dialog-container .hxp-add-permission{display:flex;flex-direction:column}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-input,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-input{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-end;align-items:center;gap:12px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-input-title,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-input-title{font-style:normal;font-weight:var(--theme-menu-container-font-weight, 300);font-size:14px;line-height:23px;color:var(--adf-about-panel-header-title-color)}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-input-area,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-input-area{display:flex;flex-direction:column;height:48px;border:1px solid var(--adf-edit-process-filter-header-description-color);border-radius:8px;max-width:400px;padding-inline:12px;background-color:var(--adf-info-drawer-tab-default-background)}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-input-area .mat-mdc-select-placeholder,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-input-area .mat-mdc-select-placeholder{font-size:14px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-input-area .mat-mdc-text-field-wrapper,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-input-area .mat-mdc-text-field-wrapper{background-color:var(--adf-info-drawer-tab-default-background)}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-align-arrow-right,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-align-arrow-right{padding:12px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-input-area,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-input-area{margin-top:24px;position:relative;font-size:14px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-button,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-button{align-self:flex-end;margin-top:15px}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-select-arrow,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-select-arrow{opacity:0}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field{display:flex;flex-direction:column}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field-flex,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field-flex{align-items:center}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field-infix:not(.mdc-text-field--outlined):not(:disabled),.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field-infix:not(.mdc-text-field--outlined):not(:disabled){font-size:14px;min-height:auto;padding:0}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-select .mat-icon,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-select .mat-icon{padding:2px}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field.mat-form-field-invalid .mat-mdc-floating-label,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field.mat-form-field-invalid .mat-mdc-floating-label{color:inherit}.hxp-permissions-management-panel-container .hxp-permission-panel .mat-mdc-option.mat-mdc-select:not(.mat-mdc-option-multiple),.hxp-permissions-management-dialog-container .hxp-permission-panel .mat-mdc-option.mat-mdc-select:not(.mat-mdc-option-multiple){background-color:var(--adf-theme-primary-50);border-inline-start:4px solid var(--theme-primary-color, #5654ac);color:var(--adf-theme-foreground-text-color)}.hxp-permissions-management-panel-container .hxp-user-panel .hxp-selected-suggestion.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled),.hxp-permissions-management-dialog-container .hxp-user-panel .hxp-selected-suggestion.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled){background-color:var(--adf-theme-primary-50);border-inline-start:4px solid var(--theme-primary-color, #5654ac);color:var(--adf-theme-foreground-text-color)}.hxp-permissions-management-panel-container .hxp-user-panel .hxp-selected-suggestion,.hxp-permissions-management-dialog-container .hxp-user-panel .hxp-selected-suggestion{background-color:var(--adf-theme-primary-50)}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i3$3.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i3$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i3$3.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$1.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: AddPermissionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-add-permission', encapsulation: ViewEncapsulation.None, standalone: true, imports: [
                        MatFormFieldModule,
                        MatInputModule,
                        FormsModule,
                        MatAutocompleteModule,
                        ReactiveFormsModule,
                        MatIconModule,
                        NgIf,
                        MatOptionModule,
                        MatProgressSpinnerModule,
                        NgFor,
                        NgClass,
                        MatSelectModule,
                        MatButtonModule,
                        KeyValuePipe,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-add-permission\">\n    <div class=\"hxp-permission-dialog-input-area\">\n        <div class=\"hxp-permission-dialog-input-title\">\n            <ng-content select=\"[title]\" />\n        </div>\n\n        <div class=\"hxp-input-area\">\n            <mat-form-field hideRequiredMarker subscriptSizing=\"dynamic\">\n                <input matInput id=\"hxp-add-permissions-text-search\" class=\"\" [formControl]=\"form.controls.search\"\n                    [placeholder]=\"searchPlaceholderText\" type=\"text\" [matAutocomplete]=\"auto\" md-select-on-focus/>\n                <mat-icon class=\"hxp-permission-dialog-align-arrow-right\" matSuffix>\n                    keyboard_arrow_down\n                </mat-icon>\n\n                <mat-autocomplete autoActiveFirstOption #auto=\"matAutocomplete\"\n                    (optionSelected)=\"selectSuggestion($event)\" [displayWith]=\"getEntityLabel\" class=\"hxp-user-panel\">\n                    <mat-option *ngIf=\"loading; else display_suggestions\">\n                        <mat-spinner diameter=\"25\" />\n                    </mat-option>\n                    <ng-template #display_suggestions>\n                        <mat-option\n                            *ngFor=\"let suggestion of suggestions;\n                            trackBy: suggestionTrackBy\"\n                            [value]=\"suggestion\"\n                            [ngClass]=\"{'hxp-selected-suggestion': suggestion.entityLabel === selectedSuggestion?.entityLabel}\">\n                            {{ suggestion.entityLabel }}\n                        </mat-option>\n                    </ng-template>\n                </mat-autocomplete>\n            </mat-form-field>\n        </div>\n    </div>\n    <div class=\"hxp-permission-dialog-input-area\">\n        <div class=\"hxp-permission-dialog-input-title\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SET_PERMISSION' | translate }}\n        </div>\n        <div class=\"hxp-input-area\">\n            <mat-form-field hideRequiredMarker subscriptSizing=\"dynamic\">\n                <mat-select id=\"hxp-permission-select\"\n                    [placeholder]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_PERMISSION' | translate\"\n                    class=\"hxp-permission-dialog-input\"\n                    [formControl]=\"form.controls.permission\"\n                    [disableOptionCentering]=\"true\"\n                    panelClass=\"hxp-permission-panel\">\n                    <mat-option *ngFor=\"let permission of permissionLabels | keyvalue: originalOrder\"\n                        [value]=\"permission.key\">\n                        {{ permission.value | translate }}\n                    </mat-option>\n                </mat-select>\n                <mat-icon class=\"hxp-permission-dialog-align-arrow-right\" matSuffix>\n                    keyboard_arrow_down\n                </mat-icon>\n            </mat-form-field>\n        </div>\n    </div>\n    <button\n        (click)=\"addPermission()\"\n        id=\"hxp-add-permission-button\"\n        class=\"hxp-permission-dialog-button\"\n        mat-button\n        color=\"primary\"\n        [disabled]=\"!form.valid\">\n        {{ addButtonLabel }}\n    </button>\n</div>\n", styles: [".hxp-permissions-management-panel-container .hxp-add-permission,.hxp-permissions-management-dialog-container .hxp-add-permission{display:flex;flex-direction:column}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-input,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-input{box-sizing:border-box;display:flex;flex-direction:row;justify-content:flex-end;align-items:center;gap:12px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-input-title,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-input-title{font-style:normal;font-weight:var(--theme-menu-container-font-weight, 300);font-size:14px;line-height:23px;color:var(--adf-about-panel-header-title-color)}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-input-area,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-input-area{display:flex;flex-direction:column;height:48px;border:1px solid var(--adf-edit-process-filter-header-description-color);border-radius:8px;max-width:400px;padding-inline:12px;background-color:var(--adf-info-drawer-tab-default-background)}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-input-area .mat-mdc-select-placeholder,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-input-area .mat-mdc-select-placeholder{font-size:14px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-input-area .mat-mdc-text-field-wrapper,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-input-area .mat-mdc-text-field-wrapper{background-color:var(--adf-info-drawer-tab-default-background)}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-align-arrow-right,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-align-arrow-right{padding:12px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-input-area,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-input-area{margin-top:24px;position:relative;font-size:14px}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-dialog-button,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-dialog-button{align-self:flex-end;margin-top:15px}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-select-arrow,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-select-arrow{opacity:0}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field{display:flex;flex-direction:column}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field-flex,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field-flex{align-items:center}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field-infix:not(.mdc-text-field--outlined):not(:disabled),.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field-infix:not(.mdc-text-field--outlined):not(:disabled){font-size:14px;min-height:auto;padding:0}.hxp-permissions-management-panel-container .hxp-add-permission .hxp-permission-select .mat-icon,.hxp-permissions-management-dialog-container .hxp-add-permission .hxp-permission-select .mat-icon{padding:2px}.hxp-permissions-management-panel-container .hxp-add-permission .mat-mdc-form-field.mat-form-field-invalid .mat-mdc-floating-label,.hxp-permissions-management-dialog-container .hxp-add-permission .mat-mdc-form-field.mat-form-field-invalid .mat-mdc-floating-label{color:inherit}.hxp-permissions-management-panel-container .hxp-permission-panel .mat-mdc-option.mat-mdc-select:not(.mat-mdc-option-multiple),.hxp-permissions-management-dialog-container .hxp-permission-panel .mat-mdc-option.mat-mdc-select:not(.mat-mdc-option-multiple){background-color:var(--adf-theme-primary-50);border-inline-start:4px solid var(--theme-primary-color, #5654ac);color:var(--adf-theme-foreground-text-color)}.hxp-permissions-management-panel-container .hxp-user-panel .hxp-selected-suggestion.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled),.hxp-permissions-management-dialog-container .hxp-user-panel .hxp-selected-suggestion.mat-mdc-option.mdc-list-item--selected:not(.mdc-list-item--disabled){background-color:var(--adf-theme-primary-50);border-inline-start:4px solid var(--theme-primary-color, #5654ac);color:var(--adf-theme-foreground-text-color)}.hxp-permissions-management-panel-container .hxp-user-panel .hxp-selected-suggestion,.hxp-permissions-management-dialog-container .hxp-user-panel .hxp-selected-suggestion{background-color:var(--adf-theme-primary-50)}\n"] }]
        }], ctorParameters: () => [{ type: i1.IsSuggestedPermissionEntityValidator }], propDecorators: { suggestions: [{
                type: Input
            }], addButtonLabel: [{
                type: Input
            }], searchPlaceholderText: [{
                type: Input
            }], loading: [{
                type: Input
            }], addNewPermission: [{
                type: Output
            }], search: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionEmptyTableComponent {
    constructor() {
        this.message = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionEmptyTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionEmptyTableComponent, isStandalone: true, selector: "hxp-permissions-empty-table", inputs: { message: "message" }, ngImport: i0, template: "<div class=\"hxp-empty-table\">\n    <img src=\"./assets/adf-enterprise-adf-hx-content-services-ui/images/EmptyTable.svg\">\n    <div class=\"hxp-no-permission-msg\">{{ message }}</div>\n</div>\n", styles: [".hxp-empty-table{display:flex;flex-direction:column;justify-content:center;align-items:center;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionEmptyTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-empty-table', standalone: true, imports: [CommonModule], template: "<div class=\"hxp-empty-table\">\n    <img src=\"./assets/adf-enterprise-adf-hx-content-services-ui/images/EmptyTable.svg\">\n    <div class=\"hxp-no-permission-msg\">{{ message }}</div>\n</div>\n", styles: [".hxp-empty-table{display:flex;flex-direction:column;justify-content:center;align-items:center;height:100%}\n"] }]
        }], propDecorators: { message: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsDocumentTitleComponent {
    constructor() {
        this.title = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsDocumentTitleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionsDocumentTitleComponent, isStandalone: true, selector: "hxp-permissions-document-title", inputs: { title: "title" }, ngImport: i0, template: "<div class=\"hxp-permission-dialog-title\" mat-dialog-title>\n    <div class=\"hxp-permissions-title\">\n        <div class=\"hxp-permission-document-title\">\n            {{ title }}\n        </div>\n        <div class=\"hxp-permission-dialog-sub-title\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.MANAGE_PERMISSION' | translate }}\n        </div>\n    </div>\n    <div role=\"button\"><ng-content select=\"[close-button]\" /></div>\n</div>\n", styles: [".hxp-permission-dialog-title{font-size:25px;line-height:35px;font-weight:var(--theme-menu-container-font-weight, 300);display:flex;justify-content:space-between;align-items:flex-start;padding-left:0;padding-right:0}.hxp-permissions-title{display:flex;flex-direction:column;flex-grow:1}.hxp-permission-document-title{word-break:break-all}.hxp-permission-dialog-sub-title{font-weight:var(--theme-menu-container-font-weight, 300);font-size:14px;line-height:23px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsDocumentTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-document-title', standalone: true, imports: [MatDialogModule, TranslatePipe], template: "<div class=\"hxp-permission-dialog-title\" mat-dialog-title>\n    <div class=\"hxp-permissions-title\">\n        <div class=\"hxp-permission-document-title\">\n            {{ title }}\n        </div>\n        <div class=\"hxp-permission-dialog-sub-title\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.MANAGE_PERMISSION' | translate }}\n        </div>\n    </div>\n    <div role=\"button\"><ng-content select=\"[close-button]\" /></div>\n</div>\n", styles: [".hxp-permission-dialog-title{font-size:25px;line-height:35px;font-weight:var(--theme-menu-container-font-weight, 300);display:flex;justify-content:space-between;align-items:flex-start;padding-left:0;padding-right:0}.hxp-permissions-title{display:flex;flex-direction:column;flex-grow:1}.hxp-permission-document-title{word-break:break-all}.hxp-permission-dialog-sub-title{font-weight:var(--theme-menu-container-font-weight, 300);font-size:14px;line-height:23px}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionInheritanceToggleComponent {
    constructor() {
        this.isInheritanceEnabled = true;
        this.toggleChange = new EventEmitter();
    }
    onToggleChange(isEnabled) {
        this.toggleChange.emit(isEnabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionInheritanceToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionInheritanceToggleComponent, isStandalone: true, selector: "hxp-permissions-inheritance-toggle", inputs: { isInheritanceEnabled: "isInheritanceEnabled" }, outputs: { toggleChange: "toggleChange" }, ngImport: i0, template: "<div class=\"hxp-inheritance-toggle-container\">\n    <span class=\"hxp-toggle-label\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TITLE' | translate }}</span>\n    <mat-button-toggle-group\n        [hideSingleSelectionIndicator]=\"true\"\n        [value]=\"isInheritanceEnabled\"\n        (change)=\"onToggleChange($event.value)\"\n        class=\"hxp-toggle-group\"\n    >\n        <mat-button-toggle [value]=\"false\" class=\"hxp-toggle-button\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TOGGLE_OPTION.OFF' | translate }}</mat-button-toggle>\n        <mat-button-toggle [value]=\"true\" class=\"hxp-toggle-button hxp-on\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TOGGLE_OPTION.ON' | translate }}</mat-button-toggle>\n    </mat-button-toggle-group>\n</div>\n", styles: [".hxp-inheritance-toggle-container{display:flex;align-items:center;gap:8px;margin:8px 0}.hxp-inheritance-toggle-container .hxp-toggle-label{font-size:14px;color:#111827}.hxp-inheritance-toggle-container .hxp-toggle-group{border:1px solid #6b7280;border-radius:100px;overflow:hidden;display:inline-flex;background-color:var(--theme-background-color, #fafafa)}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button{font-size:14px;padding:4px;border-radius:100px;border:none}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button .mat-button-toggle-label-content{line-height:inherit!important}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button.mat-button-toggle-checked{background-color:#374151;color:#fff}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button.mat-button-toggle-checked.hxp-on{background-color:var(--theme-primary-color, #5654ac);color:#fff}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button:not(.mat-button-toggle-checked){color:#4b5563}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatButtonToggleModule }, { kind: "directive", type: i1$4.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i1$4.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionInheritanceToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-inheritance-toggle', standalone: true, imports: [CommonModule, MatButtonToggleModule, TranslatePipe], encapsulation: ViewEncapsulation.None, template: "<div class=\"hxp-inheritance-toggle-container\">\n    <span class=\"hxp-toggle-label\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TITLE' | translate }}</span>\n    <mat-button-toggle-group\n        [hideSingleSelectionIndicator]=\"true\"\n        [value]=\"isInheritanceEnabled\"\n        (change)=\"onToggleChange($event.value)\"\n        class=\"hxp-toggle-group\"\n    >\n        <mat-button-toggle [value]=\"false\" class=\"hxp-toggle-button\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TOGGLE_OPTION.OFF' | translate }}</mat-button-toggle>\n        <mat-button-toggle [value]=\"true\" class=\"hxp-toggle-button hxp-on\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TOGGLE_OPTION.ON' | translate }}</mat-button-toggle>\n    </mat-button-toggle-group>\n</div>\n", styles: [".hxp-inheritance-toggle-container{display:flex;align-items:center;gap:8px;margin:8px 0}.hxp-inheritance-toggle-container .hxp-toggle-label{font-size:14px;color:#111827}.hxp-inheritance-toggle-container .hxp-toggle-group{border:1px solid #6b7280;border-radius:100px;overflow:hidden;display:inline-flex;background-color:var(--theme-background-color, #fafafa)}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button{font-size:14px;padding:4px;border-radius:100px;border:none}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button .mat-button-toggle-label-content{line-height:inherit!important}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button.mat-button-toggle-checked{background-color:#374151;color:#fff}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button.mat-button-toggle-checked.hxp-on{background-color:var(--theme-primary-color, #5654ac);color:#fff}.hxp-inheritance-toggle-container .hxp-toggle-group .hxp-toggle-button:not(.mat-button-toggle-checked){color:#4b5563}\n"] }]
        }], propDecorators: { isInheritanceEnabled: [{
                type: Input
            }], toggleChange: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionManagementContainerComponent {
    constructor(permissionsManagementFacade, documentService) {
        this.permissionsManagementFacade = permissionsManagementFacade;
        this.documentService = documentService;
        this.cancelEvent = new EventEmitter();
        this.closeEvent = new EventEmitter();
        this.restoreEvent = new EventEmitter();
        this.edited = false;
        this.destroyRef = inject(DestroyRef);
        this.suggestedGroups$ = this.permissionsManagementFacade.suggestedGroups$;
        this.suggestedIndividuals$ = this.permissionsManagementFacade.suggestedIndividuals$;
        this.title$ = this.permissionsManagementFacade.api.title$;
        this.activePermissionsManagementRows$ = this.permissionsManagementFacade.api.activePermissionsManagementRows$;
        this.isUntouched$ = this.permissionsManagementFacade.api.isUntouched$;
        this.loading$ = this.permissionsManagementFacade.api.loading$;
        this.isInheritanceEnabled$ = this.permissionsManagementFacade.api.isInheritanceEnabled$;
        this.hasLocalPermission$ = this.permissionsManagementFacade.api.hasLocalPermission$;
    }
    ngOnInit() {
        this.permissionsManagementFacade.onInitializePermissionsManagement(this.document, this.parentDocument, this.destroyRef);
        this.isUntouched$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
            next: (untouched) => (this.edited = !untouched),
            error: () => (this.edited = true),
        });
    }
    savePermissions() {
        this.saveDocumentPermissions()
            .pipe(filter$1(Boolean))
            .subscribe({
            next: () => {
                this.documentService.requestReload();
                this.closeEvent.emit();
            },
        });
    }
    restorePermissions(restoreOption) {
        this.restoreDocumentPermissions(restoreOption)
            .pipe(filter$1(Boolean))
            .subscribe({
            next: () => {
                this.documentService.requestReload();
                this.closeEvent.emit();
            },
        });
    }
    cancel() {
        this.cancelEvent.emit(this.edited);
    }
    closePermission() {
        this.closeEvent.emit(this.edited);
    }
    restore() {
        this.restoreEvent.emit();
    }
    onTabSelection(index) {
        const identityTypes = ['group', 'user'];
        this.permissionsManagementFacade.onUpdateActiveTab(identityTypes[index]);
    }
    onAddNewPermissionsManagementRow(newPermission) {
        this.permissionsManagementFacade.onAddNewPermissionsManagementRow(newPermission);
    }
    onEditPermissionsManagementRow(permission, permissionsManagementRow) {
        this.permissionsManagementFacade.onEditPermissionsManagementRow({ ...permissionsManagementRow, permission });
    }
    filterPermissionsManagementRowsByIndividual($event) {
        this.permissionsManagementFacade.onSearchUserField($event);
    }
    filterPermissionsManagementRowsByGroup($event) {
        this.permissionsManagementFacade.onSearchGroupField($event);
    }
    searchGroups($event) {
        this.permissionsManagementFacade.onNewGroupField($event);
    }
    searchIndividuals($event) {
        this.permissionsManagementFacade.onNewUserField($event);
    }
    onInheritanceStateChange(isEnabled) {
        this.permissionsManagementFacade.onUpdateInheritanceState(isEnabled);
    }
    saveDocumentPermissions() {
        return this.permissionsManagementFacade.updateDocumentAcl();
    }
    restoreDocumentPermissions(restoreOption) {
        return this.permissionsManagementFacade.restorePermissionsToInherited(restoreOption);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionManagementContainerComponent, deps: [{ token: i1.PermissionsManagementFacade }, { token: i1.DocumentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionManagementContainerComponent, isStandalone: true, selector: "hxp-permission-management-container", inputs: { document: "document", parentDocument: "parentDocument" }, outputs: { cancelEvent: "cancelEvent", closeEvent: "closeEvent", restoreEvent: "restoreEvent" }, providers: [PermissionsManagementFacade, PermissionsManagementStateService], queries: [{ propertyName: "titleTemplateRef", first: true, predicate: ["title"], descendants: true }], ngImport: i0, template: "<ng-template #defaultTitle let-title>\n    <hxp-permissions-document-title [title]=\"title || ''\">\n        <button mat-icon-button close-button class=\"hxp-permission-dialog-cross\" (click)=\"closePermission()\">\n            <mat-icon>close</mat-icon>\n        </button>\n    </hxp-permissions-document-title>\n</ng-template>\n\n<ng-template\n    *ngTemplateOutlet=\"titleTemplateRef || defaultTitle; context: { $implicit: (title$ | async) }\" />\n\n<hxp-permissions-inheritance-toggle\n    [isInheritanceEnabled]=\"(isInheritanceEnabled$ | async)\"\n    (toggleChange)=\"onInheritanceStateChange($event)\"\n />\n<form>\n    <mat-tab-group dynamicHeight mat-stretch-tabs=\"false\" mat-stretch-tabs=\"true\"\n        (selectedIndexChange)=\"onTabSelection($event)\">\n        <mat-tab class=\"hxp-permission-tabs\"\n            label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.GROUPS' | translate }}\">\n            <hxp-permissions-table *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.GROUP' | translate\"\n                [activePermissionsManagementRows]=\"activePermissionsManagementRows\">\n\n                <hxp-permission-search permission-search id=\"hxp-permission-search-group\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                    placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_GROUP' | translate }}\"\n                    (search)=\"filterPermissionsManagementRowsByGroup($event)\" />\n\n                <ng-template #entityColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.GROUPS' | translate }}</ng-template>\n                <ng-template #inheritedPermissionColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.INHERITED' | translate\n                    }}</ng-template>\n                <ng-template #fileColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_LEVEL' | translate\n                    }}</ng-template>\n\n                <ng-template #entityCell let-row>\n                    <div class=\"hxp-entity-details\">\n                        <div class=\"hxp-group-details-label\"\n                            [class]=\"{'hxp-disabled-entity': row.inheritedPermission === 'Everything'}\">\n                            <mat-icon [inline]=\"true\">people_outline</mat-icon>\n                            {{ row.entityLabel }}\n                        </div>\n                    </div>\n                </ng-template>\n\n                <ng-template #inheritedPermissionCell let-row>\n                    <hxp-inherited-permission [permission]=\"row.inheritedPermission\"\n                        [inheritanceEnabled]=\"(isInheritanceEnabled$ | async)\" />\n                </ng-template>\n\n                <ng-template #fileCell let-row>\n                    <ng-container *ngIf=\"(isInheritanceEnabled$ | async) === true && row.inheritedPermission === 'Everything'; else editableField\">\n                        <div class=\"hxp-cannot-be-changed\">{{\n                            'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.CANNOT_BE_CHANGED' | translate }}</div>\n                    </ng-container>\n\n                    <ng-template #editableField>\n                        <hxp-permissions [permission]=\"row.permission\" [inheritedPermission]=\"row.inheritedPermission\"\n                            [inheritanceEnabled]=\"(isInheritanceEnabled$ | async) || false\"\n                            (changePermission)=\"onEditPermissionsManagementRow($event, row)\" />\n                    </ng-template>\n                </ng-template>\n\n                <ng-template #emptyTable>\n                    <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.GROUP' |\n                    translate\" />\n                </ng-template>\n            </hxp-permissions-table>\n\n            <hxp-add-permission id=\"hxp-add-user-group\" [suggestions]=\"(suggestedGroups$ | async) || []\"\n                [loading]=\"(loading$ | async) || false\"\n                searchPlaceholderText=\"{{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_GROUP' | translate}}\"\n                addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_GROUP' | translate }}\"\n                (search)=\"searchGroups($event)\" (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\">\n                <ng-container title>\n                    {{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_GROUP' | translate }}\n                </ng-container>\n            </hxp-add-permission>\n        </mat-tab>\n\n        <mat-tab class=\"hxp-permission-tabs\"\n            label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.USERS' | translate }}\">\n            <hxp-permissions-table *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.USER' | translate\"\n                [activePermissionsManagementRows]=\"activePermissionsManagementRows\">\n\n                <hxp-permission-search permission-search id=\"hxp-permission-search-user\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                    placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_USER' | translate }}\"\n                    (search)=\"filterPermissionsManagementRowsByIndividual($event)\" />\n\n                <ng-template #entityColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.USERS' | translate }}</ng-template>\n                <ng-template #fileColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_ACCESS' | translate\n                    }}</ng-template>\n\n                <ng-template #entityCell let-row>\n                    <div class=\"hxp-entity-details\">\n                        <div>{{ row.entityLabel }}</div>\n                        <div *ngIf=\"row.inherited\" class=\"hxp-users-icon\">\n                            <mat-icon [inline]=\"true\">people_outline</mat-icon>\n                            <ng-container *ngIf=\"!row.overridden; else overriddenPermission\">\n                                {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED_PERMISSION' | translate }}\n                            </ng-container>\n                            <ng-template #overriddenPermission>\n                                {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.OVERRIDDEN_PERMISSION' | translate\n                                }}\n                            </ng-template>\n                        </div>\n                    </div>\n                </ng-template>\n\n                <ng-template #fileCell let-row>\n                    <hxp-permissions [permission]=\"row.permission\" [disabled]=\"!row.overridden && row.inherited\"\n                        [inheritedPermission]=\"row.inheritedPermission\"\n                        (changePermission)=\"onEditPermissionsManagementRow($event, row)\" />\n                </ng-template>\n\n                <ng-template #emptyTable>\n                    <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.USER' |\n                    translate\" />\n                </ng-template>\n            </hxp-permissions-table>\n\n            <hxp-add-permission id=\"hxp-add-user\" [suggestions]=\"(suggestedIndividuals$ | async) || []\"\n                [loading]=\"(loading$ | async) || false\"\n                searchPlaceholderText=\"{{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_USER' | translate}}\"\n                addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_USER' | translate }}\"\n                (search)=\"searchIndividuals($event)\" (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\">\n                <ng-container title>\n                    {{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_USER' | translate }}\n                </ng-container>\n            </hxp-add-permission>\n        </mat-tab>\n    </mat-tab-group>\n</form>\n<mat-divider />\n<div class=\"hxp-permissions-actions\">\n    <div class=\"hxp-left-actions\">\n        <button\n            mat-button\n            class=\"hxp-restore-button\"\n            [disabled]=\"(hasLocalPermission$ | async) === false\"\n            (click)=\"restore()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.RESTORE' | translate }}\n        </button>\n    </div>\n    <div class=\"hxp-right-actions\">\n        <button\n            mat-button\n            class=\"hxp-cancel-button\"\n            (click)=\"cancel()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.CANCEL' | translate }}\n        </button>\n\n        <button\n            class=\"hxp-save-permission-button hxp-primary-button\"\n            mat-button\n            [disabled]=\"isUntouched$ | async\"\n            (click)=\"savePermissions()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.SAVE' | translate }}\n        </button>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-panel-container .hxp-cancel-button,.hxp-permissions-management-panel-container .hxp-restore-button,.hxp-permissions-management-dialog-container .hxp-cancel-button,.hxp-permissions-management-dialog-container .hxp-restore-button{color:var(--theme-primary-color, #5654ac);border:0}.hxp-permissions-management-panel-container .hxp-restore-button[disabled],.hxp-permissions-management-dialog-container .hxp-restore-button[disabled]{color:#9ca3af}.hxp-permissions-management-panel-container .hxp-permission-tabs,.hxp-permissions-management-dialog-container .hxp-permission-tabs{font-weight:600;font-size:14px;line-height:16px}.hxp-permissions-management-panel-container .hxp-permissions-actions,.hxp-permissions-management-dialog-container .hxp-permissions-actions{display:flex;justify-content:space-between;text-align:center}.hxp-permissions-management-panel-container .hxp-permissions-actions .hxp-left-actions,.hxp-permissions-management-dialog-container .hxp-permissions-actions .hxp-left-actions{display:flex;align-items:center}.hxp-permissions-management-panel-container .hxp-permissions-actions .hxp-right-actions,.hxp-permissions-management-dialog-container .hxp-permissions-actions .hxp-right-actions{display:flex;gap:8px;align-items:center}.hxp-permissions-management-panel-container .hxp-permission-container,.hxp-permissions-management-dialog-container .hxp-permission-container{width:100%}.hxp-permissions-management-panel-container .hxp-entity-details,.hxp-permissions-management-dialog-container .hxp-entity-details{display:flex;flex-direction:column;justify-content:center;height:100%}.hxp-permissions-management-panel-container .hxp-entity-details .hxp-group-details-label,.hxp-permissions-management-dialog-container .hxp-entity-details .hxp-group-details-label{display:flex;align-items:center;gap:8px}.hxp-permissions-management-panel-container .hxp-entity-details .hxp-group-details-label mat-icon,.hxp-permissions-management-dialog-container .hxp-entity-details .hxp-group-details-label mat-icon{font-size:20px}.hxp-permissions-management-panel-container .hxp-users-icon,.hxp-permissions-management-dialog-container .hxp-users-icon{display:flex;flex-direction:row;align-items:center;gap:8px;font-size:var(--theme-caption-font-size, 12px);color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-disabled-entity,.hxp-permissions-management-dialog-container .hxp-disabled-entity{color:#6b7280}.hxp-permissions-management-panel-container .hxp-cannot-be-changed,.hxp-permissions-management-dialog-container .hxp-cannot-be-changed{color:#6b7280;font-weight:700;font-size:12px;white-space:nowrap}.hxp-permissions-management-panel-container .mat-mdc-tab-group>.mat-mdc-tab-header>.mat-mdc-tab-label-container>.mat-mdc-tab-list>.mat-mdc-tab-labels,.hxp-permissions-management-dialog-container .mat-mdc-tab-group>.mat-mdc-tab-header>.mat-mdc-tab-label-container>.mat-mdc-tab-list>.mat-mdc-tab-labels{max-width:388px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i3$4.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i3$4.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: PermissionsTableComponent, selector: "hxp-permissions-table", inputs: ["title", "activePermissionsManagementRows"] }, { kind: "component", type: PermissionsSearchComponent, selector: "hxp-permission-search", inputs: ["placeHolder", "activePermissionsManagementRows"], outputs: ["search"] }, { kind: "component", type: PermissionsComponent, selector: "hxp-permissions", inputs: ["permission", "inheritedPermission", "inheritanceEnabled", "disabled"], outputs: ["changePermission"] }, { kind: "component", type: InheritedPermissionComponent, selector: "hxp-inherited-permission", inputs: ["permission", "inheritanceEnabled"] }, { kind: "component", type: AddPermissionComponent, selector: "hxp-add-permission", inputs: ["suggestions", "addButtonLabel", "searchPlaceholderText", "loading"], outputs: ["addNewPermission", "search"] }, { kind: "ngmodule", type: MatSnackBarModule }, { kind: "component", type: PermissionEmptyTableComponent, selector: "hxp-permissions-empty-table", inputs: ["message"] }, { kind: "component", type: PermissionsDocumentTitleComponent, selector: "hxp-permissions-document-title", inputs: ["title"] }, { kind: "component", type: PermissionInheritanceToggleComponent, selector: "hxp-permissions-inheritance-toggle", inputs: ["isInheritanceEnabled"], outputs: ["toggleChange"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionManagementContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permission-management-container', standalone: true, imports: [
                        NgIf,
                        AsyncPipe,
                        MatDialogModule,
                        MatButtonModule,
                        MatTabsModule,
                        MatIconModule,
                        MatDividerModule,
                        TranslatePipe,
                        PermissionsTableComponent,
                        PermissionsSearchComponent,
                        PermissionsComponent,
                        InheritedPermissionComponent,
                        AddPermissionComponent,
                        MatSnackBarModule,
                        PermissionEmptyTableComponent,
                        PermissionsDocumentTitleComponent,
                        MatIconModule,
                        PermissionInheritanceToggleComponent,
                        CommonModule,
                    ], providers: [PermissionsManagementFacade, PermissionsManagementStateService], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template #defaultTitle let-title>\n    <hxp-permissions-document-title [title]=\"title || ''\">\n        <button mat-icon-button close-button class=\"hxp-permission-dialog-cross\" (click)=\"closePermission()\">\n            <mat-icon>close</mat-icon>\n        </button>\n    </hxp-permissions-document-title>\n</ng-template>\n\n<ng-template\n    *ngTemplateOutlet=\"titleTemplateRef || defaultTitle; context: { $implicit: (title$ | async) }\" />\n\n<hxp-permissions-inheritance-toggle\n    [isInheritanceEnabled]=\"(isInheritanceEnabled$ | async)\"\n    (toggleChange)=\"onInheritanceStateChange($event)\"\n />\n<form>\n    <mat-tab-group dynamicHeight mat-stretch-tabs=\"false\" mat-stretch-tabs=\"true\"\n        (selectedIndexChange)=\"onTabSelection($event)\">\n        <mat-tab class=\"hxp-permission-tabs\"\n            label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.GROUPS' | translate }}\">\n            <hxp-permissions-table *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.GROUP' | translate\"\n                [activePermissionsManagementRows]=\"activePermissionsManagementRows\">\n\n                <hxp-permission-search permission-search id=\"hxp-permission-search-group\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                    placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_GROUP' | translate }}\"\n                    (search)=\"filterPermissionsManagementRowsByGroup($event)\" />\n\n                <ng-template #entityColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.GROUPS' | translate }}</ng-template>\n                <ng-template #inheritedPermissionColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.INHERITED' | translate\n                    }}</ng-template>\n                <ng-template #fileColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_LEVEL' | translate\n                    }}</ng-template>\n\n                <ng-template #entityCell let-row>\n                    <div class=\"hxp-entity-details\">\n                        <div class=\"hxp-group-details-label\"\n                            [class]=\"{'hxp-disabled-entity': row.inheritedPermission === 'Everything'}\">\n                            <mat-icon [inline]=\"true\">people_outline</mat-icon>\n                            {{ row.entityLabel }}\n                        </div>\n                    </div>\n                </ng-template>\n\n                <ng-template #inheritedPermissionCell let-row>\n                    <hxp-inherited-permission [permission]=\"row.inheritedPermission\"\n                        [inheritanceEnabled]=\"(isInheritanceEnabled$ | async)\" />\n                </ng-template>\n\n                <ng-template #fileCell let-row>\n                    <ng-container *ngIf=\"(isInheritanceEnabled$ | async) === true && row.inheritedPermission === 'Everything'; else editableField\">\n                        <div class=\"hxp-cannot-be-changed\">{{\n                            'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.CANNOT_BE_CHANGED' | translate }}</div>\n                    </ng-container>\n\n                    <ng-template #editableField>\n                        <hxp-permissions [permission]=\"row.permission\" [inheritedPermission]=\"row.inheritedPermission\"\n                            [inheritanceEnabled]=\"(isInheritanceEnabled$ | async) || false\"\n                            (changePermission)=\"onEditPermissionsManagementRow($event, row)\" />\n                    </ng-template>\n                </ng-template>\n\n                <ng-template #emptyTable>\n                    <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.GROUP' |\n                    translate\" />\n                </ng-template>\n            </hxp-permissions-table>\n\n            <hxp-add-permission id=\"hxp-add-user-group\" [suggestions]=\"(suggestedGroups$ | async) || []\"\n                [loading]=\"(loading$ | async) || false\"\n                searchPlaceholderText=\"{{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_GROUP' | translate}}\"\n                addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_GROUP' | translate }}\"\n                (search)=\"searchGroups($event)\" (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\">\n                <ng-container title>\n                    {{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_GROUP' | translate }}\n                </ng-container>\n            </hxp-add-permission>\n        </mat-tab>\n\n        <mat-tab class=\"hxp-permission-tabs\"\n            label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.USERS' | translate }}\">\n            <hxp-permissions-table *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.USER' | translate\"\n                [activePermissionsManagementRows]=\"activePermissionsManagementRows\">\n\n                <hxp-permission-search permission-search id=\"hxp-permission-search-user\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                    placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_USER' | translate }}\"\n                    (search)=\"filterPermissionsManagementRowsByIndividual($event)\" />\n\n                <ng-template #entityColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.USERS' | translate }}</ng-template>\n                <ng-template #fileColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_ACCESS' | translate\n                    }}</ng-template>\n\n                <ng-template #entityCell let-row>\n                    <div class=\"hxp-entity-details\">\n                        <div>{{ row.entityLabel }}</div>\n                        <div *ngIf=\"row.inherited\" class=\"hxp-users-icon\">\n                            <mat-icon [inline]=\"true\">people_outline</mat-icon>\n                            <ng-container *ngIf=\"!row.overridden; else overriddenPermission\">\n                                {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED_PERMISSION' | translate }}\n                            </ng-container>\n                            <ng-template #overriddenPermission>\n                                {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.OVERRIDDEN_PERMISSION' | translate\n                                }}\n                            </ng-template>\n                        </div>\n                    </div>\n                </ng-template>\n\n                <ng-template #fileCell let-row>\n                    <hxp-permissions [permission]=\"row.permission\" [disabled]=\"!row.overridden && row.inherited\"\n                        [inheritedPermission]=\"row.inheritedPermission\"\n                        (changePermission)=\"onEditPermissionsManagementRow($event, row)\" />\n                </ng-template>\n\n                <ng-template #emptyTable>\n                    <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.USER' |\n                    translate\" />\n                </ng-template>\n            </hxp-permissions-table>\n\n            <hxp-add-permission id=\"hxp-add-user\" [suggestions]=\"(suggestedIndividuals$ | async) || []\"\n                [loading]=\"(loading$ | async) || false\"\n                searchPlaceholderText=\"{{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_USER' | translate}}\"\n                addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_USER' | translate }}\"\n                (search)=\"searchIndividuals($event)\" (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\">\n                <ng-container title>\n                    {{'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_USER' | translate }}\n                </ng-container>\n            </hxp-add-permission>\n        </mat-tab>\n    </mat-tab-group>\n</form>\n<mat-divider />\n<div class=\"hxp-permissions-actions\">\n    <div class=\"hxp-left-actions\">\n        <button\n            mat-button\n            class=\"hxp-restore-button\"\n            [disabled]=\"(hasLocalPermission$ | async) === false\"\n            (click)=\"restore()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.RESTORE' | translate }}\n        </button>\n    </div>\n    <div class=\"hxp-right-actions\">\n        <button\n            mat-button\n            class=\"hxp-cancel-button\"\n            (click)=\"cancel()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.CANCEL' | translate }}\n        </button>\n\n        <button\n            class=\"hxp-save-permission-button hxp-primary-button\"\n            mat-button\n            [disabled]=\"isUntouched$ | async\"\n            (click)=\"savePermissions()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.SAVE' | translate }}\n        </button>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-panel-container .hxp-cancel-button,.hxp-permissions-management-panel-container .hxp-restore-button,.hxp-permissions-management-dialog-container .hxp-cancel-button,.hxp-permissions-management-dialog-container .hxp-restore-button{color:var(--theme-primary-color, #5654ac);border:0}.hxp-permissions-management-panel-container .hxp-restore-button[disabled],.hxp-permissions-management-dialog-container .hxp-restore-button[disabled]{color:#9ca3af}.hxp-permissions-management-panel-container .hxp-permission-tabs,.hxp-permissions-management-dialog-container .hxp-permission-tabs{font-weight:600;font-size:14px;line-height:16px}.hxp-permissions-management-panel-container .hxp-permissions-actions,.hxp-permissions-management-dialog-container .hxp-permissions-actions{display:flex;justify-content:space-between;text-align:center}.hxp-permissions-management-panel-container .hxp-permissions-actions .hxp-left-actions,.hxp-permissions-management-dialog-container .hxp-permissions-actions .hxp-left-actions{display:flex;align-items:center}.hxp-permissions-management-panel-container .hxp-permissions-actions .hxp-right-actions,.hxp-permissions-management-dialog-container .hxp-permissions-actions .hxp-right-actions{display:flex;gap:8px;align-items:center}.hxp-permissions-management-panel-container .hxp-permission-container,.hxp-permissions-management-dialog-container .hxp-permission-container{width:100%}.hxp-permissions-management-panel-container .hxp-entity-details,.hxp-permissions-management-dialog-container .hxp-entity-details{display:flex;flex-direction:column;justify-content:center;height:100%}.hxp-permissions-management-panel-container .hxp-entity-details .hxp-group-details-label,.hxp-permissions-management-dialog-container .hxp-entity-details .hxp-group-details-label{display:flex;align-items:center;gap:8px}.hxp-permissions-management-panel-container .hxp-entity-details .hxp-group-details-label mat-icon,.hxp-permissions-management-dialog-container .hxp-entity-details .hxp-group-details-label mat-icon{font-size:20px}.hxp-permissions-management-panel-container .hxp-users-icon,.hxp-permissions-management-dialog-container .hxp-users-icon{display:flex;flex-direction:row;align-items:center;gap:8px;font-size:var(--theme-caption-font-size, 12px);color:var(--theme-primary-color, #5654ac)}.hxp-permissions-management-panel-container .hxp-disabled-entity,.hxp-permissions-management-dialog-container .hxp-disabled-entity{color:#6b7280}.hxp-permissions-management-panel-container .hxp-cannot-be-changed,.hxp-permissions-management-dialog-container .hxp-cannot-be-changed{color:#6b7280;font-weight:700;font-size:12px;white-space:nowrap}.hxp-permissions-management-panel-container .mat-mdc-tab-group>.mat-mdc-tab-header>.mat-mdc-tab-label-container>.mat-mdc-tab-list>.mat-mdc-tab-labels,.hxp-permissions-management-dialog-container .mat-mdc-tab-group>.mat-mdc-tab-header>.mat-mdc-tab-label-container>.mat-mdc-tab-list>.mat-mdc-tab-labels{max-width:388px}\n"] }]
        }], ctorParameters: () => [{ type: i1.PermissionsManagementFacade }, { type: i1.DocumentService }], propDecorators: { document: [{
                type: Input
            }], parentDocument: [{
                type: Input
            }], cancelEvent: [{
                type: Output
            }], closeEvent: [{
                type: Output
            }], restoreEvent: [{
                type: Output
            }], titleTemplateRef: [{
                type: ContentChild,
                args: ['title', { static: false }]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class RestorePermissionDialogComponent {
    constructor(dialogRef) {
        this.dialogRef = dialogRef;
        this.restoreOption = UserType.ALL;
    }
    reject() {
        this.dialogRef.close();
    }
    confirm() {
        this.dialogRef.close({ restore: true, option: this.restoreOption });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: RestorePermissionDialogComponent, deps: [{ token: i1$1.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: RestorePermissionDialogComponent, isStandalone: true, selector: "hxp-restore-permission-dialog", ngImport: i0, template: "<div class=\"hxp-restore-permission-dialog\">\n    <h1 mat-dialog-title>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.TITLE' | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.DESCRIPTION' | translate}}</p>\n        <ng-container>\n            <mat-radio-group [(ngModel)]=\"restoreOption\" class=\"hxp-permission-reset-options\">\n                <mat-radio-button value=\"ALL\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.ALL' | translate }}\n                </mat-radio-button>\n                <mat-radio-button value=\"GROUPS\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.GROUP' | translate }}\n                </mat-radio-button>\n                <mat-radio-button value=\"USERS\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.USER' | translate }}\n                </mat-radio-button>\n            </mat-radio-group>\n        </ng-container>\n    </div>\n    <mat-dialog-actions>\n        <button mat-flat-button class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.REJECT' | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button hxp-primary-button\" (click)=\"confirm()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.CONFIRM' | translate}}\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-restore-permission-dialog .hxp-permission-reset-options{display:flex;flex-direction:column}.hxp-restore-permission-dialog .mat-mdc-dialog-actions{justify-content:flex-end}.hxp-cancel-permission-dialog .mat-mdc-dialog-title{margin:0}.hxp-cancel-permission-dialog .hxp-permission-dialog-reject-button{color:var(--theme-primary-color, #5654ac);border:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i3$5.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i3$5.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: RestorePermissionDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-restore-permission-dialog', encapsulation: ViewEncapsulation.None, standalone: true, imports: [MatDialogModule, MatButtonModule, MatRadioModule, FormsModule, TranslatePipe], template: "<div class=\"hxp-restore-permission-dialog\">\n    <h1 mat-dialog-title>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.TITLE' | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.DESCRIPTION' | translate}}</p>\n        <ng-container>\n            <mat-radio-group [(ngModel)]=\"restoreOption\" class=\"hxp-permission-reset-options\">\n                <mat-radio-button value=\"ALL\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.ALL' | translate }}\n                </mat-radio-button>\n                <mat-radio-button value=\"GROUPS\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.GROUP' | translate }}\n                </mat-radio-button>\n                <mat-radio-button value=\"USERS\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.USER' | translate }}\n                </mat-radio-button>\n            </mat-radio-group>\n        </ng-container>\n    </div>\n    <mat-dialog-actions>\n        <button mat-flat-button class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.REJECT' | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button hxp-primary-button\" (click)=\"confirm()\">\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.CONFIRM' | translate}}\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-restore-permission-dialog .hxp-permission-reset-options{display:flex;flex-direction:column}.hxp-restore-permission-dialog .mat-mdc-dialog-actions{justify-content:flex-end}.hxp-cancel-permission-dialog .mat-mdc-dialog-title{margin:0}.hxp-cancel-permission-dialog .hxp-permission-dialog-reject-button{color:var(--theme-primary-color, #5654ac);border:0}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DIALOG_MIN_WIDTH = 436;
/**
 * This component is responsible for managing the permissions in the form of dialog.
 * The dialog overlay prevent the user to interact with the rest of the application.
 *
 * It includes functionalities to add, edit, and display permissions to `User`s and `Group`s.
 *
 * Available permissions are `Read`, `Write` and `Everything`.
 *
 * Permissions are inherited from the parent `Document`.
 * It's possible to only upgrade a inherited permission.
 *
 * To use the `PermissionsManagementPanelComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MatDialog } from '@angular/material/dialog';
 * import { PermissionsManagementPanelComponent } from '@alfresco/adf-hx-content-services/ui';
 * import { PermissionsManagementDialogData } from '@alfresco/adf-hx-content-services/services';
 *
 * @Component({
 *     template: '<button (click)="openPermissionsManagementDialog(document)">{{ document.sys_title }}</button>',
 *     standalone: true,
 * })
 * class OpenDialogButtonComponent {
 *
 *     constructor(
 *         private dialog: MatDialog,
 *     ) {}
 *
 *     openPermissionsManagementDialog(document: Document) {
 *         this.dialog.open<
 *             PermissionsManagementDialogComponent,
 *             PermissionsManagementDialogData
 *         >(PermissionsManagementDialogComponent, {
 *             data: { document }
 *          });
 *     }
 * }
 * ```
 */
class PermissionsManagementDialogComponent extends DismissPermission {
    constructor(data, dialog, dialogRef) {
        super();
        this.dialog = dialog;
        this.dialogRef = dialogRef;
        this.document = data.document;
        this.parentDocument = data.parentDocument;
    }
    cancel(isEdited) {
        if (!isEdited) {
            return this.dialogRef.close();
        }
        this.dialog.open(CancelPermissionDialogComponent, {
            width: DialogConfig.small.width,
            data: {
                dialogTitle: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.TITLE',
                dialogDescription: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.DESCRIPTION',
                dialogRejectButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.REJECT',
                dialogConfirmButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.CONFIRM',
                permissionDialogRef: this.dialogRef,
            },
        });
    }
    close(isEdited) {
        if (!isEdited) {
            return this.dialogRef.close();
        }
        const closeDialogRef = this.dialog.open(ClosePermissionDialogComponent, {
            width: DialogConfig.small.width,
            data: {
                dialogTitle: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.TITLE',
                dialogDescription: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.DESCRIPTION',
                dialogRejectButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.REJECT',
                dialogConfirmButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.CONFIRM',
            },
        });
        closeDialogRef.afterClosed().subscribe((result) => {
            this.dialogRef.close();
            if (result.save) {
                this.container.savePermissions();
            }
        });
    }
    restore() {
        const restoreDialogRef = this.dialog.open(RestorePermissionDialogComponent, {
            width: DialogConfig.small.width,
        });
        restoreDialogRef.afterClosed().subscribe((result) => {
            if (result && result.restore) {
                this.container.restorePermissions(result.option);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsManagementDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$1.MatDialog }, { token: i1$1.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionsManagementDialogComponent, isStandalone: true, selector: "hxp-permissions-management-dialog", providers: [PermissionsManagementStateService], viewQueries: [{ propertyName: "container", first: true, predicate: PermissionManagementContainerComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div class=\"hxp-permissions-management-dialog-container\">\n    <div class=\"hxp-permission-container\">\n        <div mat-dialog-content>\n            <hxp-permission-management-container\n                [document]=\"document\"\n                [parentDocument] = \"parentDocument\"\n                (cancelEvent)=\"cancel($event)\"\n                (closeEvent)=\"close($event)\"\n                (restoreEvent)=\"restore()\" />\n        </div>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-dialog-container .hxp-permission-dialog-cross{font-size:30px;background:transparent}.hxp-permissions-management-dialog-container .mat-divider{margin:32px -24px 24px -14px}.hxp-permissions-management-dialog-container .mat-mdc-icon-button .mat-mdc-button-persistent-ripple:before{background-color:#fff}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: PermissionManagementContainerComponent, selector: "hxp-permission-management-container", inputs: ["document", "parentDocument"], outputs: ["cancelEvent", "closeEvent", "restoreEvent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsManagementDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-management-dialog', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, imports: [MatDialogModule, TranslatePipe, PermissionManagementContainerComponent], providers: [PermissionsManagementStateService], template: "<div class=\"hxp-permissions-management-dialog-container\">\n    <div class=\"hxp-permission-container\">\n        <div mat-dialog-content>\n            <hxp-permission-management-container\n                [document]=\"document\"\n                [parentDocument] = \"parentDocument\"\n                (cancelEvent)=\"cancel($event)\"\n                (closeEvent)=\"close($event)\"\n                (restoreEvent)=\"restore()\" />\n        </div>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-dialog-container .hxp-permission-dialog-cross{font-size:30px;background:transparent}.hxp-permissions-management-dialog-container .mat-divider{margin:32px -24px 24px -14px}.hxp-permissions-management-dialog-container .mat-mdc-icon-button .mat-mdc-button-persistent-ripple:before{background-color:#fff}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$1.MatDialog }, { type: i1$1.MatDialogRef }], propDecorators: { container: [{
                type: ViewChild,
                args: [PermissionManagementContainerComponent]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsButtonActionService extends DocumentActionService {
    constructor(dialog, permissionsPanelRequestService, componentType = 'dialog') {
        super();
        this.dialog = dialog;
        this.permissionsPanelRequestService = permissionsPanelRequestService;
        this.componentType = componentType;
    }
    isAvailable(context) {
        return (context.documents?.length > 0 &&
            hasPermission(context.documents[0], DocumentPermissions.WRITE) &&
            hasPermission(context.documents[0], DocumentPermissions.MANAGE_SECURITY) &&
            !isVersion(context.documents[0]));
    }
    execute(context) {
        if (context.documents?.length > 0 && context.parentDocument) {
            const isDialog = this.componentType === 'dialog';
            if (isDialog) {
                this.openPermissionsManagementDialog({
                    document: context.documents[0],
                    parentDocument: context.parentDocument,
                });
            }
            else {
                this.permissionsPanelRequestService.requestOpenPanel();
            }
        }
    }
    openPermissionsManagementDialog(permissionsManagementDialogData) {
        this.dialog.open(PermissionsManagementDialogComponent, {
            width: DIALOG_MIN_WIDTH + 'px',
            height: '100vh',
            position: { top: '0px', right: '0px' },
            data: permissionsManagementDialogData,
            disableClose: true,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsButtonActionService, deps: [{ token: i1$1.MatDialog }, { token: i1.PermissionsPanelRequestService }, { token: PERMISSIONS_MANAGEMENT_COMPONENT_TYPE, optional: true }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsButtonActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.MatDialog }, { type: i1.PermissionsPanelRequestService }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [PERMISSIONS_MANAGEMENT_COMPONENT_TYPE]
                }] }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentPropertyViewerActionService extends DocumentActionService {
    constructor() {
        super();
        this.showPropertyPanelSubject = new BehaviorSubject(false);
        this.showPropertyPanel$ = this.showPropertyPanelSubject.asObservable();
    }
    isAvailable(context) {
        return context.documents?.length === 1 && hasPermission(context.documents[0], DocumentPermissions.READ);
    }
    execute(context) {
        this.showPropertyPanelSubject.next(context?.showPanel === 'property');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentPropertyViewerActionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentPropertyViewerActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentPropertyViewerActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionDeleteConfirmationDialogComponent {
    constructor(dialogData, dialogRef, documentVersionsService, documentService, hxpNotificationService, documentRouterService) {
        this.dialogData = dialogData;
        this.dialogRef = dialogRef;
        this.documentVersionsService = documentVersionsService;
        this.documentService = documentService;
        this.hxpNotificationService = hxpNotificationService;
        this.documentRouterService = documentRouterService;
        this.isDeleting = false;
        this.version = this.dialogData.version;
        this.parentId = this.dialogData.parentId;
    }
    onDelete() {
        this.isDeleting = true;
        let success = false;
        this.documentVersionsService.deleteVersion(this.version).subscribe({
            next: () => {
                this.hxpNotificationService.showSuccess('MANAGE_VERSIONS.DELETE_DIALOG.NOTIFICATION.SUCCESS');
                success = true;
            },
            error: (error) => {
                console.error(error);
                this.hxpNotificationService.showError('MANAGE_VERSIONS.DELETE_DIALOG.NOTIFICATION.ERROR');
                this.isDeleting = false;
            },
            complete: () => {
                this.isDeleting = false;
                this.dialogRef.close();
                if (success) {
                    this.documentService.documentLoaded$
                        .pipe(take(1), switchMap$1((document) => document?.sys_id === this.version.sys_id ? this.documentService.getDocumentById(this.parentId).pipe(take(1)) : EMPTY), map$1((parentDocument) => parentDocument))
                        .subscribe((parentDocument) => {
                        if (parentDocument) {
                            this.documentRouterService.navigateTo(parentDocument);
                        }
                    });
                }
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteConfirmationDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$1.MatDialogRef }, { token: i1.DocumentVersionsService }, { token: i1.DocumentService }, { token: i1.HxpNotificationService }, { token: i1.DocumentRouterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.9", type: VersionDeleteConfirmationDialogComponent, isStandalone: true, selector: "hxp-version-delete-confirmation-dialog", ngImport: i0, template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.TITLE' | translate }}</h1>\n        <button mat-dialog-close class=\"hxp-dialog-fixed-size-wrapper-close-btn\" aria-label=\"{{ 'MANAGE_VERSIONS.DELETE_DIALOG.CLOSE_ARIA_LABEL' | translate }}\">\n            <mat-icon>close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <p>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.DESCRIPTION' | translate }}</p>\n    </div>\n    <mat-dialog-actions [align]=\"'end'\">\n        <button mat-button mat-dialog-close class=\"hxp-delete-dialog-close-button\">\n            {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.CANCEL' | translate }}\n        </button>\n        <button mat-flat-button color=\"warn\" class=\"hxp-primary-warn-button\" [ngClass]=\"{'hxp-disable-btn': isDeleting}\" (click)=\"onDelete()\">\n            <span class=\"hxp-primary-warn-button-label\">\n                @if(isDeleting) {\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"15\" />\n                }\n                    {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.DELETE' | translate }}\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-dialog-fixed-size-wrapper .dialog-title{display:flex;justify-content:space-between;align-items:baseline}.hxp-dialog-fixed-size-wrapper .dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper .hxp-delete-dialog-close-button{color:var(--theme-primary-color, #5654ac);border:0}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button.hxp-disable-btn{pointer-events:none;opacity:.6}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button ::ng-deep .mat-mdc-progress-spinner{margin-right:10px}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button ::ng-deep .mat-mdc-progress-spinner circle{stroke:var(--theme-accent-color-default-contrast, white)}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .hxp-primary-warn-button-label{display:flex;align-items:center}.hxp-dialog-fixed-size-wrapper .hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i4.TranslatePipe, name: "translate" }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteConfirmationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-delete-confirmation-dialog', standalone: true, imports: [MatDialogModule, MatIconModule, MatButtonModule, MatProgressSpinnerModule, TranslateModule, NgClass], template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.TITLE' | translate }}</h1>\n        <button mat-dialog-close class=\"hxp-dialog-fixed-size-wrapper-close-btn\" aria-label=\"{{ 'MANAGE_VERSIONS.DELETE_DIALOG.CLOSE_ARIA_LABEL' | translate }}\">\n            <mat-icon>close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <p>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.DESCRIPTION' | translate }}</p>\n    </div>\n    <mat-dialog-actions [align]=\"'end'\">\n        <button mat-button mat-dialog-close class=\"hxp-delete-dialog-close-button\">\n            {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.CANCEL' | translate }}\n        </button>\n        <button mat-flat-button color=\"warn\" class=\"hxp-primary-warn-button\" [ngClass]=\"{'hxp-disable-btn': isDeleting}\" (click)=\"onDelete()\">\n            <span class=\"hxp-primary-warn-button-label\">\n                @if(isDeleting) {\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"15\" />\n                }\n                    {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.DELETE' | translate }}\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-dialog-fixed-size-wrapper .dialog-title{display:flex;justify-content:space-between;align-items:baseline}.hxp-dialog-fixed-size-wrapper .dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper .hxp-delete-dialog-close-button{color:var(--theme-primary-color, #5654ac);border:0}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button.hxp-disable-btn{pointer-events:none;opacity:.6}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button ::ng-deep .mat-mdc-progress-spinner{margin-right:10px}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button ::ng-deep .mat-mdc-progress-spinner circle{stroke:var(--theme-accent-color-default-contrast, white)}.hxp-dialog-fixed-size-wrapper .hxp-primary-warn-button .hxp-primary-warn-button-label{display:flex;align-items:center}.hxp-dialog-fixed-size-wrapper .hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$1.MatDialogRef }, { type: i1.DocumentVersionsService }, { type: i1.DocumentService }, { type: i1.HxpNotificationService }, { type: i1.DocumentRouterService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionDeleteButtonActionService extends DocumentActionService {
    constructor(dialog) {
        super();
        this.dialog = dialog;
    }
    isAvailable(context) {
        return (!!context.documents &&
            context.documents.length === 1 &&
            isVersion(context.documents[0]) &&
            hasPermission(context.documents[0], DocumentPermissions.DELETE) &&
            !!context.parentDocument &&
            hasPermission(context.parentDocument, DocumentPermissions.DELETE_CHILD));
    }
    execute(context) {
        const document = context.documents[0];
        this.dialog.open(VersionDeleteConfirmationDialogComponent, {
            data: {
                version: document,
                shouldRedirect: context.shouldRedirect || false,
                parentId: document.sys_parentId || '',
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteButtonActionService, deps: [{ token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteButtonActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.MatDialog }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionEditDialogComponent {
    constructor(version, fb, datePipe, hxpNotificationService, dialogRef, documentVersionService) {
        this.version = version;
        this.fb = fb;
        this.datePipe = datePipe;
        this.hxpNotificationService = hxpNotificationService;
        this.dialogRef = dialogRef;
        this.documentVersionService = documentVersionService;
        this.isUpdating = false;
        this.dateFormat = 'medium';
    }
    ngOnInit() {
        this.form = this.fb.group({
            sysver_title: [
                this.version?.sysver_title ||
                    this.datePipe.transform(this.version.sys_modified, this.dateFormat) ||
                    this.datePipe.transform(this.version.sysver_created, this.dateFormat) ||
                    '',
                Validators.required,
            ],
            sysver_description: [this.version?.sysver_description || ''],
        });
    }
    onSave() {
        if (this.form.invalid) {
            return;
        }
        this.isUpdating = true;
        const updatedVersion = {
            sys_id: this.version.sys_id,
            sysver_title: this.form.get('sysver_title')?.value,
            sysver_description: this.form.get('sysver_description')?.value,
        };
        this.documentVersionService.updateVersion(updatedVersion).subscribe({
            next: () => {
                this.hxpNotificationService.showSuccess('MANAGE_VERSIONS.EDIT_DIALOG.NOTIFICATION.SUCCESS');
            },
            error: (error) => {
                console.error(error);
                this.hxpNotificationService.showError('MANAGE_VERSIONS.EDIT_DIALOG.NOTIFICATION.ERROR');
                this.isUpdating = false;
            },
            complete: () => {
                this.isUpdating = false;
                this.dialogRef.close();
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionEditDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$2.FormBuilder }, { token: i2$2.DatePipe }, { token: i1.HxpNotificationService }, { token: i1$1.MatDialogRef }, { token: i1.DocumentVersionsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.9", type: VersionEditDialogComponent, isStandalone: true, selector: "hxp-version-edit-dialog", ngImport: i0, template: "<div class=\"hxp-version-edit-dialog\">\n    <h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.TITLE' | translate }}</h1>\n    <mat-dialog-content>\n        <form [formGroup]=\"form\" class=\"hxp-version-edit-dialog-form\">\n            <div class=\"hxp-version-edit-dialog-input-area\">\n                <div class=\"hxp-version-edit-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.FIELD_TITLE' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\">\n                        <input matInput formControlName=\"sysver_title\" (keydown)=\"$event.stopPropagation()\" />\n                    </mat-form-field>\n                </div>\n            </div>\n            <div class=\"hxp-version-edit-dialog-input-area\">\n                <div class=\"hxp-version-edit-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.DESCRIPTION' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\" hideRequiredMarker>\n                        <textarea\n                            matInput\n                            formControlName=\"sysver_description\"\n                            placeholder=\"{{ 'MANAGE_VERSIONS.EDIT_DIALOG.PLACEHOLDER_DESCRIPTION' | translate }}\"\n                            (keydown)=\"$event.stopPropagation()\"\n                        >\n                        </textarea>\n                    </mat-form-field>\n                </div>\n            </div>\n        </form>\n    </mat-dialog-content>\n    <mat-dialog-actions [align]=\"'end'\" class=\"hxp-version-edit-dialog-footer-action\">\n        <button mat-button mat-dialog-close>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-button class=\"hxp-primary-button\" [disabled]=\"form.invalid || isUpdating\" [ngClass]=\"{'hxp-loading': isUpdating}\" (click)=\"onSave()\">\n            <span class=\"hxp-version-edit-dialog-save-btn-label\">\n                @if (isUpdating) {\n                    <mat-progress-spinner mode=\"indeterminate\" diameter=\"15\" />\n                }\n                <span class=\"hxp-version-edit-dialog-save-btn-title\">\n                    {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.SAVE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-version-edit-dialog .hxp-version-edit-dialog-form{margin-top:24px}.hxp-version-edit-dialog .hxp-version-edit-dialog-footer-action .hxp-version-edit-dialog-save-btn-label{display:flex;justify-content:space-between;align-items:center}.hxp-version-edit-dialog .hxp-version-edit-dialog-footer-action button.hxp-loading span.hxp-version-edit-dialog-save-btn-title{margin-left:12px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area{display:flex;flex-direction:column;margin-bottom:24px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-version-edit-dialog-input-title{margin-bottom:12px;color:#111827}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area{border:1px solid #6b7280;border-radius:8px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area:focus-within{border-color:#0a60ce}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field{width:100%}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field input,.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{color:#111827}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{resize:none;min-height:48px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area ::ng-deep .mat-mdc-form-field-subscript-wrapper,.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area ::ng-deep .mdc-line-ripple{display:none}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i4.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionEditDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-edit-dialog', standalone: true, imports: [
                        NgClass,
                        MatDialogModule,
                        MatIconModule,
                        MatButtonModule,
                        ReactiveFormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatProgressSpinner,
                        TranslateModule,
                    ], template: "<div class=\"hxp-version-edit-dialog\">\n    <h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.TITLE' | translate }}</h1>\n    <mat-dialog-content>\n        <form [formGroup]=\"form\" class=\"hxp-version-edit-dialog-form\">\n            <div class=\"hxp-version-edit-dialog-input-area\">\n                <div class=\"hxp-version-edit-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.FIELD_TITLE' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\">\n                        <input matInput formControlName=\"sysver_title\" (keydown)=\"$event.stopPropagation()\" />\n                    </mat-form-field>\n                </div>\n            </div>\n            <div class=\"hxp-version-edit-dialog-input-area\">\n                <div class=\"hxp-version-edit-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.DESCRIPTION' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\" hideRequiredMarker>\n                        <textarea\n                            matInput\n                            formControlName=\"sysver_description\"\n                            placeholder=\"{{ 'MANAGE_VERSIONS.EDIT_DIALOG.PLACEHOLDER_DESCRIPTION' | translate }}\"\n                            (keydown)=\"$event.stopPropagation()\"\n                        >\n                        </textarea>\n                    </mat-form-field>\n                </div>\n            </div>\n        </form>\n    </mat-dialog-content>\n    <mat-dialog-actions [align]=\"'end'\" class=\"hxp-version-edit-dialog-footer-action\">\n        <button mat-button mat-dialog-close>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-button class=\"hxp-primary-button\" [disabled]=\"form.invalid || isUpdating\" [ngClass]=\"{'hxp-loading': isUpdating}\" (click)=\"onSave()\">\n            <span class=\"hxp-version-edit-dialog-save-btn-label\">\n                @if (isUpdating) {\n                    <mat-progress-spinner mode=\"indeterminate\" diameter=\"15\" />\n                }\n                <span class=\"hxp-version-edit-dialog-save-btn-title\">\n                    {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.SAVE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-version-edit-dialog .hxp-version-edit-dialog-form{margin-top:24px}.hxp-version-edit-dialog .hxp-version-edit-dialog-footer-action .hxp-version-edit-dialog-save-btn-label{display:flex;justify-content:space-between;align-items:center}.hxp-version-edit-dialog .hxp-version-edit-dialog-footer-action button.hxp-loading span.hxp-version-edit-dialog-save-btn-title{margin-left:12px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area{display:flex;flex-direction:column;margin-bottom:24px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-version-edit-dialog-input-title{margin-bottom:12px;color:#111827}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area{border:1px solid #6b7280;border-radius:8px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area:focus-within{border-color:#0a60ce}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field{width:100%}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field input,.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{color:#111827}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{resize:none;min-height:48px}.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area ::ng-deep .mat-mdc-form-field-subscript-wrapper,.hxp-version-edit-dialog .hxp-version-edit-dialog-input-area ::ng-deep .mdc-line-ripple{display:none}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$2.FormBuilder }, { type: i2$2.DatePipe }, { type: i1.HxpNotificationService }, { type: i1$1.MatDialogRef }, { type: i1.DocumentVersionsService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionEditButtonActionService extends DocumentActionService {
    constructor(dialog) {
        super();
        this.dialog = dialog;
    }
    isAvailable(context) {
        return (!!context.documents &&
            context.documents.length === 1 &&
            hasPermission(context.documents[0], DocumentPermissions.WRITE) &&
            hasPermission(context.documents[0], DocumentPermissions.WRITE_VERSION) &&
            isVersion(context.documents[0]));
    }
    execute(context) {
        const document = context.documents[0];
        this.dialog.open(VersionEditDialogComponent, {
            width: DialogConfig.small.width,
            data: document,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionEditButtonActionService, deps: [{ token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionEditButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionEditButtonActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.MatDialog }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionRestoreActionService extends DocumentActionService {
    constructor(hxpNotificationService, documentService) {
        super();
        this.hxpNotificationService = hxpNotificationService;
        this.documentService = documentService;
    }
    isAvailable(context) {
        return (!!context.documents &&
            isVersion(context.documents[0]) &&
            hasPermission(context.documents[0], DocumentPermissions.READ) &&
            !!context.parentDocument &&
            hasPermission(context.parentDocument, DocumentPermissions.WRITE));
    }
    execute(context) {
        const document = context.documents[0];
        if (!document?.sys_id) {
            this.hxpNotificationService.showError('DOCUMENT_VERSION.SNACKBAR.RESTORE_ERROR');
            return;
        }
        from(this.documentService.restoreVersion(document.sys_id)).subscribe({
            next: () => {
                this.documentService.requestReload();
                this.hxpNotificationService.showSuccess('DOCUMENT_VERSION.SNACKBAR.RESTORE_SUCCESS');
            },
            error: () => this.hxpNotificationService.showError('DOCUMENT_VERSION.SNACKBAR.RESTORE_ERROR'),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionRestoreActionService, deps: [{ token: i1.HxpNotificationService }, { token: i1.DocumentService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionRestoreActionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionRestoreActionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.HxpNotificationService }, { type: i1.DocumentService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageColumnDialogComponent {
    constructor(manageColumnDialogData, dialogRef, columnConfigService, identityUserService) {
        this.manageColumnDialogData = manageColumnDialogData;
        this.dialogRef = dialogRef;
        this.columnConfigService = columnConfigService;
        this.identityUserService = identityUserService;
        this.availableColumns = [];
        this.selectedColumns = [];
        this.canReset = false;
        this.canUpdate = false;
        this.canAdd = false;
        this.searchTerm = '';
        this.initialDefaultColumns = [];
        this.initialSelectedColumns = [];
        this.initialCustomColumns = [];
        this.allColumns = [];
        this.searchTerms = new Subject();
        this.destroyRef = inject(DestroyRef);
        this.identityUser$ = of(this.identityUserService.getCurrentUserInfo());
        this.columnConfigService
            .getCustomColumns()
            .pipe(takeUntilDestroyed())
            .subscribe((customColumns) => {
            this.initialCustomColumns = customColumns;
        });
    }
    ngOnInit() {
        this.identityUser$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((userInfo) => {
            this.userInfo = userInfo;
            this.initializeColumns();
        });
        this.searchTerms.pipe(debounceTime(300), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
            this.applySearch();
        });
    }
    selectColumn(column) {
        this.selectedColumns.push(column);
        this.availableColumns = this.availableColumns.filter((c) => c.key !== column.key);
        this.checkForChanges();
    }
    deselectColumn(column) {
        this.availableColumns.push(column);
        this.selectedColumns = this.selectedColumns.filter((c) => c.key !== column.key);
        this.checkForChanges();
    }
    totalSelectableColumns() {
        return this.initialDefaultColumns.length;
    }
    onSearchChange() {
        this.searchTerms.next(this.searchTerm);
    }
    applyChanges() {
        this.columnConfigService.setCurrentSelectedColumnsForCurrentUser(this.userInfo, this.selectedColumns);
        this.closeDialog();
    }
    clearSearch() {
        this.searchTerm = '';
        this.onSearchChange();
    }
    drop(event) {
        moveItemInArray(this.selectedColumns, event.previousIndex, event.currentIndex);
        this.checkForChanges();
    }
    resetToDefault() {
        this.selectedColumns = this.initialDefaultColumns;
        this.availableColumns = [...this.initialCustomColumns];
        this.searchTerm = '';
        this.checkForChanges();
    }
    hasSelectionChanged() {
        return JSON.stringify(this.selectedColumns) !== JSON.stringify(this.initialSelectedColumns);
    }
    hasDefaultChanged() {
        return JSON.stringify(this.selectedColumns) !== JSON.stringify(this.initialDefaultColumns);
    }
    addColumnEnabled() {
        return this.selectedColumns.length !== this.totalSelectableColumns();
    }
    initializeColumns() {
        this.selectedColumns = this.columnConfigService.getSelectedColumnsForCurrentUser(this.userInfo);
        this.initialDefaultColumns = this.columnConfigService.getDefaultColumns();
        this.allColumns = [...this.initialDefaultColumns, ...this.initialCustomColumns];
        this.availableColumns = this.allColumns.filter((column) => !this.selectedColumns.some((selected) => selected.key === column.key));
        this.initialSelectedColumns = [...this.selectedColumns];
        this.checkForChanges();
    }
    applySearch() {
        if (this.searchTerm) {
            const searchLower = this.searchTerm.toLowerCase();
            this.availableColumns = this.allColumns.filter((column) => column.title.toLowerCase().includes(searchLower) && !this.selectedColumns.some((selected) => selected.key === column.key));
        }
        else {
            this.availableColumns = this.allColumns.filter((column) => !this.selectedColumns.some((selected) => selected.key === column.key));
        }
    }
    checkForChanges() {
        this.canReset = this.hasDefaultChanged();
        this.canUpdate = this.hasSelectionChanged();
        this.canAdd = this.addColumnEnabled();
    }
    closeDialog() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$1.MatDialogRef }, { token: i1.ColumnConfigService }, { token: IDENTITY_USER_SERVICE_TOKEN }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ManageColumnDialogComponent, isStandalone: true, selector: "hxp-manage-column-dialog", ngImport: i0, template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.TITLE' | translate }}</h1>\n        <button class=\"hxp-dialog-fixed-size-wrapper-close-btn\" [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.CLOSE' | translate\" mat-dialog-close>\n            <mat-icon aria-hidden=\"true\">close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <div class=\"hxp-manage-columns-container\">\n            <div class=\"hxp-manage-columns-available-columns\">\n              <p>\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE_COLUMN' | translate }}\n                ({{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE' | translate:{count: availableColumns.length} }})\n              </p>\n              <div class=\"hxp-manage-columns-box-list\">\n                <div class=\"hxp-manage-columns-search-container\">\n                    <mat-form-field appearance=\"outline\">\n                        <textarea\n                            matInput\n                            [(ngModel)]=\"searchTerm\"\n                            (keyup)=\"onSearchChange()\"\n                            cdkTextareaAutosize\n                            cdkAutosizeMinRows=\"1\"\n                            cdkAutosizeMaxRows=\"3\"\n                            placeholder=\"{{ 'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.PLACEHOLDER' | translate }}\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.ARIA_LABEL' | translate\"\n                        ></textarea>\n                        <button mat-icon-button\n                            *ngIf=\"searchTerm\"\n                            (click)=\"clearSearch()\"\n                            class=\"hxp-manage-columns-search-clear\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.CLEAR.ARIA_LABEL' | translate\">\n                                <mat-icon aria-hidden=\"true\">close</mat-icon>\n                        </button>\n                        <button mat-icon-button matSuffix class=\"hxp-manage-columns-search-button\" [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.BUTTON.ARIA_LABEL' | translate\">\n                            <mat-icon aria-hidden=\"true\">search</mat-icon>\n                        </button>\n                    </mat-form-field>\n                </div>\n                <div class=\"hxp-manage-columns-column-item\" *ngFor=\"let column of availableColumns\">\n                    <div>{{ column.title | translate }}</div>\n                    <button mat-icon-button\n                        [disabled]=\"!canAdd\"\n                        (click)=\"selectColumn(column)\"\n                        [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.ADD_COLUMN' | translate\">\n                            <mat-icon aria-hidden=\"true\">add_circle_outline</mat-icon>\n                    </button>\n                </div>\n              </div>\n            </div>\n            <div class=\"hxp-manage-columns-selected-columns\">\n                <p>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.SELECTED_COLUMN' | translate:{count: selectedColumns.length} }}\n                    <span>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.COLUMN_COUNT' | translate:{selected: selectedColumns.length, total: totalSelectableColumns()} }}</span>\n                </p>\n                <div class=\"hxp-manage-columns-box-list hxp-manage-columns-drag-columns\" cdkDropList (cdkDropListDropped)=\"drop($event)\">\n                    <div class=\"hxp-manage-columns-column-item\" *ngFor=\"let column of selectedColumns\" cdkDrag>\n                        <div>\n                            <button mat-icon-button\n                                cdkDragHandle\n                                class=\"hxp-manage-columns-drag-handel\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.DRAG_COLUMN' | translate\">\n                                    <mat-icon aria-hidden=\"true\">drag_indicator</mat-icon>\n                            </button>\n                            {{ column.title | translate }}\n                        </div>\n                        <button mat-icon-button\n                            *ngIf=\"column.removable\"\n                            (click)=\"deselectColumn(column)\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.REMOVE_COLUMN' | translate\">\n                                <mat-icon aria-hidden=\"true\">remove_circle_outline</mat-icon>\n                        </button>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div mat-dialog-actions class=\"hxp-manage-column-dialog-action\">\n        <button mat-button class=\"hxp-manage-column-reset-button\" [disabled]=\"!canReset\" (click)=\"resetToDefault()\">\n            {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.RESET' | translate }}\n        </button>\n        <div>\n            <button mat-button class=\"hxp-manage-column-close-button\" mat-dialog-close>\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.CANCEL' | translate }}\n            </button>\n            <button mat-button class=\"hxp-update-table-btn hxp-primary-button\" [disabled]=\"!canUpdate\" (click)=\"applyChanges()\">\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.UPDATE_TABLE' | translate }}\n            </button>\n        </div>\n    </div>\n</div>\n", styles: [".dialog-title{display:flex;justify-content:space-between;align-items:center}.dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}.hxp-manage-column-dialog-action{display:flex;justify-content:space-between}.hxp-manage-columns-container{display:flex;justify-content:space-between;height:100%}.hxp-manage-columns-container .hxp-manage-columns-available-columns,.hxp-manage-columns-container .hxp-manage-columns-selected-columns{flex:1;display:flex;flex-direction:column}.hxp-manage-columns-container .hxp-manage-columns-available-columns{margin-right:10px}.hxp-manage-columns-container .hxp-manage-columns-box-list{border:1px solid lightgray;border-radius:5px;padding:12px;height:100%;overflow-y:auto;overflow-x:hidden}.hxp-manage-columns-container .hxp-manage-columns-box-list .mat-mdc-icon-button{height:auto;width:auto;line-height:0}.hxp-manage-columns-container .hxp-manage-columns-box-list .mat-mdc-icon-button:not(.hxp-manage-columns-search-button){padding:0}.hxp-manage-columns-container .hxp-manage-columns-search-container .hxp-manage-columns-search-clear{right:5px}.hxp-manage-columns-container .hxp-manage-columns-search-container .mat-mdc-form-field{width:100%}.hxp-manage-columns-container .hxp-manage-columns-column-item{display:flex;justify-content:space-between;padding:5px 0;align-items:center}.hxp-manage-columns-container .hxp-manage-columns-column-item div{display:flex;text-overflow:ellipsis;word-break:break-all;overflow:hidden;padding-right:10px}.hxp-manage-columns-container .hxp-manage-columns-drag-columns .hxp-manage-columns-drag-handel{cursor:move}::ng-deep .hxp-manage-columns-search-container .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{border-right:1px solid rgba(0,0,0,.12);display:flex;justify-content:space-between;border-top:0;min-height:auto;padding:12px 0}::ng-deep .hxp-manage-columns-search-container .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix .mat-mdc-input-element{overflow:hidden}::ng-deep .hxp-manage-columns-search-container .mat-mdc-form-field-flex .hxp-manage-columns-search-button{padding:0 5px}::ng-deep .hxp-manage-columns-search-container .mat-mdc-form-field-flex .hxp-manage-columns-search-button:hover>span:before{display:none}::ng-deep .hxp-manage-columns-search-container .mat-mdc-form-field-text-suffix{left:5px;top:7px}::ng-deep .hxp-manage-columns-column-item.cdk-drag-preview{display:flex;justify-content:space-between}::ng-deep .hxp-manage-columns-column-item.cdk-drag-preview .hxp-manage-columns-drag-handel .mat-ripple-element{left:2px!important;top:4px!important}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i7$2.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i9.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i9.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i9.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'hxp-manage-column-dialog', imports: [
                        NgIf,
                        NgFor,
                        MatDialogModule,
                        MatIconModule,
                        MatButtonModule,
                        MatFormFieldModule,
                        MatTooltipModule,
                        MatInputModule,
                        FormsModule,
                        DragDropModule,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <div mat-dialog-title class=\"dialog-title\">\n        <h1 mat-dialog-title>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.TITLE' | translate }}</h1>\n        <button class=\"hxp-dialog-fixed-size-wrapper-close-btn\" [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.CLOSE' | translate\" mat-dialog-close>\n            <mat-icon aria-hidden=\"true\">close</mat-icon>\n        </button>\n    </div>\n    <div mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n        <div class=\"hxp-manage-columns-container\">\n            <div class=\"hxp-manage-columns-available-columns\">\n              <p>\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE_COLUMN' | translate }}\n                ({{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE' | translate:{count: availableColumns.length} }})\n              </p>\n              <div class=\"hxp-manage-columns-box-list\">\n                <div class=\"hxp-manage-columns-search-container\">\n                    <mat-form-field appearance=\"outline\">\n                        <textarea\n                            matInput\n                            [(ngModel)]=\"searchTerm\"\n                            (keyup)=\"onSearchChange()\"\n                            cdkTextareaAutosize\n                            cdkAutosizeMinRows=\"1\"\n                            cdkAutosizeMaxRows=\"3\"\n                            placeholder=\"{{ 'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.PLACEHOLDER' | translate }}\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.ARIA_LABEL' | translate\"\n                        ></textarea>\n                        <button mat-icon-button\n                            *ngIf=\"searchTerm\"\n                            (click)=\"clearSearch()\"\n                            class=\"hxp-manage-columns-search-clear\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.CLEAR.ARIA_LABEL' | translate\">\n                                <mat-icon aria-hidden=\"true\">close</mat-icon>\n                        </button>\n                        <button mat-icon-button matSuffix class=\"hxp-manage-columns-search-button\" [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.BUTTON.ARIA_LABEL' | translate\">\n                            <mat-icon aria-hidden=\"true\">search</mat-icon>\n                        </button>\n                    </mat-form-field>\n                </div>\n                <div class=\"hxp-manage-columns-column-item\" *ngFor=\"let column of availableColumns\">\n                    <div>{{ column.title | translate }}</div>\n                    <button mat-icon-button\n                        [disabled]=\"!canAdd\"\n                        (click)=\"selectColumn(column)\"\n                        [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.ADD_COLUMN' | translate\">\n                            <mat-icon aria-hidden=\"true\">add_circle_outline</mat-icon>\n                    </button>\n                </div>\n              </div>\n            </div>\n            <div class=\"hxp-manage-columns-selected-columns\">\n                <p>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.SELECTED_COLUMN' | translate:{count: selectedColumns.length} }}\n                    <span>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.COLUMN_COUNT' | translate:{selected: selectedColumns.length, total: totalSelectableColumns()} }}</span>\n                </p>\n                <div class=\"hxp-manage-columns-box-list hxp-manage-columns-drag-columns\" cdkDropList (cdkDropListDropped)=\"drop($event)\">\n                    <div class=\"hxp-manage-columns-column-item\" *ngFor=\"let column of selectedColumns\" cdkDrag>\n                        <div>\n                            <button mat-icon-button\n                                cdkDragHandle\n                                class=\"hxp-manage-columns-drag-handel\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.DRAG_COLUMN' | translate\">\n                                    <mat-icon aria-hidden=\"true\">drag_indicator</mat-icon>\n                            </button>\n                            {{ column.title | translate }}\n                        </div>\n                        <button mat-icon-button\n                            *ngIf=\"column.removable\"\n                            (click)=\"deselectColumn(column)\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.REMOVE_COLUMN' | translate\">\n                                <mat-icon aria-hidden=\"true\">remove_circle_outline</mat-icon>\n                        </button>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div mat-dialog-actions class=\"hxp-manage-column-dialog-action\">\n        <button mat-button class=\"hxp-manage-column-reset-button\" [disabled]=\"!canReset\" (click)=\"resetToDefault()\">\n            {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.RESET' | translate }}\n        </button>\n        <div>\n            <button mat-button class=\"hxp-manage-column-close-button\" mat-dialog-close>\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.CANCEL' | translate }}\n            </button>\n            <button mat-button class=\"hxp-update-table-btn hxp-primary-button\" [disabled]=\"!canUpdate\" (click)=\"applyChanges()\">\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.UPDATE_TABLE' | translate }}\n            </button>\n        </div>\n    </div>\n</div>\n", styles: [".dialog-title{display:flex;justify-content:space-between;align-items:center}.dialog-title h1{flex:1;padding-left:0}.hxp-dialog-fixed-size-wrapper-close-btn{background-color:transparent;border:0;cursor:pointer;padding:0}.hxp-manage-column-dialog-action{display:flex;justify-content:space-between}.hxp-manage-columns-container{display:flex;justify-content:space-between;height:100%}.hxp-manage-columns-container .hxp-manage-columns-available-columns,.hxp-manage-columns-container .hxp-manage-columns-selected-columns{flex:1;display:flex;flex-direction:column}.hxp-manage-columns-container .hxp-manage-columns-available-columns{margin-right:10px}.hxp-manage-columns-container .hxp-manage-columns-box-list{border:1px solid lightgray;border-radius:5px;padding:12px;height:100%;overflow-y:auto;overflow-x:hidden}.hxp-manage-columns-container .hxp-manage-columns-box-list .mat-mdc-icon-button{height:auto;width:auto;line-height:0}.hxp-manage-columns-container .hxp-manage-columns-box-list .mat-mdc-icon-button:not(.hxp-manage-columns-search-button){padding:0}.hxp-manage-columns-container .hxp-manage-columns-search-container .hxp-manage-columns-search-clear{right:5px}.hxp-manage-columns-container .hxp-manage-columns-search-container .mat-mdc-form-field{width:100%}.hxp-manage-columns-container .hxp-manage-columns-column-item{display:flex;justify-content:space-between;padding:5px 0;align-items:center}.hxp-manage-columns-container .hxp-manage-columns-column-item div{display:flex;text-overflow:ellipsis;word-break:break-all;overflow:hidden;padding-right:10px}.hxp-manage-columns-container .hxp-manage-columns-drag-columns .hxp-manage-columns-drag-handel{cursor:move}::ng-deep .hxp-manage-columns-search-container .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{border-right:1px solid rgba(0,0,0,.12);display:flex;justify-content:space-between;border-top:0;min-height:auto;padding:12px 0}::ng-deep .hxp-manage-columns-search-container .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix .mat-mdc-input-element{overflow:hidden}::ng-deep .hxp-manage-columns-search-container .mat-mdc-form-field-flex .hxp-manage-columns-search-button{padding:0 5px}::ng-deep .hxp-manage-columns-search-container .mat-mdc-form-field-flex .hxp-manage-columns-search-button:hover>span:before{display:none}::ng-deep .hxp-manage-columns-search-container .mat-mdc-form-field-text-suffix{left:5px;top:7px}::ng-deep .hxp-manage-columns-column-item.cdk-drag-preview{display:flex;justify-content:space-between}::ng-deep .hxp-manage-columns-column-item.cdk-drag-preview .hxp-manage-columns-drag-handel .mat-ripple-element{left:2px!important;top:4px!important}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$1.MatDialogRef }, { type: i1.ColumnConfigService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [IDENTITY_USER_SERVICE_TOKEN]
                }] }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageColumnActionService extends DocumentActionService {
    constructor(dialog) {
        super();
        this.dialog = dialog;
    }
    isAvailable(context) {
        return /search/i.test(context.refererURL || '');
    }
    execute(context) {
        this.dialog.open(ManageColumnDialogComponent, {
            width: DialogConfig.medium.width,
            height: DialogConfig.medium.height,
            data: context,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnActionService, deps: [{ token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnActionService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.MatDialog }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const CONTEXT_MENU_ACTIONS_PROVIDERS = [
    {
        provide: HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE,
        useClass: PermissionsButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_DELETE_ACTION_SERVICE,
        useClass: DeleteButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE,
        useClass: SingleItemDownloadButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_SHARE_ACTION_SERVICE,
        useClass: ContentShareButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_INFO_ACTION_SERVICE,
        useClass: ContentPropertyViewerActionService,
    },
    {
        provide: HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE,
        useClass: VersionDeleteButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE,
        useClass: VersionEditButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE,
        useClass: VersionRestoreActionService,
    },
    {
        provide: HXP_MANAGE_COLUMN_ACTION_SERVICE,
        useClass: ManageColumnActionService,
    },
];

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document breadcrumb.
 * To use the `HxpDocumentListComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpDocumentListComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         HxpDocumentListComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-list [isLoading]="isLoading" [documents]="documents" [schema]="schema">
 * </hxp-document-list>
 */
class HxpDocumentListComponent {
    constructor() {
        /**
         * The list of documents to be displayed.
         * @type {Document[]}
         * @default []
         *
         */
        this.documents = [];
        /**
         * Indicates whether the document list is currently loading.
         * When set to `true`, a loading indicator may be displayed.
         * Defaults to `false`.
         * @type {boolean}
         * @default false
         */
        this.isLoading = false;
        /**
         * Indicates whether it is possible to select more than one document.
         * @type {boolean}
         * @default true
         */
        this.multiselect = true;
        /**
         * Indicates whether the context menu actions are enabled.
         * @type {boolean}
         * @default true
         */
        this.contextMenuActions = true;
        /**
         * Event emitter that notifies the list of selected documents whenever it changes.
         *
         * @event selectedDocuments
         */
        this.selectedDocuments = new EventEmitter();
        /**
         * Emit the Document associated with the clicked row, when the row is clicked.
         *
         * @event rowClicked
         */
        this.rowClicked = new EventEmitter();
        /**
         * Event emitter that notifies when sorting the Document List.
         * The emitted value is a string in the form of `<column name> <direction>`
         *
         * @event sortingClicked
         */
        this.sortingClicked = new EventEmitter();
        /**
         * Event emitter that notifies when columns are resized.
         * The event payload is an array of `DataColumn` objects with updated width.
         *
         * @event columnsResized
         */
        this.columnsResized = new EventEmitter();
        this.evaluatedSchema = [];
        this.documentCache = inject(DocumentCacheService);
        this.contextMenuActionsService = inject(ContextMenuActionsService);
    }
    /**
     * Property to access the underlying Alfresco `DataTableComponent` instance.
     * https://www.alfresco.com/abn/adf/docs/core/components/datatable.component/
     */
    get table() {
        return this.documentListElement;
    }
    ngOnChanges() {
        this.updateDocumentList();
    }
    /**
     * Resets the selection of the document list.
     */
    resetSelection() {
        if (this.documentListElement) {
            this.documentListElement.resetSelection();
            if (this.documents && this.documentListElement.data) {
                this.documentListElement.onSelectAllClick({
                    checked: false,
                });
            }
        }
        this.selectedDocuments.emit([]);
    }
    /**
     * Resets the sorting of the document list.
     */
    resetSorting() {
        if (this.documentListElement) {
            this.documentListElement.sorting = [];
        }
    }
    onShowContextMenu(event) {
        event.preventDefault();
        const allRows = this.documentListElement.data.getRows();
        this.documentListElement.onSelectAllClick({
            checked: false,
        });
        for (const row of allRows) {
            if (row.isContextMenuSource) {
                this.selectedDocuments.emit([row['obj']]);
                this.documentListElement.selectRow(row, true);
            }
        }
    }
    handleRowClicked(event) {
        this.rowClicked.emit(event.value['obj']);
    }
    handleSortingChanged(event) {
        const sortingEvent = event;
        if (!sortingEvent.detail) {
            return;
        }
        const { key, direction } = sortingEvent.detail;
        if (key && direction) {
            this.sortingClicked.emit([`${key} ${direction}`]);
        }
    }
    setSelectedRows(event) {
        const selectionEvent = event;
        if (Array.isArray(selectionEvent?.detail?.selection)) {
            const selection = selectionEvent.detail.selection.map((row) => row['obj']);
            this.selectedDocuments.emit(selection);
        }
    }
    onColumnsWidthChange(columns) {
        this.columnsResized.emit(columns);
    }
    onShowRowContextMenu(event) {
        if (!this.contextMenuActions) {
            return;
        }
        const assignActions = (doc) => {
            event.value.actions = this.getContextActions(event.value.row, doc);
        };
        if (this.parentDocument) {
            assignActions(this.parentDocument);
            return;
        }
        const parentId = event.value.row['obj'].sys_parentId;
        this.refreshCachedDocument(parentId)?.subscribe({
            next: (doc) => {
                assignActions(doc);
            },
            error: (error) => {
                console.error(error);
            },
        });
    }
    updateDocumentList() {
        if (!this.documents) {
            this.documents = [];
        }
        if (this.documents.length > 0) {
            if (Array.isArray(this.schema)) {
                this.evaluatedSchema = [...this.schema];
            }
            else {
                this.configureSchema();
            }
            this.fetchCommonParentDocument(this.documents);
        }
    }
    fetchCommonParentDocument(docs) {
        const parentIds = docs.map((doc) => doc.sys_parentId);
        if (parentIds[0] && parentIds.every((parentId) => parentId === parentIds[0])) {
            this.refreshCachedDocument(parentIds[0]).subscribe({
                next: (doc) => {
                    this.parentDocument = doc;
                },
                error: (error) => {
                    console.error(error);
                },
            });
        }
        else {
            this.parentDocument = undefined;
        }
    }
    refreshCachedDocument(sysId) {
        this.documentCache.invalidate(sysId);
        return this.documentCache.getDocument(sysId).pipe(catchError((error) => {
            /**
             * if there is an error here, we need to swallow it, otherwise the interface will hang.
             *
             * onShowRowContextMenu is called constantly which means that if we don't swallow it, we'd be
             * throwing an exception at every call.
             */
            console.error(error);
            return EMPTY;
        }), shareReplay(1));
    }
    configureSchema() {
        if (this.documentListElement) {
            const inputSchema = this.inputColumnList?.columns.toArray() || [];
            const projectedSchema = this.projectedColumnList?.columns.toArray() || [];
            this.evaluatedSchema = [...inputSchema, ...projectedSchema];
        }
    }
    getContextActions(rowData, parentDocument) {
        return this.contextMenuActionsService.getContextActions(rowData['obj'], parentDocument);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpDocumentListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: HxpDocumentListComponent, isStandalone: true, selector: "hxp-document-list", inputs: { documents: "documents", isLoading: "isLoading", multiselect: "multiselect", contextMenuActions: "contextMenuActions", inputColumnList: "inputColumnList", schema: "schema" }, outputs: { selectedDocuments: "selectedDocuments", rowClicked: "rowClicked", sortingClicked: "sortingClicked", columnsResized: "columnsResized" }, host: { listeners: { "contextmenu": "onShowContextMenu($event)" } }, providers: [
            provideTranslations('adf-enterprise-adf-hx-content-services-ui', 'assets/adf-enterprise-adf-hx-content-services-ui'),
            provideTranslations('process-services-cloud-extension-process-form', 'assets/process-services-cloud-extension-process-form'),
            provideTranslations('content-services-extension-content-browser-feature-shell', 'assets/content-services-extension-content-browser'),
            ...CONTEXT_MENU_ACTIONS_PROVIDERS,
        ], queries: [{ propertyName: "projectedColumnList", first: true, predicate: DataColumnListComponent, descendants: true }], viewQueries: [{ propertyName: "documentListElement", first: true, predicate: ["documentList"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-document-list-container\">\n    <ng-content />\n    <adf-datatable\n        #documentList\n        [loading]=\"isLoading\"\n        [isResizingEnabled]=\"true\"\n        [rows]=\"documents\"\n        [stickyHeader]=\"true\"\n        [multiselect]=\"multiselect\"\n        selectionMode=\"multiple\"\n        (rowClick)=\"handleRowClicked($event)\"\n        (sorting-changed)=\"handleSortingChanged($event)\"\n        (row-select)=\"setSelectedRows($event)\"\n        (row-unselect)=\"setSelectedRows($event)\"\n        [contextMenu]=\"contextMenuActions\"\n        (showRowContextMenu)=\"onShowRowContextMenu($event)\"\n        (columnsWidthChanged)=\"onColumnsWidthChange($event)\"\n        [columns]=\"evaluatedSchema\">\n        <data-columns/>\n        <no-content-template>\n            <ng-template>\n                <adf-empty-content icon=\"folder_open\" title=\"DOCUMENT_LIST.NO_CONTENT.TITLE\"\n                    subtitle=\"DOCUMENT_LIST.NO_CONTENT.SUBTITLE\" />\n            </ng-template>\n        </no-content-template>\n    </adf-datatable>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%}.hxp-document-list-container{flex:1;height:calc(100% - 65px)}.mat-mdc-paginator{display:flex;flex:1}::ng-deep .mat-mdc-paginator-outer-container,::ng-deep .mat-mdc-paginator-container,::ng-deep .mat-mdc-paginator-page-size{flex:1}::ng-deep .mat-mdc-tab-body-wrapper{height:100%}::ng-deep .adf-ellipsis-cell .adf-cell-value{display:block!important;min-height:auto!important;text-overflow:ellipsis;overflow:hidden}::ng-deep .adf-ellipsis-cell .adf-cell-value .adf-datatable-content-cell{position:relative!important}::ng-deep .adf-datatable-list .adf-datatable-cell--text{max-width:320px!important}::ng-deep .adf-datatable-checkbox label{display:none}\n"], dependencies: [{ kind: "component", type: DataColumnListComponent, selector: "data-columns" }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "directive", type: NoContentTemplateDirective, selector: "adf-no-content-template, no-content-template" }, { kind: "component", type: EmptyContentComponent, selector: "adf-empty-content", inputs: ["icon", "title", "subtitle"] }, { kind: "component", type: DataTableComponent, selector: "adf-datatable", inputs: ["data", "rows", "sorting", "columns", "selectionMode", "multiselect", "mainTableAction", "actions", "showMainDatatableActions", "showProvidedActions", "actionsPosition", "actionsVisibleOnHover", "fallbackThumbnail", "contextMenu", "rowStyle", "rowStyleClass", "showHeader", "stickyHeader", "loading", "noPermission", "rowMenuCacheEnabled", "resolverFn", "allowFiltering", "isResizingEnabled", "blurOnResize", "displayCheckboxesOnHover", "enableDragRows"], outputs: ["rowClick", "rowDblClick", "showRowContextMenu", "showRowActionsMenu", "executeRowAction", "columnOrderChanged", "columnsWidthChanged", "selectedItemsCountChanged", "dragDropped"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpDocumentListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-list', standalone: true, imports: [
                        DataColumnListComponent,
                        LoadingContentTemplateDirective,
                        MatProgressSpinnerModule,
                        NoContentTemplateDirective,
                        EmptyContentComponent,
                        DataTableComponent,
                    ], providers: [
                        provideTranslations('adf-enterprise-adf-hx-content-services-ui', 'assets/adf-enterprise-adf-hx-content-services-ui'),
                        provideTranslations('process-services-cloud-extension-process-form', 'assets/process-services-cloud-extension-process-form'),
                        provideTranslations('content-services-extension-content-browser-feature-shell', 'assets/content-services-extension-content-browser'),
                        ...CONTEXT_MENU_ACTIONS_PROVIDERS,
                    ], template: "<div class=\"hxp-document-list-container\">\n    <ng-content />\n    <adf-datatable\n        #documentList\n        [loading]=\"isLoading\"\n        [isResizingEnabled]=\"true\"\n        [rows]=\"documents\"\n        [stickyHeader]=\"true\"\n        [multiselect]=\"multiselect\"\n        selectionMode=\"multiple\"\n        (rowClick)=\"handleRowClicked($event)\"\n        (sorting-changed)=\"handleSortingChanged($event)\"\n        (row-select)=\"setSelectedRows($event)\"\n        (row-unselect)=\"setSelectedRows($event)\"\n        [contextMenu]=\"contextMenuActions\"\n        (showRowContextMenu)=\"onShowRowContextMenu($event)\"\n        (columnsWidthChanged)=\"onColumnsWidthChange($event)\"\n        [columns]=\"evaluatedSchema\">\n        <data-columns/>\n        <no-content-template>\n            <ng-template>\n                <adf-empty-content icon=\"folder_open\" title=\"DOCUMENT_LIST.NO_CONTENT.TITLE\"\n                    subtitle=\"DOCUMENT_LIST.NO_CONTENT.SUBTITLE\" />\n            </ng-template>\n        </no-content-template>\n    </adf-datatable>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%}.hxp-document-list-container{flex:1;height:calc(100% - 65px)}.mat-mdc-paginator{display:flex;flex:1}::ng-deep .mat-mdc-paginator-outer-container,::ng-deep .mat-mdc-paginator-container,::ng-deep .mat-mdc-paginator-page-size{flex:1}::ng-deep .mat-mdc-tab-body-wrapper{height:100%}::ng-deep .adf-ellipsis-cell .adf-cell-value{display:block!important;min-height:auto!important;text-overflow:ellipsis;overflow:hidden}::ng-deep .adf-ellipsis-cell .adf-cell-value .adf-datatable-content-cell{position:relative!important}::ng-deep .adf-datatable-list .adf-datatable-cell--text{max-width:320px!important}::ng-deep .adf-datatable-checkbox label{display:none}\n"] }]
        }], propDecorators: { documents: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], multiselect: [{
                type: Input
            }], contextMenuActions: [{
                type: Input
            }], inputColumnList: [{
                type: Input
            }], schema: [{
                type: Input
            }], selectedDocuments: [{
                type: Output
            }], rowClicked: [{
                type: Output
            }], sortingClicked: [{
                type: Output
            }], columnsResized: [{
                type: Output
            }], documentListElement: [{
                type: ViewChild,
                args: ['documentList']
            }], projectedColumnList: [{
                type: ContentChild,
                args: [DataColumnListComponent]
            }], onShowContextMenu: [{
                type: HostListener,
                args: ['contextmenu', ['$event']]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that display the content type icon of a given `Document`.
 *
 * To use the `ContentTypeIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { ContentTypeIconComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentTypeIconComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *   <hxp-document-type-icon [document]="document" [isExpanded]="isExpanded"></hxp-document-type-icon>
 */
class ContentTypeIconComponent {
    constructor() {
        /**
         * Toggles between expanded and collapsed for folder type documents only.
         * If the document is not a folder, this property is ignored.
         * @type {boolean}
         * @default false
         */
        this.isExpanded = false;
        this.documentIconType = DefaultIcon.UNKNOWN;
    }
    /**
     * The mime type of the `Document`.
     * @type {string}
     * @readonly
     */
    get mimeType() {
        return this.documentIconType;
    }
    ngOnChanges() {
        this.checkDocumentIconType();
    }
    checkDocumentIconType() {
        this.documentIconType = DefaultIcon.UNKNOWN;
        if (!this.document) {
            return;
        }
        if (isFolder(this.document)) {
            this.documentIconType = this.getFolderIcon(this.isExpanded);
        }
        else if (hasBlob(this.document)) {
            this.documentIconType = this.document['sysfile_blob'].mimeType;
        }
    }
    getFolderIcon(isExpanded) {
        return isExpanded ? DefaultIcon.OPEN_FOLDER : DefaultIcon.FOLDER;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentTypeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ContentTypeIconComponent, isStandalone: true, selector: "hxp-document-type-icon", inputs: { document: "document", isExpanded: "isExpanded" }, usesOnChanges: true, ngImport: i0, template: "<hxp-mime-type-icon [mimeType]=\"documentIconType\" />\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: MimeTypeIconComponent, selector: "hxp-mime-type-icon", inputs: ["mimeType"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentTypeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-type-icon', standalone: true, imports: [CommonModule, MimeTypeIconComponent], template: "<hxp-mime-type-icon [mimeType]=\"documentIconType\" />\n" }]
        }], propDecorators: { document: [{
                type: Input
            }], isExpanded: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const EditPropertiesStatus = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
    INFO: 'INFO',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const editPropertiesNotificationMessages = {
    [EditPropertiesStatus.SUCCESS]: 'DOCUMENT.PROPERTIES.EDIT.SUCCESS',
    [EditPropertiesStatus.ERROR]: 'DOCUMENT.PROPERTIES.EDIT.ERROR',
    [EditPropertiesStatus.INFO]: 'DOCUMENT.PROPERTIES.EDIT.INFO',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const editPropertiesSnackBarTypes = {
    [EditPropertiesStatus.SUCCESS]: 'done',
    [EditPropertiesStatus.ERROR]: 'error',
    [EditPropertiesStatus.INFO]: 'info',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document properties viewer container.
 *
 * To use the `PropertiesViewerContainerComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PropertiesViewerContainerComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         PropertiesViewerContainerComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-viewer-container
 *    [document]="document"
 *    [properties]="defaultProperties"
 *    [editable]="editable"
 *    [expanded]="expanded"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayDefaultProperties]="displayDefaultProperties"
 *    [displayEmpty]="displayEmpty"
 *    [multi]="multi"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty"
 *    [displayLabelForChips]="true">
 * </hxp-properties-viewer-container>
 */
class PropertiesViewerContainerComponent {
    constructor(documentService, cardViewUpdateService, hxpNotificationService, documentPropertiesService, 
    /**
     * An attribute representing a text to display in the header. Can be a key to translate.
     * @type {boolean}
     * @default false
     */
    headerText = 'CORE.METADATA.BASIC.HEADER') {
        this.documentService = documentService;
        this.cardViewUpdateService = cardViewUpdateService;
        this.hxpNotificationService = hxpNotificationService;
        this.documentPropertiesService = documentPropertiesService;
        this.headerText = headerText;
        this.destroyRef = inject(DestroyRef);
        /**
         * The properties to display in the card view.
         * @type {CardViewItem[]}
         * @default []
         *
         * ```ts
         * export interface CardViewItem {
         *      label: string;
         *      value: any;
         *      key: string;
         *      default?: any;
         *      type: string;
         *      displayValue: any;
         *      editable?: boolean;
         *      icon?: string;
         * }
         * ```
         *
         */
        this.properties = [];
        /**
         * Toggles whether or not to enable copy to clipboard action.
         * @type {boolean}
         * @default true
         */
        this.copyToClipboardAction = true;
        /**
         * Toggles whether the metadata properties should be shown.
         * @type {boolean}
         * @default true
         */
        this.displayDefaultProperties = true;
        /**
         * Toggles whether to display empty values in the card view.
         * @type {boolean}
         * @default false
         */
        this.displayEmpty = false;
        /**
         * Toggles whether the edit button should be shown
         * @type {boolean}
         * @default false
         */
        this.editable = false;
        /**
         * Expand or collapse the panel.
         * @type {boolean}
         * @default false
         */
        this.expanded = false;
        /**
         * The multi parameter of the underlying material expansion panel, set to true to allow multi accordion to be expanded at the same time.
         * @type {boolean}
         * @default false
         */
        this.multi = false;
        /**
         * Toggles whether or not to enable chips for multivalued properties.
         * @type {boolean}
         * @default true
         */
        this.useChipsForMultiValueProperty = true;
        /**
         * Toggles whether or not to display label for multivalued properties.
         * @type {boolean}
         * @default false
         */
        this.displayLabelForChips = false;
        this.propertyUpdateRequest = new EventEmitter();
        this.editMode = false;
        this.workingCopy = true;
        this.isEditableRecord = false;
        this.cardValueValidationMap = {};
        this.documentPropertiesToUpdate = {};
        this.requiredProperties = this.documentPropertiesService.getRequiredProperties();
        this.cardViewUpdateService.itemUpdated$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(this.respondToCardUpdate.bind(this));
    }
    ngOnChanges() {
        if (this.document) {
            this.workingCopy = !isVersion(this.document);
            this.isEditableRecord = !BLOCK_EDIT_STATUSES.includes(getRetentionStatus(this.document));
        }
    }
    onSaveProperties() {
        if (!this.document?.sys_id) {
            return;
        }
        this.documentService
            .updateDocument(this.document.sys_id, this.documentPropertiesToUpdate)
            .pipe(take$1(1))
            .subscribe({
            next: (document) => {
                this.document = document;
                this.editMode = false;
                this.documentPropertiesToUpdate = {};
                this.hxpNotificationService.openSnackBar(editPropertiesNotificationMessages[EditPropertiesStatus.SUCCESS], editPropertiesSnackBarTypes[EditPropertiesStatus.SUCCESS]);
            },
            error: () => {
                this.hxpNotificationService.openSnackBar(editPropertiesNotificationMessages[EditPropertiesStatus.ERROR], editPropertiesSnackBarTypes[EditPropertiesStatus.ERROR]);
            },
        });
    }
    toggleEditMode() {
        this.editMode = !this.editMode;
        this.documentPropertiesToUpdate = {};
        if (!this.editMode) {
            this.propertyUpdateRequest.emit(true);
        }
    }
    hasBeenModified() {
        return Object.keys(this.documentPropertiesToUpdate).length > 0;
    }
    allCardValuesAreValid() {
        return Object.keys(this.documentPropertiesToUpdate).every((changedKey) => this.cardValueValidationMap[changedKey]);
    }
    respondToCardUpdate(updateNotification) {
        const changedKey = Object.keys(updateNotification.changed)[0];
        const changedValue = updateNotification.changed[changedKey];
        const fieldType = this.documentPropertiesService.propertyType(changedKey);
        this.cardValueValidationMap[changedKey] = this.validateCardValue(changedKey, changedValue, fieldType);
        if (!this.cardValueValidationMap[changedKey]) {
            return;
        }
        const updatedValue = this.isComplexProperty(changedValue, fieldType)
            ? this.getUpdatedComplexProperty(changedKey, changedValue)
            : updateNotification.changed;
        this.documentPropertiesToUpdate = {
            ...this.documentPropertiesToUpdate,
            ...updatedValue,
        };
    }
    getUpdatedComplexProperty(changedKey, changedValue) {
        const existingDataInDocument = this.document?.[changedKey] || {};
        const existingUpdateData = this.documentPropertiesToUpdate[changedKey] || {};
        return {
            [changedKey]: {
                ...existingDataInDocument,
                ...existingUpdateData,
                ...changedValue,
            },
        };
    }
    validateCardValue(changedKey, changedValue, fieldType) {
        let invalidCardValue = false;
        if (fieldType === FieldType.Blob || fieldType === FieldType.Complex) {
            const nestedPropertyName = Object.keys(changedValue)[0];
            if (this.isEmptyProperty(changedValue[`${nestedPropertyName}`])) {
                invalidCardValue = this.handleEmptyProperty(`${changedKey}.${nestedPropertyName || ''}`);
            }
        }
        else if (this.isEmptyProperty(changedValue)) {
            invalidCardValue = this.handleEmptyProperty(changedKey);
        }
        return !invalidCardValue;
    }
    isComplexProperty(changedValue, fieldType) {
        return fieldType === FieldType.Complex || (fieldType !== FieldType.Date && typeof changedValue === 'object' && !Array.isArray(changedValue));
    }
    isEmptyProperty(changedValue) {
        return !changedValue;
    }
    handleEmptyProperty(propertyName) {
        if (this.requiredProperties.includes(propertyName)) {
            this.hxpNotificationService.openSnackBar(editPropertiesNotificationMessages[EditPropertiesStatus.INFO], editPropertiesSnackBarTypes[EditPropertiesStatus.INFO]);
            return true;
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PropertiesViewerContainerComponent, deps: [{ token: DOCUMENT_SERVICE }, { token: i1$5.CardViewUpdateService }, { token: i1.HxpNotificationService }, { token: DOCUMENT_PROPERTIES_SERVICE }, { token: 'headerText', attribute: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.9", type: PropertiesViewerContainerComponent, isStandalone: true, selector: "hxp-properties-viewer-container", inputs: { document: "document", properties: "properties", copyToClipboardAction: "copyToClipboardAction", displayDefaultProperties: "displayDefaultProperties", displayEmpty: "displayEmpty", editable: "editable", expanded: "expanded", multi: "multi", useChipsForMultiValueProperty: "useChipsForMultiValueProperty", displayLabelForChips: "displayLabelForChips" }, outputs: { propertyUpdateRequest: "propertyUpdateRequest" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-metadata-properties\">\n    <mat-accordion displayMode=\"flat\" [multi]=\"multi\">\n        <mat-expansion-panel\n            *ngIf=\"displayDefaultProperties\"\n            [expanded]=\"expanded\"\n        >\n            <mat-expansion-panel-header>\n                <mat-panel-title class=\"hxp-metadata-properties-title mat-subtitle-1\">\n                    {{ headerText | translate }}\n                </mat-panel-title>\n            </mat-expansion-panel-header>\n            <adf-card-view\n                [properties]=\"properties\"\n                [editable]=\"editMode\"\n                [displayEmpty]=\"displayEmpty\"\n                [copyToClipboardAction]=\"copyToClipboardAction\"\n                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty\"\n                [displayLabelForChips]=\"displayLabelForChips\"\n                [multiValueSeparator]=\"', '\"\n            />\n\n            @if (workingCopy && editable && isEditableRecord) {\n                <div class=\"hxp-property-edit-actions\">\n                    @if (!editMode) {\n                        <button\n                            mat-button\n                            class=\"hxp-property-edit-button hxp-primary-button\"\n                            (click)=\"toggleEditMode()\">\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.EDIT' | translate }}\n                        </button>\n                    } @else {\n                        <button\n                            mat-button\n                            class=\"hxp-cancel-button\"\n                            (click)=\"toggleEditMode()\">\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.CANCEL' | translate }}\n                        </button>\n                        <button\n                            class=\"hxp-save-properties-button hxp-primary-button\"\n                            mat-button\n                            [disabled]=\"!(hasBeenModified() && allCardValuesAreValid())\"\n                            (click)=\"onSaveProperties()\">\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.SAVE' | translate }}\n                        </button>\n                    }\n                </div>\n            }\n        </mat-expansion-panel>\n    </mat-accordion>\n</div>\n", styles: [".hxp-metadata-properties ::ng-deep .adf-card-view-selectitem .mat-mdc-form-field-infix{margin-right:10px}.hxp-metadata-properties .mat-expansion-panel-header.mat-expanded:hover,.hxp-metadata-properties .mat-expansion-panel-header.mat-expanded:focus{background:var(--theme-background-hover-color, #f9f9fc)}.hxp-metadata-properties mat-expansion-panel-header{height:64px}.hxp-metadata-properties .mat-expansion-panel:not([class*=mat-elevation-z]){box-shadow:none}.hxp-metadata-properties-title{margin-bottom:0}.hxp-metadata-properties .hxp-property-edit-actions{padding-top:40px;display:flex;justify-content:flex-end;gap:8px}.hxp-metadata-properties .hxp-property-edit-actions .hxp-cancel-button{color:var(--theme-primary-color, #5654ac);border:0}\n"], dependencies: [{ kind: "ngmodule", type: MatExpansionModule }, { kind: "directive", type: i3$6.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i3$6.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i3$6.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i3$6.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardViewComponent, selector: "adf-card-view", inputs: ["properties", "editable", "displayEmpty", "displayNoneOption", "displayClearAction", "copyToClipboardAction", "useChipsForMultiValueProperty", "multiValueSeparator", "displayLabelForChips"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PropertiesViewerContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-properties-viewer-container', standalone: true, imports: [MatExpansionModule, NgIf, CardViewComponent, MatButtonModule, TranslatePipe], template: "<div class=\"hxp-metadata-properties\">\n    <mat-accordion displayMode=\"flat\" [multi]=\"multi\">\n        <mat-expansion-panel\n            *ngIf=\"displayDefaultProperties\"\n            [expanded]=\"expanded\"\n        >\n            <mat-expansion-panel-header>\n                <mat-panel-title class=\"hxp-metadata-properties-title mat-subtitle-1\">\n                    {{ headerText | translate }}\n                </mat-panel-title>\n            </mat-expansion-panel-header>\n            <adf-card-view\n                [properties]=\"properties\"\n                [editable]=\"editMode\"\n                [displayEmpty]=\"displayEmpty\"\n                [copyToClipboardAction]=\"copyToClipboardAction\"\n                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty\"\n                [displayLabelForChips]=\"displayLabelForChips\"\n                [multiValueSeparator]=\"', '\"\n            />\n\n            @if (workingCopy && editable && isEditableRecord) {\n                <div class=\"hxp-property-edit-actions\">\n                    @if (!editMode) {\n                        <button\n                            mat-button\n                            class=\"hxp-property-edit-button hxp-primary-button\"\n                            (click)=\"toggleEditMode()\">\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.EDIT' | translate }}\n                        </button>\n                    } @else {\n                        <button\n                            mat-button\n                            class=\"hxp-cancel-button\"\n                            (click)=\"toggleEditMode()\">\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.CANCEL' | translate }}\n                        </button>\n                        <button\n                            class=\"hxp-save-properties-button hxp-primary-button\"\n                            mat-button\n                            [disabled]=\"!(hasBeenModified() && allCardValuesAreValid())\"\n                            (click)=\"onSaveProperties()\">\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.SAVE' | translate }}\n                        </button>\n                    }\n                </div>\n            }\n        </mat-expansion-panel>\n    </mat-accordion>\n</div>\n", styles: [".hxp-metadata-properties ::ng-deep .adf-card-view-selectitem .mat-mdc-form-field-infix{margin-right:10px}.hxp-metadata-properties .mat-expansion-panel-header.mat-expanded:hover,.hxp-metadata-properties .mat-expansion-panel-header.mat-expanded:focus{background:var(--theme-background-hover-color, #f9f9fc)}.hxp-metadata-properties mat-expansion-panel-header{height:64px}.hxp-metadata-properties .mat-expansion-panel:not([class*=mat-elevation-z]){box-shadow:none}.hxp-metadata-properties-title{margin-bottom:0}.hxp-metadata-properties .hxp-property-edit-actions{padding-top:40px;display:flex;justify-content:flex-end;gap:8px}.hxp-metadata-properties .hxp-property-edit-actions .hxp-cancel-button{color:var(--theme-primary-color, #5654ac);border:0}\n"] }]
        }], ctorParameters: () => [{ type: i1.SharedDocumentService, decorators: [{
                    type: Inject,
                    args: [DOCUMENT_SERVICE]
                }] }, { type: i1$5.CardViewUpdateService }, { type: i1.HxpNotificationService }, { type: i1.SharedDocumentPropertiesService, decorators: [{
                    type: Inject,
                    args: [DOCUMENT_PROPERTIES_SERVICE]
                }] }, { type: undefined, decorators: [{
                    type: Attribute,
                    args: ['headerText']
                }] }], propDecorators: { document: [{
                type: Input
            }], properties: [{
                type: Input
            }], copyToClipboardAction: [{
                type: Input
            }], displayDefaultProperties: [{
                type: Input
            }], displayEmpty: [{
                type: Input
            }], editable: [{
                type: Input
            }], expanded: [{
                type: Input
            }], multi: [{
                type: Input
            }], useChipsForMultiValueProperty: [{
                type: Input
            }], displayLabelForChips: [{
                type: Input
            }], propertyUpdateRequest: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * This component is responsible for managing the permissions in the form of a panel.
 * The rest of the application is still accessible.
 *
 * It includes functionalities to add, edit, and display permissions to `User`s and `Group`s.
 *
 * Available permissions are `Read`, `Write` and `Everything`.
 *
 * Permissions are inherited from the parent `Document`.
 * It's possible to only upgrade a inherited permission.
 *
 * To use the `PermissionsManagementPanelComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PermissionsManagementPanelComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         PermissionsManagementPanelComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-permissions-management-panel></hxp-permissions-management-panel>
 */
class PermissionsManagementPanelComponent extends DismissPermission {
    constructor(permissionsPanelRequestService, dialog) {
        super();
        this.permissionsPanelRequestService = permissionsPanelRequestService;
        this.dialog = dialog;
    }
    cancel(isEdited) {
        if (!isEdited) {
            return this.close();
        }
        this.dialog.open(CancelPermissionDialogComponent, {
            width: DialogConfig.small.width,
            data: {
                dialogTitle: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.TITLE',
                dialogDescription: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.DESCRIPTION',
                dialogRejectButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.REJECT',
                dialogConfirmButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.CONFIRM',
            },
        });
    }
    close() {
        this.permissionsPanelRequestService.requestClosePanel();
    }
    restore() {
        this.dialog.open(RestorePermissionDialogComponent, {
            width: DialogConfig.small.width,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsManagementPanelComponent, deps: [{ token: i1.PermissionsPanelRequestService }, { token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PermissionsManagementPanelComponent, isStandalone: true, selector: "hxp-permissions-management-panel", inputs: { document: "document", parentDocument: "parentDocument" }, providers: [PermissionsManagementStateService], usesInheritance: true, ngImport: i0, template: "<div class=\"hxp-permissions-management-panel-container\">\n    <div class=\"hxp-permission-container\">\n        <hxp-permission-management-container\n            [document]=\"document\"\n            [parentDocument]=\"parentDocument\"\n            (cancelEvent)=\"cancel($event)\"\n            (closeEvent)=\"close()\"\n            (restoreEvent)=\"restore()\">\n            <ng-template #title let-title>\n                <hxp-permissions-document-title [title]=\"title || ''\" />\n            </ng-template>\n        </hxp-permission-management-container>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-panel-container{padding:16px;overflow:auto;height:calc(100% - 32px)}.hxp-permissions-management-panel-container .mat-divider{margin:32px -16px 24px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatTabsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: PermissionsDocumentTitleComponent, selector: "hxp-permissions-document-title", inputs: ["title"] }, { kind: "ngmodule", type: MatSnackBarModule }, { kind: "component", type: PermissionManagementContainerComponent, selector: "hxp-permission-management-container", inputs: ["document", "parentDocument"], outputs: ["cancelEvent", "closeEvent", "restoreEvent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PermissionsManagementPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-management-panel', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTabsModule,
                        MatIconModule,
                        MatDividerModule,
                        TranslatePipe,
                        PermissionsDocumentTitleComponent,
                        MatSnackBarModule,
                        PermissionManagementContainerComponent,
                    ], providers: [PermissionsManagementStateService], template: "<div class=\"hxp-permissions-management-panel-container\">\n    <div class=\"hxp-permission-container\">\n        <hxp-permission-management-container\n            [document]=\"document\"\n            [parentDocument]=\"parentDocument\"\n            (cancelEvent)=\"cancel($event)\"\n            (closeEvent)=\"close()\"\n            (restoreEvent)=\"restore()\">\n            <ng-template #title let-title>\n                <hxp-permissions-document-title [title]=\"title || ''\" />\n            </ng-template>\n        </hxp-permission-management-container>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-panel-container{padding:16px;overflow:auto;height:calc(100% - 32px)}.hxp-permissions-management-panel-container .mat-divider{margin:32px -16px 24px}\n"] }]
        }], ctorParameters: () => [{ type: i1.PermissionsPanelRequestService }, { type: i1$1.MatDialog }], propDecorators: { document: [{
                type: Input
            }], parentDocument: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Pipe that transforms a Document object into a URL string using the DocumentRouterService.
 *
 * @example
 * * Using the pipe in a component:
 * ```typescript
 * const document: Document = { id: '123', name: 'example.docx' };
 * const options: DocumentRouterOptions = { absolute: true };
 * const url: string = documentRouterPipe.transform(document, options);
 * ```
 * Using the pipe in a template:
 * ```html
 * <a [href]="document | urlFor: { absolute: true }">Document Details</a>
 * ```
 */
class DocumentRouterPipe {
    constructor(documentRouterService) {
        this.documentRouterService = documentRouterService;
    }
    transform(document, options = { absolute: false }) {
        return this.documentRouterService.urlFor(document, options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentRouterPipe, deps: [{ token: i1.DocumentRouterService }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: DocumentRouterPipe, isStandalone: true, name: "urlFor" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentRouterPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'urlFor',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i1.DocumentRouterService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document breadcrumb.
 * To use the `HxpUiBreadcrumbComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpUiBreadcrumbComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         HxpUiBreadcrumbComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-ui-breadcrumb [documents]="documents"></hxp-ui-breadcrumb>
 */
class HxpUiBreadcrumbComponent {
    constructor() {
        /**
         * List of `Document` object the breadcrumb is rendered from.
         * @type {Document}
         */
        this.documents = [];
        /**
         * If true, breadcrumb elements are grouped together and displayed as ellipsis, except for the first and last entry.
         * @default false
         * @type {boolean}
         */
        this.compact = false;
    }
    documentTrackBy(_index, document) {
        return document?.sys_id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpUiBreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: HxpUiBreadcrumbComponent, isStandalone: true, selector: "hxp-ui-breadcrumb", inputs: { documents: "documents", compact: "compact" }, ngImport: i0, template: "<adf-breadcrumb [compact]=\"compact\" data-testid=\"breadcrumb\">\n    <adf-breadcrumb-item\n        *ngFor=\"\n            let doc of documents;\n            last as isLast;\n            trackBy: documentTrackBy\n        \"\n    >\n        <a\n            *ngIf=\"!!doc else notNavigable\"\n            [routerLink]=\"!isLast ? (doc | urlFor) : undefined\"\n            [attr.aria-current]=\"isLast ? 'location' : undefined\"\n        >\n            {{ doc | breadcrumbLabel: 'DOCUMENT_BREADCRUMB.ROOT' }}\n        </a>\n        <ng-template #notNavigable>\n            <span class=\"hxp-not-navigable-folder\">\n               ...\n            </span>\n        </ng-template>\n    </adf-breadcrumb-item>\n</adf-breadcrumb>\n", styles: ["ui-breadcrumb .hxp-not-navigable-folder{font:600 14px/16px var(--theme-font-family, \"Noto Sans\");color:var(--theme-accent-color-a200)}\n"], dependencies: [{ kind: "component", type: BreadcrumbComponent, selector: "adf-breadcrumb", inputs: ["compact"], outputs: ["compactChange"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: BreadcrumbItemComponent, selector: "adf-breadcrumb-item" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: DocumentRouterPipe, name: "urlFor" }, { kind: "pipe", type: BreadcrumbLabelPipe, name: "breadcrumbLabel" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpUiBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-ui-breadcrumb', encapsulation: ViewEncapsulation.None, standalone: true, imports: [BreadcrumbComponent, NgFor, BreadcrumbItemComponent, NgIf, RouterLink, DocumentRouterPipe, BreadcrumbLabelPipe], template: "<adf-breadcrumb [compact]=\"compact\" data-testid=\"breadcrumb\">\n    <adf-breadcrumb-item\n        *ngFor=\"\n            let doc of documents;\n            last as isLast;\n            trackBy: documentTrackBy\n        \"\n    >\n        <a\n            *ngIf=\"!!doc else notNavigable\"\n            [routerLink]=\"!isLast ? (doc | urlFor) : undefined\"\n            [attr.aria-current]=\"isLast ? 'location' : undefined\"\n        >\n            {{ doc | breadcrumbLabel: 'DOCUMENT_BREADCRUMB.ROOT' }}\n        </a>\n        <ng-template #notNavigable>\n            <span class=\"hxp-not-navigable-folder\">\n               ...\n            </span>\n        </ng-template>\n    </adf-breadcrumb-item>\n</adf-breadcrumb>\n", styles: ["ui-breadcrumb .hxp-not-navigable-folder{font:600 14px/16px var(--theme-font-family, \"Noto Sans\");color:var(--theme-accent-color-a200)}\n"] }]
        }], propDecorators: { documents: [{
                type: Input
            }], compact: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that displays a series of clickable links that represent the path to a given `Document`.
 * To use the `HxpBreadcrumbComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpBreadcrumbComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         HxpBreadcrumbComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-breadcrumb [document]="document"></hxp-breadcrumb>
 *
 */
class HxpBreadcrumbComponent {
    constructor(documentService) {
        this.documentService = documentService;
        /**
         * If true, breadcrumb elements are grouped together and displayed as ellipsis, except for the first and last entry.
         * @default false
         * @type {boolean}
         */
        this.compact = false;
        this.breadcrumbElements = [];
        this.document = ROOT_DOCUMENT;
    }
    ngOnInit() {
        this._buildBreadcrumb(this.document);
    }
    ngOnChanges(changes) {
        if (changes['document']) {
            this._buildBreadcrumb(this.document);
        }
    }
    _buildBreadcrumb(document) {
        if (!document) {
            this.breadcrumbElements = [];
            return;
        }
        this.documentService
            .getAncestors(document?.sys_id ?? '')
            .pipe(catchError(() => of([{ ...ROOT_DOCUMENT }])), map$1((ancestors) => (isVersion(document) ? ancestors.filter((ancestor) => ancestor.sys_id !== document.sys_parentId) : ancestors)))
            .subscribe({
            next: (ancestors) => {
                this.breadcrumbElements = ancestors;
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpBreadcrumbComponent, deps: [{ token: i1.DocumentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: HxpBreadcrumbComponent, isStandalone: true, selector: "hxp-breadcrumb", inputs: { document: "document", compact: "compact" }, usesOnChanges: true, ngImport: i0, template: "<hxp-ui-breadcrumb\n    [compact]=\"compact\"\n    [documents]=\"breadcrumbElements\"\n/>\n\n", dependencies: [{ kind: "component", type: HxpUiBreadcrumbComponent, selector: "hxp-ui-breadcrumb", inputs: ["documents", "compact"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-breadcrumb', encapsulation: ViewEncapsulation.None, standalone: true, imports: [HxpUiBreadcrumbComponent], template: "<hxp-ui-breadcrumb\n    [compact]=\"compact\"\n    [documents]=\"breadcrumbElements\"\n/>\n\n" }]
        }], ctorParameters: () => [{ type: i1.DocumentService }], propDecorators: { document: [{
                type: Input
            }], compact: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpPropertiesSidebarComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpPropertiesSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpPropertiesSidebarComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-sidebar [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
class HxpPropertiesSidebarComponent {
    constructor(documentService, documentPropertiesService) {
        this.documentService = documentService;
        this.documentPropertiesService = documentPropertiesService;
        this.destroyRef = inject(DestroyRef);
        /**
         * Input property to enable or disable edit mode availability
         * @type {boolean}
         * @default true
         */
        this.editable = true;
        /**
         * Emits an event when the sidebar is closed
         */
        this.closePropertySidebar = new EventEmitter();
        this.propertyLoading = false;
        this.subscribeToDocumentUpdates();
    }
    ngOnChanges() {
        this.loadDocumentProperties(this.document?.sys_id ?? '');
    }
    handlePropertyUpdate(propertyUpdated) {
        if (propertyUpdated) {
            this.fetchDefaultProperties();
            this.fetchOtherProperties();
        }
    }
    onClose() {
        this.closePropertySidebar.emit();
    }
    subscribeToDocumentUpdates() {
        this.documentService.documentUpdated$
            .pipe(filter(({ document }) => !!document && document.sys_id === this.document?.sys_id), takeUntilDestroyed(this.destroyRef))
            .subscribe({
            next: () => {
                this.loadDocumentProperties(this.document?.sys_id ?? '');
            },
            error: (error) => console.error(error),
        });
    }
    loadDocumentProperties(documentId) {
        if (!documentId) {
            return;
        }
        this.propertyLoading = true;
        this.documentService
            .getDocumentById(documentId)
            .pipe(take$1(1), finalize(() => (this.propertyLoading = false)))
            .subscribe({
            next: (doc) => {
                this.selectedDocument = doc;
                this.fetchDocumentProperties();
            },
            error: ({ error }) => {
                console.error(error);
            },
        });
    }
    fetchDocumentProperties() {
        if (!this.selectedDocument) {
            return;
        }
        this.documentPropertiesService
            .extractCustomSchemaFields(this.selectedDocument.sys_primaryType)
            .pipe(take$1(1))
            .subscribe({
            next: (schemaFields) => {
                this.initializeDocumentWithSchema(schemaFields);
            },
            error: (error) => console.error(error),
        });
        this.fetchDefaultProperties();
        this.fetchOtherProperties();
    }
    initializeDocumentWithSchema(schemaFields, currentDoc = this.selectedDocument) {
        for (const fieldName of Object.keys(schemaFields)) {
            if (!currentDoc[fieldName]) {
                currentDoc[fieldName] = typeof schemaFields[fieldName] === 'object' ? {} : '';
            }
            if (typeof schemaFields[fieldName] === 'object') {
                this.initializeDocumentWithSchema(schemaFields[fieldName], currentDoc[fieldName]);
            }
        }
    }
    fetchDefaultProperties() {
        this.documentProperties$ = this.documentPropertiesService.getDefaultPropertiesFromDocument(this.selectedDocument);
    }
    fetchOtherProperties() {
        this.otherDocumentProperties$ = this.documentPropertiesService.getPropertiesFromDocument(this.selectedDocument, {
            exclude: {
                schemas: ['sysfile_blob', 'sys_', 'sysver_', 'sysgov_'],
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpPropertiesSidebarComponent, deps: [{ token: i1.DocumentService }, { token: DOCUMENT_PROPERTIES_SERVICE }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: HxpPropertiesSidebarComponent, isStandalone: true, selector: "hxp-properties-sidebar", inputs: { document: "document", editable: "editable" }, outputs: { closePropertySidebar: "closePropertySidebar" }, usesOnChanges: true, ngImport: i0, template: "<adf-info-drawer-layout>\n    <div info-drawer-content>\n        <div class=\"hxp-property-panel-header\">\n            <div class=\"hxp-property-panel-header_title mat-h1\">{{ selectedDocument?.sys_title }}</div>\n            <button\n                mat-icon-button\n                attr.aria-label=\"{{ 'DOCUMENT.PROPERTIES.RIGHT_SIDEBAR.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n                class=\"hxp-property-sidebar-close-button\"\n            >\n                <mat-icon>close</mat-icon>\n            </button>\n        </div>\n        <adf-info-drawer>\n            <adf-info-drawer-tab label=\"Properties\">\n                <div *ngIf=\"propertyLoading\" class=\"hxp-property-panel-spinner-container\">\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"30\" />\n                </div>\n\n                <ng-container *ngIf=\"!propertyLoading && (documentProperties$ | async) as documentProperties\">\n                    <hxp-properties-viewer-container\n                        [expanded]=\"true\"\n                        [useChipsForMultiValueProperty]=\"false\"\n                        [properties]=\"documentProperties\"\n                        headerText=\"DOCUMENT.PROPERTIES.VIEWER.MAIN.CONTAINER.HEADER\"\n                        id=\"properties-viewer-container\"\n                        [editable]=\"editable\"\n                        [document]=\"selectedDocument\"\n                        (propertyUpdateRequest)=\"handlePropertyUpdate($event)\" />\n                </ng-container>\n\n                <ng-container *ngIf=\"!propertyLoading && (otherDocumentProperties$ | async) as otherProperties\">\n                    <hxp-properties-viewer-container\n                        *ngIf=\"otherProperties.length > 0\"\n                        [expanded]=\"false\"\n                        [useChipsForMultiValueProperty]=\"true\"\n                        [displayLabelForChips]=\"true\"\n                        [properties]=\"otherProperties\"\n                        headerText=\"DOCUMENT.PROPERTIES.VIEWER.OTHER.CONTAINER.HEADER\"\n                        id=\"properties-viewer-container\"\n                        [editable]=\"editable\"\n                        [document]=\"selectedDocument\"\n                        (propertyUpdateRequest)=\"handlePropertyUpdate($event)\" />\n                </ng-container>\n            </adf-info-drawer-tab>\n        </adf-info-drawer>\n    </div>\n</adf-info-drawer-layout>\n", styles: [".mat-mdc-form-field-infix .mat-mdc-form-field-input-control.adf-property-value,.adf-property-container adf-card-view-selectitem .adf-property-value,.adf-property-container adf-card-view-dateitem .adf-property-value{font-size:1,14rem;line-height:1.43rem;font-weight:500}.hxp-property-panel-header{display:flex;justify-content:space-between;align-items:center;padding:20px 0}.hxp-property-panel-header_title{margin:0;padding:0 16px;display:inline-block;text-overflow:ellipsis;width:260px;overflow:hidden}.hxp-property-panel-spinner-container{display:flex!important;justify-content:center;align-items:center;height:300px}adf-info-drawer-layout .adf-info-drawer-layout-content{position:relative}adf-info-drawer-layout .adf-info-drawer-layout-header{display:none}.adf-property-container adf-card-view-selectitem .adf-property-value,.adf-property-container adf-card-view-dateitem .adf-property-value{margin-top:0;padding-top:0}.adf-property-container adf-card-view-selectitem .adf-property-label,.adf-property-container adf-card-view-dateitem .adf-property-label{line-height:1.43rem;font-weight:400;font-size:.86rem}.adf-info-drawer-layout{background-color:var(--adf-theme-background-card-color)!important}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}.mat-mdc-form-field-subscript-wrapper,.mdc-line-ripple{display:none}.mdc-text-field--filled .mdc-floating-label .adf-property-label{font-size:calc(.86rem / var(--mat-mdc-form-field-floating-label-scale))}.mat-mdc-form-field-infix{display:flex;align-items:center}\n"], dependencies: [{ kind: "component", type: InfoDrawerLayoutComponent, selector: "adf-info-drawer-layout", inputs: ["showHeader"] }, { kind: "directive", type: InfoDrawerContentDirective, selector: "[adf-info-drawer-content], [info-drawer-content]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: InfoDrawerComponent, selector: "adf-info-drawer", inputs: ["title", "icon", "selectedIndex", "showHeader"], outputs: ["currentTab"] }, { kind: "component", type: InfoDrawerTabComponent, selector: "adf-info-drawer-tab", inputs: ["label", "icon"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "component", type: PropertiesViewerContainerComponent, selector: "hxp-properties-viewer-container", inputs: ["document", "properties", "copyToClipboardAction", "displayDefaultProperties", "displayEmpty", "editable", "expanded", "multi", "useChipsForMultiValueProperty", "displayLabelForChips"], outputs: ["propertyUpdateRequest"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpPropertiesSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-properties-sidebar', encapsulation: ViewEncapsulation.None, standalone: true, imports: [
                        InfoDrawerLayoutComponent,
                        InfoDrawerContentDirective,
                        MatButtonModule,
                        MatIconModule,
                        InfoDrawerComponent,
                        InfoDrawerTabComponent,
                        NgIf,
                        MatProgressSpinnerModule,
                        PropertiesViewerContainerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<adf-info-drawer-layout>\n    <div info-drawer-content>\n        <div class=\"hxp-property-panel-header\">\n            <div class=\"hxp-property-panel-header_title mat-h1\">{{ selectedDocument?.sys_title }}</div>\n            <button\n                mat-icon-button\n                attr.aria-label=\"{{ 'DOCUMENT.PROPERTIES.RIGHT_SIDEBAR.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n                class=\"hxp-property-sidebar-close-button\"\n            >\n                <mat-icon>close</mat-icon>\n            </button>\n        </div>\n        <adf-info-drawer>\n            <adf-info-drawer-tab label=\"Properties\">\n                <div *ngIf=\"propertyLoading\" class=\"hxp-property-panel-spinner-container\">\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"30\" />\n                </div>\n\n                <ng-container *ngIf=\"!propertyLoading && (documentProperties$ | async) as documentProperties\">\n                    <hxp-properties-viewer-container\n                        [expanded]=\"true\"\n                        [useChipsForMultiValueProperty]=\"false\"\n                        [properties]=\"documentProperties\"\n                        headerText=\"DOCUMENT.PROPERTIES.VIEWER.MAIN.CONTAINER.HEADER\"\n                        id=\"properties-viewer-container\"\n                        [editable]=\"editable\"\n                        [document]=\"selectedDocument\"\n                        (propertyUpdateRequest)=\"handlePropertyUpdate($event)\" />\n                </ng-container>\n\n                <ng-container *ngIf=\"!propertyLoading && (otherDocumentProperties$ | async) as otherProperties\">\n                    <hxp-properties-viewer-container\n                        *ngIf=\"otherProperties.length > 0\"\n                        [expanded]=\"false\"\n                        [useChipsForMultiValueProperty]=\"true\"\n                        [displayLabelForChips]=\"true\"\n                        [properties]=\"otherProperties\"\n                        headerText=\"DOCUMENT.PROPERTIES.VIEWER.OTHER.CONTAINER.HEADER\"\n                        id=\"properties-viewer-container\"\n                        [editable]=\"editable\"\n                        [document]=\"selectedDocument\"\n                        (propertyUpdateRequest)=\"handlePropertyUpdate($event)\" />\n                </ng-container>\n            </adf-info-drawer-tab>\n        </adf-info-drawer>\n    </div>\n</adf-info-drawer-layout>\n", styles: [".mat-mdc-form-field-infix .mat-mdc-form-field-input-control.adf-property-value,.adf-property-container adf-card-view-selectitem .adf-property-value,.adf-property-container adf-card-view-dateitem .adf-property-value{font-size:1,14rem;line-height:1.43rem;font-weight:500}.hxp-property-panel-header{display:flex;justify-content:space-between;align-items:center;padding:20px 0}.hxp-property-panel-header_title{margin:0;padding:0 16px;display:inline-block;text-overflow:ellipsis;width:260px;overflow:hidden}.hxp-property-panel-spinner-container{display:flex!important;justify-content:center;align-items:center;height:300px}adf-info-drawer-layout .adf-info-drawer-layout-content{position:relative}adf-info-drawer-layout .adf-info-drawer-layout-header{display:none}.adf-property-container adf-card-view-selectitem .adf-property-value,.adf-property-container adf-card-view-dateitem .adf-property-value{margin-top:0;padding-top:0}.adf-property-container adf-card-view-selectitem .adf-property-label,.adf-property-container adf-card-view-dateitem .adf-property-label{line-height:1.43rem;font-weight:400;font-size:.86rem}.adf-info-drawer-layout{background-color:var(--adf-theme-background-card-color)!important}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}.mat-mdc-form-field-subscript-wrapper,.mdc-line-ripple{display:none}.mdc-text-field--filled .mdc-floating-label .adf-property-label{font-size:calc(.86rem / var(--mat-mdc-form-field-floating-label-scale))}.mat-mdc-form-field-infix{display:flex;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i1.DocumentService }, { type: i1.SharedDocumentPropertiesService, decorators: [{
                    type: Inject,
                    args: [DOCUMENT_PROPERTIES_SERVICE]
                }] }], propDecorators: { document: [{
                type: Input
            }], editable: [{
                type: Input
            }], closePropertySidebar: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentMoreMenuItemComponent {
    constructor() {
        this.actionContext = { documents: [] };
    }
    ngOnInit() {
        this.appComponent = this.item?.component ?? '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentMoreMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: DocumentMoreMenuItemComponent, isStandalone: true, selector: "hxp-document-more-menu-item", inputs: { item: "item", actionContext: "actionContext" }, ngImport: i0, template: "<ng-container [ngSwitch]=\"item?.type\">\n    <ng-container *ngSwitchCase=\"'custom'\">\n        <adf-dynamic-component [id]=\"appComponent\" [data]=\"actionContext\" />\n    </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "component", type: DynamicExtensionComponent, selector: "adf-dynamic-component", inputs: ["id", "data"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentMoreMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-more-menu-item', standalone: true, imports: [NgSwitch, NgSwitchCase, DynamicExtensionComponent], template: "<ng-container [ngSwitch]=\"item?.type\">\n    <ng-container *ngSwitchCase=\"'custom'\">\n        <adf-dynamic-component [id]=\"appComponent\" [data]=\"actionContext\" />\n    </ng-container>\n</ng-container>\n" }]
        }], propDecorators: { item: [{
                type: Input
            }], actionContext: [{
                type: Input
            }] } });

/**
 * Component that display a menu on click, built on top of Alfresco Extensions API (https://www.alfresco.com/abn/adf/docs/extensions/components/dynamic.component/).
 *
 * To use the `DocumentMoreActionComponent`, first create a module to register your custom components using Alfresco `ExtensionService`:
 *
 * ```ts
 * import { NgModule } from '@angular/core';
 * import { ExtensionService } from '@alfresco/adf-extensions';
 *
 * @NgModule({})
 * export class ExtensionsRegisterModule {
 *     constructor(private readonly extensions: ExtensionService) {
 *         this.extensions.setComponents({
 *             'action.one': ActionOneButtonComponent,
 *             'action.two': ActionTwoButtonComponent,
 *         });
 *     }
 * }
 * ```
 * The components should provide a `data` Input property to receive the `ActionContext` object.
 * Example:
 *
 * ```ts
 * import { Component, Input } from '@angular/core';
 * import { ActionContext } from '@alfresco/adf-hx-content-services/services';
 *
 * @Component({
 *   template: '<button (click)="sayHello()">{{ data.documents[0].sys_title }}</button>',
 *   standalone: true,
 * })
 * class ActionTwoButtonComponent {
 *    @Input() data: ActionContext;
 *
 *    sayHello() {
 *        console.log(`Hello world! Here is ${data?.documents[0]?.sys_title}, nice to meet you!`);
 *    }
 * }
 * ```
 *
 * Then import your customized `ExtensionsRegisterModule` and the `DocumentMoreActionComponent` component in your module
 *
 * ```ts
 * import { DocumentMoreActionComponent } from '@alfresco/adf-hx-content-services/ui';
 * import { ExtensionsRegisterModule } from './extensions-register.module';
 *
 * @NgModule({
 *     imports: [
 *         ExtensionsRegisterModule,
 *         DocumentMoreActionComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-more-action [menuItems]="menuItems" [actionContext]="actionContext"></hxp-document-more-action>
 *
 */
class DocumentMoreActionComponent {
    constructor() {
        /**
         * Input property which specifies an `ActionContext` object
         * An `ActionContext` object must provide a list of documents.
         * The object is passed as `data` input property to the registered components.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         *     parentDocument?: Document;
         *     shouldRedirect?: boolean;
         *     refererURL?: string;
         *     showPanel?: 'property' | 'version';
         * }
         *
         */
        this.actionContext = { documents: [] };
    }
    childTrackBy(_index, child) {
        return child.id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentMoreActionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: DocumentMoreActionComponent, isStandalone: true, selector: "hxp-document-more-action", inputs: { menuItems: "menuItems", actionContext: "actionContext" }, ngImport: i0, template: "<div class=\"hxp-more-action-button\" *ngIf=\"actionContext.documents.length === 1\">\n    <ng-container *ngIf=\"menuItems\">\n        <button mat-icon-button [matMenuTriggerFor]=\"menu\" [attr.aria-label]=\"menuItems.title\">\n            <mat-icon>{{menuItems.icon}}</mat-icon>\n        </button>\n        <mat-menu #menu=\"matMenu\" xPosition=\"before\">\n            <div data-automation-id=\"hxp-document-more-menu-panel\">\n                <ng-container *ngFor=\"let action of menuItems.children; trackBy: childTrackBy\">\n                    <hxp-document-more-menu-item [actionContext]=\"actionContext\" [item]=\"action\"/>\n                </ng-container>\n            </div>\n        </mat-menu>\n    </ng-container>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i6.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i6.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: DocumentMoreMenuItemComponent, selector: "hxp-document-more-menu-item", inputs: ["item", "actionContext"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentMoreActionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-more-action', standalone: true, imports: [NgIf, MatButtonModule, MatMenuModule, MatIconModule, NgFor, DocumentMoreMenuItemComponent], template: "<div class=\"hxp-more-action-button\" *ngIf=\"actionContext.documents.length === 1\">\n    <ng-container *ngIf=\"menuItems\">\n        <button mat-icon-button [matMenuTriggerFor]=\"menu\" [attr.aria-label]=\"menuItems.title\">\n            <mat-icon>{{menuItems.icon}}</mat-icon>\n        </button>\n        <mat-menu #menu=\"matMenu\" xPosition=\"before\">\n            <div data-automation-id=\"hxp-document-more-menu-panel\">\n                <ng-container *ngFor=\"let action of menuItems.children; trackBy: childTrackBy\">\n                    <hxp-document-more-menu-item [actionContext]=\"actionContext\" [item]=\"action\"/>\n                </ng-container>\n            </div>\n        </mat-menu>\n    </ng-container>\n</div>\n" }]
        }], propDecorators: { menuItems: [{
                type: Input
            }], actionContext: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that display the content of a Document.
 *
 * To use the `HxpUiDocumentViewerComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpUiDocumentViewerComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         HxpUiDocumentViewerComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *  <hxp-ui-document-viewer
 *      [document]="document"
 *      [showRightSidebar]="showRightSidebar"
 *      [fullScreen]="fullScreen"
 *      (closeViewer)="onClose()">
 *          <ng-template #toolbar>
 *              <div>Your optional custom toolbar</div>
 *          </ng-template>
 *          <ng-template #sidebar>
 *              <div>Your optional custom sidebar</div>
 *          </ng-template>
 *  </hxp-ui-document-viewer>
 */
class HxpUiDocumentViewerComponent {
    constructor(blobDownloadService, renditionsService, viewUtilService) {
        this.blobDownloadService = blobDownloadService;
        this.renditionsService = renditionsService;
        this.viewUtilService = viewUtilService;
        this.destroyRef = inject(DestroyRef);
        /**
         * A boolean input property that determines whether the right sidebar is displayed.
         * When set to `true`, the right sidebar will be shown. When set to `false`, the right sidebar will be hidden.
         * @type {boolean}
         * @default false
         */
        this.showRightSidebar = false;
        /**
         * A boolean input property that trigger the browser native full-screen mode.
         * The default value is `false`. To trigger the full-screen mode, set the property to `true`.
         * Setting it back to `false` will not exit the full-screen mode,
         * you have to manually set it to `false` when the `closeViewer` event is emitted
         *
         * @type {boolean}
         * @default false
         */
        this.fullScreen = false;
        /**
         * Event emitter that notifies when the document has been closed.
         *
         * @event closeViewer
         */
        this.closeViewer = new EventEmitter();
        this.toolbarTemplateRef = null;
        this.sidebarTemplateRef = null;
        this.isRenditionLoading = false;
        this.isEnteredFullScreenMode = false;
    }
    ngOnChanges(changes) {
        if (changes['document']) {
            this.fetchBlob();
        }
        if (this.viewer) {
            if (changes['showRightSidebar']) {
                this.viewer.showRightSidebar = this.showRightSidebar;
            }
            if (changes['fullScreen']) {
                this.manageFullScreenMode(this.fullScreen);
            }
        }
    }
    onClose() {
        this.isEnteredFullScreenMode = false;
        this.closeViewer.emit();
    }
    manageFullScreenMode(shouldEnterFullScreen) {
        if (shouldEnterFullScreen && !this.isEnteredFullScreenMode) {
            try {
                this.viewer.enterFullScreen();
                this.isEnteredFullScreenMode = true;
            }
            catch {
                console.warn('Unable to enter full-screen mode');
            }
        }
        else if (!shouldEnterFullScreen && this.isEnteredFullScreenMode) {
            console.warn(`Not allowed to exit full-screen mode by updating fullScreen input to false, as it is handled by the native browser.
                Remember to set the fullScreen property back to false when the closeViewer event is emitted.`);
        }
    }
    fetchBlob() {
        if (this.document) {
            const documentMimeType = this.document['sysfile_blob']?.['mimeType'];
            const isMimeTypeSupported = this.viewUtilService.getViewerTypeByMimeType(documentMimeType) !== 'unknown';
            if (isMimeTypeSupported) {
                this.blobFile$ = this.blobDownloadService.downloadBlob(this.document.sys_id).pipe(catchError(() => of(new Blob())));
            }
            else {
                this.isRenditionLoading = true;
                this.renditionsService
                    .listRenditions(this.document.sys_id)
                    .pipe(switchMap((renditions = []) => iif(() => renditions.length === 0, this.requestRendition(this.document), this.getRendition(this.document))))
                    .subscribe({
                    next: (rendition) => {
                        if (hasRenditionBlob(rendition)) {
                            this.blobFile$ = this.blobDownloadService.downloadBlob(rendition.sys_id, 'sysrendition_blob');
                            this.isRenditionLoading = false;
                        }
                        else if (!this.isRenditionLoading || rendition['sysrendition_status'] === RenditionStatus.FAILED) {
                            this.blobFile$ = of(new Blob());
                        }
                    },
                    error: () => {
                        this.blobFile$ = of(new Blob());
                        this.isRenditionLoading = false;
                    },
                });
            }
        }
    }
    requestRendition(document) {
        return defer(() => this.renditionsService.requestRenditionCreation(document.sys_id, DEFAULT_RENDITION_ID).pipe(switchMap((rendition) => this.renditionsService.getRendition(rendition['sysrendition_sourceDoc'], DEFAULT_RENDITION_ID)), pollWhile(1000, (rendition) => rendition['sysrendition_sourceDoc'] === RenditionStatus.PENDING), finalize(() => (this.isRenditionLoading = false)), takeUntilDestroyed(this.destroyRef)));
    }
    getRendition(document) {
        return defer(() => this.renditionsService.getRendition(document.sys_id, DEFAULT_RENDITION_ID)).pipe(pollWhile(1000, (rendition) => rendition['sysrendition_status'] === RenditionStatus.PENDING), finalize(() => (this.isRenditionLoading = false)), takeUntilDestroyed(this.destroyRef));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpUiDocumentViewerComponent, deps: [{ token: i1.BlobDownloadService }, { token: i1.RenditionsService }, { token: i1$5.ViewUtilService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: HxpUiDocumentViewerComponent, isStandalone: true, selector: "hxp-ui-document-viewer", inputs: { document: "document", showRightSidebar: "showRightSidebar", fullScreen: "fullScreen" }, outputs: { closeViewer: "closeViewer" }, queries: [{ propertyName: "toolbarTemplateRef", first: true, predicate: ["toolbar"], descendants: true }, { propertyName: "sidebarTemplateRef", first: true, predicate: ["sidebar"], descendants: true }], viewQueries: [{ propertyName: "viewer", first: true, predicate: ["viewer"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<adf-viewer\n    id=\"hxp-viewer\"\n    #viewer\n    *ngIf=\"document\"\n    [allowFullScreen]=\"true\"\n    [allowRightSidebar]=\"!!sidebarTemplateRef\"\n    [showViewer]=\"true\"\n    [overlayMode]=\"true\"\n    [blobFile]=\"(blobFile$ | async)!\"\n    (showViewerChange)=\"onClose()\"\n>\n    <adf-viewer-toolbar class=\"hxp-document-viewer-toolbar\">\n        <ng-container *ngTemplateOutlet=\"toolbarTemplateRef || toolbar\" />\n    </adf-viewer-toolbar>\n    <adf-viewer-sidebar *ngIf=\"sidebarTemplateRef\">\n        <ng-container *ngTemplateOutlet=\"sidebarTemplateRef\" />\n    </adf-viewer-sidebar>\n</adf-viewer>\n<ng-template #toolbar />\n\n", styles: ["#hxp-viewer adf-toolbar-title{display:flex;flex:1;flex-direction:row;align-items:center}#hxp-viewer .adf-viewer-sidebar{min-width:436px;display:block;height:100%}#hxp-viewer .adf-viewer-sidebars .adf-viewer__sidebar{width:436px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: ViewerComponent, selector: "adf-viewer", inputs: ["urlFile", "blobFile", "showViewer", "allowGoBack", "allowFullScreen", "showToolbar", "overlayMode", "allowNavigate", "canNavigateBefore", "canNavigateNext", "allowLeftSidebar", "allowRightSidebar", "showRightSidebar", "showLeftSidebar", "sidebarRightTemplate", "sidebarLeftTemplate", "readOnly", "allowedEditActions", "tracks", "mimeType", "sidebarRightTemplateContext", "sidebarLeftTemplateContext", "closeButtonPosition", "hideInfoButton", "viewerExtensions", "nodeId", "nodeMimeType", "customError", "showToolbarDividers", "title", "fileName"], outputs: ["downloadFile", "navigateBefore", "navigateNext", "showViewerChange", "submitFile"] }, { kind: "component", type: ViewerToolbarComponent, selector: "adf-viewer-toolbar" }, { kind: "component", type: ViewerSidebarComponent, selector: "adf-viewer-sidebar" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatDialogModule }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: HxpUiDocumentViewerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-ui-document-viewer', encapsulation: ViewEncapsulation.None, standalone: true, imports: [NgIf, ViewerComponent, ViewerToolbarComponent, ViewerSidebarComponent, AsyncPipe, TranslatePipe, NgTemplateOutlet, MatDialogModule], template: "<adf-viewer\n    id=\"hxp-viewer\"\n    #viewer\n    *ngIf=\"document\"\n    [allowFullScreen]=\"true\"\n    [allowRightSidebar]=\"!!sidebarTemplateRef\"\n    [showViewer]=\"true\"\n    [overlayMode]=\"true\"\n    [blobFile]=\"(blobFile$ | async)!\"\n    (showViewerChange)=\"onClose()\"\n>\n    <adf-viewer-toolbar class=\"hxp-document-viewer-toolbar\">\n        <ng-container *ngTemplateOutlet=\"toolbarTemplateRef || toolbar\" />\n    </adf-viewer-toolbar>\n    <adf-viewer-sidebar *ngIf=\"sidebarTemplateRef\">\n        <ng-container *ngTemplateOutlet=\"sidebarTemplateRef\" />\n    </adf-viewer-sidebar>\n</adf-viewer>\n<ng-template #toolbar />\n\n", styles: ["#hxp-viewer adf-toolbar-title{display:flex;flex:1;flex-direction:row;align-items:center}#hxp-viewer .adf-viewer-sidebar{min-width:436px;display:block;height:100%}#hxp-viewer .adf-viewer-sidebars .adf-viewer__sidebar{width:436px}\n"] }]
        }], ctorParameters: () => [{ type: i1.BlobDownloadService }, { type: i1.RenditionsService }, { type: i1$5.ViewUtilService }], propDecorators: { document: [{
                type: Input
            }], showRightSidebar: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], closeViewer: [{
                type: Output
            }], viewer: [{
                type: ViewChild,
                args: ['viewer']
            }], toolbarTemplateRef: [{
                type: ContentChild,
                args: ['toolbar', { static: false }]
            }], sidebarTemplateRef: [{
                type: ContentChild,
                args: ['sidebar', { static: false }]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a skeleton to display during content loading.
 *
 * To use the `TableSkeletonLoaderComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { TableSkeletonLoaderComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         TableSkeletonLoaderComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-table-skeleton-loader></hxp-table-skeleton-loader>
 */
class TableSkeletonLoaderComponent {
    constructor() {
        /**
         * Indicates the number of rows to display in the skeleton table.
         * @type {number}
         * @default 5
         */
        this.skeletonRows = TableSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    /**
     * Default value of skeleton tree rows to display.
     * @readonly
     * @type {number}
     */
    static { this.DEFAULT_SKELETON_ROWS = 5; }
    ngOnChanges() {
        if (!this.skeletonRows && this.skeletonRows !== 0) {
            this.skeletonRows = TableSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        }
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    skeletonRowTrackBy(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: TableSkeletonLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: TableSkeletonLoaderComponent, isStandalone: true, selector: "hxp-table-skeleton-loader", inputs: { skeletonRows: "skeletonRows" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-skeleton-table-wrapper\">\n    <table class=\"hxp-skeleton-table\">\n        <thead>\n            <tr>\n                <th class=\"hxp-skeleton-checkbox-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-checkbox\"></div></th>\n                <th class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-100\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-80\"></div></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n                <td class=\"hxp-skeleton-checkbox-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-checkbox\"><input type=\"checkbox\" disabled></div></td>\n                <td class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-small\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-wrapper{padding-bottom:50%}.hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}thead th,tbody td{padding:20px;text-align:start}thead th{border-bottom:2px solid #f9f9fc;padding-top:15px;padding-bottom:15px}.hxp-skeleton-box{background-color:#d1d5db;border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-checkbox{width:20px;height:20px;background:transparent}.hxp-skeleton-icon{width:20px;height:20px}.hxp-skeleton-header-70{width:70%;height:16px}.hxp-skeleton-header-80{width:80%;height:16px}.hxp-skeleton-header-100,.hxp-skeleton-text-100{width:100%;height:16px}.hxp-skeleton-text-50{width:50%;height:16px}.hxp-skeleton-small{width:50px;height:16px}.hxp-skeleton-checkbox-cell,.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: TableSkeletonLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-table-skeleton-loader', standalone: true, imports: [NgFor], template: "<div class=\"hxp-skeleton-table-wrapper\">\n    <table class=\"hxp-skeleton-table\">\n        <thead>\n            <tr>\n                <th class=\"hxp-skeleton-checkbox-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-checkbox\"></div></th>\n                <th class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-100\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-80\"></div></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n                <td class=\"hxp-skeleton-checkbox-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-checkbox\"><input type=\"checkbox\" disabled></div></td>\n                <td class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-small\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-wrapper{padding-bottom:50%}.hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}thead th,tbody td{padding:20px;text-align:start}thead th{border-bottom:2px solid #f9f9fc;padding-top:15px;padding-bottom:15px}.hxp-skeleton-box{background-color:#d1d5db;border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-checkbox{width:20px;height:20px;background:transparent}.hxp-skeleton-icon{width:20px;height:20px}.hxp-skeleton-header-70{width:70%;height:16px}.hxp-skeleton-header-80{width:80%;height:16px}.hxp-skeleton-header-100,.hxp-skeleton-text-100{width:100%;height:16px}.hxp-skeleton-text-50{width:50%;height:16px}.hxp-skeleton-small{width:50px;height:16px}.hxp-skeleton-checkbox-cell,.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"] }]
        }], propDecorators: { skeletonRows: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionContextMenuActionsService {
    constructor(documentSingleItemDownloadHandler, documentShareHandler, documentVersionRestoreHandler, documentVersionEditHandler, documentVersionDeleteHandler) {
        this.documentSingleItemDownloadHandler = documentSingleItemDownloadHandler;
        this.documentShareHandler = documentShareHandler;
        this.documentVersionRestoreHandler = documentVersionRestoreHandler;
        this.documentVersionEditHandler = documentVersionEditHandler;
        this.documentVersionDeleteHandler = documentVersionDeleteHandler;
    }
    getVersionContextActions(data, parentDocument) {
        const context = {
            documents: [data],
            parentDocument,
            showPanel: 'version',
        };
        const actions = [
            {
                data,
                model: {
                    key: 'download',
                    icon: 'download',
                    title: 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE',
                    visible: this.documentSingleItemDownloadHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentSingleItemDownloadHandler, context),
            },
            {
                data,
                model: {
                    key: 'share',
                    icon: 'share',
                    title: 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE',
                    visible: this.documentShareHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentShareHandler, context),
            },
        ];
        if (this.documentVersionRestoreHandler) {
            actions.push({
                data,
                model: {
                    key: 'restore-version',
                    icon: 'history',
                    title: 'RESTORE_VERSION.TOOLBAR.BUTTONS.RESTORE.TITLE',
                    visible: this.documentVersionRestoreHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentVersionRestoreHandler, context),
            });
        }
        if (this.documentVersionEditHandler) {
            actions.push({
                data,
                model: {
                    key: 'edit-version',
                    icon: 'edit',
                    title: 'MANAGE_VERSIONS.DIALOG.MORE_MENU.EDIT',
                    visible: this.documentVersionEditHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentVersionEditHandler, context),
            });
        }
        if (this.documentVersionDeleteHandler) {
            actions.push({
                data,
                model: {
                    key: 'delete-version',
                    icon: 'delete',
                    title: 'MANAGE_VERSIONS.DIALOG.MORE_MENU.DELETE',
                    visible: this.documentVersionDeleteHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentVersionDeleteHandler, context),
            });
        }
        return actions;
    }
    toContextAction(documentActionService, context) {
        const subject = new Subject();
        subject.subscribe({
            next: () => {
                documentActionService.execute(context);
            },
        });
        return subject;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionContextMenuActionsService, deps: [{ token: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE }, { token: HXP_DOCUMENT_SHARE_ACTION_SERVICE }, { token: HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE }, { token: HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE }, { token: HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionContextMenuActionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionContextMenuActionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE]
                }] }, { type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_SHARE_ACTION_SERVICE]
                }] }, { type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE]
                }] }, { type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE]
                }] }, { type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE]
                }] }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class EditVersionDialogComponent {
    constructor(version, fb, datePipe) {
        this.version = version;
        this.fb = fb;
        this.datePipe = datePipe;
        this.isUpdating = false;
        this.versionUpdated$ = new Subject();
        this.dateFormat = 'medium';
    }
    ngOnInit() {
        this.form = this.fb.group({
            sysver_title: [
                this.version?.sysver_title ||
                    this.datePipe.transform(this.version.sys_modified, this.dateFormat) ||
                    this.datePipe.transform(this.version.sysver_created, this.dateFormat) ||
                    '',
                Validators.required,
            ],
            sysver_description: [this.version?.sysver_description || ''],
        });
    }
    save() {
        if (this.form.invalid) {
            return;
        }
        this.isUpdating = true;
        const updatedVersion = {
            sys_id: this.version.sys_id,
            sysver_title: this.form.value.sysver_title,
            sysver_description: this.form.value.sysver_description,
        };
        this.versionUpdated$.next(updatedVersion);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: EditVersionDialogComponent, deps: [{ token: MAT_DIALOG_DATA }, { token: i1$2.FormBuilder }, { token: i2$2.DatePipe }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: EditVersionDialogComponent, isStandalone: true, selector: "hxp-edit-version-dialog", ngImport: i0, template: "<div class=\"hxp-edit-version-dialog\">\n    <h2 mat-dialog-title>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.TITLE' | translate }}</h2>\n    <mat-dialog-content>\n        <form [formGroup]=\"form\" class=\"hxp-manage-versions-dialog-form\">\n            <div class=\"hxp-manage-versions-dialog-input-area\">\n                <div class=\"hxp-manage-versions-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.FIELD_TITLE' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\">\n                        <input matInput data-automation-id=\"title-field\" formControlName=\"sysver_title\" (keydown)=\"$event.stopPropagation()\" />\n                    </mat-form-field>\n                </div>\n            </div>\n            <div class=\"hxp-manage-versions-dialog-input-area\">\n                <div class=\"hxp-manage-versions-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.DESCRIPTION' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\" hideRequiredMarker>\n                        <textarea\n                            matInput\n                            formControlName=\"sysver_description\"\n                            placeholder=\"{{ 'MANAGE_VERSIONS.EDIT_DIALOG.PLACEHOLDER_DESCRIPTION' | translate }}\"\n                            data-automation-id=\"description-field\"\n                            (keydown)=\"$event.stopPropagation()\"\n                        >\n                        </textarea>\n                    </mat-form-field>\n                </div>\n            </div>\n        </form>\n    </mat-dialog-content>\n    <mat-dialog-actions align=\"end\" class=\"hxp-edit-version-dialog-footer-action\">\n        <button mat-button mat-dialog-close>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-button class=\"hxp-primary-button\" [disabled]=\"form.invalid || isUpdating\" [ngClass]=\"{'hxp-loading': isUpdating}\" (click)=\"save()\">\n            <span class=\"hxp-manage-version-dialog-save-btn-label\">\n                <mat-progress-spinner *ngIf=\"isUpdating\" mode=\"indeterminate\" diameter=\"15\" />\n                <span class=\"hxp-manage-version-dialog-save-btn-title\">\n                    {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.SAVE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-edit-version-dialog .hxp-manage-versions-dialog-form{margin-top:24px}.hxp-edit-version-dialog .hxp-edit-version-dialog-footer-action{padding:0 24px 24px}.hxp-edit-version-dialog .hxp-edit-version-dialog-footer-action .hxp-manage-version-dialog-save-btn-label{display:flex;justify-content:space-between;align-items:center}.hxp-edit-version-dialog .hxp-edit-version-dialog-footer-action button.hxp-loading span.hxp-manage-version-dialog-save-btn-title{margin-left:12px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area{display:flex;flex-direction:column;margin-bottom:24px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-manage-versions-dialog-input-title{margin-bottom:12px;color:var(--adf-theme-foreground-secondary-text-color)}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area{border:1px solid var(--adf-edit-process-filter-header-description-color);border-radius:8px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field{width:100%}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field input,.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{color:var(--adf-theme-foreground-text-color)}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{resize:none;min-height:48px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .mat-mdc-form-field-subscript-wrapper,.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .mdc-line-ripple{display:none}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: EditVersionDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-edit-version-dialog', encapsulation: ViewEncapsulation.None, standalone: true, imports: [
                        NgIf,
                        NgClass,
                        MatDialogModule,
                        MatButtonModule,
                        ReactiveFormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatProgressSpinnerModule,
                        TranslatePipe,
                        AsyncPipe,
                        DatePipe,
                    ], template: "<div class=\"hxp-edit-version-dialog\">\n    <h2 mat-dialog-title>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.TITLE' | translate }}</h2>\n    <mat-dialog-content>\n        <form [formGroup]=\"form\" class=\"hxp-manage-versions-dialog-form\">\n            <div class=\"hxp-manage-versions-dialog-input-area\">\n                <div class=\"hxp-manage-versions-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.FIELD_TITLE' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\">\n                        <input matInput data-automation-id=\"title-field\" formControlName=\"sysver_title\" (keydown)=\"$event.stopPropagation()\" />\n                    </mat-form-field>\n                </div>\n            </div>\n            <div class=\"hxp-manage-versions-dialog-input-area\">\n                <div class=\"hxp-manage-versions-dialog-input-title\">\n                    <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.DESCRIPTION' | translate }}</mat-label>\n                </div>\n                <div class=\"hxp-input-area\">\n                    <mat-form-field class=\"hxp-edit-form-field\" hideRequiredMarker>\n                        <textarea\n                            matInput\n                            formControlName=\"sysver_description\"\n                            placeholder=\"{{ 'MANAGE_VERSIONS.EDIT_DIALOG.PLACEHOLDER_DESCRIPTION' | translate }}\"\n                            data-automation-id=\"description-field\"\n                            (keydown)=\"$event.stopPropagation()\"\n                        >\n                        </textarea>\n                    </mat-form-field>\n                </div>\n            </div>\n        </form>\n    </mat-dialog-content>\n    <mat-dialog-actions align=\"end\" class=\"hxp-edit-version-dialog-footer-action\">\n        <button mat-button mat-dialog-close>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-button class=\"hxp-primary-button\" [disabled]=\"form.invalid || isUpdating\" [ngClass]=\"{'hxp-loading': isUpdating}\" (click)=\"save()\">\n            <span class=\"hxp-manage-version-dialog-save-btn-label\">\n                <mat-progress-spinner *ngIf=\"isUpdating\" mode=\"indeterminate\" diameter=\"15\" />\n                <span class=\"hxp-manage-version-dialog-save-btn-title\">\n                    {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.SAVE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-edit-version-dialog .hxp-manage-versions-dialog-form{margin-top:24px}.hxp-edit-version-dialog .hxp-edit-version-dialog-footer-action{padding:0 24px 24px}.hxp-edit-version-dialog .hxp-edit-version-dialog-footer-action .hxp-manage-version-dialog-save-btn-label{display:flex;justify-content:space-between;align-items:center}.hxp-edit-version-dialog .hxp-edit-version-dialog-footer-action button.hxp-loading span.hxp-manage-version-dialog-save-btn-title{margin-left:12px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area{display:flex;flex-direction:column;margin-bottom:24px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-manage-versions-dialog-input-title{margin-bottom:12px;color:var(--adf-theme-foreground-secondary-text-color)}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area{border:1px solid var(--adf-edit-process-filter-header-description-color);border-radius:8px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field{width:100%}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field input,.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{color:var(--adf-theme-foreground-text-color)}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .hxp-input-area .hxp-edit-form-field textarea{resize:none;min-height:48px}.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .mat-mdc-form-field-subscript-wrapper,.hxp-edit-version-dialog .hxp-manage-versions-dialog-input-area .mdc-line-ripple{display:none}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }, { type: i1$2.FormBuilder }, { type: i2$2.DatePipe }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DeleteVersionDialogComponent {
    constructor(version) {
        this.version = version;
        this.isDeleting = false;
        this.versionDeleted$ = new Subject();
    }
    delete() {
        this.isDeleting = true;
        this.versionDeleted$.next(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DeleteVersionDialogComponent, deps: [{ token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: DeleteVersionDialogComponent, isStandalone: true, selector: "hxp-delete-version-dialog", ngImport: i0, template: "<div class=\"hxp-delete-version-dialog mat-mdc-dialog-container\">\n    <h2 mat-dialog-title>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.TITLE' | translate }}</h2>\n    <mat-dialog-content>\n        <p class=\"hxp-delete-version-dialog-description\">{{ 'MANAGE_VERSIONS.DELETE_DIALOG.DESCRIPTION' | translate }}</p>\n    </mat-dialog-content>\n    <mat-dialog-actions align=\"end\" class=\"hxp-delete-version-dialog-footer-action\">\n        <button mat-button mat-dialog-close>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-flat-button data-automation-id=\"confirm-delete\" color=\"warn\" [disabled]=\"isDeleting\" [ngClass]=\"{'hxp-loading': isDeleting}\" (click)=\"delete()\">\n            <span class=\"hxp-manage-version-dialog-delete-btn-label\">\n                <mat-progress-spinner *ngIf=\"isDeleting\" mode=\"indeterminate\" diameter=\"15\" />\n                <span class=\"hxp-manage-version-dialog-delete-btn-title\">\n                    {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.DELETE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-delete-version-dialog .hxp-delete-version-dialog-footer-action{padding:0 24px 24px}.hxp-delete-version-dialog .hxp-delete-version-dialog-footer-action .hxp-manage-version-dialog-delete-btn-label{display:flex;justify-content:space-between;align-items:center}.hxp-delete-version-dialog .hxp-delete-version-dialog-footer-action button.hxp-loading span.hxp-manage-version-dialog-delete-btn-title{margin-left:12px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DeleteVersionDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-delete-version-dialog', encapsulation: ViewEncapsulation.None, standalone: true, imports: [NgIf, NgClass, MatDialogModule, MatButtonModule, MatProgressSpinnerModule, TranslatePipe], template: "<div class=\"hxp-delete-version-dialog mat-mdc-dialog-container\">\n    <h2 mat-dialog-title>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.TITLE' | translate }}</h2>\n    <mat-dialog-content>\n        <p class=\"hxp-delete-version-dialog-description\">{{ 'MANAGE_VERSIONS.DELETE_DIALOG.DESCRIPTION' | translate }}</p>\n    </mat-dialog-content>\n    <mat-dialog-actions align=\"end\" class=\"hxp-delete-version-dialog-footer-action\">\n        <button mat-button mat-dialog-close>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.CANCEL' | translate }}</button>\n        <button mat-flat-button data-automation-id=\"confirm-delete\" color=\"warn\" [disabled]=\"isDeleting\" [ngClass]=\"{'hxp-loading': isDeleting}\" (click)=\"delete()\">\n            <span class=\"hxp-manage-version-dialog-delete-btn-label\">\n                <mat-progress-spinner *ngIf=\"isDeleting\" mode=\"indeterminate\" diameter=\"15\" />\n                <span class=\"hxp-manage-version-dialog-delete-btn-title\">\n                    {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.DELETE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-delete-version-dialog .hxp-delete-version-dialog-footer-action{padding:0 24px 24px}.hxp-delete-version-dialog .hxp-delete-version-dialog-footer-action .hxp-manage-version-dialog-delete-btn-label{display:flex;justify-content:space-between;align-items:center}.hxp-delete-version-dialog .hxp-delete-version-dialog-footer-action button.hxp-loading span.hxp-manage-version-dialog-delete-btn-title{margin-left:12px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PanelSkeletonLoaderComponent {
    constructor() {
        /**
         * Indicates the number of rows to display in the skeleton panel.
         * @type {number}
         * @default 10
         */
        this.skeletonRows = PanelSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    /**
     * Default value of skeleton panel rows to display.
     * @readonly
     * @type {number}
     */
    static { this.DEFAULT_SKELETON_ROWS = 10; }
    ngOnChanges() {
        if (!this.skeletonRows && this.skeletonRows !== 0) {
            this.skeletonRows = PanelSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        }
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    skeletonRowTrackBy(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PanelSkeletonLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: PanelSkeletonLoaderComponent, isStandalone: true, selector: "hxp-panel-skeleton-loader", inputs: { skeletonRows: "skeletonRows" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-skeleton-table-container\">\n    <table class=\"hxp-skeleton-table\" aria-hidden=\"true\" *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n        <tbody>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-container{width:100%}.hxp-skeleton-table{border-collapse:collapse;table-layout:fixed;margin-bottom:20px;width:100%}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:#d1d5db;border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-text-25{width:25%;height:15px}.hxp-skeleton-text-50{width:50%;height:15px}.hxp-skeleton-text-100{width:100%;height:15px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: PanelSkeletonLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-panel-skeleton-loader', standalone: true, imports: [NgFor], template: "<div class=\"hxp-skeleton-table-container\">\n    <table class=\"hxp-skeleton-table\" aria-hidden=\"true\" *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n        <tbody>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-container{width:100%}.hxp-skeleton-table{border-collapse:collapse;table-layout:fixed;margin-bottom:20px;width:100%}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:#d1d5db;border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-text-25{width:25%;height:15px}.hxp-skeleton-text-50{width:50%;height:15px}.hxp-skeleton-text-100{width:100%;height:15px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"] }]
        }], propDecorators: { skeletonRows: [{
                type: Input
            }] } });

class ManageVersionsSidebarComponent {
    constructor(documentRouterService, documentVersionsService, hxpNotificationService, dialog, versionContextMenuActionsService) {
        this.documentRouterService = documentRouterService;
        this.documentVersionsService = documentVersionsService;
        this.hxpNotificationService = hxpNotificationService;
        this.dialog = dialog;
        this.versionContextMenuActionsService = versionContextMenuActionsService;
        /**
         * Emits an event when the sidebar is closed
         */
        this.closeVersionsSidebar = new EventEmitter();
        this.documentVersions = [];
        this.isLoading = false;
        this.workingCopy = undefined;
        this.selectedDocument = undefined;
        this.contextActionMenuTemplateRef = null;
        this.contextMenuPosition = { x: '0px', y: '0px' };
        this.contextActions = [];
        this.isNewContextMenu = false;
        this.featuresService = inject(FeaturesServiceToken);
    }
    ngOnInit() {
        this.featuresService.isOn$(ADF_HX_CONTENT_SERVICES_INTERNAL.VERSIONING_NEW_CONTEXT_MENU).subscribe((isOn) => {
            this.isNewContextMenu = isOn;
        });
        merge(this.documentVersionsService.versionDeleted$, this.documentVersionsService.versionUpdated$).subscribe(() => {
            this.loadVersions();
        });
    }
    ngOnChanges() {
        if (this.document) {
            this.selectedDocument = this.document;
            this.loadVersions();
        }
    }
    redirectToVersion(document) {
        if (document) {
            this.selectedDocument = document;
            this.documentRouterService.navigateTo(document);
        }
    }
    openEditVersionDialog(version) {
        const editDialogRef = this.dialog.open(EditVersionDialogComponent, {
            width: DialogConfig.small.width,
            data: version,
        });
        editDialogRef.componentInstance.versionUpdated$.pipe(take(1)).subscribe((updatedVersion) => {
            this.updateVersion(updatedVersion, editDialogRef);
        });
    }
    openDeleteVersionDialog(version) {
        const deleteDialogRef = this.dialog.open(DeleteVersionDialogComponent, {
            width: DialogConfig.small.width,
            data: version,
        });
        deleteDialogRef.componentInstance.versionDeleted$.pipe(take(1)).subscribe((status) => {
            if (status) {
                this.deleteVersion(version, deleteDialogRef);
            }
        });
    }
    onClose() {
        this.closeVersionsSidebar.emit();
    }
    onContextMenu(event, version) {
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuPosition = { x: `${event.clientX}px`, y: `${event.clientY}px` };
        const targetHtmlElement = event.target;
        if (targetHtmlElement.tagName !== 'BUTTON' && targetHtmlElement.tagName !== 'MAT-ICON') {
            const node = targetHtmlElement.closest('.hxp-version-item');
            const trigger = node?.querySelector('.hxp-menu-trigger');
            this.contextActions = this.getContextActions(version);
            if (this.contextActions.some((action) => action.model.visible)) {
                trigger?.dispatchEvent(new MouseEvent('click'));
            }
        }
        else {
            this.contextActions = this.getContextActions(version);
            if (this.contextActions.some((action) => action.model.visible)) {
                this.hiddenTrigger?.openMenu();
            }
        }
    }
    getContextActions(version) {
        return this.versionContextMenuActionsService.getVersionContextActions(version, this.workingCopy);
    }
    loadVersions() {
        if (!this.selectedDocument) {
            return;
        }
        this.isLoading = true;
        this.documentVersionsService
            .getCurrentDocument(this.selectedDocument)
            .pipe(take(1), switchMap$1((currentDoc) => {
            this.workingCopy = currentDoc;
            return this.documentVersionsService
                .getVersions(currentDoc)
                .pipe(map$1((versions) => [currentDoc, ...versions]));
        }), finalize$1(() => (this.isLoading = false)))
            .subscribe({
            next: (mergedVersions) => {
                this.documentVersions = mergedVersions;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }
    updateVersion(updatedVersion, editDialogRef) {
        if (!updatedVersion?.sys_id) {
            return;
        }
        this.documentVersionsService
            .updateVersion(updatedVersion)
            .pipe(finalize$1(() => (editDialogRef.componentInstance.isUpdating = false)))
            .subscribe({
            next: () => {
                editDialogRef.close();
                this.loadVersions();
                this.hxpNotificationService.showSuccess('MANAGE_VERSIONS.EDIT_DIALOG.NOTIFICATION.SUCCESS');
            },
            error: (error) => {
                console.error(error);
                this.hxpNotificationService.showError('MANAGE_VERSIONS.EDIT_DIALOG.NOTIFICATION.ERROR');
            },
        });
    }
    deleteVersion(version, deleteDialogRef) {
        if (!version.sys_id) {
            return;
        }
        this.documentVersionsService
            .deleteVersion(version)
            .pipe(finalize$1(() => (deleteDialogRef.componentInstance.isDeleting = false)))
            .subscribe({
            next: () => {
                deleteDialogRef.close();
                this.loadVersions();
                this.hxpNotificationService.showSuccess('MANAGE_VERSIONS.DELETE_DIALOG.NOTIFICATION.SUCCESS');
                if (version.sys_id === this.selectedDocument?.sys_id) {
                    this.redirectToVersion(this.workingCopy);
                }
            },
            error: (error) => {
                console.error(error);
                this.hxpNotificationService.showError('MANAGE_VERSIONS.DELETE_DIALOG.NOTIFICATION.ERROR');
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageVersionsSidebarComponent, deps: [{ token: i1.DocumentRouterService }, { token: i1.DocumentVersionsService }, { token: i1.HxpNotificationService }, { token: i1$1.MatDialog }, { token: VersionContextMenuActionsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.9", type: ManageVersionsSidebarComponent, isStandalone: true, selector: "hxp-manage-versions-sidebar", inputs: { document: "document" }, outputs: { closeVersionsSidebar: "closeVersionsSidebar" }, queries: [{ propertyName: "contextActionMenuTemplateRef", first: true, predicate: ["contextActionMenu"], descendants: true }], viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: ["trigger"], descendants: true }, { propertyName: "hiddenTrigger", first: true, predicate: ["hiddenTrigger"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<adf-info-drawer-layout>\n    <div info-drawer-content>\n        <div class=\"hxp-manage-versions-sidebar-header\">\n            <div class=\"mat-h1\">{{ 'MANAGE_VERSIONS.DIALOG.TITLE' | translate }}</div>\n            <button\n                mat-icon-button\n                class=\"hxp-manage-versions-sidebar-close-btn\"\n                attr.aria-label=\"{{ 'MANAGE_VERSIONS.DIALOG.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n            >\n                <mat-icon>close</mat-icon>\n            </button>\n        </div>\n        @if(isLoading) {\n            <hxp-panel-skeleton-loader [skeletonRows]=\"10\" class=\"hxp-version-panel-skeleton-loader\"/>\n        } @else {\n            <div class=\"hxp-version-list\">\n                @for(version of documentVersions; track version) {\n                    <button\n                        type=\"button\" class=\"hxp-version-item\"\n                        [class.hxp-current-version]=\"!version.sysver_isVersion\"\n                        [class.active]=\"document?.sys_id === version.sys_id\"\n                        [ngClass]=\"isNewContextMenu ? 'hxp-has-new-context' : 'hxp-has-old-context'\"\n                        (click)=\"redirectToVersion(version)\"\n                        (contextmenu)=\"onContextMenu($event, version)\"\n                    >\n                        @if(!version.sysver_isVersion){\n                            <div class=\"hxp-version-header\">\n                                <span class=\"hxp-version-title\" matTooltip=\"{{ version?.sys_modified | date: 'medium' }}\">\n                                    {{ version?.sys_modified | date: 'medium' }}\n                                </span>\n                                    @if(isNewContextMenu) {\n                                        <div class=\"hxp-context-btn\">\n                                            <button\n                                                mat-icon-button\n                                                [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                                (click)=\"onContextMenu($event, version)\"\n                                            >\n                                                <mat-icon>more_vert</mat-icon>\n                                            </button>\n                                        </div>\n                                    }\n                            </div>\n                            <div class=\"hxp-version-description\" matTooltip=\"{{ version.sysver_description }}\">\n                                {{ 'MANAGE_VERSIONS.DIALOG.CURRENT_VERSION' | translate }}\n                            </div>\n                            <div class=\"hxp-version-meta\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sys_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sys_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        } @else {\n                            <div class=\"hxp-version-header\">\n                                <span class=\"hxp-version-title\" matTooltip=\"{{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\">\n                                    {{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\n                                </span>\n                                @if(isNewContextMenu) {\n                                    <div class=\"hxp-context-btn\">\n                                        <button\n                                            mat-icon-button\n                                            [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                            (click)=\"onContextMenu($event, version)\"\n                                        >\n                                            <mat-icon>more_vert</mat-icon>\n                                        </button>\n                                    </div>\n                                } @else {\n                                    <button mat-icon-button class=\"hxp-version-menu\" [matMenuTriggerFor]=\"versionMenu\" (click)=\"$event.stopPropagation()\">\n                                        <mat-icon>more_vert</mat-icon>\n                                    </button>\n                                    <mat-menu #versionMenu=\"matMenu\" class=\"hxp-version-menu-panel\">\n                                        <button mat-menu-item (click)=\"openEditVersionDialog(version)\">\n                                            <mat-icon>edit</mat-icon>\n                                            <span>{{ 'MANAGE_VERSIONS.DIALOG.MORE_MENU.EDIT' | translate }}</span>\n                                        </button>\n                                        <button mat-menu-item (click)=\"openDeleteVersionDialog(version)\">\n                                            <mat-icon>delete</mat-icon>\n                                            <span>{{ 'MANAGE_VERSIONS.DIALOG.MORE_MENU.DELETE' | translate }}</span>\n                                        </button>\n                                    </mat-menu>\n                                }\n                            </div>\n                            @if(version.sysver_description) {\n                                <div class=\"hxp-version-description\" matTooltip=\"{{ version.sysver_description }}\">\n                                    {{ version.sysver_description }}\n                                </div>\n                            }\n                            <div class=\"hxp-version-meta\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sysver_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sysver_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        }\n                        <div class=\"hxp-version-footer\">\n                            <span>\n                                {{ version.sysver_expires\n                                ? (('MANAGE_VERSIONS.DIALOG.EXPIRES' | translate) + version.sysver_expires | date: 'medium')\n                                : ('MANAGE_VERSIONS.DIALOG.NEVER_EXPIRES' | translate) }}\n                            </span>\n                        </div>\n                        @if(isNewContextMenu) {\n                            <div\n                                #hiddenTrigger=\"matMenuTrigger\"\n                                class=\"hxp-menu-trigger\"\n                                [style.left]=\"contextMenuPosition.x\"\n                                [style.top]=\"contextMenuPosition.y\"\n                                [matMenuTriggerFor]=\"contextMenu\"\n                                [matMenuTriggerData]=\"{ actions: contextActions }\"\n                            ></div>\n                        }\n                    </button>\n                }\n            </div>\n        }\n    </div>\n    <mat-menu #contextMenu=\"matMenu\" class=\"hxp-context-menu\">\n        <ng-container *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n    </mat-menu>\n</adf-info-drawer-layout>\n", styles: ["adf-info-drawer-layout .hxp-version-panel-skeleton-loader{display:inline-block;width:370px}adf-info-drawer-layout .adf-info-drawer-layout-content{position:relative}adf-info-drawer-layout .adf-info-drawer-layout-header{display:none}adf-info-drawer-layout .hxp-manage-versions-sidebar-header{display:flex;justify-content:space-between;align-items:center;padding:24px 0}adf-info-drawer-layout .hxp-manage-versions-sidebar-header h1{font-size:var(--theme-title-font-size, 24px);margin:0;padding:0 16px;font-weight:400;display:inline-block;text-overflow:ellipsis;width:260px;overflow:hidden}adf-info-drawer-layout .hxp-manage-versions-sidebar-close-btn{background-color:transparent;border:0;cursor:pointer;align-items:center}adf-info-drawer-layout .hxp-version-list{display:flex;flex-direction:column;flex:1;overflow-y:auto;padding:12px;height:100vh}adf-info-drawer-layout .hxp-version-list .hxp-version-item{padding:0 24px;margin-bottom:8px;text-align:left;cursor:pointer;border:0;background:#fff}adf-info-drawer-layout .hxp-version-list .hxp-version-item:hover,adf-info-drawer-layout .hxp-version-list .hxp-version-item.active{background:var(--adf-filter-chip-background-color)}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-current-version .hxp-version-description{color:var(--theme-primary-color, #5654ac);font-size:14px;font-weight:600}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-current-version.hxp-has-old-context .hxp-version-title{padding-top:12px;padding-bottom:12px}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-has-old-context .hxp-version-header button{margin-right:-24px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header{display:flex;justify-content:space-between;align-items:center}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header .hxp-context-btn{position:relative;right:-24px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{padding-bottom:12px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-title{font-weight:700}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-title,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{max-width:320px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-meta,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-footer{font-size:12px;padding-bottom:12px;color:#4b5563}adf-info-drawer-layout .hxp-menu-trigger{visibility:hidden;position:fixed}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "pipe", type: UserResolverPipe, name: "hxpUserResolverPipe" }, { kind: "pipe", type: DatePipe, name: "date" }, { kind: "component", type: InfoDrawerLayoutComponent, selector: "adf-info-drawer-layout", inputs: ["showHeader"] }, { kind: "directive", type: InfoDrawerContentDirective, selector: "[adf-info-drawer-content], [info-drawer-content]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: PanelSkeletonLoaderComponent, selector: "hxp-panel-skeleton-loader", inputs: ["skeletonRows"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i6.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i6.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i6.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageVersionsSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-manage-versions-sidebar', standalone: true, encapsulation: ViewEncapsulation.None, imports: [
                        NgTemplateOutlet,
                        TranslatePipe,
                        UserResolverPipe,
                        DatePipe,
                        InfoDrawerLayoutComponent,
                        InfoDrawerContentDirective,
                        MatButtonModule,
                        MatIconModule,
                        PanelSkeletonLoaderComponent,
                        MatMenuModule,
                        MatTooltipModule,
                        NgClass,
                    ], template: "<adf-info-drawer-layout>\n    <div info-drawer-content>\n        <div class=\"hxp-manage-versions-sidebar-header\">\n            <div class=\"mat-h1\">{{ 'MANAGE_VERSIONS.DIALOG.TITLE' | translate }}</div>\n            <button\n                mat-icon-button\n                class=\"hxp-manage-versions-sidebar-close-btn\"\n                attr.aria-label=\"{{ 'MANAGE_VERSIONS.DIALOG.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n            >\n                <mat-icon>close</mat-icon>\n            </button>\n        </div>\n        @if(isLoading) {\n            <hxp-panel-skeleton-loader [skeletonRows]=\"10\" class=\"hxp-version-panel-skeleton-loader\"/>\n        } @else {\n            <div class=\"hxp-version-list\">\n                @for(version of documentVersions; track version) {\n                    <button\n                        type=\"button\" class=\"hxp-version-item\"\n                        [class.hxp-current-version]=\"!version.sysver_isVersion\"\n                        [class.active]=\"document?.sys_id === version.sys_id\"\n                        [ngClass]=\"isNewContextMenu ? 'hxp-has-new-context' : 'hxp-has-old-context'\"\n                        (click)=\"redirectToVersion(version)\"\n                        (contextmenu)=\"onContextMenu($event, version)\"\n                    >\n                        @if(!version.sysver_isVersion){\n                            <div class=\"hxp-version-header\">\n                                <span class=\"hxp-version-title\" matTooltip=\"{{ version?.sys_modified | date: 'medium' }}\">\n                                    {{ version?.sys_modified | date: 'medium' }}\n                                </span>\n                                    @if(isNewContextMenu) {\n                                        <div class=\"hxp-context-btn\">\n                                            <button\n                                                mat-icon-button\n                                                [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                                (click)=\"onContextMenu($event, version)\"\n                                            >\n                                                <mat-icon>more_vert</mat-icon>\n                                            </button>\n                                        </div>\n                                    }\n                            </div>\n                            <div class=\"hxp-version-description\" matTooltip=\"{{ version.sysver_description }}\">\n                                {{ 'MANAGE_VERSIONS.DIALOG.CURRENT_VERSION' | translate }}\n                            </div>\n                            <div class=\"hxp-version-meta\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sys_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sys_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        } @else {\n                            <div class=\"hxp-version-header\">\n                                <span class=\"hxp-version-title\" matTooltip=\"{{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\">\n                                    {{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\n                                </span>\n                                @if(isNewContextMenu) {\n                                    <div class=\"hxp-context-btn\">\n                                        <button\n                                            mat-icon-button\n                                            [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                            (click)=\"onContextMenu($event, version)\"\n                                        >\n                                            <mat-icon>more_vert</mat-icon>\n                                        </button>\n                                    </div>\n                                } @else {\n                                    <button mat-icon-button class=\"hxp-version-menu\" [matMenuTriggerFor]=\"versionMenu\" (click)=\"$event.stopPropagation()\">\n                                        <mat-icon>more_vert</mat-icon>\n                                    </button>\n                                    <mat-menu #versionMenu=\"matMenu\" class=\"hxp-version-menu-panel\">\n                                        <button mat-menu-item (click)=\"openEditVersionDialog(version)\">\n                                            <mat-icon>edit</mat-icon>\n                                            <span>{{ 'MANAGE_VERSIONS.DIALOG.MORE_MENU.EDIT' | translate }}</span>\n                                        </button>\n                                        <button mat-menu-item (click)=\"openDeleteVersionDialog(version)\">\n                                            <mat-icon>delete</mat-icon>\n                                            <span>{{ 'MANAGE_VERSIONS.DIALOG.MORE_MENU.DELETE' | translate }}</span>\n                                        </button>\n                                    </mat-menu>\n                                }\n                            </div>\n                            @if(version.sysver_description) {\n                                <div class=\"hxp-version-description\" matTooltip=\"{{ version.sysver_description }}\">\n                                    {{ version.sysver_description }}\n                                </div>\n                            }\n                            <div class=\"hxp-version-meta\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sysver_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sysver_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        }\n                        <div class=\"hxp-version-footer\">\n                            <span>\n                                {{ version.sysver_expires\n                                ? (('MANAGE_VERSIONS.DIALOG.EXPIRES' | translate) + version.sysver_expires | date: 'medium')\n                                : ('MANAGE_VERSIONS.DIALOG.NEVER_EXPIRES' | translate) }}\n                            </span>\n                        </div>\n                        @if(isNewContextMenu) {\n                            <div\n                                #hiddenTrigger=\"matMenuTrigger\"\n                                class=\"hxp-menu-trigger\"\n                                [style.left]=\"contextMenuPosition.x\"\n                                [style.top]=\"contextMenuPosition.y\"\n                                [matMenuTriggerFor]=\"contextMenu\"\n                                [matMenuTriggerData]=\"{ actions: contextActions }\"\n                            ></div>\n                        }\n                    </button>\n                }\n            </div>\n        }\n    </div>\n    <mat-menu #contextMenu=\"matMenu\" class=\"hxp-context-menu\">\n        <ng-container *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n    </mat-menu>\n</adf-info-drawer-layout>\n", styles: ["adf-info-drawer-layout .hxp-version-panel-skeleton-loader{display:inline-block;width:370px}adf-info-drawer-layout .adf-info-drawer-layout-content{position:relative}adf-info-drawer-layout .adf-info-drawer-layout-header{display:none}adf-info-drawer-layout .hxp-manage-versions-sidebar-header{display:flex;justify-content:space-between;align-items:center;padding:24px 0}adf-info-drawer-layout .hxp-manage-versions-sidebar-header h1{font-size:var(--theme-title-font-size, 24px);margin:0;padding:0 16px;font-weight:400;display:inline-block;text-overflow:ellipsis;width:260px;overflow:hidden}adf-info-drawer-layout .hxp-manage-versions-sidebar-close-btn{background-color:transparent;border:0;cursor:pointer;align-items:center}adf-info-drawer-layout .hxp-version-list{display:flex;flex-direction:column;flex:1;overflow-y:auto;padding:12px;height:100vh}adf-info-drawer-layout .hxp-version-list .hxp-version-item{padding:0 24px;margin-bottom:8px;text-align:left;cursor:pointer;border:0;background:#fff}adf-info-drawer-layout .hxp-version-list .hxp-version-item:hover,adf-info-drawer-layout .hxp-version-list .hxp-version-item.active{background:var(--adf-filter-chip-background-color)}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-current-version .hxp-version-description{color:var(--theme-primary-color, #5654ac);font-size:14px;font-weight:600}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-current-version.hxp-has-old-context .hxp-version-title{padding-top:12px;padding-bottom:12px}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-has-old-context .hxp-version-header button{margin-right:-24px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header{display:flex;justify-content:space-between;align-items:center}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header .hxp-context-btn{position:relative;right:-24px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{padding-bottom:12px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-title{font-weight:700}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-title,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{max-width:320px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-meta,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-footer{font-size:12px;padding-bottom:12px;color:#4b5563}adf-info-drawer-layout .hxp-menu-trigger{visibility:hidden;position:fixed}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}\n"] }]
        }], ctorParameters: () => [{ type: i1.DocumentRouterService }, { type: i1.DocumentVersionsService }, { type: i1.HxpNotificationService }, { type: i1$1.MatDialog }, { type: VersionContextMenuActionsService }], propDecorators: { document: [{
                type: Input
            }], closeVersionsSidebar: [{
                type: Output
            }], contextActionMenuTemplateRef: [{
                type: ContentChild,
                args: ['contextActionMenu', { static: false }]
            }], menuTrigger: [{
                type: ViewChild,
                args: ['trigger', { static: false }]
            }], hiddenTrigger: [{
                type: ViewChild,
                args: ['hiddenTrigger', { static: false }]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that delete a `Document` file. Success or error action result status is notified to the user.
 *
 * To display the component:
 * - the `actionContext` input property must provide a list of `Document` to delete in the `documents` array;
 * - current logged in user must have `DELETE` permission on every `Document` in the list;
 * - current logged in user must have `DELETE_CHILD` permission on the parent `Document`.
 *
 * To use the `ContentDeleteButtonComponent`, import the component in your module
 *
 * ```ts
 * import { ContentDeleteButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentDeleteButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-content-delete [actionContext]="actionContext"></hxp-content-delete>
 *
 */
class ContentDeleteButtonComponent {
    constructor(deleteButtonActionService, documentCache) {
        this.deleteButtonActionService = deleteButtonActionService;
        this.documentCache = documentCache;
        this.isAvailable = false;
    }
    ngOnChanges() {
        if (!this.actionContext.parentDocument && this.actionContext.documents.length > 0 && this.actionContext.documents[0].sys_parentId) {
            this.documentCache.getDocument(this.actionContext.documents[0].sys_parentId).subscribe({
                next: (doc) => {
                    this.actionContext.parentDocument = doc;
                    this.isAvailable = this.deleteButtonActionService.isAvailable(this.actionContext);
                },
                error: (error) => console.error(error),
            });
        }
        else {
            this.isAvailable = this.deleteButtonActionService.isAvailable(this.actionContext);
        }
    }
    onDelete() {
        this.deleteButtonActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentDeleteButtonComponent, deps: [{ token: HXP_DOCUMENT_DELETE_ACTION_SERVICE }, { token: i1.DocumentCacheService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ContentDeleteButtonComponent, isStandalone: true, selector: "hxp-content-delete", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button\n  *ngIf=\"isAvailable\"\n  mat-icon-button\n  [attr.aria-label]=\"'APP.TOOLBAR.BUTTONS.DELETE.ARIA-LABEL' | translate\"\n  title=\"{{ 'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate }}\"\n  [matTooltip]=\"'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate\"\n  (click)=\"onDelete()\"\n  >\n    <mat-icon>delete</mat-icon>\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentDeleteButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-content-delete', standalone: true, imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button\n  *ngIf=\"isAvailable\"\n  mat-icon-button\n  [attr.aria-label]=\"'APP.TOOLBAR.BUTTONS.DELETE.ARIA-LABEL' | translate\"\n  title=\"{{ 'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate }}\"\n  [matTooltip]=\"'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate\"\n  (click)=\"onDelete()\"\n  >\n    <mat-icon>delete</mat-icon>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_DELETE_ACTION_SERVICE]
                }] }, { type: i1.DocumentCacheService }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that downloads a `Document` file. Success or error action result status is notified to the user.
 *
 * To display the component:
 * - the `actionContext` input property must provide only one `Document` in the `documents` array;
 * - the `Document` must have a valid blob to download;
 * - the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `SingleItemDownloadButtonComponent`, import the component in your module
 *
 * ```ts
 * import { SingleItemDownloadButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         SingleItemDownloadButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-single-item-download [actionContext]="actionContext"></hxp-single-item-download>
 *
 */
class SingleItemDownloadButtonComponent {
    constructor(singleItemDownloadButtonActionService) {
        this.singleItemDownloadButtonActionService = singleItemDownloadButtonActionService;
        /**
         * Input property which specifies an `ActionContext` object
         * The `ActionContext` object should provide an array containing only one `Document`.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         * }
         *
         */
        this.actionContext = { documents: [] };
        this.isAvailable = false;
    }
    ngOnChanges() {
        this.isAvailable = this.singleItemDownloadButtonActionService.isAvailable(this.actionContext);
    }
    onDownload() {
        this.singleItemDownloadButtonActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SingleItemDownloadButtonComponent, deps: [{ token: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: SingleItemDownloadButtonComponent, isStandalone: true, selector: "hxp-single-item-download", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button\n    *ngIf=\"isAvailable\"\n    id=\"document-viewer-single-download-button\"\n    mat-icon-button\n    [attr.aria-label]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.ARIA-LABEL' | translate\"\n    title=\"{{ 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate }}\"\n    [matTooltip]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate\"\n    (click)=\"onDownload()\"\n    >\n        <mat-icon>download</mat-icon>\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SingleItemDownloadButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-single-item-download', standalone: true, imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button\n    *ngIf=\"isAvailable\"\n    id=\"document-viewer-single-download-button\"\n    mat-icon-button\n    [attr.aria-label]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.ARIA-LABEL' | translate\"\n    title=\"{{ 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate }}\"\n    [matTooltip]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate\"\n    (click)=\"onDownload()\"\n    >\n        <mat-icon>download</mat-icon>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE]
                }] }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that shows a dialog to share a `Document` url.
 *
 * To display the component, the `actionContext` input property must provide only one `Document` in the `documents` array,
 * and the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `ContentShareButtonComponent`, import the component in your module
 *
 * ```ts
 * import { ContentShareButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentShareButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-single-file-share [actionContext]="actionContext"></hxp-single-file-share>
 *
 */
class ContentShareButtonComponent {
    constructor(contentShareButtonActionService) {
        this.contentShareButtonActionService = contentShareButtonActionService;
        /**
         * Input property which specifies an `ActionContext` object
         * The `ActionContext` object should provide an array containing only one `Document`.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         * }
         *
         */
        this.actionContext = { documents: [] };
        this.isAvailable = false;
    }
    ngOnChanges() {
        this.isAvailable = this.contentShareButtonActionService.isAvailable(this.actionContext);
    }
    onShare() {
        this.contentShareButtonActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareButtonComponent, deps: [{ token: HXP_DOCUMENT_SHARE_ACTION_SERVICE }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ContentShareButtonComponent, isStandalone: true, selector: "hxp-single-file-share", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button *ngIf=\"isAvailable\"\n    mat-icon-button\n    class=\"hxp-content-share-button\"\n    [attr.aria-label]=\"'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.ARIA-LABEL' | translate\"\n    title=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n    matTooltip=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n    (click)=\"onShare()\">\n    <mat-icon>share</mat-icon>\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentShareButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-single-file-share', standalone: true, imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button *ngIf=\"isAvailable\"\n    mat-icon-button\n    class=\"hxp-content-share-button\"\n    [attr.aria-label]=\"'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.ARIA-LABEL' | translate\"\n    title=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n    matTooltip=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n    (click)=\"onShare()\">\n    <mat-icon>share</mat-icon>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_SHARE_ACTION_SERVICE]
                }] }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that triggers an event to display the Document Properties Sidebar.
 *
 * To display the component, the `actionContext` input property must provide only one `Document` in the `documents` array,
 * and the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `ContentPropertiesViewerButtonComponent`, import the component in your module along with `HxpPropertiesSidebarComponent`.
 *
 * ```ts
 * import { ContentPropertiesViewerButtonComponent, HxpPropertiesSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentPropertiesViewerButtonComponent,
 *         HxpPropertiesSidebarComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Inject the `ContentPropertyViewerActionService` in your component as shown in the example below.
 * Subscribe to `showPropertyPanel$` service stream to update the `ActionContext` object with the new value.
 *
 * ```ts
 * import { ActionContext, ContentPropertyViewerActionService, HXP_DOCUMENT_INFO_ACTION_SERVICE } from '@alfresco/adf-hx-content-services/services';
 * import { Subject } from 'rxjs';
 * import { takeUntil } from 'rxjs/operators';
 *
 * @Component({
 *   template: '
 *       <hxp-content-properties-viewer-button [actionContext]="actionContext"></hxp-content-properties-viewer-button>
 *       <hxp-properties-sidebar
 *           *ngIf="actionContext?.showPanel === 'property'"
 *           [document]="actionContext?.documents[0]"
 *           (closePropertySidebar)="closePropertiesSidebar()"
 *           >
 *        </hxp-properties-sidebar>
 * ',
 * })
 * export class YourComponent implements OnDestroy {
 *
 *     actionContext: ActionContext = { documents: [] };
 *
 *     private destroyed$: Subject<void> = new Subject<void>();
 *
 *     constructor(@Inject(HXP_DOCUMENT_INFO_ACTION_SERVICE) private contentPropertyViewerActionService: ContentPropertyViewerActionService) {
 *         this.subscribeToShowPropertyPanelStatus();
 *     }
 *
 *     ngOnDestroy() {
 *         this.destroyed$.next();
 *         this.destroyed$.complete();
 *     }
 *
 *     [...]
 *
 *     closePropertiesSidebar(): void {
 *         this.actionContext = { ...this.actionContext, showPanel: undefined };
 *         this.contentPropertyViewerActionService.execute(this.actionContext);
 *     }
 *
 *     private subscribeToShowPropertyPanelStatus(): void {
 *         this.contentPropertyViewerActionService.showPropertyPanel$
 *             .pipe(takeUntil(this.destroyed$))
 *             .subscribe({
 *                  next: (showPropertyPanel) => {
 *                      this.actionContext = { ...this.actionContext, showPanel : showPropertyPanel ? 'property' : undefined };
 *                  },
 *                  error: (error) => console.error(error)
 *         });
 *     }
 * }
 * ```
 *
 */
class ContentPropertiesViewerButtonComponent {
    constructor(contentPropertyViewerActionService) {
        this.contentPropertyViewerActionService = contentPropertyViewerActionService;
        /**
         * Input property which specifies an `ActionContext` object
         * The `ActionContext` object should provide an array containing only one `Document`.
         *
         * Optionally the object can provide the `showPanel` to forcefully trigger an event to display or hidden the Properties Viewer.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         *     showPanel?: 'property' | 'version';
         * }
         *
         */
        this.actionContext = { documents: [] };
        this.isAvailable = false;
    }
    ngOnChanges() {
        this.isAvailable = this.contentPropertyViewerActionService.isAvailable(this.actionContext);
    }
    showInfo() {
        this.contentPropertyViewerActionService.execute({ ...this.actionContext, showPanel: 'property' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentPropertiesViewerButtonComponent, deps: [{ token: HXP_DOCUMENT_INFO_ACTION_SERVICE }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ContentPropertiesViewerButtonComponent, isStandalone: true, selector: "hxp-content-properties-viewer-button", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button\n    id=\"document-properties-viewer-button\"\n    mat-icon-button\n    data-automation-id=\"document-properties-viewer-button\"\n    [attr.aria-label]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    title=\"{{ 'ADF_VIEWER.ACTIONS.INFO' | translate }}\"\n    [matTooltip]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    *ngIf=\"isAvailable\"\n    (click)=\"showInfo()\"\n>\n    <mat-icon>info</mat-icon>\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ContentPropertiesViewerButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-content-properties-viewer-button', standalone: true, imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button\n    id=\"document-properties-viewer-button\"\n    mat-icon-button\n    data-automation-id=\"document-properties-viewer-button\"\n    [attr.aria-label]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    title=\"{{ 'ADF_VIEWER.ACTIONS.INFO' | translate }}\"\n    [matTooltip]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    *ngIf=\"isAvailable\"\n    (click)=\"showInfo()\"\n>\n    <mat-icon>info</mat-icon>\n</button>\n" }]
        }], ctorParameters: () => [{ type: ContentPropertyViewerActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_INFO_ACTION_SERVICE]
                }] }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageColumnButtonComponent {
    constructor(manageColumnActionService) {
        this.manageColumnActionService = manageColumnActionService;
        this.actionContext = { documents: [] };
        this.isAvailable = false;
    }
    ngOnChanges() {
        this.isAvailable = this.manageColumnActionService.isAvailable(this.actionContext);
    }
    onCopy() {
        this.manageColumnActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnButtonComponent, deps: [{ token: HXP_MANAGE_COLUMN_ACTION_SERVICE }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: ManageColumnButtonComponent, isStandalone: true, selector: "hxp-manage-column-button", inputs: { actionContext: "actionContext", isAvailable: "isAvailable" }, usesOnChanges: true, ngImport: i0, template: "<button\n    *ngIf=\"isAvailable\"\n    [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    mat-icon-button\n    [matTooltip]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    (click)=\"onCopy()\"\n    class=\"hxp-manage-column-button mat-button-base\"\n>\n    <mat-icon aria-hidden=\"true\">tune</mat-icon>\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ManageColumnButtonComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'hxp-manage-column-button', imports: [NgIf, MatIconModule, MatButtonModule, MatTooltipModule, TranslatePipe], template: "<button\n    *ngIf=\"isAvailable\"\n    [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    mat-icon-button\n    [matTooltip]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    (click)=\"onCopy()\"\n    class=\"hxp-manage-column-button mat-button-base\"\n>\n    <mat-icon aria-hidden=\"true\">tune</mat-icon>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_MANAGE_COLUMN_ACTION_SERVICE]
                }] }], propDecorators: { actionContext: [{
                type: Input
            }], isAvailable: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionDeleteButtonComponent {
    constructor(versionDeleteActionService) {
        this.versionDeleteActionService = versionDeleteActionService;
        this.isAvailable = false;
    }
    ngOnChanges() {
        this.isAvailable = this.versionDeleteActionService.isAvailable(this.actionContext);
    }
    onDelete() {
        this.versionDeleteActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteButtonComponent, deps: [{ token: HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.9", type: VersionDeleteButtonComponent, isStandalone: true, selector: "hxp-version-delete-button", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "@if (isAvailable) {\n    <button\n        mat-icon-button\n        [attr.aria-label]=\"'MANAGE_VERSIONS.DELETE_BUTTON.ARIA_LABEL' | translate\"\n        title=\"{{ 'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate }}\"\n        [matTooltip]=\"'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate\"\n    >\n        <mat-icon>delete</mat-icon>\n    </button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i4.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionDeleteButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-delete-button', standalone: true, imports: [MatButtonModule, MatTooltipModule, MatIconModule, TranslateModule], template: "@if (isAvailable) {\n    <button\n        mat-icon-button\n        [attr.aria-label]=\"'MANAGE_VERSIONS.DELETE_BUTTON.ARIA_LABEL' | translate\"\n        title=\"{{ 'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate }}\"\n        [matTooltip]=\"'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate\"\n    >\n        <mat-icon>delete</mat-icon>\n    </button>\n}\n" }]
        }], ctorParameters: () => [{ type: i1.DocumentActionService, decorators: [{
                    type: Inject,
                    args: [HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE]
                }] }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionRestoreComponent {
    constructor() {
        this.isAvailable = false;
        this.data = { documents: [] };
        this.versionRestoreService = Inject(VersionRestoreActionService);
    }
    ngOnChanges() {
        this.isAvailable = this.versionRestoreService.isAvailable(this.data);
    }
    restoreVersion() {
        this.versionRestoreService.execute(this.data);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionRestoreComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.9", type: VersionRestoreComponent, isStandalone: true, selector: "hxp-version-restore", inputs: { isAvailable: "isAvailable", data: "data" }, usesOnChanges: true, ngImport: i0, template: "@if(isAvailable) {\n    <button\n        mat-menu-item\n        class=\"hxp-restore-version-button\"\n        (click)=\"restoreVersion()\"\n        aria-labelledby=\"hxp-restore-version-button-label\"\n    >\n        <mat-icon>history</mat-icon>\n        <span id=\"hxp-restore-version-button-label\">{{ 'DOCUMENT_RESTORE_VERSION.LABEL' | translate }}</span>\n    </button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i6.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i4.TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: VersionRestoreComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-restore', standalone: true, imports: [MatButtonModule, MatMenuModule, MatIconModule, TranslateModule], template: "@if(isAvailable) {\n    <button\n        mat-menu-item\n        class=\"hxp-restore-version-button\"\n        (click)=\"restoreVersion()\"\n        aria-labelledby=\"hxp-restore-version-button-label\"\n    >\n        <mat-icon>history</mat-icon>\n        <span id=\"hxp-restore-version-button-label\">{{ 'DOCUMENT_RESTORE_VERSION.LABEL' | translate }}</span>\n    </button>\n}\n" }]
        }], propDecorators: { isAvailable: [{
                type: Input
            }], data: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FormatDocumentPathDirective {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.originalText = null;
    }
    ngOnChanges(changes) {
        if (changes['columnWidths']) {
            this.truncatePath();
        }
    }
    ngAfterViewInit() {
        this.originalText = this.el.nativeElement.textContent;
        this.truncatePath();
    }
    truncatePath() {
        if (!this.originalText) {
            return;
        }
        const element = this.el.nativeElement;
        const parentElement = element.parentNode;
        this.renderer.setProperty(element, 'innerText', this.originalText);
        const parentWidth = parentElement.offsetWidth;
        const textWidth = element.offsetWidth;
        const parts = this.originalText.split('/');
        if (textWidth > parentWidth && parts.length > 2) {
            this.renderer.setProperty(element, 'innerText', `${parts[0]}/.../${parts[parts.length - 1]}`);
        }
        else {
            this.renderer.setProperty(element, 'innerText', this.originalText);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FormatDocumentPathDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.9", type: FormatDocumentPathDirective, isStandalone: true, selector: "[hxpFormatDocumentPath]", inputs: { columnWidths: ["hxpFormatDocumentPath", "columnWidths"] }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FormatDocumentPathDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[hxpFormatDocumentPath]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { columnWidths: [{
                type: Input,
                args: ['hxpFormatDocumentPath']
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterInputComponent {
    constructor(matIconRegistry, domSanitizer) {
        this.matIconRegistry = matIconRegistry;
        this.domSanitizer = domSanitizer;
        this.applyOnEnter = false;
        this.search = new EventEmitter();
        this.clear = new EventEmitter();
        this.prefixClick = new EventEmitter();
        this.searchTerm = '';
        const icons = {
            search_glass: 'assets/search-icons/Search.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    applyFilter(event) {
        if (!this.applyOnEnter) {
            this.emitSearch();
        }
        else if (event.key === 'Enter') {
            this.emitSearch();
        }
    }
    emitSearch() {
        this.search.emit(this.searchTerm);
    }
    clearInput() {
        this.searchTerm = '';
        this.clear.emit();
    }
    onPrefixClick() {
        this.prefixClick.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchFilterInputComponent, deps: [{ token: i3$1.MatIconRegistry }, { token: i2$4.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: SearchFilterInputComponent, isStandalone: true, selector: "hxp-search-filter-input", inputs: { applyOnEnter: "applyOnEnter", inputAriaLabel: "inputAriaLabel", placeholder: "placeholder", clearAriaLabel: "clearAriaLabel", prefixIcon: "prefixIcon", prefixAriaLabel: "prefixAriaLabel" }, outputs: { search: "search", clear: "clear", prefixClick: "prefixClick" }, ngImport: i0, template: "<mat-form-field\n    class=\"hxp-search-filter-input hxp-input\"\n    appearance=\"outline\"\n>\n    <div\n        *ngIf=\"prefixIcon\"\n        matPrefix\n        class=\"hxp-search-filter-input-prefix\"\n    >\n        <button\n            mat-icon-button\n            type=\"button\"\n            [attr.aria-label]=\"prefixAriaLabel\"\n            (click)=\"onPrefixClick()\"\n        >\n            <mat-icon\n                aria-hidden=\"true\"\n                [svgIcon]=\"prefixIcon\"\n            />\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n    </div>\n    <input\n        matInput\n        type=\"text\"\n        [attr.aria-label]=\"inputAriaLabel\"\n        [placeholder]=\"placeholder ?? ''\"\n        [(ngModel)]=\"searchTerm\"\n        (keyup)=\"applyFilter($event)\"\n    >\n    <div matSuffix class=\"hxp-search-filter-input-suffix\">\n        <button\n            *ngIf=\"searchTerm\"\n            mat-icon-button\n            class=\"hxp-search-filter-input-clear\"\n            [attr.aria-label]=\"clearAriaLabel\"\n            (click)=\"clearInput()\"\n        >\n            <mat-icon class=\"hxp-search-filter-input-clear-icon\">\n                close\n            </mat-icon>\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n        <div class=\"hxp-search-filter-input-search\">\n            <div\n                *ngIf=\"applyOnEnter\"\n                class=\"hxp-search-filter-search-button\"\n            >\n                <button\n                    mat-icon-button\n                    type=\"button\"\n                    [attr.aria-label]=\"'SEARCH.FILTERS.SEARCH'\"\n                    (click)=\"emitSearch()\"\n                    >\n                        <mat-icon\n                            class=\"hxp-search-filter-input-search-icon\"\n                            svgIcon=\"search_glass\"\n                        />\n                </button>\n            </div>\n            <mat-icon\n                *ngIf=\"!applyOnEnter\"\n                class=\"hxp-search-filter-input-search-icon\"\n                svgIcon=\"search_glass\"\n            />\n        </div>\n    </div>\n</mat-form-field>\n", styles: [".hxp-search-filter-input{width:100%}.hxp-search-filter-input-prefix,.hxp-search-filter-input-suffix{display:flex;align-items:center}.hxp-search-filter-input-divider{background:#d1d5db;height:54px}.hxp-search-filter-input-clear{display:flex;text-align:center}.hxp-search-filter-input-clear-icon{color:#111827}.hxp-search-filter-input-search{min-width:48px;position:relative;display:flex;justify-content:center;align-items:center}.hxp-search-filter-input-search button{display:flex;justify-content:center;align-items:center}.hxp-search-filter-input-search-icon{--mdc-icon-button-icon-size: 16px;width:16px;color:#111827}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchFilterInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-filter-input', standalone: true, imports: [CommonModule, FormsModule, MatIconModule, MatDividerModule, MatFormFieldModule, MatInputModule, MatButtonModule], template: "<mat-form-field\n    class=\"hxp-search-filter-input hxp-input\"\n    appearance=\"outline\"\n>\n    <div\n        *ngIf=\"prefixIcon\"\n        matPrefix\n        class=\"hxp-search-filter-input-prefix\"\n    >\n        <button\n            mat-icon-button\n            type=\"button\"\n            [attr.aria-label]=\"prefixAriaLabel\"\n            (click)=\"onPrefixClick()\"\n        >\n            <mat-icon\n                aria-hidden=\"true\"\n                [svgIcon]=\"prefixIcon\"\n            />\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n    </div>\n    <input\n        matInput\n        type=\"text\"\n        [attr.aria-label]=\"inputAriaLabel\"\n        [placeholder]=\"placeholder ?? ''\"\n        [(ngModel)]=\"searchTerm\"\n        (keyup)=\"applyFilter($event)\"\n    >\n    <div matSuffix class=\"hxp-search-filter-input-suffix\">\n        <button\n            *ngIf=\"searchTerm\"\n            mat-icon-button\n            class=\"hxp-search-filter-input-clear\"\n            [attr.aria-label]=\"clearAriaLabel\"\n            (click)=\"clearInput()\"\n        >\n            <mat-icon class=\"hxp-search-filter-input-clear-icon\">\n                close\n            </mat-icon>\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n        <div class=\"hxp-search-filter-input-search\">\n            <div\n                *ngIf=\"applyOnEnter\"\n                class=\"hxp-search-filter-search-button\"\n            >\n                <button\n                    mat-icon-button\n                    type=\"button\"\n                    [attr.aria-label]=\"'SEARCH.FILTERS.SEARCH'\"\n                    (click)=\"emitSearch()\"\n                    >\n                        <mat-icon\n                            class=\"hxp-search-filter-input-search-icon\"\n                            svgIcon=\"search_glass\"\n                        />\n                </button>\n            </div>\n            <mat-icon\n                *ngIf=\"!applyOnEnter\"\n                class=\"hxp-search-filter-input-search-icon\"\n                svgIcon=\"search_glass\"\n            />\n        </div>\n    </div>\n</mat-form-field>\n", styles: [".hxp-search-filter-input{width:100%}.hxp-search-filter-input-prefix,.hxp-search-filter-input-suffix{display:flex;align-items:center}.hxp-search-filter-input-divider{background:#d1d5db;height:54px}.hxp-search-filter-input-clear{display:flex;text-align:center}.hxp-search-filter-input-clear-icon{color:#111827}.hxp-search-filter-input-search{min-width:48px;position:relative;display:flex;justify-content:center;align-items:center}.hxp-search-filter-input-search button{display:flex;justify-content:center;align-items:center}.hxp-search-filter-input-search-icon{--mdc-icon-button-icon-size: 16px;width:16px;color:#111827}\n"] }]
        }], ctorParameters: () => [{ type: i3$1.MatIconRegistry }, { type: i2$4.DomSanitizer }], propDecorators: { applyOnEnter: [{
                type: Input
            }], inputAriaLabel: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], clearAriaLabel: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], prefixAriaLabel: [{
                type: Input
            }], search: [{
                type: Output
            }], clear: [{
                type: Output
            }], prefixClick: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchNoResultsComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchNoResultsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: SearchNoResultsComponent, isStandalone: true, selector: "hxp-search-no-results", ngImport: i0, template: "<div class=\"hxp-search-no-results adf-full-width adf-datatable-list adf-datatable--empty\">\n    <adf-custom-empty-content-template>\n        <adf-empty-content\n            icon=\"null\"\n            title=\"SEARCH.NO_RESULTS.TITLE\"\n            subtitle=\"SEARCH.NO_RESULTS.SUBTITLE\"\n            class=\"hxp-search-empty-content\"\n        />\n    </adf-custom-empty-content-template>\n</div>\n", styles: [".hxp-search-no-results{display:flex;flex-direction:column;flex:1;height:100%;justify-content:center}\n"], dependencies: [{ kind: "component", type: EmptyContentComponent, selector: "adf-empty-content", inputs: ["icon", "title", "subtitle"] }, { kind: "directive", type: CustomEmptyContentTemplateDirective, selector: "adf-custom-empty-content-template, empty-folder-content" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchNoResultsComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'hxp-search-no-results', imports: [EmptyContentComponent, CustomEmptyContentTemplateDirective], template: "<div class=\"hxp-search-no-results adf-full-width adf-datatable-list adf-datatable--empty\">\n    <adf-custom-empty-content-template>\n        <adf-empty-content\n            icon=\"null\"\n            title=\"SEARCH.NO_RESULTS.TITLE\"\n            subtitle=\"SEARCH.NO_RESULTS.SUBTITLE\"\n            class=\"hxp-search-empty-content\"\n        />\n    </adf-custom-empty-content-template>\n</div>\n", styles: [".hxp-search-no-results{display:flex;flex-direction:column;flex:1;height:100%;justify-content:center}\n"] }]
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreatedDateSearchFilterService {
    toHXQL(data) {
        const valuesArray = data?.values;
        if (!valuesArray || valuesArray?.length === 0) {
            return '';
        }
        const createdDateValue = valuesArray[0];
        switch (createdDateValue.date) {
            case 'LAST_7_DAYS': {
                return this.formatCreatedDateToHXQL('after', sub(new Date(), { days: 7 }));
            }
            case 'LAST_30_DAYS': {
                return this.formatCreatedDateToHXQL('after', sub(new Date(), { months: 1 }));
            }
            case 'LAST_6_MONTHS': {
                return this.formatCreatedDateToHXQL('after', sub(new Date(), { months: 6 }));
            }
            case 'LAST_YEAR': {
                return this.formatCreatedDateToHXQL('after', sub(new Date(), { years: 1 }));
            }
            default: {
                const { afterDate, beforeDate } = createdDateValue;
                if (afterDate && beforeDate) {
                    const afterDateValue = this.formatCreatedDateToHXQL('after', afterDate);
                    const beforeDateValue = this.formatCreatedDateToHXQL('before', beforeDate);
                    return `${afterDateValue} AND ${beforeDateValue}`;
                }
                else if (afterDate && !beforeDate) {
                    return this.formatCreatedDateToHXQL('after', afterDate);
                }
                else if (!afterDate && beforeDate) {
                    return this.formatCreatedDateToHXQL('before', beforeDate);
                }
            }
        }
        return '';
    }
    formatCreatedDateToHXQL(type, date) {
        const formattedDate = formatISO(date, { representation: 'date' });
        return type === 'before' ? `sys_created <= DATE '${formattedDate}'` : `sys_created >= DATE '${formattedDate}'`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CreatedDateSearchFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CreatedDateSearchFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CreatedDateSearchFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreatedDateSearchFilterValue {
    constructor() {
        this.label = '';
    }
}
class CreatedDateSearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        // only single selection is supported for this data type
        const val = this.values[0];
        const dataVal = data.values[0];
        return (val.date === dataVal.date &&
            val.beforeDate?.toISOString() === dataVal.beforeDate?.toISOString() &&
            val.afterDate?.toISOString() === dataVal.afterDate?.toISOString());
    }
}

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterContainerComponent {
    constructor(overlay, viewContainerRef) {
        this.overlay = overlay;
        this.viewContainerRef = viewContainerRef;
        this.name = '';
        this.filterForm = new FormGroup({});
        /**
         * Event emitted when the filter overlay is closed without any explicit action (e.g. clear or apply filter)
         */
        this.overlayClosed = new EventEmitter();
        this.filterCleared = new EventEmitter();
        this.filterApplied = new EventEmitter();
        this.selectionLabel = '';
        this.hiddenValuesCount = 0;
        this.isFilterOverlayOpened = false;
        this.overlayPosition = [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
            },
        ];
        this.destroyRef = inject(DestroyRef);
    }
    ngAfterViewInit() {
        this.templatePortal = new TemplatePortal(this.template, this.viewContainerRef);
    }
    ngOnChanges(changes) {
        const { selectedValue } = changes;
        if (!selectedValue) {
            return;
        }
        const currentValue = selectedValue.currentValue;
        if (this.data === currentValue || (this.data === undefined && currentValue === undefined) || this.data?.isEquivalentTo(currentValue)) {
            this.filterForm.markAsPristine();
        }
        else {
            this.filterForm.markAsDirty();
        }
    }
    applyChanges() {
        this.data = this.selectedValue;
        this.filterForm.markAsPristine();
        this.computeLabelVisibility();
    }
    clearChanges() {
        this.selectedValue = undefined;
        this.data = undefined;
        this.filterForm.markAsPristine();
        this.computeLabelVisibility();
    }
    clearFilter(event) {
        event.stopPropagation();
        event.preventDefault();
        this.clearChanges();
        this.filterCleared.emit();
        this.closeOverlay();
    }
    applyFilter(event) {
        event.stopPropagation();
        event.preventDefault();
        this.applyChanges();
        this.filterApplied.emit(this.data);
        this.closeOverlay();
    }
    computeLabelVisibility() {
        if ((this.selectedValue?.values || []).length > 0 && this.data?.values) {
            this.selectionLabel = this.data.values[0].label;
            this.hiddenValuesCount = this.data.values.length - 1;
        }
        else {
            this.selectionLabel = '';
            this.hiddenValuesCount = 0;
        }
    }
    hasPendingChanges() {
        return this.data !== this.selectedValue;
    }
    discardPendingChanges() {
        this.selectedValue = this.data;
    }
    openFilterOverlay() {
        const positionStrategy = this.chip
            ? this.overlay.position().flexibleConnectedTo(this.chip._elementRef.nativeElement).withPositions(this.overlayPosition)
            : undefined;
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            positionStrategy,
        });
        this.overlayRef = this.overlay.create(overlayConfig);
        this.overlayRef.attach(this.templatePortal);
        this.isFilterOverlayOpened = true;
        this.overlayRef
            .backdropClick()
            .pipe(takeUntilDestroyed(this.destroyRef), finalize(() => this.closeOverlay()))
            .subscribe({
            next: () => {
                if (this.hasPendingChanges()) {
                    this.discardPendingChanges();
                }
                this.overlayClosed.emit();
                this.closeOverlay();
            },
        });
    }
    closeOverlay() {
        this.isFilterOverlayOpened = false;
        if (this.overlayRef && this.overlayRef.hasAttached()) {
            this.overlayRef.detach();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchFilterContainerComponent, deps: [{ token: i1$6.Overlay }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: SearchFilterContainerComponent, isStandalone: true, selector: "hxp-search-filter-container", inputs: { name: "name", filterForm: "filterForm", selectedValue: "selectedValue" }, outputs: { overlayClosed: "overlayClosed", filterCleared: "filterCleared", filterApplied: "filterApplied" }, viewQueries: [{ propertyName: "template", first: true, predicate: ["template"], descendants: true }, { propertyName: "chip", first: true, predicate: ["chip"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-search-filter\">\n    <mat-chip-set>\n        <mat-chip\n            #chip\n            (click)=\"openFilterOverlay()\"\n            class=\"hxp-search-filter-chip\"\n            [ngClass]=\"{\n                'hxp-search-filter-chip_active': data,\n                'hxp-search-filter-chip_opened': isFilterOverlayOpened\n            }\"\n            [matTooltip]=\"selectionLabel | translate\"\n        >\n            <div class=\"hxp-search-filter-chip-label-container\">\n                <div class=\"hxp-search-filter-chip-label\" #chipLabel>\n                    <span>{{ name + (selectionLabel ? ': ' + (selectionLabel | translate) : '') }}</span>\n                </div>\n                <div *ngIf=\"hiddenValuesCount > 0\"\n                    aria-hidden=\"true\"\n                    class=\"hxp-search-filter-chip-badge\">+{{ hiddenValuesCount }}\n                </div>\n                <mat-icon class=\"hxp-search-filter-chip-icon\">{{\n                    isFilterOverlayOpened ? 'expand_less' : 'expand_more'\n                }}</mat-icon>\n            </div>\n        </mat-chip>\n    </mat-chip-set>\n    <ng-template #template>\n        <div class=\"hxp-search-filter-overlay\">\n            <form [formGroup]=\"filterForm\"\n                (ngSubmit)=\"applyFilter($event)\"\n                (reset)=\"clearFilter($event)\"\n                (keydown.enter)=\"$event.preventDefault()\">\n                <ng-content />\n\n                <div class=\"hxp-search-filter-overlay-actions\">\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-clear hxp-text-button\"\n                        mat-button\n                        type=\"reset\"\n                        [disabled]=\"(!data || data.values?.length === 0) && filterForm.pristine\"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.CLEAR_ALL' | translate }}\n                    </button>\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-apply hxp-primary-button\"\n                        mat-button\n                        type=\"submit\"\n                        [disabled]=\"\n                            filterForm.pristine ||\n                            filterForm.invalid\n                        \"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.APPLY' | translate }}\n                    </button>\n                </div>\n            </form>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-search-filter .hxp-search-filter-chip{border:1px solid #6b7280;max-width:320px;background-color:var(--theme-background-color, #fafafa)}.hxp-search-filter .hxp-search-filter-chip-label-container{display:flex;align-items:center;color:var(--theme-primary-color, #5654ac);font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;max-width:290px}.hxp-search-filter .hxp-search-filter-chip-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:255px}.hxp-search-filter .hxp-search-filter-chip-badge{color:#fff;background-color:var(--theme-primary-color, #5654ac);border-radius:100px;width:24px;height:24px;min-width:24px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;margin:0 5px}.hxp-search-filter .hxp-search-filter-chip_active{border:2px solid #5654ac;background:var(--adf-theme-primary-50)}.hxp-search-filter .hxp-search-filter-chip_opened{background:var(--adf-theme-primary-50)}.hxp-search-filter-overlay{box-shadow:0 3px 3px -2px #0003,0 3px 4px #00000024,0 1px 8px #0000001f;background-color:var(--theme-background-color, #fafafa);border-radius:8px;width:100%}.hxp-search-filter-overlay-actions{display:flex;flex-direction:row;justify-content:space-between;padding:var(--mat-dialog-actions-padding, 16px 24px)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2$2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i6$3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i6$3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "ngmodule", type: PortalModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchFilterContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-filter-container', standalone: true, imports: [
                        CommonModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatIconModule,
                        MatTooltipModule,
                        OverlayModule,
                        PortalModule,
                        ReactiveFormsModule,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-search-filter\">\n    <mat-chip-set>\n        <mat-chip\n            #chip\n            (click)=\"openFilterOverlay()\"\n            class=\"hxp-search-filter-chip\"\n            [ngClass]=\"{\n                'hxp-search-filter-chip_active': data,\n                'hxp-search-filter-chip_opened': isFilterOverlayOpened\n            }\"\n            [matTooltip]=\"selectionLabel | translate\"\n        >\n            <div class=\"hxp-search-filter-chip-label-container\">\n                <div class=\"hxp-search-filter-chip-label\" #chipLabel>\n                    <span>{{ name + (selectionLabel ? ': ' + (selectionLabel | translate) : '') }}</span>\n                </div>\n                <div *ngIf=\"hiddenValuesCount > 0\"\n                    aria-hidden=\"true\"\n                    class=\"hxp-search-filter-chip-badge\">+{{ hiddenValuesCount }}\n                </div>\n                <mat-icon class=\"hxp-search-filter-chip-icon\">{{\n                    isFilterOverlayOpened ? 'expand_less' : 'expand_more'\n                }}</mat-icon>\n            </div>\n        </mat-chip>\n    </mat-chip-set>\n    <ng-template #template>\n        <div class=\"hxp-search-filter-overlay\">\n            <form [formGroup]=\"filterForm\"\n                (ngSubmit)=\"applyFilter($event)\"\n                (reset)=\"clearFilter($event)\"\n                (keydown.enter)=\"$event.preventDefault()\">\n                <ng-content />\n\n                <div class=\"hxp-search-filter-overlay-actions\">\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-clear hxp-text-button\"\n                        mat-button\n                        type=\"reset\"\n                        [disabled]=\"(!data || data.values?.length === 0) && filterForm.pristine\"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.CLEAR_ALL' | translate }}\n                    </button>\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-apply hxp-primary-button\"\n                        mat-button\n                        type=\"submit\"\n                        [disabled]=\"\n                            filterForm.pristine ||\n                            filterForm.invalid\n                        \"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.APPLY' | translate }}\n                    </button>\n                </div>\n            </form>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-search-filter .hxp-search-filter-chip{border:1px solid #6b7280;max-width:320px;background-color:var(--theme-background-color, #fafafa)}.hxp-search-filter .hxp-search-filter-chip-label-container{display:flex;align-items:center;color:var(--theme-primary-color, #5654ac);font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;max-width:290px}.hxp-search-filter .hxp-search-filter-chip-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:255px}.hxp-search-filter .hxp-search-filter-chip-badge{color:#fff;background-color:var(--theme-primary-color, #5654ac);border-radius:100px;width:24px;height:24px;min-width:24px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;margin:0 5px}.hxp-search-filter .hxp-search-filter-chip_active{border:2px solid #5654ac;background:var(--adf-theme-primary-50)}.hxp-search-filter .hxp-search-filter-chip_opened{background:var(--adf-theme-primary-50)}.hxp-search-filter-overlay{box-shadow:0 3px 3px -2px #0003,0 3px 4px #00000024,0 1px 8px #0000001f;background-color:var(--theme-background-color, #fafafa);border-radius:8px;width:100%}.hxp-search-filter-overlay-actions{display:flex;flex-direction:row;justify-content:space-between;padding:var(--mat-dialog-actions-padding, 16px 24px)}\n"] }]
        }], ctorParameters: () => [{ type: i1$6.Overlay }, { type: i0.ViewContainerRef }], propDecorators: { name: [{
                type: Input
            }], filterForm: [{
                type: Input
            }], selectedValue: [{
                type: Input
            }], overlayClosed: [{
                type: Output
            }], filterCleared: [{
                type: Output
            }], filterApplied: [{
                type: Output
            }], template: [{
                type: ViewChild,
                args: ['template']
            }], chip: [{
                type: ViewChild,
                args: ['chip']
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class BaseSearchFilterDirective {
    constructor(searchFilterValueService) {
        this.searchFilterValueService = searchFilterValueService;
        this.filterCleared = new EventEmitter();
        this.filterApplied = new EventEmitter();
        this.filterForm = new FormGroup(this.getFormControls());
        this.initialFormValue = { ...this.filterForm.value };
        this.oldFormValue = { ...this.filterForm.value };
    }
    clearFilter() {
        this.clearChanges();
        this.filterCleared.emit();
        this.searchFilterValueService.filterReset$.next(this);
        this.clearForm();
    }
    applyFilter() {
        this.applyChanges();
        this.filterApplied.emit(this.value);
        this.searchFilterValueService.filterApplied$.next({
            filter: this,
            value: this.value,
        });
    }
    applyChanges() {
        this.value = this.selectedValue;
        this.oldFormValue = { ...this.filterForm.value };
    }
    clearChanges() {
        this.selectedValue = undefined;
        this.value = undefined;
        this.clearForm();
    }
    /**
     * A change is pending if the currently selected value is different from the value already applied.
     */
    hasPendingChanges() {
        return this.oldFormValue !== this.filterForm.value || this.value !== this.selectedValue;
    }
    /**
     * Discards pending changes by resetting the selected value to the applied value.
     */
    discardPendingChanges() {
        this.selectedValue = this.value;
        this.filterForm.setValue({ ...this.oldFormValue });
    }
    /**
     * Populates whatever properties the filter needs with the provided data and updates the filter container.
     */
    populateWith(data) {
        this.setData(data);
        if (this.searchFilterContainer) {
            this.searchFilterContainer.selectedValue = this.selectedValue;
            this.searchFilterContainer.applyChanges();
        }
        this.applyFilter();
    }
    clearForm() {
        this.filterForm.reset({ ...this.initialFormValue });
        this.oldFormValue = { ...this.initialFormValue };
    }
    /**
     * Called when the overlay is closed.
     * Discards any pending changes, because neither clear and filter actions were applied.
     */
    overlayClosed() {
        this.discardPendingChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: BaseSearchFilterDirective, deps: [{ token: i1.SearchFilterValueService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.9", type: BaseSearchFilterDirective, isStandalone: true, inputs: { selectedValue: "selectedValue" }, outputs: { filterCleared: "filterCleared", filterApplied: "filterApplied" }, viewQueries: [{ propertyName: "searchFilterContainer", first: true, predicate: ["searchFilter"], descendants: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: BaseSearchFilterDirective, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1.SearchFilterValueService }], propDecorators: { selectedValue: [{
                type: Input
            }], filterCleared: [{
                type: Output
            }], filterApplied: [{
                type: Output
            }], searchFilterContainer: [{
                type: ViewChild,
                args: ['searchFilter']
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreatedDateSearchFiltersComponent extends BaseSearchFilterDirective {
    constructor(datePipe, searchFilterValueService, createdDateSearchFilterService, translate, matIconRegistry, domSanitizer) {
        super(searchFilterValueService);
        this.datePipe = datePipe;
        this.searchFilterValueService = searchFilterValueService;
        this.createdDateSearchFilterService = createdDateSearchFilterService;
        this.translate = translate;
        this.matIconRegistry = matIconRegistry;
        this.domSanitizer = domSanitizer;
        this.destroyRef = inject(DestroyRef);
        this.defaultCreatedDateOptions = [
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_7_DAYS',
                date: 'LAST_7_DAYS',
            },
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_30_DAYS',
                date: 'LAST_30_DAYS',
            },
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_6_MONTHS',
                date: 'LAST_6_MONTHS',
            },
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_YEAR',
                date: 'LAST_YEAR',
            },
        ];
        this.beforeDateInputSubject = new Subject();
        this.afterDateInputSubject = new Subject();
        this.afterDateFilter = (d) => {
            const beforeDate = this.filterForm.value.beforeDate;
            return !beforeDate || !d || isBefore(d, beforeDate);
        };
        this.beforeDateFilter = (d) => {
            const afterDate = this.filterForm.value.afterDate;
            return !afterDate || !d || isAfter(d, afterDate);
        };
        const icons = {
            search_calendar: 'assets/search-icons/Calendar_search.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    get id() {
        return 'CreatedDateSearchFiltersComponent';
    }
    ngOnInit() {
        this.beforeDateInputSubject.pipe(debounceTime(500), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
            this.filterForm.get('beforeDate')?.updateValueAndValidity({ onlySelf: true, emitEvent: false });
        });
        this.afterDateInputSubject.pipe(debounceTime(500), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
            this.filterForm.get('afterDate')?.updateValueAndValidity({ onlySelf: true, emitEvent: false });
        });
    }
    toHXQL(data) {
        return this.createdDateSearchFilterService.toHXQL(data);
    }
    setData(data) {
        try {
            for (const value of data?.values || []) {
                const beforeDate = value.beforeDate ? new Date(value.beforeDate) : null;
                const afterDate = value.afterDate ? new Date(value.afterDate) : null;
                if (afterDate || beforeDate) {
                    this.filterForm.patchValue({
                        isCustomDate: true,
                        afterDate,
                        beforeDate,
                    });
                    this.updateCustomDateSelectedValue();
                }
                else if (value['date']) {
                    this.createdDateValueChanged(value);
                }
            }
        }
        catch (error) {
            console.error('Error while setting data for Created Date filter', error);
        }
    }
    getFormControls() {
        return {
            defaultOption: new FormControl(null),
            isCustomDate: new FormControl(false),
            afterDate: new FormControl(null, [this.dateFormatValidator('afterDateInput'), this.afterDateValidator()]),
            beforeDate: new FormControl(null, [this.dateFormatValidator('beforeDateInput'), this.beforeDateValidator()]),
        };
    }
    dateFormatValidator(dateInputTypeLocator) {
        return () => {
            const value = this[dateInputTypeLocator]?.nativeElement.value || '';
            const parsedDate = parse(value, 'MM/dd/yyyy', new Date());
            if (value && !isValid(parsedDate)) {
                return { invalidDateFormat: true };
            }
            return null;
        };
    }
    afterDateValidator() {
        return (control) => {
            const afterDate = control.value;
            const beforeDate = this.filterForm?.get('beforeDate')?.value;
            if (isAfter(afterDate, beforeDate)) {
                return { afterDateTooLate: true };
            }
            return null;
        };
    }
    beforeDateValidator() {
        return (control) => {
            const beforeDate = control.value;
            const afterDate = this.filterForm?.get('afterDate')?.value;
            if (isBefore(beforeDate, afterDate)) {
                return { beforeDateTooEarly: true };
            }
            return null;
        };
    }
    enableCustomDate(e) {
        e.preventDefault();
        this.selectionList?.deselectAll();
        this.selectedValue = this.value;
        this.filterForm.patchValue({
            defaultOption: null,
            isCustomDate: true,
        });
    }
    createdDateValueChanged(data) {
        this.selectedValue = new CreatedDateSearchFilterData([data]);
        this.filterForm.patchValue({
            defaultOption: this.selectedValue,
            isCustomDate: false,
            afterDate: null,
            beforeDate: null,
        });
    }
    afterDateChanged(event) {
        this.filterForm.patchValue({
            afterDate: event.value,
        });
        this.updateCustomDateSelectedValue();
    }
    beforeDateChanged(event) {
        this.filterForm.patchValue({
            beforeDate: event.value,
        });
        this.updateCustomDateSelectedValue();
    }
    clearAfterDate(event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.afterDateInput) {
            this.afterDateInput.nativeElement.value = '';
            this.filterForm.patchValue({
                afterDate: null,
            });
            this.updateCustomDateSelectedValue();
        }
    }
    clearBeforeDate(event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.beforeDateInput) {
            this.beforeDateInput.nativeElement.value = '';
            this.filterForm.patchValue({
                beforeDate: null,
            });
            this.updateCustomDateSelectedValue();
        }
    }
    validateInput(event) {
        const pattern = /[0-9+\-/]/;
        const inputChar = String.fromCharCode(event.charCode);
        if (!pattern.test(inputChar)) {
            event.preventDefault();
        }
    }
    updateCustomDateSelectedValue() {
        let label = '';
        const { afterDate, beforeDate } = this.filterForm.value;
        if (afterDate && beforeDate) {
            label = this.translate.instant('SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.SINCE_TO_DATE', {
                afterDate: this.datePipe.transform(afterDate, 'mediumDate'),
                beforeDate: this.datePipe.transform(beforeDate, 'mediumDate'),
            });
        }
        else if (afterDate && !beforeDate) {
            label = this.translate.instant('SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.SINCE_TO_TODAY', {
                date: this.datePipe.transform(afterDate, 'mediumDate'),
            });
        }
        else if (!afterDate && beforeDate) {
            label = this.translate.instant('SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.UNTIL_DATE', {
                date: this.datePipe.transform(beforeDate, 'mediumDate'),
            });
        }
        this.selectedValue = label
            ? new CreatedDateSearchFilterData([
                {
                    label,
                    afterDate,
                    beforeDate,
                },
            ])
            : this.value;
    }
    discardPendingChanges() {
        super.discardPendingChanges();
        this.selectionList?.deselectAll();
    }
    clearChanges() {
        super.clearChanges();
        this.selectionList?.deselectAll();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CreatedDateSearchFiltersComponent, deps: [{ token: i2$2.DatePipe }, { token: i1.SearchFilterValueService }, { token: CreatedDateSearchFilterService }, { token: i4.TranslateService }, { token: i3$1.MatIconRegistry }, { token: i2$4.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: CreatedDateSearchFiltersComponent, isStandalone: true, selector: "hxp-search-created-date-filter", providers: [CreatedDateSearchFilterService], viewQueries: [{ propertyName: "afterDateInput", first: true, predicate: ["afterDateInput"], descendants: true }, { propertyName: "beforeDateInput", first: true, predicate: ["beforeDateInput"], descendants: true }, { propertyName: "selectionList", first: true, predicate: MatSelectionList, descendants: true }], usesInheritance: true, ngImport: i0, template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.CREATED_DATE.LABEL' | translate\"\n    [filterForm]=\"filterForm\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n>\n    <div class=\"hxp-created-date-filter-container\">\n        <mat-selection-list\n            id=\"hxp-created-data-filter-default-options-list\"\n            multiple=\"false\"\n            hideSingleSelectionIndicator\n            [attr.aria-label]=\"\n                'SEARCH.FILTERS.CREATED_DATE.ARIA-LABEL.DEFAULT_OPTIONS_LIST'\n                    | translate\n            \"\n        >\n            <mat-list-option\n                *ngFor=\"let option of defaultCreatedDateOptions\"\n                id=\"{{ option.date }}\"\n                [class.hxp-created-date-filter-option_active]=\"this.filterForm.value.defaultOption?.values[0].date === option.date\"\n                class=\"hxp-created-date-filter-option\"\n                (click)=\"createdDateValueChanged(option)\"\n                [value]=\"option.label\"\n                [attr.aria-label]=\"option.label | translate\"\n            >\n                <span>\n                    {{ option.label | translate }}\n                </span>\n            </mat-list-option>\n        </mat-selection-list>\n\n        <mat-divider />\n\n        <button\n            class=\"hxp-created-date-filter-custom-date-button\"\n            *ngIf=\"!filterForm.value.isCustomDate; else customDateRange\"\n            mat-menu-item\n            (click)=\"enableCustomDate($event)\"\n        >\n            <mat-icon aria-hidden=\"true\">add</mat-icon>\n            <span class=\"mat-body-1\">\n                {{\n                    'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.LABEL'\n                    | translate\n                }}\n            </span>\n        </button>\n\n        <ng-template #customDateRange>\n            <div class=\"hxp-custom-created-date\">\n                <label\n                    id=\"hxp-after-created-date-picker-label\"\n                    for=\"hxp-after-created-date-picker-input\"\n                >\n                    {{\n                        'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.AFTER'\n                            | translate\n                    }}\n                </label>\n                <mat-form-field\n                    appearance=\"outline\"\n                    [class.hxp-custom-created-date_active]=\"afterPicker.opened\"\n                >\n                    <input\n                        #afterDateInput\n                        id=\"hxp-after-created-date-picker-input\"\n                        aria-labelledby=\"hxp-after-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.afterDate\"\n                        (click)=\"afterPicker.open()\"\n                        [matDatepicker]=\"afterPicker\"\n                        [matDatepickerFilter]=\"afterDateFilter\"\n                        (dateChange)=\"afterDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"afterDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('afterDate')?.errors?.['afterDateTooLate']\n                        \"\n                        class=\"hxp-custom-created-date-error mat-caption\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.AFTER_DATE_TOO_LATE'\n                                | translate\n                        }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('afterDate')?.errors\n                                ?.['invalidDateFormat']\n                        \"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT'\n                                | translate\n                        }}\n                    </mat-error>\n\n                    <div class=\"hxp-created-date-picker-suffix\" matSuffix>\n                        <button\n                            *ngIf=\"afterDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"\n                                'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.AFTER'\n                                    | translate\n                            \"\n                            (click)=\"clearAfterDate($event)\"\n                        >\n                            <mat-icon> close </mat-icon>\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"afterPicker\"\n                            data-automation-id=\"hxp-after-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"search_calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                    </div>\n                    <mat-datepicker #afterPicker />\n                </mat-form-field>\n            </div>\n\n            <div class=\"hxp-custom-created-date\">\n                <label\n                    id=\"hxp-before-created-date-picker-label\"\n                    for=\"hxp-before-created-date-picker-input\"\n                >\n                    {{\n                        'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.BEFORE'\n                            | translate\n                    }}\n                </label>\n\n                <mat-form-field\n                    appearance=\"outline\"\n                    [class.hxp-custom-created-date_active]=\"beforePicker.opened\"\n                >\n                    <input\n                        #beforeDateInput\n                        id=\"hxp-before-created-date-picker-input\"\n                        aria-labelledby=\"hxp-before-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.beforeDate\"\n                        (click)=\"beforePicker.open()\"\n                        [matDatepicker]=\"beforePicker\"\n                        [matDatepickerFilter]=\"beforeDateFilter\"\n                        (dateChange)=\"beforeDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"beforeDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('beforeDate')?.errors\n                                ?.['beforeDateTooEarly']\n                        \"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.BEFORE_DATE_TOO_EARLY'\n                                | translate\n                        }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('beforeDate')?.errors\n                                ?.['invalidDateFormat']\n                        \"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT'\n                                | translate\n                        }}\n                    </mat-error>\n\n                    <div class=\"hxp-created-date-picker-suffix\" matSuffix>\n                        <button\n                            *ngIf=\"beforeDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"\n                                'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.BEFORE'\n                                    | translate\n                            \"\n                            (click)=\"clearBeforeDate($event)\"\n                        >\n                            <mat-icon>close</mat-icon>\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"beforePicker\"\n                            data-automation-id=\"hxp-before-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"search_calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                        <mat-datepicker #beforePicker />\n                    </div>\n                </mat-form-field>\n            </div>\n        </ng-template>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-created-date-filter-container{width:300px;display:flex;flex-direction:column}.hxp-created-date-filter-container .hxp-created-date-filter-option{border-inline-start:6px solid transparent;box-sizing:border-box}.hxp-created-date-filter-container .hxp-created-date-filter-option_active{background-color:#f9f9fc;border-inline-start:6px solid #5654ac}.hxp-created-date-filter-container mat-divider{margin:10px}.hxp-created-date-filter-container .hxp-custom-created-date{display:flex;flex-direction:column;margin:0 15px 15px}.hxp-created-date-filter-container .hxp-custom-created-date-error{margin:0 -15px}.hxp-created-date-filter-container .hxp-custom-created-date ::ng-deep .mat-form-field-appearance-outline.mat-focused .mdc-notched-outline{color:#5654ac}.hxp-created-date-filter-container .hxp-custom-created-date ::ng-deep .mat-form-field-appearance-outline:hover .mdc-notched-outline{color:#5654ac}.hxp-created-date-filter-container .hxp-custom-created-date .hxp-created-date-picker-suffix{display:flex}::ng-deep .mat-form-field-appearance-outline.hxp-custom-created-date_active .mdc-notched-outline{color:#5654ac;opacity:1}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2$2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i5.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i10.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i10.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i10.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "directive", type: i10.MatDatepickerToggleIcon, selector: "[matDatepickerToggleIcon]" }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatListModule }, { kind: "component", type: i13.MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "component", type: i13.MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i6.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: SearchFilterContainerComponent, selector: "hxp-search-filter-container", inputs: ["name", "filterForm", "selectedValue"], outputs: ["overlayClosed", "filterCleared", "filterApplied"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: CreatedDateSearchFiltersComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-created-date-filter', standalone: true, imports: [
                        CommonModule,
                        FormsModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatDatepickerModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        MatMenuModule,
                        ReactiveFormsModule,
                        SearchFilterContainerComponent,
                        TranslatePipe,
                    ], providers: [CreatedDateSearchFilterService], template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.CREATED_DATE.LABEL' | translate\"\n    [filterForm]=\"filterForm\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n>\n    <div class=\"hxp-created-date-filter-container\">\n        <mat-selection-list\n            id=\"hxp-created-data-filter-default-options-list\"\n            multiple=\"false\"\n            hideSingleSelectionIndicator\n            [attr.aria-label]=\"\n                'SEARCH.FILTERS.CREATED_DATE.ARIA-LABEL.DEFAULT_OPTIONS_LIST'\n                    | translate\n            \"\n        >\n            <mat-list-option\n                *ngFor=\"let option of defaultCreatedDateOptions\"\n                id=\"{{ option.date }}\"\n                [class.hxp-created-date-filter-option_active]=\"this.filterForm.value.defaultOption?.values[0].date === option.date\"\n                class=\"hxp-created-date-filter-option\"\n                (click)=\"createdDateValueChanged(option)\"\n                [value]=\"option.label\"\n                [attr.aria-label]=\"option.label | translate\"\n            >\n                <span>\n                    {{ option.label | translate }}\n                </span>\n            </mat-list-option>\n        </mat-selection-list>\n\n        <mat-divider />\n\n        <button\n            class=\"hxp-created-date-filter-custom-date-button\"\n            *ngIf=\"!filterForm.value.isCustomDate; else customDateRange\"\n            mat-menu-item\n            (click)=\"enableCustomDate($event)\"\n        >\n            <mat-icon aria-hidden=\"true\">add</mat-icon>\n            <span class=\"mat-body-1\">\n                {{\n                    'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.LABEL'\n                    | translate\n                }}\n            </span>\n        </button>\n\n        <ng-template #customDateRange>\n            <div class=\"hxp-custom-created-date\">\n                <label\n                    id=\"hxp-after-created-date-picker-label\"\n                    for=\"hxp-after-created-date-picker-input\"\n                >\n                    {{\n                        'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.AFTER'\n                            | translate\n                    }}\n                </label>\n                <mat-form-field\n                    appearance=\"outline\"\n                    [class.hxp-custom-created-date_active]=\"afterPicker.opened\"\n                >\n                    <input\n                        #afterDateInput\n                        id=\"hxp-after-created-date-picker-input\"\n                        aria-labelledby=\"hxp-after-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.afterDate\"\n                        (click)=\"afterPicker.open()\"\n                        [matDatepicker]=\"afterPicker\"\n                        [matDatepickerFilter]=\"afterDateFilter\"\n                        (dateChange)=\"afterDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"afterDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('afterDate')?.errors?.['afterDateTooLate']\n                        \"\n                        class=\"hxp-custom-created-date-error mat-caption\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.AFTER_DATE_TOO_LATE'\n                                | translate\n                        }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('afterDate')?.errors\n                                ?.['invalidDateFormat']\n                        \"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT'\n                                | translate\n                        }}\n                    </mat-error>\n\n                    <div class=\"hxp-created-date-picker-suffix\" matSuffix>\n                        <button\n                            *ngIf=\"afterDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"\n                                'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.AFTER'\n                                    | translate\n                            \"\n                            (click)=\"clearAfterDate($event)\"\n                        >\n                            <mat-icon> close </mat-icon>\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"afterPicker\"\n                            data-automation-id=\"hxp-after-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"search_calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                    </div>\n                    <mat-datepicker #afterPicker />\n                </mat-form-field>\n            </div>\n\n            <div class=\"hxp-custom-created-date\">\n                <label\n                    id=\"hxp-before-created-date-picker-label\"\n                    for=\"hxp-before-created-date-picker-input\"\n                >\n                    {{\n                        'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.BEFORE'\n                            | translate\n                    }}\n                </label>\n\n                <mat-form-field\n                    appearance=\"outline\"\n                    [class.hxp-custom-created-date_active]=\"beforePicker.opened\"\n                >\n                    <input\n                        #beforeDateInput\n                        id=\"hxp-before-created-date-picker-input\"\n                        aria-labelledby=\"hxp-before-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.beforeDate\"\n                        (click)=\"beforePicker.open()\"\n                        [matDatepicker]=\"beforePicker\"\n                        [matDatepickerFilter]=\"beforeDateFilter\"\n                        (dateChange)=\"beforeDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"beforeDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('beforeDate')?.errors\n                                ?.['beforeDateTooEarly']\n                        \"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.BEFORE_DATE_TOO_EARLY'\n                                | translate\n                        }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"\n                            filterForm.get('beforeDate')?.errors\n                                ?.['invalidDateFormat']\n                        \"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT'\n                                | translate\n                        }}\n                    </mat-error>\n\n                    <div class=\"hxp-created-date-picker-suffix\" matSuffix>\n                        <button\n                            *ngIf=\"beforeDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"\n                                'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.BEFORE'\n                                    | translate\n                            \"\n                            (click)=\"clearBeforeDate($event)\"\n                        >\n                            <mat-icon>close</mat-icon>\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"beforePicker\"\n                            data-automation-id=\"hxp-before-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"search_calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                        <mat-datepicker #beforePicker />\n                    </div>\n                </mat-form-field>\n            </div>\n        </ng-template>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-created-date-filter-container{width:300px;display:flex;flex-direction:column}.hxp-created-date-filter-container .hxp-created-date-filter-option{border-inline-start:6px solid transparent;box-sizing:border-box}.hxp-created-date-filter-container .hxp-created-date-filter-option_active{background-color:#f9f9fc;border-inline-start:6px solid #5654ac}.hxp-created-date-filter-container mat-divider{margin:10px}.hxp-created-date-filter-container .hxp-custom-created-date{display:flex;flex-direction:column;margin:0 15px 15px}.hxp-created-date-filter-container .hxp-custom-created-date-error{margin:0 -15px}.hxp-created-date-filter-container .hxp-custom-created-date ::ng-deep .mat-form-field-appearance-outline.mat-focused .mdc-notched-outline{color:#5654ac}.hxp-created-date-filter-container .hxp-custom-created-date ::ng-deep .mat-form-field-appearance-outline:hover .mdc-notched-outline{color:#5654ac}.hxp-created-date-filter-container .hxp-custom-created-date .hxp-created-date-picker-suffix{display:flex}::ng-deep .mat-form-field-appearance-outline.hxp-custom-created-date_active .mdc-notched-outline{color:#5654ac;opacity:1}\n"] }]
        }], ctorParameters: () => [{ type: i2$2.DatePipe }, { type: i1.SearchFilterValueService }, { type: CreatedDateSearchFilterService }, { type: i4.TranslateService }, { type: i3$1.MatIconRegistry }, { type: i2$4.DomSanitizer }], propDecorators: { afterDateInput: [{
                type: ViewChild,
                args: ['afterDateInput']
            }], beforeDateInput: [{
                type: ViewChild,
                args: ['beforeDateInput']
            }], selectionList: [{
                type: ViewChild,
                args: [MatSelectionList]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCategorySearchFilterService {
    toHXQL(data) {
        return data?.values?.length > 0 ? `sys_primaryType IN (${data.values.map((i) => `'${i.value}'`).join(',')})` : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentCategorySearchFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentCategorySearchFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentCategorySearchFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCategorySearchFilterValue {
    constructor() {
        this.label = '';
        this.value = '';
    }
}
const compareFn$2 = (a, b) => a.value.localeCompare(b.value);
class DocumentCategorySearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn$2);
        const sortedDataValues = data.values.sort(compareFn$2);
        for (const [i, sortedValue] of sortedValues.entries()) {
            if (sortedValue.value !== sortedDataValues[i].value) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCategorySearchFiltersComponent extends BaseSearchFilterDirective {
    constructor(documentModelService, searchFilterValueService, documentCategorySearchFilterService, changeDetector, matIconRegistry, domSanitizer) {
        super(searchFilterValueService);
        this.documentModelService = documentModelService;
        this.searchFilterValueService = searchFilterValueService;
        this.documentCategorySearchFilterService = documentCategorySearchFilterService;
        this.changeDetector = changeDetector;
        this.matIconRegistry = matIconRegistry;
        this.domSanitizer = domSanitizer;
        this.allowedSysCategories = ['SysFolder', 'SysFile'];
        this.isLoading = false;
        this.categories = [];
        this.filteredCategories = [];
        this.searchTerm = '';
        this.selection = new SelectionModel(true, []);
        this.destroyRef = inject(DestroyRef);
        const icons = {
            search_clear: 'assets/search-icons/Clear.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    get id() {
        return 'DocumentCategorySearchFiltersComponent';
    }
    ngOnInit() {
        this.isLoading = true;
        this.documentModelService
            .getModel()
            .pipe(takeUntilDestroyed(this.destroyRef), finalize(() => (this.isLoading = false)))
            .subscribe({
            next: (model) => {
                this.categories = model
                    .getSubtypes('')
                    .filter((category) => (category.startsWith('Sys') ? this.allowedSysCategories.includes(category) : category));
                this.filteredCategories = this.categories;
            },
        });
    }
    toHXQL(data) {
        return this.documentCategorySearchFilterService.toHXQL(data);
    }
    clearFilter() {
        super.clearFilter();
        this.searchFilterComponent?.clearInput();
        this.selection.clear();
    }
    applyFilter() {
        if (this.selection.selected.length === 0) {
            return this.clearFilter();
        }
        super.applyFilter();
    }
    overlayClosed() {
        this.selection.clear();
        if (this.oldFormValue.selectedCategories.length > 0) {
            for (const category of this.oldFormValue.selectedCategories) {
                this.selection.select(category);
            }
        }
        this.discardPendingChanges();
    }
    getFormControls() {
        return {
            selectedCategories: new FormControl([]),
        };
    }
    setData(data) {
        try {
            if (data?.values) {
                for (const category of data?.values || []) {
                    this.selection.select(category.value);
                }
            }
            this.setSelectedValue();
        }
        catch (error) {
            console.error('Error while setting data for Content Type filter', error);
        }
    }
    filteredSearch(searchTerm) {
        this.searchTerm = searchTerm;
        this.filteredCategories = this.categories.filter((entry) => entry.toLowerCase().includes(searchTerm));
    }
    onSelectionListChange(event) {
        this.onSelectionChange(event?.options[0]?.value);
    }
    onDeselect(category) {
        this.onSelectionChange(category);
    }
    onSelectionChange(category) {
        this.selection.toggle(category);
        this.setSelectedValue();
    }
    setSelectedValue() {
        this.filterForm.patchValue({
            selectedCategories: this.selection.selected,
        });
        if (this.selection.selected.length === 0) {
            this.selectedValue = undefined;
            return;
        }
        const selectedValues = this.selection.selected.length === 0
            ? undefined
            : this.selection.selected.map((sel) => ({
                label: sel,
                value: sel,
            }));
        this.selectedValue = new DocumentCategorySearchFilterData(selectedValues);
    }
    isChecked(category) {
        return this.selection.isSelected(category);
    }
    clearInput() {
        this.searchTerm = '';
        this.filteredCategories = this.categories;
        this.changeDetector.detectChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentCategorySearchFiltersComponent, deps: [{ token: i1.DocumentModelService }, { token: i1.SearchFilterValueService }, { token: DocumentCategorySearchFilterService }, { token: i0.ChangeDetectorRef }, { token: i3$1.MatIconRegistry }, { token: i2$4.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: DocumentCategorySearchFiltersComponent, isStandalone: true, selector: "hxp-search-document-category-filter", providers: [DocumentCategorySearchFilterService], viewQueries: [{ propertyName: "searchFilterComponent", first: true, predicate: SearchFilterInputComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n    [filterForm]=\"filterForm\"\n>\n    <div class=\"hxp-document-category-filter-container\">\n        <hxp-search-filter-input\n            [inputAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n            [placeholder]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.PLACEHOLDER' | translate\"\n            [clearAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.CLEAR_INPUT' | translate\"\n            (search)=\"filteredSearch($event)\"\n            (clear)=\"clearInput()\"\n        />\n\n        <div class=\"hxp-document-category-filter-summary\">\n            <mat-chip-set\n                class=\"hxp-document-category-filter-summary-list\"\n                tabindex=\"0\"\n            >\n                <span class=\"hxp-document-category-filter-summary-list-prefix\">\n                    {{\n                        'SEARCH.FILTERS.DOCUMENT_CATEGORY.SELECTED'\n                            | translate: { selected: selection.selected.length }\n                    }}<span *ngIf=\"selection.selected.length > 0\" class=\"hxp-document-category-filter-summary-list-colon\">:</span>\n                </span>\n                <mat-chip\n                    *ngFor=\"let selectedCategory of selection.selected\"\n                    class=\"hxp-document-category-filter-summary-list-item\"\n                    [attr.aria-label]=\"selectedCategory\"\n                >\n                    <span class=\"hxp-document-category-filter-summary-list-item__label\">{{ selectedCategory }}</span>\n                    <button\n                        matChipRemove\n                        [attr.aria-label]=\"\n                            ('SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.REMOVE'\n                                | translate) +\n                            ' ' +\n                            selectedCategory\n                        \"\n                        (click)=\"onDeselect(selectedCategory)\"\n                    >\n                        <mat-icon\n                            class=\"hxp-document-category-filter-summary-list-remove-item-icon\"\n                            svgIcon=\"search_clear\"\n                            aria-hidden=\"true\"\n                        />\n                    </button>\n                </mat-chip>\n            </mat-chip-set>\n        </div>\n\n        <div\n            *ngIf=\"isLoading\"\n            class=\"hxp-document-category-filter-spinner-container\"\n        >\n            <mat-progress-spinner mode=\"indeterminate\" />\n        </div>\n\n        <ng-container *ngIf=\"!isLoading\">\n            <mat-selection-list\n                #documentCategories\n                class=\"hxp-document-category-filter-list\"\n                (selectionChange)=\"onSelectionListChange($event)\"\n                *ngIf=\"filteredCategories.length; else noResults\"\n                [attr.aria-label]=\"\n                    'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.DOCUMENT_CATEGORIES_LIST'\n                        | translate\n                \"\n            >\n                <mat-list-option\n                    *ngFor=\"let category of filteredCategories\"\n                    [value]=\"category\"\n                    class=\"hxp-document-category-filter-list-option\"\n                    checkboxPosition=\"before\"\n                    [selected]=\"isChecked(category)\"\n                    [attr.aria-label]=\"category\"\n                >\n                    <span>{{ category }}</span>\n                </mat-list-option>\n            </mat-selection-list>\n\n            <ng-template #noResults>\n                <div class=\"hxp-document-category-filter-no-results\">\n                    <h2>\n                        {{\n                            'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.TITLE'\n                                | translate\n                        }}\n                    </h2>\n                    <p>\n                        {{\n                            'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.MESSAGE'\n                                | translate\n                        }}\n                    </p>\n                </div>\n            </ng-template>\n        </ng-container>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-document-category-filter-container{width:300px;height:468px;display:flex;flex-direction:column;padding:24px}.hxp-document-category-filter-list{max-height:360px;overflow-y:scroll}.hxp-document-category-filter-summary{padding-bottom:8px}.hxp-document-category-filter-summary-list{width:100%;max-height:110px;overflow-y:auto}.hxp-document-category-filter-summary-list-prefix{margin-top:2px;margin-bottom:2px;margin-left:8px}.hxp-document-category-filter-summary-list-item{min-height:auto;height:14px;background-color:#ebeaf5;border-radius:2px;padding-top:3px;padding-bottom:3px}.hxp-document-category-filter-summary-list-item button{margin:0}.hxp-document-category-filter-summary-list-item__label{color:var(--theme-primary-color, #5654ac);font-weight:600}.hxp-document-category-filter-summary-list-remove-item-icon{color:var(--theme-primary-color, #5654ac);opacity:1;width:12px!important}.hxp-document-category-filter-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#111827}.hxp-document-category-filter-no-results h2,.hxp-document-category-filter-no-results p{margin:0}.hxp-document-category-filter-spinner-container{display:flex;justify-content:center;align-items:center;height:100%;width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2$2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i6$3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: i6$3.MatChipRemove, selector: "[matChipRemove]" }, { kind: "component", type: i6$3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatListModule }, { kind: "component", type: i13.MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "component", type: i13.MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i6$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: SearchFilterContainerComponent, selector: "hxp-search-filter-container", inputs: ["name", "filterForm", "selectedValue"], outputs: ["overlayClosed", "filterCleared", "filterApplied"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: SearchFilterInputComponent, selector: "hxp-search-filter-input", inputs: ["applyOnEnter", "inputAriaLabel", "placeholder", "clearAriaLabel", "prefixIcon", "prefixAriaLabel"], outputs: ["search", "clear", "prefixClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: DocumentCategorySearchFiltersComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-document-category-filter', standalone: true, imports: [
                        CommonModule,
                        FormsModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatDividerModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        MatProgressSpinnerModule,
                        ReactiveFormsModule,
                        SearchFilterContainerComponent,
                        TranslatePipe,
                        SearchFilterInputComponent,
                    ], providers: [DocumentCategorySearchFilterService], template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n    [filterForm]=\"filterForm\"\n>\n    <div class=\"hxp-document-category-filter-container\">\n        <hxp-search-filter-input\n            [inputAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n            [placeholder]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.PLACEHOLDER' | translate\"\n            [clearAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.CLEAR_INPUT' | translate\"\n            (search)=\"filteredSearch($event)\"\n            (clear)=\"clearInput()\"\n        />\n\n        <div class=\"hxp-document-category-filter-summary\">\n            <mat-chip-set\n                class=\"hxp-document-category-filter-summary-list\"\n                tabindex=\"0\"\n            >\n                <span class=\"hxp-document-category-filter-summary-list-prefix\">\n                    {{\n                        'SEARCH.FILTERS.DOCUMENT_CATEGORY.SELECTED'\n                            | translate: { selected: selection.selected.length }\n                    }}<span *ngIf=\"selection.selected.length > 0\" class=\"hxp-document-category-filter-summary-list-colon\">:</span>\n                </span>\n                <mat-chip\n                    *ngFor=\"let selectedCategory of selection.selected\"\n                    class=\"hxp-document-category-filter-summary-list-item\"\n                    [attr.aria-label]=\"selectedCategory\"\n                >\n                    <span class=\"hxp-document-category-filter-summary-list-item__label\">{{ selectedCategory }}</span>\n                    <button\n                        matChipRemove\n                        [attr.aria-label]=\"\n                            ('SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.REMOVE'\n                                | translate) +\n                            ' ' +\n                            selectedCategory\n                        \"\n                        (click)=\"onDeselect(selectedCategory)\"\n                    >\n                        <mat-icon\n                            class=\"hxp-document-category-filter-summary-list-remove-item-icon\"\n                            svgIcon=\"search_clear\"\n                            aria-hidden=\"true\"\n                        />\n                    </button>\n                </mat-chip>\n            </mat-chip-set>\n        </div>\n\n        <div\n            *ngIf=\"isLoading\"\n            class=\"hxp-document-category-filter-spinner-container\"\n        >\n            <mat-progress-spinner mode=\"indeterminate\" />\n        </div>\n\n        <ng-container *ngIf=\"!isLoading\">\n            <mat-selection-list\n                #documentCategories\n                class=\"hxp-document-category-filter-list\"\n                (selectionChange)=\"onSelectionListChange($event)\"\n                *ngIf=\"filteredCategories.length; else noResults\"\n                [attr.aria-label]=\"\n                    'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.DOCUMENT_CATEGORIES_LIST'\n                        | translate\n                \"\n            >\n                <mat-list-option\n                    *ngFor=\"let category of filteredCategories\"\n                    [value]=\"category\"\n                    class=\"hxp-document-category-filter-list-option\"\n                    checkboxPosition=\"before\"\n                    [selected]=\"isChecked(category)\"\n                    [attr.aria-label]=\"category\"\n                >\n                    <span>{{ category }}</span>\n                </mat-list-option>\n            </mat-selection-list>\n\n            <ng-template #noResults>\n                <div class=\"hxp-document-category-filter-no-results\">\n                    <h2>\n                        {{\n                            'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.TITLE'\n                                | translate\n                        }}\n                    </h2>\n                    <p>\n                        {{\n                            'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.MESSAGE'\n                                | translate\n                        }}\n                    </p>\n                </div>\n            </ng-template>\n        </ng-container>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-document-category-filter-container{width:300px;height:468px;display:flex;flex-direction:column;padding:24px}.hxp-document-category-filter-list{max-height:360px;overflow-y:scroll}.hxp-document-category-filter-summary{padding-bottom:8px}.hxp-document-category-filter-summary-list{width:100%;max-height:110px;overflow-y:auto}.hxp-document-category-filter-summary-list-prefix{margin-top:2px;margin-bottom:2px;margin-left:8px}.hxp-document-category-filter-summary-list-item{min-height:auto;height:14px;background-color:#ebeaf5;border-radius:2px;padding-top:3px;padding-bottom:3px}.hxp-document-category-filter-summary-list-item button{margin:0}.hxp-document-category-filter-summary-list-item__label{color:var(--theme-primary-color, #5654ac);font-weight:600}.hxp-document-category-filter-summary-list-remove-item-icon{color:var(--theme-primary-color, #5654ac);opacity:1;width:12px!important}.hxp-document-category-filter-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#111827}.hxp-document-category-filter-no-results h2,.hxp-document-category-filter-no-results p{margin:0}.hxp-document-category-filter-spinner-container{display:flex;justify-content:center;align-items:center;height:100%;width:100%}\n"] }]
        }], ctorParameters: () => [{ type: i1.DocumentModelService }, { type: i1.SearchFilterValueService }, { type: DocumentCategorySearchFilterService }, { type: i0.ChangeDetectorRef }, { type: i3$1.MatIconRegistry }, { type: i2$4.DomSanitizer }], propDecorators: { searchFilterComponent: [{
                type: ViewChild,
                args: [SearchFilterInputComponent]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterService {
    toHXQL(data) {
        if (!data?.values?.length) {
            return '';
        }
        const mimeTypes = data.values.flatMap((fileType) => fileType.value);
        return `sysfile_blob/mimeType IN (${mimeTypes.map((type) => `'${type}'`).join(', ')})`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterValue {
    constructor() {
        this.label = '';
        this.value = [];
        this.fileTypeId = '';
    }
}
const compareFn$1 = (a, b) => a.fileTypeId.localeCompare(b.fileTypeId);
class FileTypeSearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn$1);
        const sortedDataValues = data.values.sort(compareFn$1);
        return sortedValues.every((sortedValue, index) => sortedValue.value === sortedDataValues[index].value);
    }
}

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeNode {
    constructor() {
        this.id = '';
        this.label = '';
        this.formats = [];
    }
}
class FileTypeFlatNode {
    constructor() {
        this.id = '';
        this.label = '';
        this.mimeTypeIcon = '';
    }
}
const TREE_DATA = [
    {
        id: 'documents',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.LABEL',
        formats: [
            {
                id: 'documents/portable-document-format',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.PORTABLE_DOCUMENT_FORMAT',
                extensions: ['pdf'],
                mimeTypes: ['application/pdf'],
                mimeTypeIcon: 'application/pdf',
            },
            {
                id: 'documents/presentation',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.PRESENTATION',
                extensions: ['ppt', 'pptx'],
                mimeTypes: ['application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
                mimeTypeIcon: 'application/vnd.ms-powerpoint',
            },
            {
                id: 'documents/spreadsheet',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.SPREADSHEET',
                extensions: ['xls', 'xlsx'],
                mimeTypes: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                mimeTypeIcon: 'application/vnd.ms-excel',
            },
            {
                id: 'documents/text-document',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.TEXT_DOCUMENT',
                extensions: ['doc', 'docx'],
                mimeTypes: ['application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
                mimeTypeIcon: 'application/msword',
            },
            {
                id: 'documents/text-file',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.TEXT_FILE',
                extensions: ['txt'],
                mimeTypes: ['text/plain'],
                mimeTypeIcon: 'text/plain',
            },
        ],
    },
    {
        id: 'images',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.LABEL',
        formats: [
            {
                id: 'images/uncompressed-image-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.UNCOMPRESSED_IMAGE_FORMATS',
                extensions: ['bmp', 'raw'],
                mimeTypes: ['image/bmp', 'image/x-panasonic-raw'],
                mimeTypeIcon: 'image/bmp',
            },
            {
                id: 'images/compressed-image-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.COMPRESSED_IMAGE_FORMATS',
                extensions: ['png', 'jpg', 'jpeg', 'gif', 'tiff', 'tif', 'webp'],
                mimeTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/tiff', 'image/webp'],
                mimeTypeIcon: 'image/png',
            },
            {
                id: 'images/vector-image-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.VECTOR_IMAGE_FORMATS',
                extensions: ['eps', 'svg'],
                mimeTypes: ['image/svg+xml', 'application/postscript'],
                mimeTypeIcon: 'image/svg+xml',
            },
            {
                id: 'images/software-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.SOFTWARE_FILES',
                extensions: ['ai', 'eps', 'psd', 'tga'],
                mimeTypes: [
                    'image/vnd.adobe.photoshop',
                    'application/postscript',
                    'application/illustrator',
                    'application/pdf',
                    'application/vsn.adobe.illustrator',
                    'image/x-tga',
                    'image/x-targa',
                    'image/targa',
                ],
                mimeTypeIcon: 'image/vnd.adobe.photoshop',
            },
        ],
    },
    {
        id: 'video',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.LABEL',
        formats: [
            {
                id: 'video/uncompressed-video-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.FORMATS.UNCOMPRESSED_VIDEO_FORMATS',
                extensions: ['avi', 'mov', 'raw'],
                mimeTypes: ['video/x-msvideo', 'video/quicktime', 'image/x-panasonic-raw'],
                mimeTypeIcon: 'video/x-msvideo',
            },
            {
                id: 'video/compressed-video-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.FORMATS.COMPRESSED_VIDEO_FORMATS',
                extensions: ['mp4', 'avi', 'mov', 'webm', 'flv'],
                mimeTypes: ['video/mp4', 'video/x-msvideo', 'video/quicktime', 'video/webm', 'video/x-flv'],
                mimeTypeIcon: 'video/mp4',
            },
            {
                id: 'video/software-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.FORMATS.SOFTWARE_FILES',
                extensions: ['mov', 'mp4', '3gp'],
                mimeTypes: ['video/quicktime', 'video/mp4', 'video/3gpp'],
                mimeTypeIcon: 'video/quicktime',
            },
        ],
    },
    {
        id: 'audio',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.AUDIO.LABEL',
        formats: [
            {
                id: 'audio/uncompressed-audio-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.AUDIO.FORMATS.UNCOMPRESSED_AUDIO_FORMATS',
                extensions: ['wav', 'aiff', 'au', 'raw'],
                mimeTypes: ['audio/vnd.wav', 'audio/wav', 'audio/aiff', 'audio/basic', 'image/x-panasonic-raw'],
                mimeTypeIcon: 'audio/wav',
            },
            {
                id: 'audio/compressed-audio-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.AUDIO.FORMATS.COMPRESSED_AUDIO_FORMATS',
                extensions: ['flac', 'wma', 'm4a', 'mp3', 'aac'],
                mimeTypes: ['audio/flac', 'audio/x-ms-wma', 'audio/m4a', 'audio/mp4', 'audio/mpeg', 'audio/aac'],
                mimeTypeIcon: 'audio/mp3',
            },
        ],
    },
    {
        id: 'other',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.OTHER.LABEL',
        formats: [
            {
                id: 'other/archive-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.OTHER.FORMATS.ARCHIVE_FILES',
                extensions: ['7z', 'zip'],
                mimeTypes: ['application/x-7z-compressed', 'application/zip', 'application/zip-compressed', 'application/x-zip-compressed'],
                mimeTypeIcon: 'application/zip',
            },
            {
                id: 'other/font-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.OTHER.FORMATS.FONT_FILES',
                extensions: ['otf', 'ttf'],
                mimeTypes: ['font/otf', 'application/x-font-otf', 'application/x-font-ttf'],
                mimeTypeIcon: 'font/otf',
            },
        ],
    },
];

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ArrayToStringPipe {
    transform(value = [], prefix = '.', separator = ',') {
        if (!Array.isArray(value) || value.length === 0) {
            return '';
        }
        return value.map((val) => `${prefix}${val}`).join(`${separator} `);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ArrayToStringPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: ArrayToStringPipe, isStandalone: true, name: "arrayToString" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ArrayToStringPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'arrayToString',
                    standalone: true,
                }]
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterTreeComponent {
    constructor() {
        this.flatNodeMap = new Map();
        this.nestedNodeMap = new Map();
        this.selectedParent = null;
        this.fileTypeSelection = new SelectionModel(true, [], true, (node1, node2) => node1.id === node2.id);
        this.selectedFileTypes = new EventEmitter();
        this.getLevel = (node) => node.level || 0;
        this.isExpandable = (node) => node.expandable || false;
        this.getChildren = (node) => node.formats || [];
        this.hasChild = (_, _nodeData) => _nodeData.expandable;
        this.hasNoContent = (_, _nodeData) => _nodeData.label === '';
        /**
         * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
         */
        this.transformer = (node, level) => {
            const existingNode = this.nestedNodeMap.get(node);
            const flatNode = existingNode && existingNode.label === node.label ? existingNode : new FileTypeFlatNode();
            flatNode.id = node.id;
            flatNode.label = node.label;
            flatNode.level = level;
            flatNode.expandable = !!node.formats?.length;
            if (!flatNode.expandable) {
                flatNode.mimeTypes = node['mimeTypes'];
                flatNode.extensions = node['extensions'];
                flatNode.mimeTypeIcon = node['mimeTypeIcon'];
            }
            this.flatNodeMap.set(flatNode, node);
            this.nestedNodeMap.set(node, flatNode);
            return flatNode;
        };
        this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
        this.treeControl = new FlatTreeControl(this.getLevel, this.isExpandable);
        this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
        this.dataSource.data = TREE_DATA;
    }
    ngOnChanges() {
        this.filterTree(this.filteredFileType);
    }
    fileTypeSelectionToggleById(nodeId) {
        const treeNode = this.treeControl.dataNodes.find((n) => n.id === nodeId);
        const node = this.flatNodeMap.get(treeNode);
        if (node) {
            this.fileTypeSelectionToggle(this.nestedNodeMap.get(node));
        }
    }
    fileTypeSelectionToggle(node) {
        this.fileTypeSelection.toggle(node);
        const descendants = this.treeControl.getDescendants(node);
        if (this.fileTypeSelection.isSelected(node)) {
            this.fileTypeSelection.select(...descendants);
        }
        else {
            this.fileTypeSelection.deselect(...descendants);
        }
        // Force update for the parent
        for (const child of descendants) {
            this.fileTypeSelection.isSelected(child);
        }
        this.checkAllParentsSelection(node);
        this.selectedFileTypes.emit(this.fileTypeSelection.selected);
        // keep the selected nodes expanded
        this.expandSelectedNodes();
    }
    clearSelection() {
        this.fileTypeSelection.clear();
        this.treeControl.collapseAll();
    }
    onNodeExpand(event) {
        event.preventDefault();
        event.stopPropagation();
    }
    descendantsAllSelected(node) {
        const descendants = this.treeControl.getDescendants(node);
        const descAllSelected = descendants.length > 0 &&
            descendants.every((child) => {
                return this.fileTypeSelection.isSelected(child);
            });
        return descAllSelected;
    }
    descendantsPartiallySelected(node) {
        const descendants = this.treeControl.getDescendants(node);
        const result = descendants.some((child) => this.fileTypeSelection.isSelected(child));
        return result && !this.descendantsAllSelected(node);
    }
    leafItemSelectionToggle(node) {
        this.fileTypeSelectionToggle(node);
        this.checkAllParentsSelection(node);
    }
    checkAllParentsSelection(node) {
        let parent = this.getParentNode(node);
        while (parent) {
            this.checkRootNodeSelection(parent);
            parent = this.getParentNode(parent);
        }
    }
    checkRootNodeSelection(node) {
        const nodeSelected = this.fileTypeSelection.isSelected(node);
        const descendants = this.treeControl.getDescendants(node);
        const descAllSelected = descendants.length > 0 &&
            descendants.every((child) => {
                return this.fileTypeSelection.isSelected(child);
            });
        if (nodeSelected && !descAllSelected) {
            this.fileTypeSelection.deselect(node);
        }
        else if (!nodeSelected && descAllSelected) {
            this.fileTypeSelection.select(node);
        }
    }
    getParentNode(node) {
        const currentLevel = this.getLevel(node);
        if (currentLevel < 1) {
            return null;
        }
        const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
        for (let i = startIndex; i >= 0; i--) {
            const currentNode = this.treeControl.dataNodes[i];
            if (this.getLevel(currentNode) < currentLevel) {
                return currentNode;
            }
        }
        return null;
    }
    filterTree(filterText) {
        this.dataSource.data = this.filterRecursive(filterText, TREE_DATA, 'label');
        if (filterText) {
            this.treeControl.expandAll();
        }
        else {
            // confirm if parent nodes are selected or not, because in case of filter we need to recheck the parent selection
            [...this.flatNodeMap.keys()].forEach((node) => this.checkAllParentsSelection(node));
            this.expandSelectedNodes();
        }
    }
    filterRecursive(filterText, data, property) {
        if (!filterText) {
            return data;
        }
        const copy = (o) => {
            return Object.assign({}, o);
        };
        filterText = filterText.toLowerCase();
        const filteredData = data.map(copy).filter(function x(y) {
            if (y[property].toLowerCase().includes(filterText)) {
                return true;
            }
            if (y?.formats) {
                return (y.formats = y.formats.map(copy).filter(x)).length;
            }
            if (y?.extensions) {
                return y.extensions.some((ext) => ext.includes(filterText));
            }
        });
        return filteredData;
    }
    /**
     * Expands all selected nodes to make inner nodes visible.
     */
    expandSelectedNodes() {
        for (const node of this.treeControl.dataNodes) {
            if (this.descendantsPartiallySelected(node) || this.descendantsAllSelected(node)) {
                this.treeControl.expand(node);
                let parent = this.getParentNode(node);
                while (parent) {
                    this.treeControl.expand(parent);
                    parent = this.getParentNode(parent);
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterTreeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: FileTypeSearchFilterTreeComponent, isStandalone: true, selector: "hxp-file-type-search-filter-tree", inputs: { filteredFileType: "filteredFileType" }, outputs: { selectedFileTypes: "selectedFileTypes" }, usesOnChanges: true, ngImport: i0, template: "<mat-tree\n    *ngIf=\"dataSource?.data?.length; else noResults\"\n    [dataSource]=\"dataSource\"\n    [treeControl]=\"treeControl\"\n>\n    <mat-tree-node\n        *matTreeNodeDef=\"let node\"\n        matTreeNodeToggle\n        matTreeNodePadding\n    >\n        <button mat-icon-button disabled></button>\n        <mat-checkbox\n            [checked]=\"fileTypeSelection.isSelected(node)\"\n            (change)=\"leafItemSelectionToggle(node)\"\n        >\n            <div class=\"hxp-mime-type-row\">\n                <hxp-mime-type-icon\n                    [mimeType]=\"node?.mimeTypeIcon\"\n                    aria-hidden=\"true\"\n                />\n                <div class=\"hxp-mime-type-description\">\n                    <span class=\"hxp-mime-type-description-title\">{{\n                        node.label | translate\n                    }}</span>\n                    <span class=\"hxp-mime-type-description-extensions\">{{\n                        node.extensions | arrayToString\n                    }}</span>\n                </div>\n            </div>\n        </mat-checkbox>\n    </mat-tree-node>\n\n    <mat-tree-node\n        *matTreeNodeDef=\"let node; when: hasChild\"\n        matTreeNodePadding\n    >\n        <button\n            mat-icon-button\n            matTreeNodeToggle\n            [attr.aria-label]=\"'Toggle ' + node.label\"\n            (click)=\"onNodeExpand($event)\"\n        >\n            <mat-icon class=\"mat-icon-rtl-mirror\">\n                {{\n                    treeControl.isExpanded(node)\n                        ? 'expand_more'\n                        : 'chevron_right'\n                }}\n            </mat-icon>\n        </button>\n        <mat-checkbox\n            [checked]=\"descendantsAllSelected(node)\"\n            [indeterminate]=\"descendantsPartiallySelected(node)\"\n            (change)=\"fileTypeSelectionToggle(node)\"\n        >\n            <span class=\"hxp-mime-type-parent-label hxp-label-bold\">{{ node.label | translate }}</span>\n        </mat-checkbox>\n    </mat-tree-node>\n</mat-tree>\n\n<ng-template #noResults>\n    <div class=\"hxp-file-type-no-results\">\n        <h2>\n            {{ 'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.TITLE' | translate }}\n        </h2>\n        <p>\n            {{\n                'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.MESSAGE' | translate\n            }}\n        </p>\n    </div>\n</ng-template>\n", styles: [":host{display:block;height:100%}.hxp-mime-type-row{display:flex;flex-direction:row;align-items:center;gap:8px}.hxp-mime-type-description{display:flex;flex-direction:column}.hxp-mime-type-description-extensions{font:var(--theme-body-font);color:#4b5563}.hxp-file-type-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#111827}.hxp-file-type-no-results h2{font:400 25px/35px Noto Sans;margin:0}.hxp-file-type-no-results p{font:var(--theme-body-font);margin:0}\n"], dependencies: [{ kind: "pipe", type: ArrayToStringPipe, name: "arrayToString" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i3.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatTreeModule }, { kind: "directive", type: i7.MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: i7.MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "directive", type: i7.MatTreeNodeToggle, selector: "[matTreeNodeToggle]", inputs: ["matTreeNodeToggleRecursive"] }, { kind: "component", type: i7.MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: i7.MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "component", type: MimeTypeIconComponent, selector: "hxp-mime-type-icon", inputs: ["mimeType"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterTreeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-file-type-search-filter-tree', standalone: true, imports: [ArrayToStringPipe, NgIf, MatCheckboxModule, MatTreeModule, MatIconModule, MatButtonModule, MimeTypeIconComponent, TranslatePipe], template: "<mat-tree\n    *ngIf=\"dataSource?.data?.length; else noResults\"\n    [dataSource]=\"dataSource\"\n    [treeControl]=\"treeControl\"\n>\n    <mat-tree-node\n        *matTreeNodeDef=\"let node\"\n        matTreeNodeToggle\n        matTreeNodePadding\n    >\n        <button mat-icon-button disabled></button>\n        <mat-checkbox\n            [checked]=\"fileTypeSelection.isSelected(node)\"\n            (change)=\"leafItemSelectionToggle(node)\"\n        >\n            <div class=\"hxp-mime-type-row\">\n                <hxp-mime-type-icon\n                    [mimeType]=\"node?.mimeTypeIcon\"\n                    aria-hidden=\"true\"\n                />\n                <div class=\"hxp-mime-type-description\">\n                    <span class=\"hxp-mime-type-description-title\">{{\n                        node.label | translate\n                    }}</span>\n                    <span class=\"hxp-mime-type-description-extensions\">{{\n                        node.extensions | arrayToString\n                    }}</span>\n                </div>\n            </div>\n        </mat-checkbox>\n    </mat-tree-node>\n\n    <mat-tree-node\n        *matTreeNodeDef=\"let node; when: hasChild\"\n        matTreeNodePadding\n    >\n        <button\n            mat-icon-button\n            matTreeNodeToggle\n            [attr.aria-label]=\"'Toggle ' + node.label\"\n            (click)=\"onNodeExpand($event)\"\n        >\n            <mat-icon class=\"mat-icon-rtl-mirror\">\n                {{\n                    treeControl.isExpanded(node)\n                        ? 'expand_more'\n                        : 'chevron_right'\n                }}\n            </mat-icon>\n        </button>\n        <mat-checkbox\n            [checked]=\"descendantsAllSelected(node)\"\n            [indeterminate]=\"descendantsPartiallySelected(node)\"\n            (change)=\"fileTypeSelectionToggle(node)\"\n        >\n            <span class=\"hxp-mime-type-parent-label hxp-label-bold\">{{ node.label | translate }}</span>\n        </mat-checkbox>\n    </mat-tree-node>\n</mat-tree>\n\n<ng-template #noResults>\n    <div class=\"hxp-file-type-no-results\">\n        <h2>\n            {{ 'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.TITLE' | translate }}\n        </h2>\n        <p>\n            {{\n                'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.MESSAGE' | translate\n            }}\n        </p>\n    </div>\n</ng-template>\n", styles: [":host{display:block;height:100%}.hxp-mime-type-row{display:flex;flex-direction:row;align-items:center;gap:8px}.hxp-mime-type-description{display:flex;flex-direction:column}.hxp-mime-type-description-extensions{font:var(--theme-body-font);color:#4b5563}.hxp-file-type-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#111827}.hxp-file-type-no-results h2{font:400 25px/35px Noto Sans;margin:0}.hxp-file-type-no-results p{font:var(--theme-body-font);margin:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { filteredFileType: [{
                type: Input
            }], selectedFileTypes: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterComponent extends BaseSearchFilterDirective {
    constructor(searchFilterValueService, fileTypeSearchFilterService, arrayToStringPipe, translateService) {
        super(searchFilterValueService);
        this.searchFilterValueService = searchFilterValueService;
        this.fileTypeSearchFilterService = fileTypeSearchFilterService;
        this.arrayToStringPipe = arrayToStringPipe;
        this.translateService = translateService;
        this.searchTerm = '';
        this.selection = new SelectionModel(true, [], true, (fileType1, fileType2) => fileType1.id === fileType2.id);
    }
    get id() {
        return 'FileTypeSearchFilterComponent';
    }
    toHXQL(data) {
        return this.fileTypeSearchFilterService.toHXQL(data);
    }
    setData(data) {
        try {
            if (data?.values) {
                for (const value of data?.values || []) {
                    if (value.fileTypeId) {
                        this.toggleNodeSelectionFromId(value.fileTypeId);
                    }
                }
            }
            this.setSelectedValue();
        }
        catch (error) {
            console.error('Error while setting data for File Type Search Filter', error);
        }
    }
    applyFilter() {
        if (this.selection.selected.length === 0) {
            return this.clearFilter();
        }
        super.applyFilter();
    }
    clearFilter() {
        super.clearFilter();
        this.selection.clear();
        this.searchFilterInputComponent.clearInput();
        this.fileTypeSearchFilterTreeComponent.clearSelection();
    }
    overlayClosed() {
        this.selection.clear();
        this.fileTypeSearchFilterTreeComponent.clearSelection();
        this.oldFormValue?.['selectedFileTypes']?.forEach((item) => {
            this.fileTypeSearchFilterTreeComponent.fileTypeSelectionToggle(item);
            this.selection.select(item);
        });
        this.discardPendingChanges();
    }
    filteredSearch(searchTerm) {
        this.searchTerm = searchTerm;
    }
    getFormControls() {
        return {
            selectedFileTypes: new FormControl([]),
        };
    }
    onSelectedFileType(selectedFileTypes) {
        this.selection.clear();
        for (const selectedFileType of selectedFileTypes) {
            if (selectedFileType?.level !== 0) {
                this.selection.select(selectedFileType);
            }
        }
        this.setSelectedValue();
        this.filterForm.markAsDirty();
    }
    toggleSelection(fileTypeNode) {
        this.selection.toggle(fileTypeNode);
        this.fileTypeSearchFilterTreeComponent.fileTypeSelectionToggle(fileTypeNode);
        this.setSelectedValue();
    }
    clearSearchInput() {
        this.searchTerm = '';
    }
    toggleNodeSelectionFromId(fileTypeId) {
        this.fileTypeSearchFilterTreeComponent.fileTypeSelectionToggleById(fileTypeId);
    }
    setSelectedValue() {
        this.filterForm.patchValue({
            selectedFileTypes: [...this.selection.selected],
        });
        if (this.selection.selected.length === 0) {
            this.selectedValue = undefined;
            return;
        }
        const selectedValues = this.selection.selected.map((sel) => ({
            label: `${this.translateService.instant(sel.label)} (${this.arrayToStringPipe.transform(sel.extensions || [])})`,
            value: sel.mimeTypes || [],
            fileTypeId: sel.id,
        }));
        this.selectedValue = new FileTypeSearchFilterData(selectedValues);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterComponent, deps: [{ token: i1.SearchFilterValueService }, { token: FileTypeSearchFilterService }, { token: ArrayToStringPipe }, { token: i4.TranslateService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: FileTypeSearchFilterComponent, isStandalone: true, selector: "hxp-file-type-search-filter", providers: [ArrayToStringPipe, FileTypeSearchFilterService], viewQueries: [{ propertyName: "searchFilterInputComponent", first: true, predicate: SearchFilterInputComponent, descendants: true }, { propertyName: "fileTypeSearchFilterTreeComponent", first: true, predicate: FileTypeSearchFilterTreeComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<hxp-search-filter-container\n        #searchFilter\n        [name]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n        [selectedValue]=\"selectedValue\"\n        [filterForm]=\"filterForm\"\n        (filterApplied)=\"applyFilter()\"\n        (filterCleared)=\"clearFilter()\"\n        (overlayClosed)=\"overlayClosed()\"\n    >\n        <div class=\"hxp-file-type-search-filter-container\">\n            <hxp-search-filter-input\n                [inputAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n                [placeholder]=\"'SEARCH.FILTERS.FILE_TYPE.PLACEHOLDER' | translate\"\n                [clearAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.CLEAR_INPUT' | translate\"\n                (search)=\"filteredSearch($event)\"\n                (clear)=\"clearSearchInput()\"\n            />\n            <div class=\"hxp-file-type-search-filter-summary\">\n                <mat-chip-set\n                    ariaLabel=\"\n                        'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.SELECTED_FILTERS'\n                            | translate\n                    \"\n                    class=\"hxp-file-type-search-filter-summary-list\"\n                >\n                    <span\n                        class=\"hxp-file-type-search-filter-summary-list-prefix\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.FILE_TYPE.SELECTED'\n                                | translate\n                                    : { selected: selection.selected.length }\n                        }}\n                    </span>\n                    <span\n                        *ngIf=\"selection.selected.length > 0\"\n                        class=\"hxp-file-type-search-filter-summary-list-colon\"\n                        >:</span\n                    >\n                    <mat-chip\n                        *ngFor=\"let selectedFileType of selection.selected\"\n                        class=\"hxp-file-type-search-filter-summary-list-item\"\n                        [attr.aria-label]=\"selectedFileType\"\n                        [matTooltip]=\"selectedFileType.extensions | arrayToString\"\n                    >\n                        <span\n                            class=\"hxp-file-type-filter-summary-list-item__label\"\n                        >\n                            {{ (selectedFileType.label | translate) + ' (' + (selectedFileType.extensions | arrayToString) + ')' }}\n                        </span>\n                        <button\n                            matChipRemove\n                            [attr.aria-label]=\"\n                                ('SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.REMOVE'\n                                    | translate) +\n                                ' ' +\n                                selectedFileType\n                            \"\n                            (click)=\"toggleSelection(selectedFileType)\"\n                        >\n                            <mat-icon\n                                class=\"hxp-file-type-search-filter-summary-list-remove-item-icon\"\n                                svgIcon=\"search_clear\"\n                                />\n                        </button>\n                    </mat-chip>\n                </mat-chip-set>\n            </div>\n\n            <hxp-file-type-search-filter-tree\n                (selectedFileTypes)=\"onSelectedFileType($event)\"\n                [filteredFileType]=\"searchTerm\"\n            />\n        </div>\n</hxp-search-filter-container>\n", styles: [".hxp-file-type-search-filter-container{height:468px;width:370px;display:flex;flex-direction:column;padding:24px;font:var(--theme-body-font)}.hxp-file-type-search-filter-list{max-height:360px;overflow-y:scroll;font:var(--theme-body-font)}.hxp-file-type-search-filter-list-option{font:var(--theme-body-font)}.hxp-file-type-search-filter-list-option-title{display:flex!important;flex-direction:row;flex:1 1 auto;align-items:center;gap:8px}.hxp-file-type-search-filter-list-option-path{font:400 12px/19px Noto Sans!important;color:#4b5563}.hxp-document-category-filter-summary-list-colon{padding-top:6px}.hxp-file-type-search-filter-input-back{display:flex;flex-direction:row}.hxp-file-type-search-filter-input-search{position:relative;display:flex;align-items:center;justify-content:center}.hxp-file-type-search-filter-search-button-divider{height:48px}.hxp-file-type-search-filter-input-back-icon{line-height:24px!important}.hxp-file-type-search-filter-input-search-icon,.hxp-file-type-search-filter-input-clear-icon,.hxp-file-type-search-filter-input-back-icon{color:#111827;text-align:center}.hxp-file-type-search-filter-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#111827}.hxp-file-type-search-filter-no-results h2{font:400 25px/35px Noto Sans;margin:0}.hxp-file-type-search-filter-no-results p{font:var(--theme-body-font);margin:0}.hxp-file-type-search-filter-spinner-container{display:flex;justify-content:center;align-items:center;height:100%}.hxp-file-type-search-filter-tree{overflow:hidden}.hxp-file-type-search-filter-folder-icon{display:block;width:16px;height:16px;line-height:16px}.hxp-file-type-search-filter-input-clear-icon,.hxp-file-type-search-filter-input-search-icon{display:flex;justify-content:center;align-items:center;transform:scale(.75)}.hxp-file-type-search-filter-input-clear-icon{transform:scale(.65)}.hxp-file-type-search-filter-summary{margin-bottom:20px}.hxp-file-type-search-filter-summary-list{width:100%;max-height:110px;overflow-y:scroll;font:600 14px/23px Noto Sans}.hxp-file-type-search-filter-summary-list-prefix{margin-top:2px;margin-bottom:2px;margin-left:8px}.hxp-file-type-search-filter-summary-list-colon{margin-top:2px;margin-bottom:2px}.hxp-file-type-search-filter-summary-list-item{min-height:auto;height:18px;background-color:var(--adf-theme-primary-50);border-radius:2px;padding-top:3px;padding-bottom:3px}.hxp-file-type-search-filter-summary-list-item button{margin:0}.hxp-file-type-search-filter-summary-list-remove-item-icon{color:var(--theme-primary-color, #5654ac);opacity:1;width:12px!important}.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__cell--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__action--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mat-mdc-chip-action-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}.hxp-file-type-filter-summary-list-item__label{color:var(--theme-primary-color, #5654ac);font:var(--theme-body-font);font-weight:600}hxp-file-type-search-filter-tree{overflow-y:scroll}\n"], dependencies: [{ kind: "pipe", type: ArrayToStringPipe, name: "arrayToString" }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2$2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: FileTypeSearchFilterTreeComponent, selector: "hxp-file-type-search-filter-tree", inputs: ["filteredFileType"], outputs: ["selectedFileTypes"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i6$3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: i6$3.MatChipRemove, selector: "[matChipRemove]" }, { kind: "component", type: i6$3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: SearchFilterContainerComponent, selector: "hxp-search-filter-container", inputs: ["name", "filterForm", "selectedValue"], outputs: ["overlayClosed", "filterCleared", "filterApplied"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: SearchFilterInputComponent, selector: "hxp-search-filter-input", inputs: ["applyOnEnter", "inputAriaLabel", "placeholder", "clearAriaLabel", "prefixIcon", "prefixAriaLabel"], outputs: ["search", "clear", "prefixClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FileTypeSearchFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-file-type-search-filter', standalone: true, imports: [
                        ArrayToStringPipe,
                        CommonModule,
                        FileTypeSearchFilterTreeComponent,
                        FormsModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatDividerModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        SearchFilterContainerComponent,
                        TranslatePipe,
                        SearchFilterInputComponent,
                    ], providers: [ArrayToStringPipe, FileTypeSearchFilterService], template: "<hxp-search-filter-container\n        #searchFilter\n        [name]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n        [selectedValue]=\"selectedValue\"\n        [filterForm]=\"filterForm\"\n        (filterApplied)=\"applyFilter()\"\n        (filterCleared)=\"clearFilter()\"\n        (overlayClosed)=\"overlayClosed()\"\n    >\n        <div class=\"hxp-file-type-search-filter-container\">\n            <hxp-search-filter-input\n                [inputAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n                [placeholder]=\"'SEARCH.FILTERS.FILE_TYPE.PLACEHOLDER' | translate\"\n                [clearAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.CLEAR_INPUT' | translate\"\n                (search)=\"filteredSearch($event)\"\n                (clear)=\"clearSearchInput()\"\n            />\n            <div class=\"hxp-file-type-search-filter-summary\">\n                <mat-chip-set\n                    ariaLabel=\"\n                        'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.SELECTED_FILTERS'\n                            | translate\n                    \"\n                    class=\"hxp-file-type-search-filter-summary-list\"\n                >\n                    <span\n                        class=\"hxp-file-type-search-filter-summary-list-prefix\"\n                    >\n                        {{\n                            'SEARCH.FILTERS.FILE_TYPE.SELECTED'\n                                | translate\n                                    : { selected: selection.selected.length }\n                        }}\n                    </span>\n                    <span\n                        *ngIf=\"selection.selected.length > 0\"\n                        class=\"hxp-file-type-search-filter-summary-list-colon\"\n                        >:</span\n                    >\n                    <mat-chip\n                        *ngFor=\"let selectedFileType of selection.selected\"\n                        class=\"hxp-file-type-search-filter-summary-list-item\"\n                        [attr.aria-label]=\"selectedFileType\"\n                        [matTooltip]=\"selectedFileType.extensions | arrayToString\"\n                    >\n                        <span\n                            class=\"hxp-file-type-filter-summary-list-item__label\"\n                        >\n                            {{ (selectedFileType.label | translate) + ' (' + (selectedFileType.extensions | arrayToString) + ')' }}\n                        </span>\n                        <button\n                            matChipRemove\n                            [attr.aria-label]=\"\n                                ('SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.REMOVE'\n                                    | translate) +\n                                ' ' +\n                                selectedFileType\n                            \"\n                            (click)=\"toggleSelection(selectedFileType)\"\n                        >\n                            <mat-icon\n                                class=\"hxp-file-type-search-filter-summary-list-remove-item-icon\"\n                                svgIcon=\"search_clear\"\n                                />\n                        </button>\n                    </mat-chip>\n                </mat-chip-set>\n            </div>\n\n            <hxp-file-type-search-filter-tree\n                (selectedFileTypes)=\"onSelectedFileType($event)\"\n                [filteredFileType]=\"searchTerm\"\n            />\n        </div>\n</hxp-search-filter-container>\n", styles: [".hxp-file-type-search-filter-container{height:468px;width:370px;display:flex;flex-direction:column;padding:24px;font:var(--theme-body-font)}.hxp-file-type-search-filter-list{max-height:360px;overflow-y:scroll;font:var(--theme-body-font)}.hxp-file-type-search-filter-list-option{font:var(--theme-body-font)}.hxp-file-type-search-filter-list-option-title{display:flex!important;flex-direction:row;flex:1 1 auto;align-items:center;gap:8px}.hxp-file-type-search-filter-list-option-path{font:400 12px/19px Noto Sans!important;color:#4b5563}.hxp-document-category-filter-summary-list-colon{padding-top:6px}.hxp-file-type-search-filter-input-back{display:flex;flex-direction:row}.hxp-file-type-search-filter-input-search{position:relative;display:flex;align-items:center;justify-content:center}.hxp-file-type-search-filter-search-button-divider{height:48px}.hxp-file-type-search-filter-input-back-icon{line-height:24px!important}.hxp-file-type-search-filter-input-search-icon,.hxp-file-type-search-filter-input-clear-icon,.hxp-file-type-search-filter-input-back-icon{color:#111827;text-align:center}.hxp-file-type-search-filter-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;color:#111827}.hxp-file-type-search-filter-no-results h2{font:400 25px/35px Noto Sans;margin:0}.hxp-file-type-search-filter-no-results p{font:var(--theme-body-font);margin:0}.hxp-file-type-search-filter-spinner-container{display:flex;justify-content:center;align-items:center;height:100%}.hxp-file-type-search-filter-tree{overflow:hidden}.hxp-file-type-search-filter-folder-icon{display:block;width:16px;height:16px;line-height:16px}.hxp-file-type-search-filter-input-clear-icon,.hxp-file-type-search-filter-input-search-icon{display:flex;justify-content:center;align-items:center;transform:scale(.75)}.hxp-file-type-search-filter-input-clear-icon{transform:scale(.65)}.hxp-file-type-search-filter-summary{margin-bottom:20px}.hxp-file-type-search-filter-summary-list{width:100%;max-height:110px;overflow-y:scroll;font:600 14px/23px Noto Sans}.hxp-file-type-search-filter-summary-list-prefix{margin-top:2px;margin-bottom:2px;margin-left:8px}.hxp-file-type-search-filter-summary-list-colon{margin-top:2px;margin-bottom:2px}.hxp-file-type-search-filter-summary-list-item{min-height:auto;height:18px;background-color:var(--adf-theme-primary-50);border-radius:2px;padding-top:3px;padding-bottom:3px}.hxp-file-type-search-filter-summary-list-item button{margin:0}.hxp-file-type-search-filter-summary-list-remove-item-icon{color:var(--theme-primary-color, #5654ac);opacity:1;width:12px!important}.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__cell--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__action--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mat-mdc-chip-action-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}.hxp-file-type-filter-summary-list-item__label{color:var(--theme-primary-color, #5654ac);font:var(--theme-body-font);font-weight:600}hxp-file-type-search-filter-tree{overflow-y:scroll}\n"] }]
        }], ctorParameters: () => [{ type: i1.SearchFilterValueService }, { type: FileTypeSearchFilterService }, { type: ArrayToStringPipe }, { type: i4.TranslateService }], propDecorators: { searchFilterInputComponent: [{
                type: ViewChild,
                args: [SearchFilterInputComponent]
            }], fileTypeSearchFilterTreeComponent: [{
                type: ViewChild,
                args: [FileTypeSearchFilterTreeComponent]
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchTermFilterValue {
    constructor() {
        this.label = '';
        this.term = '';
        this.type = SearchType.BASIC;
    }
}
const compareFn = (a, b) => a.term.localeCompare(b.term) && a.type.localeCompare(b.type);
class SearchTermFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn);
        const sortedDataValues = data.values.sort(compareFn);
        for (const [i, sortedValue] of sortedValues.entries()) {
            if (sortedValue.term !== sortedDataValues[i].term && sortedValue.type !== sortedDataValues[i].type) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchTermFilterService {
    toHXQL(data) {
        return data?.values?.length > 0 ? `sys_fulltext = '${data.values[0].term}*'` : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchTermFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchTermFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchTermFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchTermFilterComponent extends BaseSearchFilterDirective {
    constructor(searchFilterValueService, searchTermFilterService) {
        super(searchFilterValueService);
        this.searchFilterValueService = searchFilterValueService;
        this.searchTermFilterService = searchTermFilterService;
        this.searchType = SearchType.BASIC;
        this.searchTerm = '';
        this.searchTermChanged = new EventEmitter();
        this.clearIcon = 'CLEAR';
        this.SearchTypeEnum = SearchType;
        this.errorStateMatcher = new ShowOnDirtyErrorStateMatcher();
    }
    ngOnChanges() {
        this.filterForm.get('type')?.setValue(this.searchType);
        this.filterForm.get('query')?.setValue(this.searchTerm);
    }
    get id() {
        return 'SearchTermFilterComponent';
    }
    toHXQL(data) {
        return this.searchTermFilterService.toHXQL(data);
    }
    onInput() {
        this.selectedValue = new SearchTermFilterData([
            {
                label: 'Search term',
                term: this.filterForm.get('query')?.value,
                type: this.filterForm.get('type')?.value,
            },
        ]);
        this.applyChanges();
        this.emitSearchTermChanged();
    }
    onClear() {
        this.filterForm.get('query')?.setValue('');
        this.clearFilter();
        this.emitSearchTermChanged();
    }
    onSearch(event) {
        // Stops textarea from adding a newline on 'enter' button
        if (event) {
            event.preventDefault();
        }
        if (this.filterForm.invalid) {
            return;
        }
        this.applyFilter();
    }
    getFormControls() {
        return {
            type: new FormControl(SearchType.BASIC, {
                nonNullable: true,
            }),
            query: new FormControl('', {
                validators: Validators.required,
            }),
        };
    }
    setData(data) {
        if (!data?.values?.length) {
            return;
        }
        try {
            this.filterForm.setValue({
                type: data.values[0].type ?? SearchType.BASIC,
                query: data.values[0].term ?? '',
            });
            if (data.values[0].term) {
                this.selectedValue = data;
            }
        }
        catch (error) {
            console.error('Error while setting data for Search Term filter', error);
        }
    }
    emitSearchTermChanged() {
        this.searchTermChanged.emit(this.filterForm.get('query')?.value.trim());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchTermFilterComponent, deps: [{ token: i1.SearchFilterValueService }, { token: SearchTermFilterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: SearchTermFilterComponent, isStandalone: true, selector: "hxp-search-term-filter", inputs: { searchType: "searchType", searchTerm: "searchTerm" }, outputs: { searchTermChanged: "searchTermChanged" }, providers: [SearchTermFilterService], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<form\n    class=\"hxp-search-input\"\n    role=\"search\"\n    [formGroup]=\"filterForm\"\n    (submit)=\"onSearch()\"\n>\n    <div class=\"hxp-search-text\">\n        <mat-form-field\n            appearance=\"outline\"\n            subscriptSizing=\"dynamic\"\n            class=\"hxp-new-search-input\"\n        >\n            <textarea\n                matInput\n                #searchInput\n                type=\"search\"\n                formControlName=\"query\"\n                cdkTextareaAutosize\n                cdkAutosizeMinRows=\"1\"\n                cdkAutosizeMaxRows=\"3\"\n                placeholder=\"{{ 'SEARCH.INPUT.PLACEHOLDER' | translate }}\"\n                [attr.aria-label]=\"'SEARCH.INPUT.ARIA_LABEL' | translate\"\n                [errorStateMatcher]=\"errorStateMatcher\"\n                (input)=\"onInput()\"\n                (keydown.enter)=\"onSearch($event)\"\n            ></textarea>\n            <div\n                matSuffix\n                class=\"hxp-search-text-suffix-container\"\n                *ngIf=\"searchInput?.value?.length\"\n            >\n                <ng-container *ngTemplateOutlet=\"clearButton\" />\n            </div>\n        </mat-form-field>\n    </div>\n</form>\n\n<ng-template #clearButton>\n    <button\n        *ngIf=\"filterForm.get('query')?.value\"\n        class=\"hxp-clear\"\n        type=\"button\"\n        [attr.aria-label]=\"'SEARCH.INPUT.CLEAR_INPUT' | translate\"\n        (click)=\"onClear()\"\n    >\n        <hxp-search-action-icon\n            [actionIcon]=\"clearIcon\"\n        />\n    </button>\n</ng-template>\n", styles: [".hxp-search-input{width:100%;display:flex;border-radius:8px;justify-content:space-between}.hxp-search-input>*{border:none;background:none}.hxp-search-input ::ng-deep .mat-form-field-appearance-outline .mdc-notched-outline{color:transparent;inset:0}.hxp-search-input ::ng-deep .mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{height:100%;margin:0;padding:0}.hxp-search-input ::ng-deep .mat-mdc-form-field-flex{height:100%;margin-top:0;align-items:center}.hxp-search-input ::ng-deep .mat-mdc-form-field-flex:hover{border:none}.hxp-search-input ::ng-deep .mat-mdc-form-field-infix{width:60px;border-top:none}.hxp-search-input ::ng-deep .mat-mdc-select-arrow-wrapper{transform:none}.hxp-search-input ::ng-deep .mdc-notched-outline,.hxp-search-input ::ng-deep .mdc-text-field--outlined-thick,.hxp-search-input ::ng-deep .mdc-text-field--outlined{border-radius:0;border-left:none;border-top:none;border-bottom:none}.hxp-search-input textarea{align-self:center;border:0;width:100%;height:22px;max-height:65px;padding:0 12.5px;resize:none}.hxp-search-input textarea:active{outline:none;border:0}.hxp-search-input button{cursor:pointer;padding:0 16px}.hxp-search-input button.hxp-clear hxp-search-action-icon{width:12px}.hxp-search-input button.hxp-submit hxp-search-action-icon{width:16px}.hxp-search-text{display:flex;justify-content:space-between;flex-grow:1}.hxp-search-text .hxp-new-search-input{flex:1}.hxp-search-text .hxp-new-search-input ::ng-deep .mat-mdc-form-field-infix{display:flex}.hxp-search-text .hxp-new-search-input textarea{height:22px}.hxp-clear{display:flex;border:none;background:transparent;align-items:center}.hxp-search-text-suffix-container{align-items:center;border-left:1px solid #d1d5db;display:flex;height:56px;justify-content:center;width:56px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2$2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i6$2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6$2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i7$2.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: SearchActionIconComponent, selector: "hxp-search-action-icon", inputs: ["actionIcon", "actionAlt"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchTermFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-term-filter', standalone: true, imports: [CommonModule, MatFormFieldModule, MatInputModule, MatSelectModule, ReactiveFormsModule, SearchActionIconComponent, TranslatePipe], providers: [SearchTermFilterService], template: "<form\n    class=\"hxp-search-input\"\n    role=\"search\"\n    [formGroup]=\"filterForm\"\n    (submit)=\"onSearch()\"\n>\n    <div class=\"hxp-search-text\">\n        <mat-form-field\n            appearance=\"outline\"\n            subscriptSizing=\"dynamic\"\n            class=\"hxp-new-search-input\"\n        >\n            <textarea\n                matInput\n                #searchInput\n                type=\"search\"\n                formControlName=\"query\"\n                cdkTextareaAutosize\n                cdkAutosizeMinRows=\"1\"\n                cdkAutosizeMaxRows=\"3\"\n                placeholder=\"{{ 'SEARCH.INPUT.PLACEHOLDER' | translate }}\"\n                [attr.aria-label]=\"'SEARCH.INPUT.ARIA_LABEL' | translate\"\n                [errorStateMatcher]=\"errorStateMatcher\"\n                (input)=\"onInput()\"\n                (keydown.enter)=\"onSearch($event)\"\n            ></textarea>\n            <div\n                matSuffix\n                class=\"hxp-search-text-suffix-container\"\n                *ngIf=\"searchInput?.value?.length\"\n            >\n                <ng-container *ngTemplateOutlet=\"clearButton\" />\n            </div>\n        </mat-form-field>\n    </div>\n</form>\n\n<ng-template #clearButton>\n    <button\n        *ngIf=\"filterForm.get('query')?.value\"\n        class=\"hxp-clear\"\n        type=\"button\"\n        [attr.aria-label]=\"'SEARCH.INPUT.CLEAR_INPUT' | translate\"\n        (click)=\"onClear()\"\n    >\n        <hxp-search-action-icon\n            [actionIcon]=\"clearIcon\"\n        />\n    </button>\n</ng-template>\n", styles: [".hxp-search-input{width:100%;display:flex;border-radius:8px;justify-content:space-between}.hxp-search-input>*{border:none;background:none}.hxp-search-input ::ng-deep .mat-form-field-appearance-outline .mdc-notched-outline{color:transparent;inset:0}.hxp-search-input ::ng-deep .mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{height:100%;margin:0;padding:0}.hxp-search-input ::ng-deep .mat-mdc-form-field-flex{height:100%;margin-top:0;align-items:center}.hxp-search-input ::ng-deep .mat-mdc-form-field-flex:hover{border:none}.hxp-search-input ::ng-deep .mat-mdc-form-field-infix{width:60px;border-top:none}.hxp-search-input ::ng-deep .mat-mdc-select-arrow-wrapper{transform:none}.hxp-search-input ::ng-deep .mdc-notched-outline,.hxp-search-input ::ng-deep .mdc-text-field--outlined-thick,.hxp-search-input ::ng-deep .mdc-text-field--outlined{border-radius:0;border-left:none;border-top:none;border-bottom:none}.hxp-search-input textarea{align-self:center;border:0;width:100%;height:22px;max-height:65px;padding:0 12.5px;resize:none}.hxp-search-input textarea:active{outline:none;border:0}.hxp-search-input button{cursor:pointer;padding:0 16px}.hxp-search-input button.hxp-clear hxp-search-action-icon{width:12px}.hxp-search-input button.hxp-submit hxp-search-action-icon{width:16px}.hxp-search-text{display:flex;justify-content:space-between;flex-grow:1}.hxp-search-text .hxp-new-search-input{flex:1}.hxp-search-text .hxp-new-search-input ::ng-deep .mat-mdc-form-field-infix{display:flex}.hxp-search-text .hxp-new-search-input textarea{height:22px}.hxp-clear{display:flex;border:none;background:transparent;align-items:center}.hxp-search-text-suffix-container{align-items:center;border-left:1px solid #d1d5db;display:flex;height:56px;justify-content:center;width:56px}\n"] }]
        }], ctorParameters: () => [{ type: i1.SearchFilterValueService }, { type: SearchTermFilterService }], propDecorators: { searchType: [{
                type: Input
            }], searchTerm: [{
                type: Input
            }], searchTermChanged: [{
                type: Output
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const getMockInput = () => ngMocks.find('hxp-search-filter-input').componentInstance;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterHarness extends ComponentHarness {
    constructor() {
        super(...arguments);
        this.getLabel = this.locatorForOptional('.hxp-search-filter-chip-label');
        this.getExpandIcon = this.locatorForOptional(MatIconHarness.with({ selector: '.hxp-search-filter-chip-icon' }));
        this.getBadge = this.locatorForOptional('.hxp-search-filter-chip-badge');
        this.getApplyButton = this.documentRootLocatorFactory().locatorForOptional(MatButtonHarness.with({ selector: '.hxp-search-filter-overlay-actions-apply' }));
        this.getClearButton = this.documentRootLocatorFactory().locatorForOptional(MatButtonHarness.with({ selector: '.hxp-search-filter-overlay-actions-clear' }));
        this.getOverlayBackdrop = this.documentRootLocatorFactory().locatorForOptional('.cdk-overlay-backdrop');
        this.getChip = this.locatorForOptional('.hxp-search-filter-chip');
        this.getOverlayContainer = this.documentRootLocatorFactory().locatorForOptional('.hxp-search-filter-overlay');
    }
    static { this.hostSelector = '.hxp-search-filter'; }
    async isOpen() {
        return !!(await this.getOverlayContainer());
    }
    async open() {
        const chip = await this.getChip();
        return chip ? chip.click() : undefined;
    }
}

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BaseSearchFilterDirective, CONTEXT_MENU_ACTIONS_PROVIDERS, ContentDeleteButtonComponent, ContentPropertiesViewerButtonComponent, ContentPropertyViewerActionService, ContentShareButtonActionService, ContentShareButtonComponent, ContentShareDialogComponent, ContentTypeIconComponent, CreatedDateSearchFiltersComponent, DIALOG_MIN_WIDTH, DeleteButtonActionService, DialogConfig, DocumentCategorySearchFiltersComponent, DocumentMoreActionComponent, FileTypeSearchFilterComponent, FileTypeSearchFilterTreeComponent, FormatDocumentPathDirective, HxpBreadcrumbComponent, HxpDocumentListComponent, HxpDocumentTreeComponent, HxpPropertiesSidebarComponent, HxpUiBreadcrumbComponent, HxpUiDocumentViewerComponent, ManageColumnButtonComponent, ManageVersionsSidebarComponent, PermissionsButtonActionService, PermissionsManagementDialogComponent, PermissionsManagementPanelComponent, PropertiesViewerContainerComponent, SearchFilterContainerComponent, SearchFilterHarness, SearchFilterInputComponent, SearchNoResultsComponent, SearchTermFilterComponent, SearchTermFilterData, SearchTermFilterValue, SingleItemDownloadButtonActionService, SingleItemDownloadButtonComponent, TableSkeletonLoaderComponent, TreeSkeletonLoaderComponent, VersionDeleteButtonComponent, VersionRestoreComponent, getMockInput };
//# sourceMappingURL=alfresco-adf-hx-content-services-ui.mjs.map
