import * as i0 from '@angular/core';
import { Injectable, Pipe, Input, Component } from '@angular/core';
import { ThumbnailService as ThumbnailService$1 } from '@alfresco/adf-core';
import * as i1 from '@ngx-translate/core';
import * as i2 from '@angular/material/icon';
import * as i3 from '@angular/platform-browser';

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DefaultIcon = {
    UNKNOWN: '',
    FOLDER: 'folder',
    OPEN_FOLDER: 'openFolder',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const mimeTypeLinkedImages = {
    'image/png': './assets/images/Image.svg',
    'image/jpeg': './assets/images/Image.svg',
    'image/gif': './assets/images/Image.svg',
    'image/bmp': './assets/images/Image.svg',
    'image/cgm': './assets/images/Image.svg',
    'image/ief': './assets/images/Image.svg',
    'image/jp2': './assets/images/Image.svg',
    'image/tiff': './assets/images/Image.svg',
    'image/vnd.adobe.photoshop': './assets/images/Image.svg',
    'image/vnd.adobe.premiere': './assets/images/Image.svg',
    'image/x-cmu-raster': './assets/images/Image.svg',
    'image/x-dwt': './assets/images/Image.svg',
    'image/x-portable-anymap': './assets/images/Image.svg',
    'image/x-portable-bitmap': './assets/images/Image.svg',
    'image/x-portable-graymap': './assets/images/Image.svg',
    'image/x-portable-pixmap': './assets/images/Image.svg',
    'image/x-raw-adobe': './assets/images/Image.svg',
    'image/x-raw-canon': './assets/images/Image.svg',
    'image/x-raw-fuji': './assets/images/Image.svg',
    'image/x-raw-hasselblad': './assets/images/Image.svg',
    'image/x-raw-kodak': './assets/images/Image.svg',
    'image/x-raw-leica': './assets/images/Image.svg',
    'image/x-raw-minolta': './assets/images/Image.svg',
    'image/x-raw-nikon': './assets/images/Image.svg',
    'image/x-raw-olympus': './assets/images/Image.svg',
    'image/x-raw-panasonic': './assets/images/Image.svg',
    'image/x-raw-pentax': './assets/images/Image.svg',
    'image/x-raw-red': './assets/images/Image.svg',
    'image/x-raw-sigma': './assets/images/Image.svg',
    'image/x-raw-sony': './assets/images/Image.svg',
    'image/x-xbitmap': './assets/images/Image.svg',
    'image/x-xpixmap': './assets/images/Image.svg',
    'image/x-xwindowdump': './assets/images/Image.svg',
    'image/svg+xml': './assets/images/Image.svg',
    'application/eps': './assets/images/Image.svg',
    'application/illustrator': './assets/images/Image.svg',
    'application/pdf': './assets/images/PDF.svg',
    'application/vnd.ms-excel': './assets/images/Excel.svg',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': './assets/images/Excel.svg',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.template': './assets/images/Excel.svg',
    'application/vnd.ms-excel.addin.macroenabled.12': './assets/images/Excel.svg',
    'application/vnd.ms-excel.sheet.binary.macroenabled.12': './assets/images/Excel.svg',
    'application/vnd.ms-excel.sheet.macroenabled.12': './assets/images/Excel.svg',
    'application/vnd.ms-excel.template.macroenabled.12': './assets/images/Excel.svg',
    'application/vnd.sun.xml.calc': './assets/images/Excel.svg',
    'application/vnd.sun.xml.calc.template': './assets/images/Excel.svg',
    'application/vnd.ms-outlook': './assets/images/Text.svg',
    'application/msword': './assets/images/Word.svg',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': './assets/images/Word.svg',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.template': './assets/images/Word.svg',
    'application/vnd.ms-word.document.macroenabled.12': './assets/images/Word.svg',
    'application/vnd.ms-word.template.macroenabled.12': './assets/images/Word.svg',
    'application/vnd.sun.xml.writer': './assets/images/Word.svg',
    'application/vnd.sun.xml.writer.template': './assets/images/Word.svg',
    'application/rtf': './assets/images/Word.svg',
    'text/rtf': './assets/images/Word.svg',
    'application/vnd.ms-powerpoint': './assets/images/Powerpoint.svg',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation': './assets/images/Powerpoint.svg',
    'application/vnd.openxmlformats-officedocument.presentationml.template': './assets/images/Powerpoint.svg',
    'application/vnd.openxmlformats-officedocument.presentationml.slideshow': './assets/images/Powerpoint.svg',
    'application/vnd.oasis.opendocument.presentation': './assets/images/Powerpoint.svg',
    'application/vnd.oasis.opendocument.presentation-template': './assets/images/Powerpoint.svg',
    'application/vnd.openxmlformats-officedocument.presentationml.slide': './assets/images/Powerpoint.svg',
    'application/vnd.sun.xml.impress': './assets/images/Powerpoint.svg',
    'application/vnd.sun.xml.impress.template': './assets/images/Powerpoint.svg',
    'application/vnd.oasis.opendocument.spreadsheet': './assets/images/Excel.svg',
    'application/vnd.oasis.opendocument.spreadsheet-template': './assets/images/Excel.svg',
    'application/vnd.ms-powerpoint.addin.macroenabled.12': './assets/images/Powerpoint.svg',
    'application/vnd.ms-powerpoint.presentation.macroenabled.12': './assets/images/Powerpoint.svg',
    'application/vnd.ms-powerpoint.slide.macroenabled.12': './assets/images/Powerpoint.svg',
    'application/vnd.ms-powerpoint.slideshow.macroenabled.12': './assets/images/Powerpoint.svg',
    'application/vnd.ms-powerpoint.template.macroenabled.12': './assets/images/Powerpoint.svg',
    'video/mp4': './assets/images/Video.svg',
    'video/3gpp': './assets/images/Video.svg',
    'video/3gpp2': './assets/images/Video.svg',
    'video/mp2t': './assets/images/Video.svg',
    'video/mpeg': './assets/images/Video.svg',
    'video/mpeg2': './assets/images/Video.svg',
    'video/ogg': './assets/images/Video.svg',
    'video/quicktime': './assets/images/Video.svg',
    'video/webm': './assets/images/Video.svg',
    'video/x-flv': './assets/images/Video.svg',
    'video/x-m4v': './assets/images/Video.svg',
    'video/x-ms-asf': './assets/images/Video.svg',
    'video/x-ms-wmv': './assets/images/Video.svg',
    'video/x-msvideo': './assets/images/Video.svg',
    'video/x-rad-screenplay': './assets/images/Video.svg',
    'video/x-sgi-movie': './assets/images/Video.svg',
    'video/x-matroska': './assets/images/Video.svg',
    'audio/mpeg': './assets/images/Audio.svg',
    'audio/ogg': './assets/images/Audio.svg',
    'audio/wav': './assets/images/Audio.svg',
    'audio/basic': './assets/images/Audio.svg',
    'audio/mp3': './assets/images/Audio.svg',
    'audio/mp4': './assets/images/Audio.svg',
    'audio/vnd.adobe.soundbooth': './assets/images/Audio.svg',
    'audio/vorbis': './assets/images/Audio.svg',
    'audio/x-aiff': './assets/images/Audio.svg',
    'audio/x-flac': './assets/images/Audio.svg',
    'audio/x-ms-wma': './assets/images/Audio.svg',
    'audio/x-wav': './assets/images/Audio.svg',
    'x-world/x-vrml': './assets/images/Video.svg',
    'text/plain': './assets/images/Text.svg',
    'application/vnd.oasis.opendocument.text': './assets/images/Text.svg',
    'application/vnd.oasis.opendocument.text-template': './assets/images/Text.svg',
    'application/x-javascript': './assets/images/Code.svg',
    'application/json': './assets/images/Code.svg',
    'text/csv': './assets/images/Text.svg',
    'text/xml': './assets/images/Text.svg',
    'text/html': './assets/images/Code.svg',
    'text/css': './assets/images/Code.svg',
    'application/x-compressed': './assets/images/Zip.svg',
    'application/x-zip-compressed': './assets/images/Zip.svg',
    'application/zip': './assets/images/Zip.svg',
    'application/x-tar': './assets/images/Zip.svg',
    'application/vnd.apple.keynote': './assets/images/Powerpoint.svg',
    'application/vnd.apple.pages': './assets/images/Text.svg',
    'application/vnd.apple.numbers': './assets/images/Excel.svg',
    'application/vnd.visio': './assets/images/Text.svg',
    'application/wordperfect': './assets/images/Text.svg',
    'application/x-cpio': './assets/images/Text.svg',
    'multipart/related': './assets/images/Code.svg',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ThumbnailService extends ThumbnailService$1 {
    constructor() {
        super(...arguments);
        this.mimeTypeIcons = {
            ...mimeTypeLinkedImages,
            [DefaultIcon.FOLDER]: './assets/images/Folder.svg',
            [DefaultIcon.OPEN_FOLDER]: './assets/images/Folder_open.svg',
        };
        this.DEFAULT_ICON = './assets/images/Generic.svg';
    }
    getMimeTypeIcon(mimeType) {
        return this.mimeTypeIcons[mimeType] ? super.getMimeTypeIcon(mimeType) : this.DEFAULT_ICON;
    }
    getDefaultMimeTypeIcon() {
        return this.DEFAULT_ICON;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ThumbnailService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ThumbnailService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: ThumbnailService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class MimeTypeIconPipe {
    constructor(thumbnailService) {
        this.thumbnailService = thumbnailService;
    }
    transform(text) {
        return this.thumbnailService.getMimeTypeIcon(text);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: MimeTypeIconPipe, deps: [{ token: ThumbnailService }], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.9", ngImport: i0, type: MimeTypeIconPipe, isStandalone: true, name: "hxpMimeTypeIcon" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: MimeTypeIconPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'hxpMimeTypeIcon',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: ThumbnailService }] });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a mime type icon.
 *
 * To use the `MimeTypeIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MimeTypeIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         MimeTypeIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-mime-type-icon [mimeType]="'image/png'"></hxp-mime-type-icon>
 *
 */
class MimeTypeIconComponent {
    constructor(
    // ThumbnailService is required to display icons
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    thumbnailService) {
        /**
         * A string representing a valid mime type.
         * @type {string}
         *
         * <details>
         * <summary>Supported mime types</summary>
         *
         * - 'image/png'
         * - 'image/jpeg'
         * - 'image/gif'
         * - 'image/bmp'
         * - 'image/cgm'
         * - 'image/ief'
         * - 'image/jp2'
         * - 'image/tiff'
         * - 'image/vnd.adobe.photoshop'
         * - 'image/vnd.adobe.premiere'
         * - 'image/x-cmu-raster'
         * - 'image/x-dwt'
         * - 'image/x-portable-anymap'
         * - 'image/x-portable-bitmap'
         * - 'image/x-portable-graymap'
         * - 'image/x-portable-pixmap'
         * - 'image/x-raw-adobe'
         * - 'image/x-raw-canon'
         * - 'image/x-raw-fuji'
         * - 'image/x-raw-hasselblad'
         * - 'image/x-raw-kodak'
         * - 'image/x-raw-leica'
         * - 'image/x-raw-minolta'
         * - 'image/x-raw-nikon'
         * - 'image/x-raw-olympus'
         * - 'image/x-raw-panasonic'
         * - 'image/x-raw-pentax'
         * - 'image/x-raw-red'
         * - 'image/x-raw-sigma'
         * - 'image/x-raw-sony'
         * - 'image/x-xbitmap'
         * - 'image/x-xpixmap'
         * - 'image/x-xwindowdump'
         * - 'image/svg+xml'
         * - 'application/eps'
         * - 'application/illustrator'
         * - 'application/pdf'
         * - 'application/vnd.ms-excel'
         * - 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
         * - 'application/vnd.openxmlformats-officedocument.spreadsheetml.template'
         * - 'application/vnd.ms-excel.addin.macroenabled.12'
         * - 'application/vnd.ms-excel.sheet.binary.macroenabled.12'
         * - 'application/vnd.ms-excel.sheet.macroenabled.12'
         * - 'application/vnd.ms-excel.template.macroenabled.12'
         * - 'application/vnd.sun.xml.calc'
         * - 'application/vnd.sun.xml.calc.template'
         * - 'application/vnd.ms-outlook'
         * - 'application/msword'
         * - 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
         * - 'application/vnd.openxmlformats-officedocument.wordprocessingml.template'
         * - 'application/vnd.ms-word.document.macroenabled.12'
         * - 'application/vnd.ms-word.template.macroenabled.12'
         * - 'application/vnd.sun.xml.writer'
         * - 'application/vnd.sun.xml.writer.template'
         * - 'application/rtf'
         * - 'text/rtf'
         * - 'application/vnd.ms-powerpoint'
         * - 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
         * - 'application/vnd.openxmlformats-officedocument.presentationml.template'
         * - 'application/vnd.openxmlformats-officedocument.presentationml.slideshow'
         * - 'application/vnd.oasis.opendocument.presentation'
         * - 'application/vnd.oasis.opendocument.presentation-template'
         * - 'application/vnd.openxmlformats-officedocument.presentationml.slide'
         * - 'application/vnd.sun.xml.impress'
         * - 'application/vnd.sun.xml.impress.template'
         * - 'application/vnd.oasis.opendocument.spreadsheet'
         * - 'application/vnd.oasis.opendocument.spreadsheet-template'
         * - 'application/vnd.ms-powerpoint.addin.macroenabled.12'
         * - 'application/vnd.ms-powerpoint.presentation.macroenabled.12'
         * - 'application/vnd.ms-powerpoint.slide.macroenabled.12'
         * - 'application/vnd.ms-powerpoint.slideshow.macroenabled.12'
         * - 'application/vnd.ms-powerpoint.template.macroenabled.12'
         * - 'video/mp4'
         * - 'video/3gpp'
         * - 'video/3gpp2'
         * - 'video/mp2t'
         * - 'video/mpeg'
         * - 'video/mpeg2'
         * - 'video/ogg'
         * - 'video/quicktime'
         * - 'video/webm'
         * - 'video/x-flv'
         * - 'video/x-m4v'
         * - 'video/x-ms-asf'
         * - 'video/x-ms-wmv'
         * - 'video/x-msvideo'
         * - 'video/x-rad-screenplay'
         * - 'video/x-sgi-movie'
         * - 'video/x-matroska'
         * - 'audio/mpeg'
         * - 'audio/ogg'
         * - 'audio/wav'
         * - 'audio/basic'
         * - 'audio/mp3'
         * - 'audio/mp4'
         * - 'audio/vnd.adobe.soundbooth'
         * - 'audio/vorbis'
         * - 'audio/x-aiff'
         * - 'audio/x-flac'
         * - 'audio/x-ms-wma'
         * - 'audio/x-wav'
         * - 'x-world/x-vrml'
         * - 'text/plain'
         * - 'application/vnd.oasis.opendocument.text'
         * - 'application/vnd.oasis.opendocument.text-template'
         * - 'application/x-javascript'
         * - 'application/json'
         * - 'text/csv'
         * - 'text/xml'
         * - 'text/html'
         * - 'text/css'
         * - 'application/x-compressed'
         * - 'application/x-zip-compressed'
         * - 'application/zip'
         * - 'application/x-tar'
         * - 'application/vnd.apple.keynote'
         * - 'application/vnd.apple.pages'
         * - 'application/vnd.apple.numbers'
         * - 'application/vnd.visio'
         * - 'application/wordperfect'
         * - 'application/x-cpio'
         * - 'multipart/related'
         *
         * </details>
         *
         *
         */
        this.mimeType = DefaultIcon.UNKNOWN;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: MimeTypeIconComponent, deps: [{ token: ThumbnailService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: MimeTypeIconComponent, isStandalone: true, selector: "hxp-mime-type-icon", inputs: { mimeType: "mimeType" }, providers: [{ provide: ThumbnailService$1, useClass: ThumbnailService }], ngImport: i0, template: "<img [src]=\"mimeType | hxpMimeTypeIcon\" [alt]=\"mimeType\" />\n", styles: ["img{all:inherit}\n"], dependencies: [{ kind: "pipe", type: MimeTypeIconPipe, name: "hxpMimeTypeIcon" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: MimeTypeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-mime-type-icon', standalone: true, imports: [MimeTypeIconPipe], providers: [{ provide: ThumbnailService$1, useClass: ThumbnailService }], template: "<img [src]=\"mimeType | hxpMimeTypeIcon\" [alt]=\"mimeType\" />\n", styles: ["img{all:inherit}\n"] }]
        }], ctorParameters: () => [{ type: ThumbnailService }], propDecorators: { mimeType: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a folder icon.
 *
 * To use the `FolderIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { FolderIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         FolderIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-folder-icon [isExpanded]="false"></hxp-folder-icon>
 */
class FolderIconComponent {
    constructor() {
        /**
         * Indicates whether the folder is expanded.
         * @type {boolean}
         */
        this.isExpanded = false;
        this.folderIcon = 'folder';
        this.openFolderIcon = 'openFolder';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FolderIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: FolderIconComponent, isStandalone: true, selector: "hxp-folder-icon", inputs: { isExpanded: "isExpanded" }, ngImport: i0, template: "<hxp-mime-type-icon\n    [mimeType]=\"isExpanded ? openFolderIcon : folderIcon\"\n/>\n", dependencies: [{ kind: "component", type: MimeTypeIconComponent, selector: "hxp-mime-type-icon", inputs: ["mimeType"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: FolderIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-folder-icon', standalone: true, imports: [MimeTypeIconComponent], template: "<hxp-mime-type-icon\n    [mimeType]=\"isExpanded ? openFolderIcon : folderIcon\"\n/>\n" }]
        }], propDecorators: { isExpanded: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const SearchIconAssets = {
    SEARCH: 'assets/search-icons/Search.svg',
    CLEAR: 'assets/search-icons/Clear.svg',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a search action icon.
 *
 * To use the `SearchActionIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { SearchActionIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         SearchActionIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *  <hxp-search-action-icon></hxp-search-action-icon>
 *
 */
class SearchActionIconComponent {
    constructor(translateService, matIconRegistry, domSanitizer) {
        this.translateService = translateService;
        this.matIconRegistry = matIconRegistry;
        this.domSanitizer = domSanitizer;
        /**
         * A custom text for HTML <img> alt attribute.
         * @type {string}
         *
         */
        this.actionAlt = '';
        this.alt = '';
        this.actionIcon = 'SEARCH';
        this.iconAssetPath = SearchIconAssets[this.actionIcon];
        const icons = {
            search_calendar: 'assets/search-icons/Calendar_search.svg',
            search_clear: 'assets/search-icons/Clear.svg',
            search_glass: 'assets/search-icons/Search.svg',
            search_arrow_left: 'assets/search-icons/Arrow_left.svg',
            repository_search: 'assets/search-icons/Repository_search.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    ngOnChanges() {
        this.iconAssetPath = SearchIconAssets[this.actionIcon];
        this.alt =
            this.actionAlt ||
                (this.actionIcon === 'SEARCH'
                    ? this.translateService.instant('SEARCH.ICON.SEARCH')
                    : this.translateService.instant('SEARCH.ICON.CLEAR_INPUT'));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchActionIconComponent, deps: [{ token: i1.TranslateService }, { token: i2.MatIconRegistry }, { token: i3.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.9", type: SearchActionIconComponent, isStandalone: true, selector: "hxp-search-action-icon", inputs: { actionIcon: "actionIcon", actionAlt: "actionAlt" }, usesOnChanges: true, ngImport: i0, template: "<img [src]=\"iconAssetPath\" [alt]=\"alt\">\n", styles: ["img{display:block}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.9", ngImport: i0, type: SearchActionIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-action-icon', standalone: true, template: "<img [src]=\"iconAssetPath\" [alt]=\"alt\">\n", styles: ["img{display:block}\n"] }]
        }], ctorParameters: () => [{ type: i1.TranslateService }, { type: i2.MatIconRegistry }, { type: i3.DomSanitizer }], propDecorators: { actionIcon: [{
                type: Input
            }], actionAlt: [{
                type: Input
            }] } });

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
// standalone components

/**
 * Generated bundle index. Do not edit.
 */

export { DefaultIcon, FolderIconComponent, MimeTypeIconComponent, SearchActionIconComponent, SearchIconAssets, ThumbnailService };
//# sourceMappingURL=alfresco-adf-hx-content-services-icons.mjs.map
