import { Configuration, DownloadApi, UserApi, QueryApi, MoveApi, CopyApi, GroupApi, DocumentApi, ModelApi, RenditionsApi, UploadApi, CheckInApi, VersionApi } from '@hylandsoftware/hxcs-js-client';
import { AppConfigValues, AuthenticationService, AppConfigService } from '@alfresco/adf-core';
import { InjectionToken } from '@angular/core';
import { share } from 'rxjs/operators';
import { Subject } from 'rxjs';

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const ROOT_DOCUMENT = {
    sys_id: '00000000-0000-0000-0000-000000000000',
    sys_isFolderish: true,
    sys_primaryType: 'SysRoot',
    sys_path: '/',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DEFAULT_REPOSITORY_ID = 'default';

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const FieldType = {
    Boolean: 'boolean',
    BooleanArray: 'boolean[]',
    Blob: 'blob',
    BlobArray: 'blob[]',
    Complex: 'complex',
    Date: 'date',
    DateArray: 'date[]',
    Float: 'double',
    FloatArray: 'double[]',
    Integer: 'long',
    IntegerArray: 'long[]',
    Object: 'object',
    String: 'string',
    StringArray: 'string[]',
    User: 'user',
    UserArray: 'user[]',
};

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/*
 * Best practices to avoid circular dependency:
 * every provider and token pair should be created in a separate file
 * inside the providers folder of this lib
 * and add exports in the entry-point lib (index.ts)
 * then you can import the provider in any module from the shared folder
 */
function getHxcsJsClientApiFactoryFunction(apiClass) {
    const hxcsSdkJsApiFactoryFn = (authService, configService) => {
        if (configService.status !== 'loaded') {
            throw new Error('[hxcsSdkJsApiFactoryFn]: Configuration not available to initialize provider');
        }
        const config = new Configuration({
            basePath: configService.get(AppConfigValues.ECMHOST),
            accessToken: authService.getToken(),
        });
        return getRefreshingTokenApi(apiClass, authService, config);
    };
    return hxcsSdkJsApiFactoryFn;
}
function getHxcsJsClientProvider(tokenName, apiClass) {
    const injectionToken = new InjectionToken(tokenName);
    return {
        provide: injectionToken,
        useFactory: getHxcsJsClientApiFactoryFunction(apiClass),
        deps: [AuthenticationService, AppConfigService],
    };
}
function getRefreshingTokenApi(apiClass, authService, config) {
    const instance = new apiClass(config);
    authService.onTokenReceived.pipe(share()).subscribe(() => {
        instance.configuration.accessToken = authService.getToken();
    });
    return instance;
}

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const downloadApiProvider = getHxcsJsClientProvider('DownloadApi', DownloadApi);
const DOWNLOAD_API_TOKEN = downloadApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const userApiProvider = getHxcsJsClientProvider('UserApi', UserApi);
const USER_API_TOKEN = userApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const queryApiProvider = getHxcsJsClientProvider('QueryApi', QueryApi);
const QUERY_API_TOKEN = queryApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const moveApiProvider = getHxcsJsClientProvider('MoveApi', MoveApi);
const MOVE_API_TOKEN = moveApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const copyApiProvider = getHxcsJsClientProvider('CopyApi', CopyApi);
const COPY_API_TOKEN = copyApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const groupApiProvider = getHxcsJsClientProvider('GroupApi', GroupApi);
const GROUP_API_TOKEN = groupApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const documentApiProvider = getHxcsJsClientProvider('DocumentApi', DocumentApi);
const DOCUMENT_API_TOKEN = documentApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const modelApiProvider = getHxcsJsClientProvider('ModelApi', ModelApi);
const MODEL_API_TOKEN = modelApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const renditionsApiProvider = getHxcsJsClientProvider('RenditionsApi', RenditionsApi);
const RENDITIONS_API_TOKEN = renditionsApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const uploadApiProvider = getHxcsJsClientProvider('UploadApi', UploadApi);
const UPLOAD_API_TOKEN = uploadApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const checkInApiProvider = getHxcsJsClientProvider('CheckInApi', CheckInApi);
const CHECKIN_API_TOKEN = checkInApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const versionApiProvider = getHxcsJsClientProvider('VersionApi', VersionApi);
const VERSION_API_TOKEN = versionApiProvider.provide;

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const mockAppConfigService = {
    status: 'loaded',
    get: (key) => {
        return key === 'viewer'
            ? {
                enableDownloadPrompt: false,
                enableDownloadPromptReminder: false,
                downloadPromptDelay: 3,
                downloadPromptReminderDelay: 2,
            }
            : {};
    },
};
const mockHxcsJsClientConfigurationService = [
    {
        provide: AuthenticationService,
        useValue: {
            getToken: () => 'fake token',
            onTokenReceived: new Subject(),
        },
    },
    {
        provide: AppConfigService,
        useValue: mockAppConfigService,
    },
];

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const ADF_HX_CONTENT_SERVICES_API_PROVIDERS = [
    checkInApiProvider,
    copyApiProvider,
    documentApiProvider,
    downloadApiProvider,
    groupApiProvider,
    modelApiProvider,
    moveApiProvider,
    queryApiProvider,
    renditionsApiProvider,
    userApiProvider,
    uploadApiProvider,
    versionApiProvider,
];

/*
 * Copyright © 2005 - 2021 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ADF_HX_CONTENT_SERVICES_API_PROVIDERS, CHECKIN_API_TOKEN, COPY_API_TOKEN, DEFAULT_REPOSITORY_ID, DOCUMENT_API_TOKEN, DOWNLOAD_API_TOKEN, FieldType, GROUP_API_TOKEN, MODEL_API_TOKEN, MOVE_API_TOKEN, QUERY_API_TOKEN, RENDITIONS_API_TOKEN, ROOT_DOCUMENT, UPLOAD_API_TOKEN, USER_API_TOKEN, VERSION_API_TOKEN, checkInApiProvider, copyApiProvider, documentApiProvider, downloadApiProvider, getHxcsJsClientProvider, groupApiProvider, mockHxcsJsClientConfigurationService, modelApiProvider, moveApiProvider, queryApiProvider, renditionsApiProvider, uploadApiProvider, userApiProvider, versionApiProvider };
//# sourceMappingURL=alfresco-adf-hx-content-services-api.mjs.map
