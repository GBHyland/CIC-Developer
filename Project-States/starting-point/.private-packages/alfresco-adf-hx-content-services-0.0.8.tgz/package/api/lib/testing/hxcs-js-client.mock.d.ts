import { AppConfigService, AuthenticationService } from '@alfresco/adf-core';
import { Subject } from 'rxjs';
export declare const mockHxcsJsClientConfigurationService: ({
    provide: typeof AuthenticationService;
    useValue: {
        getToken: () => string;
        onTokenReceived: Subject<any>;
    };
} | {
    provide: typeof AppConfigService;
    useValue: {
        status: string;
        get: (key: string) => {
            enableDownloadPrompt: boolean;
            enableDownloadPromptReminder: boolean;
            downloadPromptDelay: number;
            downloadPromptReminderDelay: number;
        } | {
            enableDownloadPrompt?: undefined;
            enableDownloadPromptReminder?: undefined;
            downloadPromptDelay?: undefined;
            downloadPromptReminderDelay?: undefined;
        };
    };
})[];
