export declare const ADF_HX_CONTENT_SERVICES_API_PROVIDERS: import("@angular/core").FactoryProvider[];
