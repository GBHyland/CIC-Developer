export type DefaultStatusSnackBarIcon = 'info' | 'done' | 'error';
