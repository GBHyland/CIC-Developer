export declare const FieldType: {
    readonly Boolean: "boolean";
    readonly BooleanArray: "boolean[]";
    readonly Blob: "blob";
    readonly BlobArray: "blob[]";
    readonly Complex: "complex";
    readonly Date: "date";
    readonly DateArray: "date[]";
    readonly Float: "double";
    readonly FloatArray: "double[]";
    readonly Integer: "long";
    readonly IntegerArray: "long[]";
    readonly Object: "object";
    readonly String: "string";
    readonly StringArray: "string[]";
    readonly User: "user";
    readonly UserArray: "user[]";
};
export type FieldType = typeof FieldType[keyof typeof FieldType];
