export declare const DEFAULT_REPOSITORY_ID = "default";
