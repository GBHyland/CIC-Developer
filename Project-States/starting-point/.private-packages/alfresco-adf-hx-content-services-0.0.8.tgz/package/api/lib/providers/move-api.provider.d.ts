export declare const moveApiProvider: import("@angular/core").FactoryProvider;
export declare const MOVE_API_TOKEN: any;
