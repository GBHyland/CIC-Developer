export declare const versionApiProvider: import("@angular/core").FactoryProvider;
export declare const VERSION_API_TOKEN: any;
