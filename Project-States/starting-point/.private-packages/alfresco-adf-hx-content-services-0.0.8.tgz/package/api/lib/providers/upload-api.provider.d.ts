export declare const uploadApiProvider: import("@angular/core").FactoryProvider;
export declare const UPLOAD_API_TOKEN: any;
