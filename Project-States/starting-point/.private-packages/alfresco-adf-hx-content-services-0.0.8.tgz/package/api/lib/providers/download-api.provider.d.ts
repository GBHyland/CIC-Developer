export declare const downloadApiProvider: import("@angular/core").FactoryProvider;
export declare const DOWNLOAD_API_TOKEN: any;
