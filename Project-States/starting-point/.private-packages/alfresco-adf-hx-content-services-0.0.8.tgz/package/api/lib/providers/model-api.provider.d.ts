export declare const modelApiProvider: import("@angular/core").FactoryProvider;
export declare const MODEL_API_TOKEN: any;
