export declare const checkInApiProvider: import("@angular/core").FactoryProvider;
export declare const CHECKIN_API_TOKEN: any;
