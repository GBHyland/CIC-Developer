# Satori tokens

Design tokens for Satori-UI

## Project structure

The project is made of these files and folders:

* `/tokens` contains the design tokens input files exported by Supernova (in JSON format)
* `/css` contains the generated CSS output
* `/scss` contains the generated SCSS output

## Running the project

You can build the design tokens from the `/tokens` folder using the CLI command:

```console
npm run build
```

## Release

Run [github bump workflow](https://github.com/HylandSoftware/satori-tokens/actions/workflows/bump.yml).
It will create a PR with the version change.
Review and merge this PR.
When merged, the version will be automatically tagged, published and a Github release will be created.

### Semver

* **Patch**: Only for bug fixes
* **Minor**: Any new tokens, new theme or any token value change will need a minor bump
* **Major**: Any token or theme removed or renamed will a major bump
