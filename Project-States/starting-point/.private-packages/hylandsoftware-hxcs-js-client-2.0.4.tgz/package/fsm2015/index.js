import { __awaiter } from 'tslib';
import globalAxios from 'axios';

/* tslint:disable */
const BASE_PATH = "http://localhost:8080".replace(/\/+$/, "");
/**
 *
 * @export
 */
const COLLECTION_FORMATS = {
    csv: ",",
    ssv: " ",
    tsv: "\t",
    pipes: "|"
};
/**
 *
 * @export
 * @class BaseAPI
 */
class BaseAPI {
    constructor(configuration, basePath = BASE_PATH, axios = globalAxios) {
        this.basePath = basePath;
        this.axios = axios;
        if (configuration) {
            this.configuration = configuration;
            this.basePath = configuration.basePath || this.basePath;
        }
        // Interceptor added as we do not want encoded '/' characters
        axios.interceptors.request.use((req) => {
            if (req.url) {
                req.url = req.url.replace(/%2F/g, "/");
            }
            return req;
        });
    }
}
;
/**
 *
 * @export
 * @class RequiredError
 * @extends {Error}
 */
class RequiredError extends Error {
    constructor(field, msg) {
        super(msg);
        this.field = field;
        this.name = "RequiredError";
    }
}

/* tslint:disable */
/**
 *
 * @export
 */
const DUMMY_BASE_URL = 'https://example.com';
/**
 *
 * @throws {RequiredError}
 * @export
 */
const assertParamExists = function (functionName, paramName, paramValue) {
    if (paramValue === null || paramValue === undefined) {
        throw new RequiredError(paramName, `Required parameter ${paramName} was null or undefined when calling ${functionName}.`);
    }
};
/**
 *
 * @export
 */
const setApiKeyToObject = function (object, keyParamName, configuration) {
    return __awaiter(this, void 0, void 0, function* () {
        if (configuration && configuration.apiKey) {
            const localVarApiKeyValue = typeof configuration.apiKey === 'function'
                ? yield configuration.apiKey(keyParamName)
                : yield configuration.apiKey;
            object[keyParamName] = localVarApiKeyValue;
        }
    });
};
/**
 *
 * @export
 */
const setBasicAuthToObject = function (object, configuration) {
    if (configuration && (configuration.username || configuration.password)) {
        object["auth"] = { username: configuration.username, password: configuration.password };
    }
};
/**
 *
 * @export
 */
const setBearerAuthToObject = function (object, configuration) {
    return __awaiter(this, void 0, void 0, function* () {
        if (configuration && configuration.accessToken) {
            const accessToken = typeof configuration.accessToken === 'function'
                ? yield configuration.accessToken()
                : yield configuration.accessToken;
            object["Authorization"] = "Bearer " + accessToken;
        }
    });
};
/**
 *
 * @export
 */
const setOAuthToObject = function (object, name, scopes, configuration) {
    return __awaiter(this, void 0, void 0, function* () {
        if (configuration && configuration.accessToken) {
            const localVarAccessTokenValue = typeof configuration.accessToken === 'function'
                ? yield configuration.accessToken(name, scopes)
                : yield configuration.accessToken;
            object["Authorization"] = "Bearer " + localVarAccessTokenValue;
        }
    });
};
/**
 *
 * @export
 */
const setSearchParams = function (url, ...objects) {
    const searchParams = new URLSearchParams(url.search);
    for (const object of objects) {
        for (const key in object) {
            if (Array.isArray(object[key])) {
                searchParams.delete(key);
                for (const item of object[key]) {
                    searchParams.append(key, item);
                }
            }
            else {
                searchParams.set(key, object[key]);
            }
        }
    }
    url.search = searchParams.toString();
};
/**
 *
 * @export
 */
const serializeDataIfNeeded = function (value, requestOptions, configuration) {
    const nonString = typeof value !== 'string';
    const needsSerialization = nonString && configuration && configuration.isJsonMime
        ? configuration.isJsonMime(requestOptions.headers['Content-Type'])
        : nonString;
    return needsSerialization
        ? JSON.stringify(value !== undefined ? value : {})
        : (value || "");
};
/**
 *
 * @export
 */
const toPathString = function (url) {
    return url.pathname + url.search + url.hash;
};
/**
 *
 * @export
 */
const createRequestFunction = function (axiosArgs, globalAxios, BASE_PATH, configuration) {
    return (axios = globalAxios, basePath = BASE_PATH) => {
        const axiosRequestArgs = Object.assign(Object.assign({}, axiosArgs.options), { url: ((configuration === null || configuration === void 0 ? void 0 : configuration.basePath) || basePath) + axiosArgs.url });
        return axios.request(axiosRequestArgs);
    };
};

/* tslint:disable */
/**
 *
 * @export
 * @enum {string}
 */
const Status = {
    Pending: 'PENDING',
    Effective: 'EFFECTIVE',
    Archived: 'ARCHIVED'
};
/**
 * CheckInApi - axios parameter creator
 * @export
 */
const CheckInApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Checks in the document, creating a version.
         * @param {string} docId The id of the document to be checked in.
         * @param {boolean} [minor] Whether the Check In should create a minor version. If false, a major version will be created instead.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        checkin: (docId_1, minor_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, minor_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, minor, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('checkin', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/checkin`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (minor !== undefined) {
                localVarQueryParameter['minor'] = minor;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * CheckInApi - functional programming interface
 * @export
 */
const CheckInApiFp = function (configuration) {
    const localVarAxiosParamCreator = CheckInApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Checks in the document, creating a version.
         * @param {string} docId The id of the document to be checked in.
         * @param {boolean} [minor] Whether the Check In should create a minor version. If false, a major version will be created instead.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        checkin(docId, minor, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.checkin(docId, minor, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * CheckInApi - factory interface
 * @export
 */
const CheckInApiFactory = function (configuration, basePath, axios) {
    const localVarFp = CheckInApiFp(configuration);
    return {
        /**
         *
         * @summary Checks in the document, creating a version.
         * @param {string} docId The id of the document to be checked in.
         * @param {boolean} [minor] Whether the Check In should create a minor version. If false, a major version will be created instead.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        checkin(docId, minor, hXCSREPOSITORY, options) {
            return localVarFp.checkin(docId, minor, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * CheckInApi - object-oriented interface
 * @export
 * @class CheckInApi
 * @extends {BaseAPI}
 */
class CheckInApi extends BaseAPI {
    /**
     *
     * @summary Checks in the document, creating a version.
     * @param {string} docId The id of the document to be checked in.
     * @param {boolean} [minor] Whether the Check In should create a minor version. If false, a major version will be created instead.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof CheckInApi
     */
    checkin(docId, minor, hXCSREPOSITORY, options) {
        return CheckInApiFp(this.configuration).checkin(docId, minor, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * CopyApi - axios parameter creator
 * @export
 */
const CopyApiAxiosParamCreator = function (configuration) {
    return {
        /**
         * Copy a given document id to a given destination folder.  Requires request body with target name and targetParentId
         * @summary Copies the source document inside the destination folder
         * @param {string} docId The source document id to be copied.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {CopyCommand} [copyCommand]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        copy: (docId_1, hXCSREPOSITORY_1, copyCommand_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, copyCommand_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, copyCommand, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('copy', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/copy`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(copyCommand, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * CopyApi - functional programming interface
 * @export
 */
const CopyApiFp = function (configuration) {
    const localVarAxiosParamCreator = CopyApiAxiosParamCreator(configuration);
    return {
        /**
         * Copy a given document id to a given destination folder.  Requires request body with target name and targetParentId
         * @summary Copies the source document inside the destination folder
         * @param {string} docId The source document id to be copied.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {CopyCommand} [copyCommand]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        copy(docId, hXCSREPOSITORY, copyCommand, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.copy(docId, hXCSREPOSITORY, copyCommand, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * CopyApi - factory interface
 * @export
 */
const CopyApiFactory = function (configuration, basePath, axios) {
    const localVarFp = CopyApiFp(configuration);
    return {
        /**
         * Copy a given document id to a given destination folder.  Requires request body with target name and targetParentId
         * @summary Copies the source document inside the destination folder
         * @param {string} docId The source document id to be copied.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {CopyCommand} [copyCommand]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        copy(docId, hXCSREPOSITORY, copyCommand, options) {
            return localVarFp.copy(docId, hXCSREPOSITORY, copyCommand, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * CopyApi - object-oriented interface
 * @export
 * @class CopyApi
 * @extends {BaseAPI}
 */
class CopyApi extends BaseAPI {
    /**
     * Copy a given document id to a given destination folder.  Requires request body with target name and targetParentId
     * @summary Copies the source document inside the destination folder
     * @param {string} docId The source document id to be copied.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {CopyCommand} [copyCommand]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof CopyApi
     */
    copy(docId, hXCSREPOSITORY, copyCommand, options) {
        return CopyApiFp(this.configuration).copy(docId, hXCSREPOSITORY, copyCommand, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * DocumentApi - axios parameter creator
 * @export
 */
const DocumentApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Creates a document under parent with given id.
         * @param {string} docId The parent document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createDocumentUnderParentById: (docId_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, requestBody, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('createDocumentUnderParentById', 'docId', docId);
            const localVarPath = `/api/documents/{docId}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Creates a document under parent with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createDocumentUnderParentByPath: (docPath_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [docPath_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (docPath, hXCSREPOSITORY, requestBody, options = {}) {
            // verify required parameter 'docPath' is not null or undefined
            assertParamExists('createDocumentUnderParentByPath', 'docPath', docPath);
            const localVarPath = `/api/documents/path{docPath}`
                .replace(`{${"docPath"}}`, encodeURIComponent(String(docPath)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Deletes the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteDocumentById: (docId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('deleteDocumentById', 'docId', docId);
            const localVarPath = `/api/documents/{docId}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'DELETE' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Deletes the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteDocumentByPath: (docPath_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docPath_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docPath, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docPath' is not null or undefined
            assertParamExists('deleteDocumentByPath', 'docPath', docPath);
            const localVarPath = `/api/documents/path{docPath}`
                .replace(`{${"docPath"}}`, encodeURIComponent(String(docPath)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'DELETE' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the document\'s ancestors.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentAncestors: (docId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('getDocumentAncestors', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/ancestors`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentById: (docId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('getDocumentById', 'docId', docId);
            const localVarPath = `/api/documents/{docId}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentByPath: (docPath_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docPath_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docPath, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docPath' is not null or undefined
            assertParamExists('getDocumentByPath', 'docPath', docPath);
            const localVarPath = `/api/documents/path{docPath}`
                .replace(`{${"docPath"}}`, encodeURIComponent(String(docPath)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Patches the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchDocumentById: (docId_1, hXCSREPOSITORY_1, body_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, body_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, body, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('patchDocumentById', 'docId', docId);
            const localVarPath = `/api/documents/{docId}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PATCH' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json-patch+json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(body, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Patches the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchDocumentByPath: (docPath_1, hXCSREPOSITORY_1, body_1, ...args_1) => __awaiter(this, [docPath_1, hXCSREPOSITORY_1, body_1, ...args_1], void 0, function* (docPath, hXCSREPOSITORY, body, options = {}) {
            // verify required parameter 'docPath' is not null or undefined
            assertParamExists('patchDocumentByPath', 'docPath', docPath);
            const localVarPath = `/api/documents/path{docPath}`
                .replace(`{${"docPath"}}`, encodeURIComponent(String(docPath)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PATCH' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json-patch+json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(body, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Updates the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateDocumentById: (docId_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, requestBody, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('updateDocumentById', 'docId', docId);
            const localVarPath = `/api/documents/{docId}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Updates the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateDocumentByPath: (docPath_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [docPath_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (docPath, hXCSREPOSITORY, requestBody, options = {}) {
            // verify required parameter 'docPath' is not null or undefined
            assertParamExists('updateDocumentByPath', 'docPath', docPath);
            const localVarPath = `/api/documents/path{docPath}`
                .replace(`{${"docPath"}}`, encodeURIComponent(String(docPath)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * DocumentApi - functional programming interface
 * @export
 */
const DocumentApiFp = function (configuration) {
    const localVarAxiosParamCreator = DocumentApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Creates a document under parent with given id.
         * @param {string} docId The parent document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createDocumentUnderParentById(docId, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.createDocumentUnderParentById(docId, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Creates a document under parent with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createDocumentUnderParentByPath(docPath, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.createDocumentUnderParentByPath(docPath, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Deletes the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteDocumentById(docId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.deleteDocumentById(docId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Deletes the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteDocumentByPath(docPath, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.deleteDocumentByPath(docPath, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the document\'s ancestors.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentAncestors(docId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getDocumentAncestors(docId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentById(docId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getDocumentById(docId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentByPath(docPath, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getDocumentByPath(docPath, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Patches the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchDocumentById(docId, hXCSREPOSITORY, body, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.patchDocumentById(docId, hXCSREPOSITORY, body, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Patches the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchDocumentByPath(docPath, hXCSREPOSITORY, body, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.patchDocumentByPath(docPath, hXCSREPOSITORY, body, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Updates the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateDocumentById(docId, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.updateDocumentById(docId, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Updates the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateDocumentByPath(docPath, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.updateDocumentByPath(docPath, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * DocumentApi - factory interface
 * @export
 */
const DocumentApiFactory = function (configuration, basePath, axios) {
    const localVarFp = DocumentApiFp(configuration);
    return {
        /**
         *
         * @summary Creates a document under parent with given id.
         * @param {string} docId The parent document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createDocumentUnderParentById(docId, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.createDocumentUnderParentById(docId, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Creates a document under parent with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createDocumentUnderParentByPath(docPath, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.createDocumentUnderParentByPath(docPath, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Deletes the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteDocumentById(docId, hXCSREPOSITORY, options) {
            return localVarFp.deleteDocumentById(docId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Deletes the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteDocumentByPath(docPath, hXCSREPOSITORY, options) {
            return localVarFp.deleteDocumentByPath(docPath, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the document\'s ancestors.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentAncestors(docId, hXCSREPOSITORY, options) {
            return localVarFp.getDocumentAncestors(docId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentById(docId, hXCSREPOSITORY, options) {
            return localVarFp.getDocumentById(docId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentByPath(docPath, hXCSREPOSITORY, options) {
            return localVarFp.getDocumentByPath(docPath, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Patches the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchDocumentById(docId, hXCSREPOSITORY, body, options) {
            return localVarFp.patchDocumentById(docId, hXCSREPOSITORY, body, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Patches the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchDocumentByPath(docPath, hXCSREPOSITORY, body, options) {
            return localVarFp.patchDocumentByPath(docPath, hXCSREPOSITORY, body, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Updates the document with given id.
         * @param {string} docId The document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateDocumentById(docId, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.updateDocumentById(docId, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Updates the document with given path.
         * @param {string} docPath The document path.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: any; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateDocumentByPath(docPath, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.updateDocumentByPath(docPath, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * DocumentApi - object-oriented interface
 * @export
 * @class DocumentApi
 * @extends {BaseAPI}
 */
class DocumentApi extends BaseAPI {
    /**
     *
     * @summary Creates a document under parent with given id.
     * @param {string} docId The parent document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: any; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    createDocumentUnderParentById(docId, hXCSREPOSITORY, requestBody, options) {
        return DocumentApiFp(this.configuration).createDocumentUnderParentById(docId, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Creates a document under parent with given path.
     * @param {string} docPath The document path.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: any; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    createDocumentUnderParentByPath(docPath, hXCSREPOSITORY, requestBody, options) {
        return DocumentApiFp(this.configuration).createDocumentUnderParentByPath(docPath, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Deletes the document with given id.
     * @param {string} docId The document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    deleteDocumentById(docId, hXCSREPOSITORY, options) {
        return DocumentApiFp(this.configuration).deleteDocumentById(docId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Deletes the document with given path.
     * @param {string} docPath The document path.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    deleteDocumentByPath(docPath, hXCSREPOSITORY, options) {
        return DocumentApiFp(this.configuration).deleteDocumentByPath(docPath, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the document\'s ancestors.
     * @param {string} docId The document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    getDocumentAncestors(docId, hXCSREPOSITORY, options) {
        return DocumentApiFp(this.configuration).getDocumentAncestors(docId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the document with given id.
     * @param {string} docId The document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    getDocumentById(docId, hXCSREPOSITORY, options) {
        return DocumentApiFp(this.configuration).getDocumentById(docId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the document with given path.
     * @param {string} docPath The document path.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    getDocumentByPath(docPath, hXCSREPOSITORY, options) {
        return DocumentApiFp(this.configuration).getDocumentByPath(docPath, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Patches the document with given id.
     * @param {string} docId The document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {object} [body]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    patchDocumentById(docId, hXCSREPOSITORY, body, options) {
        return DocumentApiFp(this.configuration).patchDocumentById(docId, hXCSREPOSITORY, body, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Patches the document with given path.
     * @param {string} docPath The document path.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {object} [body]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    patchDocumentByPath(docPath, hXCSREPOSITORY, body, options) {
        return DocumentApiFp(this.configuration).patchDocumentByPath(docPath, hXCSREPOSITORY, body, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Updates the document with given id.
     * @param {string} docId The document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: any; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    updateDocumentById(docId, hXCSREPOSITORY, requestBody, options) {
        return DocumentApiFp(this.configuration).updateDocumentById(docId, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Updates the document with given path.
     * @param {string} docPath The document path.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: any; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentApi
     */
    updateDocumentByPath(docPath, hXCSREPOSITORY, requestBody, options) {
        return DocumentApiFp(this.configuration).updateDocumentByPath(docPath, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * DocumentPermissionsApi - axios parameter creator
 * @export
 */
const DocumentPermissionsApiAxiosParamCreator = function (configuration) {
    return {
        /**
         * Fetch the full list of effective ACL on the document for the given list of users.
         * @summary Fetch the full list of effective ACL on the document.
         * @param {string} docId The document id for which the ACL are fetched.
         * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        fulleffectiveacl: (docId_1, usernames_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, usernames_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, usernames, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('fulleffectiveacl', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/fulleffectiveacl`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (usernames) {
                localVarQueryParameter['usernames'] = usernames;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         * Fetch the full list of effective permissions on the document for the given list of users.
         * @summary Fetch the full list of effective permissions on the document.
         * @param {string} docId The document id for which the ACL are fetched.
         * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        fulleffectivepermissions: (docId_1, usernames_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, usernames_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, usernames, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('fulleffectivepermissions', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/fulleffectivepermissions`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (usernames) {
                localVarQueryParameter['usernames'] = usernames;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * DocumentPermissionsApi - functional programming interface
 * @export
 */
const DocumentPermissionsApiFp = function (configuration) {
    const localVarAxiosParamCreator = DocumentPermissionsApiAxiosParamCreator(configuration);
    return {
        /**
         * Fetch the full list of effective ACL on the document for the given list of users.
         * @summary Fetch the full list of effective ACL on the document.
         * @param {string} docId The document id for which the ACL are fetched.
         * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        fulleffectiveacl(docId, usernames, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.fulleffectiveacl(docId, usernames, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         * Fetch the full list of effective permissions on the document for the given list of users.
         * @summary Fetch the full list of effective permissions on the document.
         * @param {string} docId The document id for which the ACL are fetched.
         * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        fulleffectivepermissions(docId, usernames, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.fulleffectivepermissions(docId, usernames, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * DocumentPermissionsApi - factory interface
 * @export
 */
const DocumentPermissionsApiFactory = function (configuration, basePath, axios) {
    const localVarFp = DocumentPermissionsApiFp(configuration);
    return {
        /**
         * Fetch the full list of effective ACL on the document for the given list of users.
         * @summary Fetch the full list of effective ACL on the document.
         * @param {string} docId The document id for which the ACL are fetched.
         * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        fulleffectiveacl(docId, usernames, hXCSREPOSITORY, options) {
            return localVarFp.fulleffectiveacl(docId, usernames, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         * Fetch the full list of effective permissions on the document for the given list of users.
         * @summary Fetch the full list of effective permissions on the document.
         * @param {string} docId The document id for which the ACL are fetched.
         * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        fulleffectivepermissions(docId, usernames, hXCSREPOSITORY, options) {
            return localVarFp.fulleffectivepermissions(docId, usernames, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * DocumentPermissionsApi - object-oriented interface
 * @export
 * @class DocumentPermissionsApi
 * @extends {BaseAPI}
 */
class DocumentPermissionsApi extends BaseAPI {
    /**
     * Fetch the full list of effective ACL on the document for the given list of users.
     * @summary Fetch the full list of effective ACL on the document.
     * @param {string} docId The document id for which the ACL are fetched.
     * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentPermissionsApi
     */
    fulleffectiveacl(docId, usernames, hXCSREPOSITORY, options) {
        return DocumentPermissionsApiFp(this.configuration).fulleffectiveacl(docId, usernames, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     * Fetch the full list of effective permissions on the document for the given list of users.
     * @summary Fetch the full list of effective permissions on the document.
     * @param {string} docId The document id for which the ACL are fetched.
     * @param {Array<string>} [usernames] The list of users to fetch the ACL on the document.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DocumentPermissionsApi
     */
    fulleffectivepermissions(docId, usernames, hXCSREPOSITORY, options) {
        return DocumentPermissionsApiFp(this.configuration).fulleffectivepermissions(docId, usernames, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * DownloadApi - axios parameter creator
 * @export
 */
const DownloadApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the document blob.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {boolean} [inline] Inline content disposition enablement.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadByIdAndXPath: (docId_1, propertyXPathAndFilename_1, inline_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, propertyXPathAndFilename_1, inline_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('downloadByIdAndXPath', 'docId', docId);
            // verify required parameter 'propertyXPathAndFilename' is not null or undefined
            assertParamExists('downloadByIdAndXPath', 'propertyXPathAndFilename', propertyXPathAndFilename);
            const localVarPath = `/api/download/{docId}/{propertyXPathAndFilename}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)))
                .replace(`{${"propertyXPathAndFilename"}}`, encodeURIComponent(String(propertyXPathAndFilename)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (inline !== undefined) {
                localVarQueryParameter['inline'] = inline;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the document blob information.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadInfoByIdAndXPath: (docId_1, propertyXPathAndFilename_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, propertyXPathAndFilename_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, propertyXPathAndFilename, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('downloadInfoByIdAndXPath', 'docId', docId);
            // verify required parameter 'propertyXPathAndFilename' is not null or undefined
            assertParamExists('downloadInfoByIdAndXPath', 'propertyXPathAndFilename', propertyXPathAndFilename);
            const localVarPath = `/api/download/{docId}/{propertyXPathAndFilename}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)))
                .replace(`{${"propertyXPathAndFilename"}}`, encodeURIComponent(String(propertyXPathAndFilename)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'HEAD' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the the pre-signed S3 Url for a downloadable object.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {number} [expiration] expiration value for generating the S3 pre-signed url in seconds.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadUrlByIdAndXPath: (docId_1, propertyXPathAndFilename_1, expiration_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, propertyXPathAndFilename_1, expiration_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('downloadUrlByIdAndXPath', 'docId', docId);
            // verify required parameter 'propertyXPathAndFilename' is not null or undefined
            assertParamExists('downloadUrlByIdAndXPath', 'propertyXPathAndFilename', propertyXPathAndFilename);
            const localVarPath = `/api/download/url/{docId}/{propertyXPathAndFilename}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)))
                .replace(`{${"propertyXPathAndFilename"}}`, encodeURIComponent(String(propertyXPathAndFilename)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (expiration !== undefined) {
                localVarQueryParameter['expiration'] = expiration;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * DownloadApi - functional programming interface
 * @export
 */
const DownloadApiFp = function (configuration) {
    const localVarAxiosParamCreator = DownloadApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the document blob.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {boolean} [inline] Inline content disposition enablement.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadByIdAndXPath(docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.downloadByIdAndXPath(docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the document blob information.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadInfoByIdAndXPath(docId, propertyXPathAndFilename, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.downloadInfoByIdAndXPath(docId, propertyXPathAndFilename, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the the pre-signed S3 Url for a downloadable object.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {number} [expiration] expiration value for generating the S3 pre-signed url in seconds.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadUrlByIdAndXPath(docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.downloadUrlByIdAndXPath(docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * DownloadApi - factory interface
 * @export
 */
const DownloadApiFactory = function (configuration, basePath, axios) {
    const localVarFp = DownloadApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the document blob.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {boolean} [inline] Inline content disposition enablement.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadByIdAndXPath(docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options) {
            return localVarFp.downloadByIdAndXPath(docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the document blob information.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadInfoByIdAndXPath(docId, propertyXPathAndFilename, hXCSREPOSITORY, options) {
            return localVarFp.downloadInfoByIdAndXPath(docId, propertyXPathAndFilename, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the the pre-signed S3 Url for a downloadable object.
         * @param {string} docId The document id.
         * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
         * @param {number} [expiration] expiration value for generating the S3 pre-signed url in seconds.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        downloadUrlByIdAndXPath(docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options) {
            return localVarFp.downloadUrlByIdAndXPath(docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * DownloadApi - object-oriented interface
 * @export
 * @class DownloadApi
 * @extends {BaseAPI}
 */
class DownloadApi extends BaseAPI {
    /**
     *
     * @summary Returns the document blob.
     * @param {string} docId The document id.
     * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
     * @param {boolean} [inline] Inline content disposition enablement.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DownloadApi
     */
    downloadByIdAndXPath(docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options) {
        return DownloadApiFp(this.configuration).downloadByIdAndXPath(docId, propertyXPathAndFilename, inline, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the document blob information.
     * @param {string} docId The document id.
     * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DownloadApi
     */
    downloadInfoByIdAndXPath(docId, propertyXPathAndFilename, hXCSREPOSITORY, options) {
        return DownloadApiFp(this.configuration).downloadInfoByIdAndXPath(docId, propertyXPathAndFilename, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the the pre-signed S3 Url for a downloadable object.
     * @param {string} docId The document id.
     * @param {string} propertyXPathAndFilename The xpath to the property holding the blob and the filename.
     * @param {number} [expiration] expiration value for generating the S3 pre-signed url in seconds.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof DownloadApi
     */
    downloadUrlByIdAndXPath(docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options) {
        return DownloadApiFp(this.configuration).downloadUrlByIdAndXPath(docId, propertyXPathAndFilename, expiration, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * FeatureFlagsApi - axios parameter creator
 * @export
 */
const FeatureFlagsApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the feature flag with the given key.
         * @param {string} key The feature flag key.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getFeatureFlagByKey: (key_1, ...args_1) => __awaiter(this, [key_1, ...args_1], void 0, function* (key, options = {}) {
            // verify required parameter 'key' is not null or undefined
            assertParamExists('getFeatureFlagByKey', 'key', key);
            const localVarPath = `/api/feature-flags/{key}`
                .replace(`{${"key"}}`, encodeURIComponent(String(key)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * FeatureFlagsApi - functional programming interface
 * @export
 */
const FeatureFlagsApiFp = function (configuration) {
    const localVarAxiosParamCreator = FeatureFlagsApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the feature flag with the given key.
         * @param {string} key The feature flag key.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getFeatureFlagByKey(key, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getFeatureFlagByKey(key, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * FeatureFlagsApi - factory interface
 * @export
 */
const FeatureFlagsApiFactory = function (configuration, basePath, axios) {
    const localVarFp = FeatureFlagsApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the feature flag with the given key.
         * @param {string} key The feature flag key.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getFeatureFlagByKey(key, options) {
            return localVarFp.getFeatureFlagByKey(key, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * FeatureFlagsApi - object-oriented interface
 * @export
 * @class FeatureFlagsApi
 * @extends {BaseAPI}
 */
class FeatureFlagsApi extends BaseAPI {
    /**
     *
     * @summary Returns the feature flag with the given key.
     * @param {string} key The feature flag key.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof FeatureFlagsApi
     */
    getFeatureFlagByKey(key, options) {
        return FeatureFlagsApiFp(this.configuration).getFeatureFlagByKey(key, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * GreetingApi - axios parameter creator
 * @export
 */
const GreetingApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        hello: (...args_1) => __awaiter(this, [...args_1], void 0, function* (options = {}) {
            const localVarPath = `/hello`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        helloUser: (...args_1) => __awaiter(this, [...args_1], void 0, function* (options = {}) {
            const localVarPath = `/hello/protected`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * GreetingApi - functional programming interface
 * @export
 */
const GreetingApiFp = function (configuration) {
    const localVarAxiosParamCreator = GreetingApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        hello(options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.hello(options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        helloUser(options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.helloUser(options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * GreetingApi - factory interface
 * @export
 */
const GreetingApiFactory = function (configuration, basePath, axios) {
    const localVarFp = GreetingApiFp(configuration);
    return {
        /**
         *
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        hello(options) {
            return localVarFp.hello(options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        helloUser(options) {
            return localVarFp.helloUser(options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * GreetingApi - object-oriented interface
 * @export
 * @class GreetingApi
 * @extends {BaseAPI}
 */
class GreetingApi extends BaseAPI {
    /**
     *
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof GreetingApi
     */
    hello(options) {
        return GreetingApiFp(this.configuration).hello(options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof GreetingApi
     */
    helloUser(options) {
        return GreetingApiFp(this.configuration).helloUser(options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * GroupApi - axios parameter creator
 * @export
 */
const GroupApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the group with given id.
         * @param {string} groupId The group id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getGroupById: (groupId_1, ...args_1) => __awaiter(this, [groupId_1, ...args_1], void 0, function* (groupId, options = {}) {
            // verify required parameter 'groupId' is not null or undefined
            assertParamExists('getGroupById', 'groupId', groupId);
            const localVarPath = `/api/group/{groupId}`
                .replace(`{${"groupId"}}`, encodeURIComponent(String(groupId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the list of groups which name or label contains the given string
         * @param {string} name Part of the group name or label
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        searchGroups: (name_1, ...args_1) => __awaiter(this, [name_1, ...args_1], void 0, function* (name, options = {}) {
            // verify required parameter 'name' is not null or undefined
            assertParamExists('searchGroups', 'name', name);
            const localVarPath = `/api/group`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (name !== undefined) {
                localVarQueryParameter['name'] = name;
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * GroupApi - functional programming interface
 * @export
 */
const GroupApiFp = function (configuration) {
    const localVarAxiosParamCreator = GroupApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the group with given id.
         * @param {string} groupId The group id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getGroupById(groupId, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getGroupById(groupId, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the list of groups which name or label contains the given string
         * @param {string} name Part of the group name or label
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        searchGroups(name, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.searchGroups(name, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * GroupApi - factory interface
 * @export
 */
const GroupApiFactory = function (configuration, basePath, axios) {
    const localVarFp = GroupApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the group with given id.
         * @param {string} groupId The group id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getGroupById(groupId, options) {
            return localVarFp.getGroupById(groupId, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the list of groups which name or label contains the given string
         * @param {string} name Part of the group name or label
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        searchGroups(name, options) {
            return localVarFp.searchGroups(name, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * GroupApi - object-oriented interface
 * @export
 * @class GroupApi
 * @extends {BaseAPI}
 */
class GroupApi extends BaseAPI {
    /**
     *
     * @summary Returns the group with given id.
     * @param {string} groupId The group id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof GroupApi
     */
    getGroupById(groupId, options) {
        return GroupApiFp(this.configuration).getGroupById(groupId, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the list of groups which name or label contains the given string
     * @param {string} name Part of the group name or label
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof GroupApi
     */
    searchGroups(name, options) {
        return GroupApiFp(this.configuration).searchGroups(name, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * ModelApi - axios parameter creator
 * @export
 */
const ModelApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the model for the repository.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getModel: (hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [hXCSREPOSITORY_1, ...args_1], void 0, function* (hXCSREPOSITORY, options = {}) {
            const localVarPath = `/api/repository/model`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Patches the model for the repository.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchModel: (validateOnly_1, hXCSREPOSITORY_1, body_1, ...args_1) => __awaiter(this, [validateOnly_1, hXCSREPOSITORY_1, body_1, ...args_1], void 0, function* (validateOnly, hXCSREPOSITORY, body, options = {}) {
            const localVarPath = `/api/repository/model`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PATCH' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json-patch+json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(body, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Sets the model for the repository.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Model} [model]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setModel: (validateOnly_1, hXCSREPOSITORY_1, model_1, ...args_1) => __awaiter(this, [validateOnly_1, hXCSREPOSITORY_1, model_1, ...args_1], void 0, function* (validateOnly, hXCSREPOSITORY, model, options = {}) {
            const localVarPath = `/api/repository/model`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(model, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Sets the model items specific to projects in the existing content model for the repository.
         * @param {string} projectId
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Model} [model]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setModelItemsForProject: (projectId_1, validateOnly_1, hXCSREPOSITORY_1, model_1, ...args_1) => __awaiter(this, [projectId_1, validateOnly_1, hXCSREPOSITORY_1, model_1, ...args_1], void 0, function* (projectId, validateOnly, hXCSREPOSITORY, model, options = {}) {
            // verify required parameter 'projectId' is not null or undefined
            assertParamExists('setModelItemsForProject', 'projectId', projectId);
            const localVarPath = `/api/repository/model/project/{projectId}`
                .replace(`{${"projectId"}}`, encodeURIComponent(String(projectId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(model, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * ModelApi - functional programming interface
 * @export
 */
const ModelApiFp = function (configuration) {
    const localVarAxiosParamCreator = ModelApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the model for the repository.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getModel(hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getModel(hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Patches the model for the repository.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchModel(validateOnly, hXCSREPOSITORY, body, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.patchModel(validateOnly, hXCSREPOSITORY, body, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Sets the model for the repository.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Model} [model]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setModel(validateOnly, hXCSREPOSITORY, model, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.setModel(validateOnly, hXCSREPOSITORY, model, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Sets the model items specific to projects in the existing content model for the repository.
         * @param {string} projectId
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Model} [model]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setModelItemsForProject(projectId, validateOnly, hXCSREPOSITORY, model, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.setModelItemsForProject(projectId, validateOnly, hXCSREPOSITORY, model, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * ModelApi - factory interface
 * @export
 */
const ModelApiFactory = function (configuration, basePath, axios) {
    const localVarFp = ModelApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the model for the repository.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getModel(hXCSREPOSITORY, options) {
            return localVarFp.getModel(hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Patches the model for the repository.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchModel(validateOnly, hXCSREPOSITORY, body, options) {
            return localVarFp.patchModel(validateOnly, hXCSREPOSITORY, body, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Sets the model for the repository.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Model} [model]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setModel(validateOnly, hXCSREPOSITORY, model, options) {
            return localVarFp.setModel(validateOnly, hXCSREPOSITORY, model, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Sets the model items specific to projects in the existing content model for the repository.
         * @param {string} projectId
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Model} [model]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setModelItemsForProject(projectId, validateOnly, hXCSREPOSITORY, model, options) {
            return localVarFp.setModelItemsForProject(projectId, validateOnly, hXCSREPOSITORY, model, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * ModelApi - object-oriented interface
 * @export
 * @class ModelApi
 * @extends {BaseAPI}
 */
class ModelApi extends BaseAPI {
    /**
     *
     * @summary Returns the model for the repository.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof ModelApi
     */
    getModel(hXCSREPOSITORY, options) {
        return ModelApiFp(this.configuration).getModel(hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Patches the model for the repository.
     * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {object} [body]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof ModelApi
     */
    patchModel(validateOnly, hXCSREPOSITORY, body, options) {
        return ModelApiFp(this.configuration).patchModel(validateOnly, hXCSREPOSITORY, body, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Sets the model for the repository.
     * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {Model} [model]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof ModelApi
     */
    setModel(validateOnly, hXCSREPOSITORY, model, options) {
        return ModelApiFp(this.configuration).setModel(validateOnly, hXCSREPOSITORY, model, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Sets the model items specific to projects in the existing content model for the repository.
     * @param {string} projectId
     * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {Model} [model]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof ModelApi
     */
    setModelItemsForProject(projectId, validateOnly, hXCSREPOSITORY, model, options) {
        return ModelApiFp(this.configuration).setModelItemsForProject(projectId, validateOnly, hXCSREPOSITORY, model, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * MoveApi - axios parameter creator
 * @export
 */
const MoveApiAxiosParamCreator = function (configuration) {
    return {
        /**
         * Move a given document to a given destination. Requires a request body with targetParentId.
         * @summary Moves the source document to the provided destination
         * @param {string} docId The document id to be moved.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {MoveCommand} [moveCommand]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        move: (docId_1, hXCSREPOSITORY_1, moveCommand_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, moveCommand_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, moveCommand, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('move', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/move`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(moveCommand, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * MoveApi - functional programming interface
 * @export
 */
const MoveApiFp = function (configuration) {
    const localVarAxiosParamCreator = MoveApiAxiosParamCreator(configuration);
    return {
        /**
         * Move a given document to a given destination. Requires a request body with targetParentId.
         * @summary Moves the source document to the provided destination
         * @param {string} docId The document id to be moved.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {MoveCommand} [moveCommand]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        move(docId, hXCSREPOSITORY, moveCommand, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.move(docId, hXCSREPOSITORY, moveCommand, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * MoveApi - factory interface
 * @export
 */
const MoveApiFactory = function (configuration, basePath, axios) {
    const localVarFp = MoveApiFp(configuration);
    return {
        /**
         * Move a given document to a given destination. Requires a request body with targetParentId.
         * @summary Moves the source document to the provided destination
         * @param {string} docId The document id to be moved.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {MoveCommand} [moveCommand]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        move(docId, hXCSREPOSITORY, moveCommand, options) {
            return localVarFp.move(docId, hXCSREPOSITORY, moveCommand, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * MoveApi - object-oriented interface
 * @export
 * @class MoveApi
 * @extends {BaseAPI}
 */
class MoveApi extends BaseAPI {
    /**
     * Move a given document to a given destination. Requires a request body with targetParentId.
     * @summary Moves the source document to the provided destination
     * @param {string} docId The document id to be moved.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {MoveCommand} [moveCommand]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof MoveApi
     */
    move(docId, hXCSREPOSITORY, moveCommand, options) {
        return MoveApiFp(this.configuration).move(docId, hXCSREPOSITORY, moveCommand, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * QueryApi - axios parameter creator
 * @export
 */
const QueryApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the advanced search results.
         * @param {AdvancedQuery} [advancedQuery]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByAdvancedQuery: (advancedQuery_1, ...args_1) => __awaiter(this, [advancedQuery_1, ...args_1], void 0, function* (advancedQuery, options = {}) {
            const localVarPath = `/api/query/advanced`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(advancedQuery, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the search results for given named query.
         * @param {NamedQuery} [namedQuery]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByNamedQuery: (namedQuery_1, ...args_1) => __awaiter(this, [namedQuery_1, ...args_1], void 0, function* (namedQuery, options = {}) {
            const localVarPath = `/api/query/named`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(namedQuery, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the search results.
         * @param {Query} [query]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByQuery: (query_1, ...args_1) => __awaiter(this, [query_1, ...args_1], void 0, function* (query, options = {}) {
            const localVarPath = `/api/query`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(query, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the named query definition names.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getNamedQueries: (...args_1) => __awaiter(this, [...args_1], void 0, function* (options = {}) {
            const localVarPath = `/api/query/named`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the named query definition.
         * @param {string} namedQuery The named query id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getNamedQuery: (namedQuery_1, ...args_1) => __awaiter(this, [namedQuery_1, ...args_1], void 0, function* (namedQuery, options = {}) {
            // verify required parameter 'namedQuery' is not null or undefined
            assertParamExists('getNamedQuery', 'namedQuery', namedQuery);
            const localVarPath = `/api/query/named/{namedQuery}`
                .replace(`{${"namedQuery"}}`, encodeURIComponent(String(namedQuery)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Waits for for full text search indexing.
         * @param {boolean} [refresh] Refresh status.
         * @param {number} [timeout] The timeout (in seconds).
         * @param {boolean} [waitForAudit] Wait for audit.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        waitForFullTextSearchIndexing: (refresh_1, timeout_1, waitForAudit_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [refresh_1, timeout_1, waitForAudit_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (refresh, timeout, waitForAudit, hXCSREPOSITORY, options = {}) {
            const localVarPath = `/api/query/waitForFullTextSearchIndexing`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (refresh !== undefined) {
                localVarQueryParameter['refresh'] = refresh;
            }
            if (timeout !== undefined) {
                localVarQueryParameter['timeout'] = timeout;
            }
            if (waitForAudit !== undefined) {
                localVarQueryParameter['waitForAudit'] = waitForAudit;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * QueryApi - functional programming interface
 * @export
 */
const QueryApiFp = function (configuration) {
    const localVarAxiosParamCreator = QueryApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the advanced search results.
         * @param {AdvancedQuery} [advancedQuery]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByAdvancedQuery(advancedQuery, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getDocumentsByAdvancedQuery(advancedQuery, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the search results for given named query.
         * @param {NamedQuery} [namedQuery]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByNamedQuery(namedQuery, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getDocumentsByNamedQuery(namedQuery, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the search results.
         * @param {Query} [query]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByQuery(query, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getDocumentsByQuery(query, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the named query definition names.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getNamedQueries(options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getNamedQueries(options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the named query definition.
         * @param {string} namedQuery The named query id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getNamedQuery(namedQuery, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getNamedQuery(namedQuery, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Waits for for full text search indexing.
         * @param {boolean} [refresh] Refresh status.
         * @param {number} [timeout] The timeout (in seconds).
         * @param {boolean} [waitForAudit] Wait for audit.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        waitForFullTextSearchIndexing(refresh, timeout, waitForAudit, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.waitForFullTextSearchIndexing(refresh, timeout, waitForAudit, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * QueryApi - factory interface
 * @export
 */
const QueryApiFactory = function (configuration, basePath, axios) {
    const localVarFp = QueryApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the advanced search results.
         * @param {AdvancedQuery} [advancedQuery]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByAdvancedQuery(advancedQuery, options) {
            return localVarFp.getDocumentsByAdvancedQuery(advancedQuery, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the search results for given named query.
         * @param {NamedQuery} [namedQuery]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByNamedQuery(namedQuery, options) {
            return localVarFp.getDocumentsByNamedQuery(namedQuery, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the search results.
         * @param {Query} [query]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getDocumentsByQuery(query, options) {
            return localVarFp.getDocumentsByQuery(query, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the named query definition names.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getNamedQueries(options) {
            return localVarFp.getNamedQueries(options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the named query definition.
         * @param {string} namedQuery The named query id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getNamedQuery(namedQuery, options) {
            return localVarFp.getNamedQuery(namedQuery, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Waits for for full text search indexing.
         * @param {boolean} [refresh] Refresh status.
         * @param {number} [timeout] The timeout (in seconds).
         * @param {boolean} [waitForAudit] Wait for audit.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        waitForFullTextSearchIndexing(refresh, timeout, waitForAudit, hXCSREPOSITORY, options) {
            return localVarFp.waitForFullTextSearchIndexing(refresh, timeout, waitForAudit, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * QueryApi - object-oriented interface
 * @export
 * @class QueryApi
 * @extends {BaseAPI}
 */
class QueryApi extends BaseAPI {
    /**
     *
     * @summary Returns the advanced search results.
     * @param {AdvancedQuery} [advancedQuery]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof QueryApi
     */
    getDocumentsByAdvancedQuery(advancedQuery, options) {
        return QueryApiFp(this.configuration).getDocumentsByAdvancedQuery(advancedQuery, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the search results for given named query.
     * @param {NamedQuery} [namedQuery]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof QueryApi
     */
    getDocumentsByNamedQuery(namedQuery, options) {
        return QueryApiFp(this.configuration).getDocumentsByNamedQuery(namedQuery, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the search results.
     * @param {Query} [query]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof QueryApi
     */
    getDocumentsByQuery(query, options) {
        return QueryApiFp(this.configuration).getDocumentsByQuery(query, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the named query definition names.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof QueryApi
     */
    getNamedQueries(options) {
        return QueryApiFp(this.configuration).getNamedQueries(options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the named query definition.
     * @param {string} namedQuery The named query id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof QueryApi
     */
    getNamedQuery(namedQuery, options) {
        return QueryApiFp(this.configuration).getNamedQuery(namedQuery, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Waits for for full text search indexing.
     * @param {boolean} [refresh] Refresh status.
     * @param {number} [timeout] The timeout (in seconds).
     * @param {boolean} [waitForAudit] Wait for audit.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof QueryApi
     */
    waitForFullTextSearchIndexing(refresh, timeout, waitForAudit, hXCSREPOSITORY, options) {
        return QueryApiFp(this.configuration).waitForFullTextSearchIndexing(refresh, timeout, waitForAudit, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * RenditionConfigurationsApi - axios parameter creator
 * @export
 */
const RenditionConfigurationsApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Update the rendition configuration
         * @param {string} projectId The target document id.
         * @param {boolean} [validateOnly] Whether to just validate the model changes, without applying it.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {RenditionsConfig} [renditionsConfig]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        putRenditions: (projectId_1, validateOnly_1, hXCSREPOSITORY_1, renditionsConfig_1, ...args_1) => __awaiter(this, [projectId_1, validateOnly_1, hXCSREPOSITORY_1, renditionsConfig_1, ...args_1], void 0, function* (projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options = {}) {
            // verify required parameter 'projectId' is not null or undefined
            assertParamExists('putRenditions', 'projectId', projectId);
            const localVarPath = `/api/repository/renditions/project/{projectId}`
                .replace(`{${"projectId"}}`, encodeURIComponent(String(projectId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(renditionsConfig, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * RenditionConfigurationsApi - functional programming interface
 * @export
 */
const RenditionConfigurationsApiFp = function (configuration) {
    const localVarAxiosParamCreator = RenditionConfigurationsApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Update the rendition configuration
         * @param {string} projectId The target document id.
         * @param {boolean} [validateOnly] Whether to just validate the model changes, without applying it.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {RenditionsConfig} [renditionsConfig]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        putRenditions(projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.putRenditions(projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * RenditionConfigurationsApi - factory interface
 * @export
 */
const RenditionConfigurationsApiFactory = function (configuration, basePath, axios) {
    const localVarFp = RenditionConfigurationsApiFp(configuration);
    return {
        /**
         *
         * @summary Update the rendition configuration
         * @param {string} projectId The target document id.
         * @param {boolean} [validateOnly] Whether to just validate the model changes, without applying it.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {RenditionsConfig} [renditionsConfig]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        putRenditions(projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options) {
            return localVarFp.putRenditions(projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * RenditionConfigurationsApi - object-oriented interface
 * @export
 * @class RenditionConfigurationsApi
 * @extends {BaseAPI}
 */
class RenditionConfigurationsApi extends BaseAPI {
    /**
     *
     * @summary Update the rendition configuration
     * @param {string} projectId The target document id.
     * @param {boolean} [validateOnly] Whether to just validate the model changes, without applying it.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {RenditionsConfig} [renditionsConfig]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof RenditionConfigurationsApi
     */
    putRenditions(projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options) {
        return RenditionConfigurationsApiFp(this.configuration).putRenditions(projectId, validateOnly, hXCSREPOSITORY, renditionsConfig, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * RenditionsApi - axios parameter creator
 * @export
 */
const RenditionsApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Create a new rendition for the given document.
         * @param {string} docId The target document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Rendition} [rendition]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createRendition: (docId_1, hXCSREPOSITORY_1, rendition_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, rendition_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, rendition, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('createRendition', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/renditions`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(rendition, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Get a rendition for the given document.
         * @param {string} docId The target document id.
         * @param {string} renditionId The target rendition id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getRendition: (docId_1, renditionId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, renditionId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, renditionId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('getRendition', 'docId', docId);
            // verify required parameter 'renditionId' is not null or undefined
            assertParamExists('getRendition', 'renditionId', renditionId);
            const localVarPath = `/api/documents/{docId}/renditions/{renditionId}`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)))
                .replace(`{${"renditionId"}}`, encodeURIComponent(String(renditionId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Get all renditions for the given document.
         * @param {string} docId The target document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getRenditions: (docId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [docId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (docId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'docId' is not null or undefined
            assertParamExists('getRenditions', 'docId', docId);
            const localVarPath = `/api/documents/{docId}/renditions`
                .replace(`{${"docId"}}`, encodeURIComponent(String(docId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * RenditionsApi - functional programming interface
 * @export
 */
const RenditionsApiFp = function (configuration) {
    const localVarAxiosParamCreator = RenditionsApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Create a new rendition for the given document.
         * @param {string} docId The target document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Rendition} [rendition]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createRendition(docId, hXCSREPOSITORY, rendition, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.createRendition(docId, hXCSREPOSITORY, rendition, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Get a rendition for the given document.
         * @param {string} docId The target document id.
         * @param {string} renditionId The target rendition id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getRendition(docId, renditionId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getRendition(docId, renditionId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Get all renditions for the given document.
         * @param {string} docId The target document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getRenditions(docId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getRenditions(docId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * RenditionsApi - factory interface
 * @export
 */
const RenditionsApiFactory = function (configuration, basePath, axios) {
    const localVarFp = RenditionsApiFp(configuration);
    return {
        /**
         *
         * @summary Create a new rendition for the given document.
         * @param {string} docId The target document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Rendition} [rendition]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createRendition(docId, hXCSREPOSITORY, rendition, options) {
            return localVarFp.createRendition(docId, hXCSREPOSITORY, rendition, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Get a rendition for the given document.
         * @param {string} docId The target document id.
         * @param {string} renditionId The target rendition id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getRendition(docId, renditionId, hXCSREPOSITORY, options) {
            return localVarFp.getRendition(docId, renditionId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Get all renditions for the given document.
         * @param {string} docId The target document id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getRenditions(docId, hXCSREPOSITORY, options) {
            return localVarFp.getRenditions(docId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * RenditionsApi - object-oriented interface
 * @export
 * @class RenditionsApi
 * @extends {BaseAPI}
 */
class RenditionsApi extends BaseAPI {
    /**
     *
     * @summary Create a new rendition for the given document.
     * @param {string} docId The target document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {Rendition} [rendition]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof RenditionsApi
     */
    createRendition(docId, hXCSREPOSITORY, rendition, options) {
        return RenditionsApiFp(this.configuration).createRendition(docId, hXCSREPOSITORY, rendition, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Get a rendition for the given document.
     * @param {string} docId The target document id.
     * @param {string} renditionId The target rendition id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof RenditionsApi
     */
    getRendition(docId, renditionId, hXCSREPOSITORY, options) {
        return RenditionsApiFp(this.configuration).getRendition(docId, renditionId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Get all renditions for the given document.
     * @param {string} docId The target document id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof RenditionsApi
     */
    getRenditions(docId, hXCSREPOSITORY, options) {
        return RenditionsApiFp(this.configuration).getRenditions(docId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * SecurityApi - axios parameter creator
 * @export
 */
const SecurityApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getExternalUserRelations: (policyName_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [policyName_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (policyName, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'policyName' is not null or undefined
            assertParamExists('getExternalUserRelations', 'policyName', policyName);
            const localVarPath = `/api/repository/security/policies/{policyName}/externaluserrelations`
                .replace(`{${"policyName"}}`, encodeURIComponent(String(policyName)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the status of the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getExternalUserRelationsStatus: (policyName_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [policyName_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (policyName, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'policyName' is not null or undefined
            assertParamExists('getExternalUserRelationsStatus', 'policyName', policyName);
            const localVarPath = `/api/repository/security/policies/{policyName}/externaluserrelations/status`
                .replace(`{${"policyName"}}`, encodeURIComponent(String(policyName)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the security policies for the repository.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getSecurityPolicies: (hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [hXCSREPOSITORY_1, ...args_1], void 0, function* (hXCSREPOSITORY, options = {}) {
            const localVarPath = `/api/repository/security/policies`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Patches the security policies for the repository. Changes to or even tests on fixed security policies (such as acl, lock and retention) will result in an error.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchSecurityPolicies: (validateOnly_1, hXCSREPOSITORY_1, body_1, ...args_1) => __awaiter(this, [validateOnly_1, hXCSREPOSITORY_1, body_1, ...args_1], void 0, function* (validateOnly, hXCSREPOSITORY, body, options = {}) {
            const localVarPath = `/api/repository/security/policies`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PATCH' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json-patch+json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(body, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Sets the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: Array<{ [key: string]: object; }>; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setExternalUserRelations: (policyName_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [policyName_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (policyName, hXCSREPOSITORY, requestBody, options = {}) {
            // verify required parameter 'policyName' is not null or undefined
            assertParamExists('setExternalUserRelations', 'policyName', policyName);
            const localVarPath = `/api/repository/security/policies/{policyName}/externaluserrelations`
                .replace(`{${"policyName"}}`, encodeURIComponent(String(policyName)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Sets the security policies for the repository. Changes to fixed security policies (such as acl, lock and retention) will be ignored.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setSecurityPolicies: (validateOnly_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [validateOnly_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (validateOnly, hXCSREPOSITORY, requestBody, options = {}) {
            const localVarPath = `/api/repository/security/policies`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Sets security policies for a specific project. Any security policies in the request that have the same name as a system-wide security policy or one for another project or will be ignored. The projectId is automatically set in security policies in the request.
         * @param {string} projectId
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setSecurityPoliciesForProject: (projectId_1, validateOnly_1, hXCSREPOSITORY_1, requestBody_1, ...args_1) => __awaiter(this, [projectId_1, validateOnly_1, hXCSREPOSITORY_1, requestBody_1, ...args_1], void 0, function* (projectId, validateOnly, hXCSREPOSITORY, requestBody, options = {}) {
            // verify required parameter 'projectId' is not null or undefined
            assertParamExists('setSecurityPoliciesForProject', 'projectId', projectId);
            const localVarPath = `/api/repository/security/policies/project/{projectId}`
                .replace(`{${"projectId"}}`, encodeURIComponent(String(projectId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (validateOnly !== undefined) {
                localVarQueryParameter['validateOnly'] = validateOnly;
            }
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(requestBody, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * SecurityApi - functional programming interface
 * @export
 */
const SecurityApiFp = function (configuration) {
    const localVarAxiosParamCreator = SecurityApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getExternalUserRelations(policyName, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getExternalUserRelations(policyName, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the status of the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getExternalUserRelationsStatus(policyName, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getExternalUserRelationsStatus(policyName, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the security policies for the repository.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getSecurityPolicies(hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getSecurityPolicies(hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Patches the security policies for the repository. Changes to or even tests on fixed security policies (such as acl, lock and retention) will result in an error.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchSecurityPolicies(validateOnly, hXCSREPOSITORY, body, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.patchSecurityPolicies(validateOnly, hXCSREPOSITORY, body, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Sets the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: Array<{ [key: string]: object; }>; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setExternalUserRelations(policyName, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.setExternalUserRelations(policyName, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Sets the security policies for the repository. Changes to fixed security policies (such as acl, lock and retention) will be ignored.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setSecurityPolicies(validateOnly, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.setSecurityPolicies(validateOnly, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Sets security policies for a specific project. Any security policies in the request that have the same name as a system-wide security policy or one for another project or will be ignored. The projectId is automatically set in security policies in the request.
         * @param {string} projectId
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setSecurityPoliciesForProject(projectId, validateOnly, hXCSREPOSITORY, requestBody, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.setSecurityPoliciesForProject(projectId, validateOnly, hXCSREPOSITORY, requestBody, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * SecurityApi - factory interface
 * @export
 */
const SecurityApiFactory = function (configuration, basePath, axios) {
    const localVarFp = SecurityApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getExternalUserRelations(policyName, hXCSREPOSITORY, options) {
            return localVarFp.getExternalUserRelations(policyName, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the status of the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getExternalUserRelationsStatus(policyName, hXCSREPOSITORY, options) {
            return localVarFp.getExternalUserRelationsStatus(policyName, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the security policies for the repository.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getSecurityPolicies(hXCSREPOSITORY, options) {
            return localVarFp.getSecurityPolicies(hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Patches the security policies for the repository. Changes to or even tests on fixed security policies (such as acl, lock and retention) will result in an error.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {object} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        patchSecurityPolicies(validateOnly, hXCSREPOSITORY, body, options) {
            return localVarFp.patchSecurityPolicies(validateOnly, hXCSREPOSITORY, body, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Sets the external user relations for a policy.
         * @param {string} policyName The policy name.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: Array<{ [key: string]: object; }>; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setExternalUserRelations(policyName, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.setExternalUserRelations(policyName, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Sets the security policies for the repository. Changes to fixed security policies (such as acl, lock and retention) will be ignored.
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setSecurityPolicies(validateOnly, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.setSecurityPolicies(validateOnly, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Sets security policies for a specific project. Any security policies in the request that have the same name as a system-wide security policy or one for another project or will be ignored. The projectId is automatically set in security policies in the request.
         * @param {string} projectId
         * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        setSecurityPoliciesForProject(projectId, validateOnly, hXCSREPOSITORY, requestBody, options) {
            return localVarFp.setSecurityPoliciesForProject(projectId, validateOnly, hXCSREPOSITORY, requestBody, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * SecurityApi - object-oriented interface
 * @export
 * @class SecurityApi
 * @extends {BaseAPI}
 */
class SecurityApi extends BaseAPI {
    /**
     *
     * @summary Returns the external user relations for a policy.
     * @param {string} policyName The policy name.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    getExternalUserRelations(policyName, hXCSREPOSITORY, options) {
        return SecurityApiFp(this.configuration).getExternalUserRelations(policyName, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the status of the external user relations for a policy.
     * @param {string} policyName The policy name.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    getExternalUserRelationsStatus(policyName, hXCSREPOSITORY, options) {
        return SecurityApiFp(this.configuration).getExternalUserRelationsStatus(policyName, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the security policies for the repository.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    getSecurityPolicies(hXCSREPOSITORY, options) {
        return SecurityApiFp(this.configuration).getSecurityPolicies(hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Patches the security policies for the repository. Changes to or even tests on fixed security policies (such as acl, lock and retention) will result in an error.
     * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {object} [body]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    patchSecurityPolicies(validateOnly, hXCSREPOSITORY, body, options) {
        return SecurityApiFp(this.configuration).patchSecurityPolicies(validateOnly, hXCSREPOSITORY, body, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Sets the external user relations for a policy.
     * @param {string} policyName The policy name.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: Array<{ [key: string]: object; }>; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    setExternalUserRelations(policyName, hXCSREPOSITORY, requestBody, options) {
        return SecurityApiFp(this.configuration).setExternalUserRelations(policyName, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Sets the security policies for the repository. Changes to fixed security policies (such as acl, lock and retention) will be ignored.
     * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    setSecurityPolicies(validateOnly, hXCSREPOSITORY, requestBody, options) {
        return SecurityApiFp(this.configuration).setSecurityPolicies(validateOnly, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Sets security policies for a specific project. Any security policies in the request that have the same name as a system-wide security policy or one for another project or will be ignored. The projectId is automatically set in security policies in the request.
     * @param {string} projectId
     * @param {boolean} [validateOnly] Whether to just validate the changes, without applying them.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {{ [key: string]: SecurityPolicyConfig; }} [requestBody]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof SecurityApi
     */
    setSecurityPoliciesForProject(projectId, validateOnly, hXCSREPOSITORY, requestBody, options) {
        return SecurityApiFp(this.configuration).setSecurityPoliciesForProject(projectId, validateOnly, hXCSREPOSITORY, requestBody, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * UploadApi - axios parameter creator
 * @export
 */
const UploadApiAxiosParamCreator = function (configuration) {
    return {
        /**
         * Completion is mainly useful for s3 direct upload, where the upload has been created thanks to this API, but download has been done directly on the target s3 bucket.
         * @summary Completes the upload with the given id.
         * @param {string} id The upload id.
         * @param {UploadFileInfo} [uploadFileInfo]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        complete: (id_1, uploadFileInfo_1, ...args_1) => __awaiter(this, [id_1, uploadFileInfo_1, ...args_1], void 0, function* (id, uploadFileInfo, options = {}) {
            // verify required parameter 'id' is not null or undefined
            assertParamExists('complete', 'id', id);
            const localVarPath = `/api/upload/{id}/complete`
                .replace(`{${"id"}}`, encodeURIComponent(String(id)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(uploadFileInfo, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Creates a new upload and return its generated identifier and properties.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createUpload: (...args_1) => __awaiter(this, [...args_1], void 0, function* (options = {}) {
            const localVarPath = `/api/upload/create`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Cancels the upload with the given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteUpload: (id_1, ...args_1) => __awaiter(this, [id_1, ...args_1], void 0, function* (id, options = {}) {
            // verify required parameter 'id' is not null or undefined
            assertParamExists('deleteUpload', 'id', id);
            const localVarPath = `/api/upload/{id}`
                .replace(`{${"id"}}`, encodeURIComponent(String(id)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'DELETE' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the upload information for given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getUploadInfo: (id_1, ...args_1) => __awaiter(this, [id_1, ...args_1], void 0, function* (id, options = {}) {
            // verify required parameter 'id' is not null or undefined
            assertParamExists('getUploadInfo', 'id', id);
            const localVarPath = `/api/upload/{id}`
                .replace(`{${"id"}}`, encodeURIComponent(String(id)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Renews the credentials for the upload with the given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        renewCredentials: (id_1, ...args_1) => __awaiter(this, [id_1, ...args_1], void 0, function* (id, options = {}) {
            // verify required parameter 'id' is not null or undefined
            assertParamExists('renewCredentials', 'id', id);
            const localVarPath = `/api/upload/{id}/renewCredentials`
                .replace(`{${"id"}}`, encodeURIComponent(String(id)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         * Upload can be done in several parts, chunk by chunk.
         * @summary Uploads a file or a chunk to a given upload.
         * @param {number} [chunkCount] The total number of chunks.
         * @param {number} [chunkIndex] This chunk index, starting at 0..
         * @param {boolean} [chunked] Indicates that the upload is chunked.
         * @param {string} [encoding] The file encoding (for text files).
         * @param {string} [fileName] The file name.
         * @param {string} [id] The upload id. A new upload is created if null.
         * @param {string} [mimeType] The file mimetype.
         * @param {any} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        upload: (chunkCount_1, chunkIndex_1, chunked_1, encoding_1, fileName_1, id_1, mimeType_1, body_1, ...args_1) => __awaiter(this, [chunkCount_1, chunkIndex_1, chunked_1, encoding_1, fileName_1, id_1, mimeType_1, body_1, ...args_1], void 0, function* (chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options = {}) {
            const localVarPath = `/api/upload`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (chunkCount !== undefined) {
                localVarQueryParameter['chunkCount'] = chunkCount;
            }
            if (chunkIndex !== undefined) {
                localVarQueryParameter['chunkIndex'] = chunkIndex;
            }
            if (chunked !== undefined) {
                localVarQueryParameter['chunked'] = chunked;
            }
            if (encoding !== undefined) {
                localVarQueryParameter['encoding'] = encoding;
            }
            if (fileName !== undefined) {
                localVarQueryParameter['fileName'] = fileName;
            }
            if (id !== undefined) {
                localVarQueryParameter['id'] = id;
            }
            if (mimeType !== undefined) {
                localVarQueryParameter['mimeType'] = mimeType;
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(body, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * UploadApi - functional programming interface
 * @export
 */
const UploadApiFp = function (configuration) {
    const localVarAxiosParamCreator = UploadApiAxiosParamCreator(configuration);
    return {
        /**
         * Completion is mainly useful for s3 direct upload, where the upload has been created thanks to this API, but download has been done directly on the target s3 bucket.
         * @summary Completes the upload with the given id.
         * @param {string} id The upload id.
         * @param {UploadFileInfo} [uploadFileInfo]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        complete(id, uploadFileInfo, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.complete(id, uploadFileInfo, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Creates a new upload and return its generated identifier and properties.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createUpload(options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.createUpload(options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Cancels the upload with the given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteUpload(id, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.deleteUpload(id, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the upload information for given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getUploadInfo(id, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getUploadInfo(id, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Renews the credentials for the upload with the given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        renewCredentials(id, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.renewCredentials(id, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         * Upload can be done in several parts, chunk by chunk.
         * @summary Uploads a file or a chunk to a given upload.
         * @param {number} [chunkCount] The total number of chunks.
         * @param {number} [chunkIndex] This chunk index, starting at 0..
         * @param {boolean} [chunked] Indicates that the upload is chunked.
         * @param {string} [encoding] The file encoding (for text files).
         * @param {string} [fileName] The file name.
         * @param {string} [id] The upload id. A new upload is created if null.
         * @param {string} [mimeType] The file mimetype.
         * @param {any} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        upload(chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.upload(chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * UploadApi - factory interface
 * @export
 */
const UploadApiFactory = function (configuration, basePath, axios) {
    const localVarFp = UploadApiFp(configuration);
    return {
        /**
         * Completion is mainly useful for s3 direct upload, where the upload has been created thanks to this API, but download has been done directly on the target s3 bucket.
         * @summary Completes the upload with the given id.
         * @param {string} id The upload id.
         * @param {UploadFileInfo} [uploadFileInfo]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        complete(id, uploadFileInfo, options) {
            return localVarFp.complete(id, uploadFileInfo, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Creates a new upload and return its generated identifier and properties.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createUpload(options) {
            return localVarFp.createUpload(options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Cancels the upload with the given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteUpload(id, options) {
            return localVarFp.deleteUpload(id, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the upload information for given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getUploadInfo(id, options) {
            return localVarFp.getUploadInfo(id, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Renews the credentials for the upload with the given id.
         * @param {string} id The upload id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        renewCredentials(id, options) {
            return localVarFp.renewCredentials(id, options).then((request) => request(axios, basePath));
        },
        /**
         * Upload can be done in several parts, chunk by chunk.
         * @summary Uploads a file or a chunk to a given upload.
         * @param {number} [chunkCount] The total number of chunks.
         * @param {number} [chunkIndex] This chunk index, starting at 0..
         * @param {boolean} [chunked] Indicates that the upload is chunked.
         * @param {string} [encoding] The file encoding (for text files).
         * @param {string} [fileName] The file name.
         * @param {string} [id] The upload id. A new upload is created if null.
         * @param {string} [mimeType] The file mimetype.
         * @param {any} [body]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        upload(chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options) {
            return localVarFp.upload(chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * UploadApi - object-oriented interface
 * @export
 * @class UploadApi
 * @extends {BaseAPI}
 */
class UploadApi extends BaseAPI {
    /**
     * Completion is mainly useful for s3 direct upload, where the upload has been created thanks to this API, but download has been done directly on the target s3 bucket.
     * @summary Completes the upload with the given id.
     * @param {string} id The upload id.
     * @param {UploadFileInfo} [uploadFileInfo]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UploadApi
     */
    complete(id, uploadFileInfo, options) {
        return UploadApiFp(this.configuration).complete(id, uploadFileInfo, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Creates a new upload and return its generated identifier and properties.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UploadApi
     */
    createUpload(options) {
        return UploadApiFp(this.configuration).createUpload(options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Cancels the upload with the given id.
     * @param {string} id The upload id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UploadApi
     */
    deleteUpload(id, options) {
        return UploadApiFp(this.configuration).deleteUpload(id, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the upload information for given id.
     * @param {string} id The upload id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UploadApi
     */
    getUploadInfo(id, options) {
        return UploadApiFp(this.configuration).getUploadInfo(id, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Renews the credentials for the upload with the given id.
     * @param {string} id The upload id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UploadApi
     */
    renewCredentials(id, options) {
        return UploadApiFp(this.configuration).renewCredentials(id, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     * Upload can be done in several parts, chunk by chunk.
     * @summary Uploads a file or a chunk to a given upload.
     * @param {number} [chunkCount] The total number of chunks.
     * @param {number} [chunkIndex] This chunk index, starting at 0..
     * @param {boolean} [chunked] Indicates that the upload is chunked.
     * @param {string} [encoding] The file encoding (for text files).
     * @param {string} [fileName] The file name.
     * @param {string} [id] The upload id. A new upload is created if null.
     * @param {string} [mimeType] The file mimetype.
     * @param {any} [body]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UploadApi
     */
    upload(chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options) {
        return UploadApiFp(this.configuration).upload(chunkCount, chunkIndex, chunked, encoding, fileName, id, mimeType, body, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * UserApi - axios parameter creator
 * @export
 */
const UserApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Returns the user with given id.
         * @param {string} userId The user id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getUserById: (userId_1, ...args_1) => __awaiter(this, [userId_1, ...args_1], void 0, function* (userId, options = {}) {
            // verify required parameter 'userId' is not null or undefined
            assertParamExists('getUserById', 'userId', userId);
            const localVarPath = `/api/user/{userId}`
                .replace(`{${"userId"}}`, encodeURIComponent(String(userId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns the list of users which first name or last name contains the given string
         * @param {string} name Part of the user name
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        searchUsersByName: (name_1, ...args_1) => __awaiter(this, [name_1, ...args_1], void 0, function* (name, options = {}) {
            // verify required parameter 'name' is not null or undefined
            assertParamExists('searchUsersByName', 'name', name);
            const localVarPath = `/api/user`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (name !== undefined) {
                localVarQueryParameter['name'] = name;
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * UserApi - functional programming interface
 * @export
 */
const UserApiFp = function (configuration) {
    const localVarAxiosParamCreator = UserApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Returns the user with given id.
         * @param {string} userId The user id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getUserById(userId, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getUserById(userId, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns the list of users which first name or last name contains the given string
         * @param {string} name Part of the user name
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        searchUsersByName(name, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.searchUsersByName(name, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * UserApi - factory interface
 * @export
 */
const UserApiFactory = function (configuration, basePath, axios) {
    const localVarFp = UserApiFp(configuration);
    return {
        /**
         *
         * @summary Returns the user with given id.
         * @param {string} userId The user id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getUserById(userId, options) {
            return localVarFp.getUserById(userId, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns the list of users which first name or last name contains the given string
         * @param {string} name Part of the user name
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        searchUsersByName(name, options) {
            return localVarFp.searchUsersByName(name, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * UserApi - object-oriented interface
 * @export
 * @class UserApi
 * @extends {BaseAPI}
 */
class UserApi extends BaseAPI {
    /**
     *
     * @summary Returns the user with given id.
     * @param {string} userId The user id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UserApi
     */
    getUserById(userId, options) {
        return UserApiFp(this.configuration).getUserById(userId, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns the list of users which first name or last name contains the given string
     * @param {string} name Part of the user name
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof UserApi
     */
    searchUsersByName(name, options) {
        return UserApiFp(this.configuration).searchUsersByName(name, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * VersionApi - axios parameter creator
 * @export
 */
const VersionApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Restore a document from given version
         * @param {string} versionId The id of the version to be restored
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        restoreVersion: (versionId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [versionId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (versionId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'versionId' is not null or undefined
            assertParamExists('restoreVersion', 'versionId', versionId);
            const localVarPath = `/api/documents/{versionId}/restore`
                .replace(`{${"versionId"}}`, encodeURIComponent(String(versionId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * VersionApi - functional programming interface
 * @export
 */
const VersionApiFp = function (configuration) {
    const localVarAxiosParamCreator = VersionApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Restore a document from given version
         * @param {string} versionId The id of the version to be restored
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        restoreVersion(versionId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.restoreVersion(versionId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * VersionApi - factory interface
 * @export
 */
const VersionApiFactory = function (configuration, basePath, axios) {
    const localVarFp = VersionApiFp(configuration);
    return {
        /**
         *
         * @summary Restore a document from given version
         * @param {string} versionId The id of the version to be restored
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        restoreVersion(versionId, hXCSREPOSITORY, options) {
            return localVarFp.restoreVersion(versionId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * VersionApi - object-oriented interface
 * @export
 * @class VersionApi
 * @extends {BaseAPI}
 */
class VersionApi extends BaseAPI {
    /**
     *
     * @summary Restore a document from given version
     * @param {string} versionId The id of the version to be restored
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VersionApi
     */
    restoreVersion(versionId, hXCSREPOSITORY, options) {
        return VersionApiFp(this.configuration).restoreVersion(versionId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
}
/**
 * VocabularyApi - axios parameter creator
 * @export
 */
const VocabularyApiAxiosParamCreator = function (configuration) {
    return {
        /**
         *
         * @summary Creates a vocabulary
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Vocabulary} [vocabulary]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createVocabulary: (hXCSREPOSITORY_1, vocabulary_1, ...args_1) => __awaiter(this, [hXCSREPOSITORY_1, vocabulary_1, ...args_1], void 0, function* (hXCSREPOSITORY, vocabulary, options = {}) {
            const localVarPath = `/api/vocabularies`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(vocabulary, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Creates an entry for vocabulary
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createVocabularyEntry: (sysvocabId_1, hXCSREPOSITORY_1, vocabularyEntryRequest_1, ...args_1) => __awaiter(this, [sysvocabId_1, hXCSREPOSITORY_1, vocabularyEntryRequest_1, ...args_1], void 0, function* (sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options = {}) {
            // verify required parameter 'sysvocabId' is not null or undefined
            assertParamExists('createVocabularyEntry', 'sysvocabId', sysvocabId);
            const localVarPath = `/api/vocabularies/{sysvocab_id}`
                .replace(`{${"sysvocab_id"}}`, encodeURIComponent(String(sysvocabId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'POST' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(vocabularyEntryRequest, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Deletes vocabulary along with its entries
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteVocabulary: (sysvocabId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [sysvocabId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (sysvocabId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'sysvocabId' is not null or undefined
            assertParamExists('deleteVocabulary', 'sysvocabId', sysvocabId);
            const localVarPath = `/api/vocabularies/{sysvocab_id}`
                .replace(`{${"sysvocab_id"}}`, encodeURIComponent(String(sysvocabId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'DELETE' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Deletes entry of a vocabulary
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} sysvocabKey The vocabulary key.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteVocabularyEntry: (sysvocabId_1, sysvocabKey_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [sysvocabId_1, sysvocabKey_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (sysvocabId, sysvocabKey, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'sysvocabId' is not null or undefined
            assertParamExists('deleteVocabularyEntry', 'sysvocabId', sysvocabId);
            // verify required parameter 'sysvocabKey' is not null or undefined
            assertParamExists('deleteVocabularyEntry', 'sysvocabKey', sysvocabKey);
            const localVarPath = `/api/vocabularies/{sysvocab_id}/{sysvocab_key}`
                .replace(`{${"sysvocab_id"}}`, encodeURIComponent(String(sysvocabId)))
                .replace(`{${"sysvocab_key"}}`, encodeURIComponent(String(sysvocabKey)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'DELETE' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns a list of all vocabulary entries
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyEntries: (sysvocabId_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [sysvocabId_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (sysvocabId, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'sysvocabId' is not null or undefined
            assertParamExists('getVocabularyEntries', 'sysvocabId', sysvocabId);
            const localVarPath = `/api/vocabularies/{sysvocab_id}`
                .replace(`{${"sysvocab_id"}}`, encodeURIComponent(String(sysvocabId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns particular vocabulary entry
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} sysvocabKey The vocabulary key.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyEntry: (sysvocabId_1, sysvocabKey_1, hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [sysvocabId_1, sysvocabKey_1, hXCSREPOSITORY_1, ...args_1], void 0, function* (sysvocabId, sysvocabKey, hXCSREPOSITORY, options = {}) {
            // verify required parameter 'sysvocabId' is not null or undefined
            assertParamExists('getVocabularyEntry', 'sysvocabId', sysvocabId);
            // verify required parameter 'sysvocabKey' is not null or undefined
            assertParamExists('getVocabularyEntry', 'sysvocabKey', sysvocabKey);
            const localVarPath = `/api/vocabularies/{sysvocab_id}/{sysvocab_key}`
                .replace(`{${"sysvocab_id"}}`, encodeURIComponent(String(sysvocabId)))
                .replace(`{${"sysvocab_key"}}`, encodeURIComponent(String(sysvocabKey)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Returns a list of all vocabularies
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyList: (hXCSREPOSITORY_1, ...args_1) => __awaiter(this, [hXCSREPOSITORY_1, ...args_1], void 0, function* (hXCSREPOSITORY, options = {}) {
            const localVarPath = `/api/vocabularies`;
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'GET' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
        /**
         *
         * @summary Updates and returns particular VocabularyEntry
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateVocabularyEntry: (sysvocabId_1, hXCSREPOSITORY_1, vocabularyEntryRequest_1, ...args_1) => __awaiter(this, [sysvocabId_1, hXCSREPOSITORY_1, vocabularyEntryRequest_1, ...args_1], void 0, function* (sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options = {}) {
            // verify required parameter 'sysvocabId' is not null or undefined
            assertParamExists('updateVocabularyEntry', 'sysvocabId', sysvocabId);
            const localVarPath = `/api/vocabularies/{sysvocab_id}`
                .replace(`{${"sysvocab_id"}}`, encodeURIComponent(String(sysvocabId)));
            // use dummy base URL string because the URL constructor only accepts absolute URLs.
            const localVarUrlObj = new URL(localVarPath, DUMMY_BASE_URL);
            let baseOptions;
            if (configuration) {
                baseOptions = configuration.baseOptions;
            }
            const localVarRequestOptions = Object.assign(Object.assign({ method: 'PUT' }, baseOptions), options);
            const localVarHeaderParameter = {};
            const localVarQueryParameter = {};
            // authentication SecurityScheme required
            // http bearer authentication required
            yield setBearerAuthToObject(localVarHeaderParameter, configuration);
            if (hXCSREPOSITORY !== undefined && hXCSREPOSITORY !== null) {
                localVarHeaderParameter['HXCS-REPOSITORY'] = String(hXCSREPOSITORY);
            }
            localVarHeaderParameter['Content-Type'] = 'application/json';
            setSearchParams(localVarUrlObj, localVarQueryParameter);
            let headersFromBaseOptions = baseOptions && baseOptions.headers ? baseOptions.headers : {};
            localVarRequestOptions.headers = Object.assign(Object.assign(Object.assign({}, localVarHeaderParameter), headersFromBaseOptions), options.headers);
            localVarRequestOptions.data = serializeDataIfNeeded(vocabularyEntryRequest, localVarRequestOptions, configuration);
            return {
                url: toPathString(localVarUrlObj),
                options: localVarRequestOptions,
            };
        }),
    };
};
/**
 * VocabularyApi - functional programming interface
 * @export
 */
const VocabularyApiFp = function (configuration) {
    const localVarAxiosParamCreator = VocabularyApiAxiosParamCreator(configuration);
    return {
        /**
         *
         * @summary Creates a vocabulary
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Vocabulary} [vocabulary]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createVocabulary(hXCSREPOSITORY, vocabulary, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.createVocabulary(hXCSREPOSITORY, vocabulary, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Creates an entry for vocabulary
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.createVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Deletes vocabulary along with its entries
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteVocabulary(sysvocabId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.deleteVocabulary(sysvocabId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Deletes entry of a vocabulary
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} sysvocabKey The vocabulary key.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.deleteVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns a list of all vocabulary entries
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyEntries(sysvocabId, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getVocabularyEntries(sysvocabId, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns particular vocabulary entry
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} sysvocabKey The vocabulary key.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Returns a list of all vocabularies
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyList(hXCSREPOSITORY, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.getVocabularyList(hXCSREPOSITORY, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
        /**
         *
         * @summary Updates and returns particular VocabularyEntry
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options) {
            return __awaiter(this, void 0, void 0, function* () {
                const localVarAxiosArgs = yield localVarAxiosParamCreator.updateVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options);
                return createRequestFunction(localVarAxiosArgs, globalAxios, BASE_PATH, configuration);
            });
        },
    };
};
/**
 * VocabularyApi - factory interface
 * @export
 */
const VocabularyApiFactory = function (configuration, basePath, axios) {
    const localVarFp = VocabularyApiFp(configuration);
    return {
        /**
         *
         * @summary Creates a vocabulary
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {Vocabulary} [vocabulary]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createVocabulary(hXCSREPOSITORY, vocabulary, options) {
            return localVarFp.createVocabulary(hXCSREPOSITORY, vocabulary, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Creates an entry for vocabulary
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        createVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options) {
            return localVarFp.createVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Deletes vocabulary along with its entries
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteVocabulary(sysvocabId, hXCSREPOSITORY, options) {
            return localVarFp.deleteVocabulary(sysvocabId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Deletes entry of a vocabulary
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} sysvocabKey The vocabulary key.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        deleteVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options) {
            return localVarFp.deleteVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns a list of all vocabulary entries
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyEntries(sysvocabId, hXCSREPOSITORY, options) {
            return localVarFp.getVocabularyEntries(sysvocabId, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns particular vocabulary entry
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} sysvocabKey The vocabulary key.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options) {
            return localVarFp.getVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Returns a list of all vocabularies
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        getVocabularyList(hXCSREPOSITORY, options) {
            return localVarFp.getVocabularyList(hXCSREPOSITORY, options).then((request) => request(axios, basePath));
        },
        /**
         *
         * @summary Updates and returns particular VocabularyEntry
         * @param {string} sysvocabId The vocabulary id.
         * @param {string} [hXCSREPOSITORY] The repository id.
         * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
         * @param {*} [options] Override http request option.
         * @throws {RequiredError}
         */
        updateVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options) {
            return localVarFp.updateVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options).then((request) => request(axios, basePath));
        },
    };
};
/**
 * VocabularyApi - object-oriented interface
 * @export
 * @class VocabularyApi
 * @extends {BaseAPI}
 */
class VocabularyApi extends BaseAPI {
    /**
     *
     * @summary Creates a vocabulary
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {Vocabulary} [vocabulary]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    createVocabulary(hXCSREPOSITORY, vocabulary, options) {
        return VocabularyApiFp(this.configuration).createVocabulary(hXCSREPOSITORY, vocabulary, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Creates an entry for vocabulary
     * @param {string} sysvocabId The vocabulary id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    createVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options) {
        return VocabularyApiFp(this.configuration).createVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Deletes vocabulary along with its entries
     * @param {string} sysvocabId The vocabulary id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    deleteVocabulary(sysvocabId, hXCSREPOSITORY, options) {
        return VocabularyApiFp(this.configuration).deleteVocabulary(sysvocabId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Deletes entry of a vocabulary
     * @param {string} sysvocabId The vocabulary id.
     * @param {string} sysvocabKey The vocabulary key.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    deleteVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options) {
        return VocabularyApiFp(this.configuration).deleteVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns a list of all vocabulary entries
     * @param {string} sysvocabId The vocabulary id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    getVocabularyEntries(sysvocabId, hXCSREPOSITORY, options) {
        return VocabularyApiFp(this.configuration).getVocabularyEntries(sysvocabId, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns particular vocabulary entry
     * @param {string} sysvocabId The vocabulary id.
     * @param {string} sysvocabKey The vocabulary key.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    getVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options) {
        return VocabularyApiFp(this.configuration).getVocabularyEntry(sysvocabId, sysvocabKey, hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Returns a list of all vocabularies
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    getVocabularyList(hXCSREPOSITORY, options) {
        return VocabularyApiFp(this.configuration).getVocabularyList(hXCSREPOSITORY, options).then((request) => request(this.axios, this.basePath));
    }
    /**
     *
     * @summary Updates and returns particular VocabularyEntry
     * @param {string} sysvocabId The vocabulary id.
     * @param {string} [hXCSREPOSITORY] The repository id.
     * @param {VocabularyEntryRequest} [vocabularyEntryRequest]
     * @param {*} [options] Override http request option.
     * @throws {RequiredError}
     * @memberof VocabularyApi
     */
    updateVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options) {
        return VocabularyApiFp(this.configuration).updateVocabularyEntry(sysvocabId, hXCSREPOSITORY, vocabularyEntryRequest, options).then((request) => request(this.axios, this.basePath));
    }
}

/* tslint:disable */
/* eslint-disable */
/**
 * hxpr-app API
 * No description provided (generated by Openapi Generator https://github.com/openapitools/openapi-generator)
 *
 * The version of the OpenAPI document: 2.0.231
 *
 *
 * NOTE: This class is auto generated by OpenAPI Generator (https://openapi-generator.tech).
 * https://openapi-generator.tech
 * Do not edit the class manually.
 */
class Configuration {
    constructor(param = {}) {
        this.apiKey = param.apiKey;
        this.username = param.username;
        this.password = param.password;
        this.accessToken = param.accessToken;
        this.basePath = param.basePath;
        this.baseOptions = param.baseOptions;
        this.formDataCtor = param.formDataCtor;
    }
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime) {
        const jsonMime = new RegExp('^(application\/json|[^;/ \t]+\/[^;/ \t]+[+]json)[ \t]*(;.*)?$', 'i');
        return mime !== null && (jsonMime.test(mime) || mime.toLowerCase() === 'application/json-patch+json');
    }
}

/* tslint:disable */

export { CheckInApi, CheckInApiAxiosParamCreator, CheckInApiFactory, CheckInApiFp, Configuration, CopyApi, CopyApiAxiosParamCreator, CopyApiFactory, CopyApiFp, DocumentApi, DocumentApiAxiosParamCreator, DocumentApiFactory, DocumentApiFp, DocumentPermissionsApi, DocumentPermissionsApiAxiosParamCreator, DocumentPermissionsApiFactory, DocumentPermissionsApiFp, DownloadApi, DownloadApiAxiosParamCreator, DownloadApiFactory, DownloadApiFp, FeatureFlagsApi, FeatureFlagsApiAxiosParamCreator, FeatureFlagsApiFactory, FeatureFlagsApiFp, GreetingApi, GreetingApiAxiosParamCreator, GreetingApiFactory, GreetingApiFp, GroupApi, GroupApiAxiosParamCreator, GroupApiFactory, GroupApiFp, ModelApi, ModelApiAxiosParamCreator, ModelApiFactory, ModelApiFp, MoveApi, MoveApiAxiosParamCreator, MoveApiFactory, MoveApiFp, QueryApi, QueryApiAxiosParamCreator, QueryApiFactory, QueryApiFp, RenditionConfigurationsApi, RenditionConfigurationsApiAxiosParamCreator, RenditionConfigurationsApiFactory, RenditionConfigurationsApiFp, RenditionsApi, RenditionsApiAxiosParamCreator, RenditionsApiFactory, RenditionsApiFp, SecurityApi, SecurityApiAxiosParamCreator, SecurityApiFactory, SecurityApiFp, Status, UploadApi, UploadApiAxiosParamCreator, UploadApiFactory, UploadApiFp, UserApi, UserApiAxiosParamCreator, UserApiFactory, UserApiFp, VersionApi, VersionApiAxiosParamCreator, VersionApiFactory, VersionApiFp, VocabularyApi, VocabularyApiAxiosParamCreator, VocabularyApiFactory, VocabularyApiFp };
//# sourceMappingURL=index.js.map
