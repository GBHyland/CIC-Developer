import globalAxios from 'axios';

/* tslint:disable */
const BASE_PATH = "http://localhost:8080".replace(/\/+$/, "");
/**
 *
 * @export
 */
const COLLECTION_FORMATS = {
    csv: ",",
    ssv: " ",
    tsv: "\t",
    pipes: "|"
};
/**
 *
 * @export
 * @class BaseAPI
 */
class BaseAPI {
    constructor(configuration, basePath = BASE_PATH, axios = globalAxios) {
        this.basePath = basePath;
        this.axios = axios;
        if (configuration) {
            this.configuration = configuration;
            this.basePath = configuration.basePath || this.basePath;
        }
        // Interceptor added as we do not want encoded '/' characters
        axios.interceptors.request.use((req) => {
            if (req.url) {
                req.url = req.url.replace(/%2F/g, "/");
            }
            return req;
        });
    }
}
;
/**
 *
 * @export
 * @class RequiredError
 * @extends {Error}
 */
class RequiredError extends Error {
    constructor(field, msg) {
        super(msg);
        this.field = field;
        this.name = "RequiredError";
    }
}

export { BASE_PATH, BaseAPI, COLLECTION_FORMATS, RequiredError };
//# sourceMappingURL=base.js.map
