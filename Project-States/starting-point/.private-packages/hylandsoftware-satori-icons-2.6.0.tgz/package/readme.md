# Satori Icons

Sourced from https://www.figma.com/design/iojZRiN8Moza48zAH7LoTs/Satori-Design-Library?node-id=63480-8228

## Usage

First, install:

```sh
npm install @hylandsoftware/satori-icons
```

Then:

```ts
import { inject } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

import { SATORI_ICONS } from '@hylandsoftware/satori-icons';

inject(MatIconRegistry).addSvgIconSetLiteral(
  inject(DomSanitizer).bypassSecurityTrustHtml(SATORI_ICONS)
);
```

Then:

```html
<mat-icon svgIcon="add_folder_24px"></mat-icon>
<!-- When using 16x16 icons, set <mat-icon> to an appropriate size: -->
<mat-icon svgIcon="add_folder_16px" style="width: 16px; height: 16px"></mat-icon>
```

## Maintainers

### Update icons from figma

To update from source, run https://github.com/HylandSoftware/satori-icons/actions/workflows/update.yml

### Release

Run [github bump workflow](https://github.com/HylandSoftware/satori-icons/actions/workflows/bump.yml).
It will create a PR with the version change.
Review and merge this PR.
When merged, the version will be automatically tagged, published and a Github release will be created.
